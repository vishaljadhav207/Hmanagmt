package com.travel_platform.travel_platform.entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IntermediateStop {

    @NotEmpty(message = "stopName must not be empty")
    private String stopName;

    @NotEmpty(message = "arrivalTime must not be empty")
    private LocalDateTime arrivalTime;
    private int distanceFromPrevious ;
    @NotEmpty(message = "departureTime must not be empty")
    private LocalDateTime departureTime;
    private Integer sequence; // optional - for ordered stops
}
