package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Train;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.domain.Pageable;
import java.util.List;

public interface TrainRepository extends JpaRepository<Train, Integer>
{
    Page<Train> findByOrganization_OrgId(int orgId, Pageable pageable);
    List<Train> findByDepartFromAndDestination(String departFrom, String destination);
    List<Train> findByUserId(Long userId);

    List<Train> findByTrainNo(int trainNo);
    List<Train> findByTrainNameContainingIgnoreCase(String trainName);
    List<Train> findByRailwayZoneContainingIgnoreCase(String railwayZone);


    List<Train> findByTrainNoOrTrainNameContainingIgnoreCaseOrRailwayZoneContainingIgnoreCaseOrDepartFromContainingIgnoreCaseOrDestinationContainingIgnoreCase(
            int trainNo, String trainName, String railwayZone, String departFrom, String destination);
}