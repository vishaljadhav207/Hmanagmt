package com.travel_platform.travel_platform.entity;

public class SeatDTO {
    private String seatNumber;
}
