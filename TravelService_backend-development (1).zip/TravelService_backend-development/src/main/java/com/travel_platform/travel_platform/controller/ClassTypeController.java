package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.dto.ApiResponse;
import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.TransportType;

import com.travel_platform.travel_platform.service.ClassTypeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ClassTypeController {

    @Autowired
    private ClassTypeService service;

    @PostMapping("/saveClassType")
    public ResponseEntity<ClassType> create(@Valid @RequestBody ClassType classType) {
        return ResponseEntity.ok(service.createClassType(classType));
    }

    @PutMapping("/updateClassType/{id}")
    public ResponseEntity<ClassType> update(@PathVariable int id, @RequestBody ClassType classType) {
        ClassType updated = service.updateClassType(id, classType);
        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/deleteClassType/{id}")
    public ResponseEntity<String> delete(@PathVariable int id) {
        return service.deleteClassType(id) ?
                ResponseEntity.ok("Deleted") :
                ResponseEntity.notFound().build();
    }

    @GetMapping("/getClassTypeById/{id}")
    public ResponseEntity<ClassType> getById(@PathVariable int id) {
        ClassType classType = service.getClassTypeById(id);
        return classType != null ? ResponseEntity.ok(classType) : ResponseEntity.notFound().build();
    }

    @GetMapping("/getAllClassType")
    public List<ClassType> getAll(
            @RequestParam(value = "PageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "PageSize", defaultValue = "10", required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = "className", required = false) String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "asc", required = false) String sortDir
    ) {
        return service.getAllClassTypes(pageNumber, pageSize, sortBy, sortDir);
    }

    @GetMapping("/getClassNameById/{id}")
    public ApiResponse<String> getClassNameById(@PathVariable int id) {
        try {
            String className = service.getClassNameById(id);
            return new ApiResponse<>(HttpStatus.OK, "Class Name found", className);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Class not found", null);
        }
    }

    @GetMapping("/getClassTypesByTransportType")
    public ResponseEntity<List<ClassType>> getByTransportType(@RequestParam TransportType type) {
        return ResponseEntity.ok(service.getClassTypesByTransportType(type));
    }
}
