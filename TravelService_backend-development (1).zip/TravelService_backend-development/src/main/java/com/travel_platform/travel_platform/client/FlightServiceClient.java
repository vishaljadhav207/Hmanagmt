package com.travel_platform.travel_platform.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class FlightServiceClient {
   @Autowired
    private RestTemplate restTemplate;

   private String FLIGHT_SERVICE_SEATS = "http://localhost:8082";

   public List<String> getAvailableSeats(String seatPreference , String Type , int transportId , int passengers, String token){
       String url = FLIGHT_SERVICE_SEATS+"/api/flight-seats/flightSeats"+"?seatPreference="+seatPreference+"&Type="+
               Type+"&transportId="+transportId+"&passengers="+passengers;
       try{
           HttpHeaders headers = new HttpHeaders();
           headers.add(HttpHeaders.AUTHORIZATION,token);
           HttpEntity<String> entity = new HttpEntity<>(headers);
           String response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();

           ObjectMapper mapper = new ObjectMapper();
           mapper.registerModule(new JavaTimeModule());
           mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);

           List<String> empty = new ArrayList<>();
           if(response == null ){
               empty.add("");
               return empty;
           }
           JsonNode root = mapper.readTree(response);
           List<String> seatNumbers = new ArrayList<>();

           if (root.isArray()) {
               for (JsonNode seatNode : root) {
                   JsonNode seatNumberNode = seatNode.path("seatNumber");
                   if (!seatNumberNode.isMissingNode()) {
                       seatNumbers.add("CNF "+seatNumberNode.asText());
                   }
               }
           }

           return seatNumbers;
       }catch ( Exception e){
           throw new RuntimeException("Error while Fetching Available Seats ! ");
       }
   }
}
