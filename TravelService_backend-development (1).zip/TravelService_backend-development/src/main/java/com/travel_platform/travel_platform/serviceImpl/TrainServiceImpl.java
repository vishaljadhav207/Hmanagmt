package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.client.UserServiceClient;
import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import com.travel_platform.travel_platform.entity.Train;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.repository.OrganizationRepository;
import com.travel_platform.travel_platform.repository.TrainRepository;
import com.travel_platform.travel_platform.service.TrainService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.travel_platform.travel_platform.repository.TrainRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class TrainServiceImpl implements TrainService {

    @Autowired
    private TrainRepository trainRepo;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserServiceClient userServiceClient;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    public Train saveTrain(Train train , String token) {
        if (train.getUserId() != null && userServiceClient.getUserById(train.getUserId(),token) == null) {
            throw new IllegalArgumentException("Invalid or unreachable userId: " + train.getUserId());
        }
        List<ClassType> classTypes = train.getClassTypes().stream()
                .map(c -> classTypeRepository.findById(Math.toIntExact(c.getClassId()))
                        .orElseThrow(() -> new RuntimeException("ClassType not found: " + c.getClassId())))
                .toList();
        train.setClassTypes(classTypes);





        Long orgId = train.getOrganization().getOrgId();

        Organization organization = organizationRepository.findById(orgId)
                .orElseThrow(() -> new RuntimeException("Organization not found with ID: " + orgId));

        if (organization.getType() != OrganizationType.RAILWAY) {
            throw new IllegalArgumentException("Only RAILWAY organizations can have trains.");
        }
        train.setOrganization(organization);

        return trainRepo.save(train);
    }

    @Override
    public List<Train> getAllTrains(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable= PageRequest.of(pageNumber, pageSize, sort);
        Page<Train> pagetrain=trainRepo.findAll(pageable);
        List<Train> allTrains=pagetrain.getContent();
        return allTrains;
    }

    @Override
    public void deleteTrainById(int id) {

        trainRepo.deleteById(id);
    }

    @Override
    public Train getTrainById(int id) {
        return trainRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Train with ID " + id + " not found"));
    }

    @Override
    public Train updateTrain(int id, Train updatedTrain,String token) {
        Train existingTrain = trainRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Train with ID " + id + " not found"));

        if (updatedTrain.getUserId() != null && userServiceClient.getUserById(updatedTrain.getUserId(),token) == null) {
            throw new IllegalArgumentException("Invalid userId: " + updatedTrain.getUserId());
        }

        existingTrain.setTrainNo(updatedTrain.getTrainNo());
        existingTrain.setTrainName(updatedTrain.getTrainName());
        existingTrain.setRailwayZone(updatedTrain.getRailwayZone());
        existingTrain.setNumberOfCoaches(updatedTrain.getNumberOfCoaches());
        existingTrain.setDestination(updatedTrain.getDestination());
        existingTrain.setDepartFrom(updatedTrain.getDepartFrom());
        existingTrain.setUserId(updatedTrain.getUserId());

        return trainRepo.save(existingTrain);
    }

    @Override
    public List<Train> getTrainByOrgId(int orgId, int pageNumber, int pageSize , String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<Train> pageTrain = (Page<Train>) trainRepo.findByOrganization_OrgId(orgId, pageable);
        return pageTrain.getContent();
    }

    @Override
    public List<Train> getTrainsByDepartFromAndDestination(String departFrom, String destination) {
        return trainRepo.findByDepartFromAndDestination(departFrom, destination);
    }

    @Override
    public List<Train> getTrainByUserId(Long id) {
        return trainRepo.findByUserId(id);
    }

    @Override
    public List<Train> searchByTrainNo(int trainNo) {
        return trainRepo.findByTrainNo(trainNo);
    }

    @Override
    public List<Train> searchByTrainName(String trainName) {
        if (trainName == null || trainName.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return trainRepo.findByTrainNameContainingIgnoreCase(trainName);
    }

    @Override
    public List<Train> searchByRailwayZone(String railwayZone) {
        if (railwayZone == null || railwayZone.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return trainRepo.findByRailwayZoneContainingIgnoreCase(railwayZone);
    }

    @Override
    public List<Train> comprehensiveTrainSearch(Integer trainNo, String trainName, String railwayZone, String departFrom, String destination) {

        int searchTrainNo = (trainNo != null) ? trainNo : 0;

        return trainRepo.findByTrainNoOrTrainNameContainingIgnoreCaseOrRailwayZoneContainingIgnoreCaseOrDepartFromContainingIgnoreCaseOrDestinationContainingIgnoreCase(
                searchTrainNo,
                trainName != null ? trainName : "",
                railwayZone != null ? railwayZone : "",
                departFrom != null ? departFrom : "",
                destination != null ? destination : "");
    }

    @Override
    public String getTrainNoByTrainId(int trainId) {
        return trainRepo.findById(trainId)
                .map(train -> String.valueOf(train.getTrainNo()))
                .orElseThrow(() -> new RuntimeException("Train not found with ID: " + trainId));
    }
}
