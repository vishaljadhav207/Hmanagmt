package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.config.UserIdentityDetailsService;
import com.travel_platform.travel_platform.entity.PnrGenerator;
import com.travel_platform.travel_platform.repository.PnrRepository;
import com.travel_platform.travel_platform.service.PnrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.UUID;

import static com.travel_platform.travel_platform.config.UserIdentityDetailsService.getUserId;

@Service
public class PnrGeneratorImpl implements PnrService {

    @Autowired
    private PnrRepository pnrRepository;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    @Override
    public String generatePnr(String transportType , int transportId) {
        PnrGenerator pnr = new PnrGenerator();
        String prefix = switch (transportType.toLowerCase()) {
            case "bus_operator" -> "BS";
            case "airline" -> "AL";
            case "railway" -> "RL";
            default -> "GN";
        };
        try {
            String timeStamp = DateTimeFormatter.ofPattern("yyMMddHHmm").format(LocalDateTime.now());
            String generate = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
            String p = prefix + timeStamp + generate;
            pnr.setTransportType(transportType);
            pnr.setGeneratedDate(LocalDate.now());
            pnr.setPnr(p);
            long userId = getUserId();
            pnr.setUserId(userId);
            pnr.setTransportId(transportId);
            pnrRepository.save(pnr);
            return p;
        }catch (Exception e){
            throw new RuntimeException("Pnr Not generated !!");
        }
    }
}
