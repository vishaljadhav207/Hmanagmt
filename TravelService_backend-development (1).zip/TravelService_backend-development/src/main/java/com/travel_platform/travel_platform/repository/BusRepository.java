package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Bus;
import com.travel_platform.travel_platform.entity.Organization;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BusRepository extends JpaRepository<Bus, Integer> {
    List<Bus> findByDepartFromAndDestination(String departFrom,String destination);
    List<Bus> findByOrganization(Organization organization);


    Page<Bus> findByOrganization_OrgId(int orgId, Pageable pageable);
    List<Bus> findByBusNoContainingIgnoreCase(String busNo);

    // New comprehensive search method
    List<Bus> findByBusNoContainingIgnoreCaseOrBusTypeContainingIgnoreCaseOrOperatorNameContainingIgnoreCaseOrDepartFromContainingIgnoreCaseOrDestinationContainingIgnoreCase(
            String busNo, String busType, String operatorName, String departFrom, String destination);
    List<Bus> findByUserId(Long id);
}
