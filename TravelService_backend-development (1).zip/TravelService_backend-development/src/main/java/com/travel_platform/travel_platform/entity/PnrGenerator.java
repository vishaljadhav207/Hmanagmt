package com.travel_platform.travel_platform.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class PnrGenerator {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id ;
    private long userId;
    private int transportId ;
    private String transportType;
    private LocalDate generatedDate;
    private String pnr ;
}
