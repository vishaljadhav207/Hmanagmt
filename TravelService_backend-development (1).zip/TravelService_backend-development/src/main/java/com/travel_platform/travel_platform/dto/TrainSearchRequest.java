package com.travel_platform.travel_platform.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class TrainSearchRequest {
    private String origin;
    private String destination;
    private LocalDate departureDate;
    private String className;
}