package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.dto.OrganizationResponseDTO;
import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import java.util.List;

public interface OrganizationService {
    Organization createOrganization(Organization organization,String token);
    Organization getOrganizationById(Long orgId);
    List<Organization> getAllOrganizations(int pageNumber, int pageSize, String sortBy, String sortDir);
    List<Organization> getOrganizationsByType(OrganizationType type);
    Organization updateOrganization(Long orgId, Organization organization);
    void deleteOrganization(Long orgId);
    boolean organizationExists(String orgName);

    // New
    OrganizationResponseDTO getOrganizationWithUser(Long orgId , String token);
}
