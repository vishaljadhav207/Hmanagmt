package com.travel_platform.travel_platform.config;
import com.travel_platform.travel_platform.dto.UserIdentityDetails;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

@Service
public class UserIdentityDetailsService {
    public static long getUserId(){
        Object principle = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(principle instanceof UserIdentityDetails){
           UserIdentityDetails userIdentityDetails = (UserIdentityDetails) principle;
           return userIdentityDetails.getUserId();
        }
        throw new RuntimeException("User Id not Found !! ");
    }

    public String getToken(@RequestHeader("Authorization") String authorizationHeader) {
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            return authorizationHeader.substring(7); // Remove "Bearer " prefix and return the token
        } else {
            throw new RuntimeException("Token not found in Authorization header.");
        }
    }
}
