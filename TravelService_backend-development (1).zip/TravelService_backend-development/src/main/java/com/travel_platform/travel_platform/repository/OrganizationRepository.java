package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization, Long> {

    // Custom query methods
    List<Organization> findByType(OrganizationType type);

    List<Organization> findByOrgNameContainingIgnoreCase(String name);

    boolean existsByOrgName(String orgName);
}