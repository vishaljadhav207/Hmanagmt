package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TrainTripRepository extends JpaRepository<TrainTrip,Integer> {

    List<TrainTrip> findByTrain_UserId(Long userId);




    @Query("SELECT f FROM TrainTrip f WHERE f.train.id = :trainId")
    TrainTrip findByTrainId(@Param("trainId") int trainID);

    List<TrainTrip> findByOriginAndDestinationAndDepartureDate(
            String origin,
            String destination,
            LocalDate departureDate);
}
