package com.travel_platform.travel_platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "organization")
@Data
public class Organization {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orgId;

    @NotEmpty(message = "type must not be empty")
    @Enumerated(EnumType.STRING)
    private OrganizationType type;

    @NotEmpty(message = "orgName must not be empty")
    private String orgName;

    // Reference to userId from another service
    private Long userId;
}
