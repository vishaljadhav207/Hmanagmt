package com.travel_platform.travel_platform.entity;

public enum OrganizationType {
    RAILWAY, BUS_OPERATOR, AIRLINE,
}
