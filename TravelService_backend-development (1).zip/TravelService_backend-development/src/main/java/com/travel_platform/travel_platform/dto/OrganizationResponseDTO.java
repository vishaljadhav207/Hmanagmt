package com.travel_platform.travel_platform.dto;



import com.travel_platform.travel_platform.entity.OrganizationType;
import lombok.Data;

@Data
public class OrganizationResponseDTO {
    private Long orgId;
    private String orgName;
    private OrganizationType type;
    private UserDTO user; // Full user info
}
