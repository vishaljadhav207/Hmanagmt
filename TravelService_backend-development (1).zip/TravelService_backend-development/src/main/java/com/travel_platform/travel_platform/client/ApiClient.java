package com.travel_platform.travel_platform.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ApiClient {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<String> doGet(String url) {
        return restTemplate.getForEntity(url, String.class);
    }

}
