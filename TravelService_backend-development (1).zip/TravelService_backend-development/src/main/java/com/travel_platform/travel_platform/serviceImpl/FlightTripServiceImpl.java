package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.entity.Flight;
import com.travel_platform.travel_platform.entity.FlightTrip;
import com.travel_platform.travel_platform.exception.ResourceNotFoundException;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.repository.FlightTripRepository;
import com.travel_platform.travel_platform.service.FlightService;
import com.travel_platform.travel_platform.service.FlightTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.List;

@Service
public  class FlightTripServiceImpl implements FlightTripService {

    @Autowired
    private FlightTripRepository flightTripRepository;

    @Autowired
    private FlightService flightService;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    @Override
    public ResponseEntity<FlightTrip> createFlightTrip(FlightTrip flightTrip) {
        if (flightTrip.getFlight() == null || flightTrip.getFlight().getFlight_id() == 0) {
            throw new IllegalArgumentException("Flight ID is missing or invalid");
        }

        // Fetch managed flight entity
        Flight managedFlight = flightService.getFlightById(flightTrip.getFlight().getFlight_id());
        flightTrip.setFlight(managedFlight);

        // Save and return the managed trip
        FlightTrip savedTrip = flightTripRepository.save(flightTrip);
        return ResponseEntity.ok(savedTrip);
    }


    @Override
    public FlightTrip getFlightTripById(int id) {
        return flightTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("FlightTrip not found with id: " + id));
    }

    @Override
    public List<FlightTrip> getAllFlightTrips(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize,sort);
        Page<FlightTrip> pageflighttrip=flightTripRepository.findAll(pageable);
        return pageflighttrip.getContent();
    }

    @Override
    public void deleteFlightTrip(int id) {
        FlightTrip trip = getFlightTripById(id);
        flightTripRepository.delete(trip);
    }

    @Override
    public FlightTrip updateFlightTripById(int id, FlightTrip flightTrip) {
        FlightTrip existingTrip = flightTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("FlightTrip not found with id: " + id));

        existingTrip.setOrigin(flightTrip.getOrigin());
        existingTrip.setDestination(flightTrip.getDestination());
        existingTrip.setDepartureDate(flightTrip.getDepartureDate());
        existingTrip.setArrivalDate(flightTrip.getArrivalDate());
        existingTrip.setFlight(flightTrip.getFlight());
        existingTrip.setIntermediateStops(flightTrip.getIntermediateStops());

        return flightTripRepository.save(existingTrip);
    }

    @Override
    public List<FlightTrip> getFlightTripsByUserId(Long id) {
        return flightTripRepository.findByFlight_UserId(id);
    }



    @Override
    public List<FlightTrip> searchFlightTrips(String origin, String destination, LocalDate departureDate)
    {
        return flightTripRepository.findByOriginAndDestinationAndDepartureDate(origin,destination,departureDate);
    }
}
