package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.dto.ApiResponse;
import com.travel_platform.travel_platform.entity.Flight;
import com.travel_platform.travel_platform.entity.Train;
import com.travel_platform.travel_platform.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/flight")
@CrossOrigin(origins = "*")
public class FlightController {

    @Autowired
    private FlightService flightService;

    @PostMapping("/saveFlight")
    public ApiResponse<Flight> saveflight(@RequestBody Flight flight, @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        try {
            Flight flight1 = flightService.saveFlight(flight, token);
            return new ApiResponse<>(HttpStatus.OK, "Flight saved successfully", flight1);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save flight", null);
        }
    }

    @GetMapping("/getFlightById/{id}")
    public ApiResponse<Flight> getFlightById(@PathVariable int id) {
        try{
            Flight flight = flightService.getFlightById(id);
            return new ApiResponse<>(HttpStatus.OK, "Flight retrieved successfully", flight);
        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve flight", null);
        }
    }

    @GetMapping("/getAllFlight")
    public ApiResponse<List<Flight>> getAllFlight(
            @RequestParam(value = "pageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "pageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "airline",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortdir
    ) {
        try{
            List<Flight> flightList=flightService.getAllFlights(pageNumber, pageSize, sortBy, sortdir);
            return new ApiResponse<>(HttpStatus.OK, "Flight retrieved successfully", flightList);
        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve flight", null);
        }
    }

    @DeleteMapping("/deleteFlightById/{id}")
    public ApiResponse<Flight> deleteFlightById(@PathVariable int id) {
        try{
            flightService.deleteFlightById(id);
            return new ApiResponse<>(HttpStatus.OK, "Flight deleted successfully", null);
        }
        catch (Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to delete flight", null);
        }
    }

    @PutMapping("/updateFlight/{id}")
    public ApiResponse<Flight> updateFlight(@PathVariable int id, @RequestBody Flight updatedFlight , String token) {
        try{
            Flight flight1 = flightService.updateFlight(id, updatedFlight,token);
            return new ApiResponse<>(HttpStatus.OK, "Flight updated successfully", flight1);
        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update flight", null);
        }
    }

    @GetMapping("/getFlightByOrgId/{id}")
    public ApiResponse<List<Flight>> getFlightByOrgId(
            @PathVariable int id,
            @RequestParam(value = "Pagenumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "PageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "airline",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortdir) {
        try {
            List<Flight> flightList = flightService.getFlightByOrgId(id,pageNumber, pageSize, sortBy, sortdir);

            if (flightList.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NOT_FOUND, "No flights found for the given organization ID", null);
            } else {
                return new ApiResponse<>(HttpStatus.OK, "Flights retrieved successfully", flightList);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve flights", null);
        }
    }

    @GetMapping("/by-route/{departFrom}/{destination}")
    public ApiResponse<List<Flight>> getFlightsByRoute(@PathVariable String departFrom, @PathVariable String destination) {
        try {
            List<Flight> flights = flightService.searchFlights(departFrom, destination);
            return new ApiResponse<>(HttpStatus.OK, "Flight retrieved successfully", flights);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve flights", null);

        }
    }

    @GetMapping("/flightNoById/{id}")
    public ApiResponse<String> getFlightNoById(@PathVariable int id ){
        try{
          String flightNo = flightService.getFlightNoById(id);
          return new ApiResponse<>(HttpStatus.OK,"Flight Number Found !! ",flightNo);
        }catch (Exception e){
            throw new RuntimeException("Flight Number Not Found !");
        }
    }

    @GetMapping("/getFlightByUserId/{id}")
    public ApiResponse<List<Flight>> getFlightByUserId(@PathVariable Long id) {
        try{
            List<Flight> flight = flightService.getFlightByUserId(id);
            return new ApiResponse<>(HttpStatus.OK, "Flight retrieved successfully", flight);
        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to retrieve flight", null);
        }
    }
}
