package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.entity.Passenger;

import java.util.List;
import java.util.Optional;

public interface PassengerService {

    Passenger savePassenger(Passenger passenger);
    List<Passenger> getAllPassenger(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deletePassengerById(int id);
    Optional<Passenger> getPassengerById(int id);
    Passenger updatePassengerById(int id,Passenger passenger);
}
