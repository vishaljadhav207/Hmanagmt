package com.travel_platform.travel_platform.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BusServiceClient {
    @Autowired
    private RestTemplate restTemplate;


    private final String BUS_SEAT_SERVICE = "http://localhost:8082";

    public List<String> getAvailableSeats(String seatPreference, String Type, String transportId, int passengers, String token) {
        String url = BUS_SEAT_SERVICE + "/api/bus-seats/BusSeat" + "?seatPreference=" + seatPreference + "&Type=" +
                Type + "&transportId=" + transportId + "&passengers=" + passengers;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION, token);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            String response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();

            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
            JsonNode root = mapper.readTree(response);
            List<String> seatNumbers = new ArrayList<>();

            if (root.isArray()) {
                for (JsonNode seatNode : root) {
                    JsonNode seatNumberNode = seatNode.path("seatNumber");
                    if (!seatNumberNode.isMissingNode()) {
                        seatNumbers.add(seatNumberNode.asText());
                    }
                }
            }

            return seatNumbers;

        } catch (Exception e) {
            throw new RuntimeException("Error getting the seats !! ");
        }
    }

    public Map<String, Boolean> updateMultipleSeats(
            int busId,
            int classId,
            List<String> seatNumbers,
            boolean isAvailable,
            String token) {

        String url = BUS_SEAT_SERVICE + "/api/bus-seats/update-specific-seats";

        try {
            // Prepare JSON body as SeatUpdateRequest
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("busId", busId);
            requestBody.put("classId", classId);
            requestBody.put("seatNumbers", seatNumbers);
            requestBody.put("available", isAvailable);

            HttpHeaders headers = new HttpHeaders();
            if (!token.startsWith("Bearer ")) {
                token = "Bearer " + token;
            }
            headers.set("Authorization", token);
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                    url,
                    HttpMethod.PUT, // Make sure server supports PATCH
                    entity,
                    Map.class
            );

            return response.getBody();

        } catch (Exception e) {
            System.err.println("Error updating seats: " + e.getMessage());
            throw new RuntimeException("Error updating seats: " + e.getMessage());
        }
    }

}
