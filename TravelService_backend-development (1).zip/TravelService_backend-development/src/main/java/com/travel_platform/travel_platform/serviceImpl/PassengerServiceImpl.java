package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.entity.Passenger;
import com.travel_platform.travel_platform.entity.Train;
import com.travel_platform.travel_platform.repository.PassengerRepository;
import com.travel_platform.travel_platform.service.PassengerService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerServiceImpl implements PassengerService {

    @Autowired
    private PassengerRepository passengerRepository;

    @Override
    public Passenger savePassenger(Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    @Override
    public List<Passenger> getAllPassenger(int pageNumber, int pageSize, String sortBy, String sortDir)
    {
        Sort sort = null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<Passenger> passengers = passengerRepository.findAll(pageable);
        return passengers.getContent();
    }

    @Override
    public void deletePassengerById(int id) {
        passengerRepository.deleteById(id);
    }

    @Override
    public Optional<Passenger> getPassengerById(int id) {
        return passengerRepository.findById(id);
    }


    @Override
    public Passenger updatePassengerById(int id, Passenger updatedPassenger) {
        return passengerRepository.findById(id)
                .map(existingPassenger -> {
                    existingPassenger.setName(updatedPassenger.getName());
                    existingPassenger.setAge(updatedPassenger.getAge());
                    existingPassenger.setGender(updatedPassenger.getGender());
                    existingPassenger.setSeatNumber(updatedPassenger.getSeatNumber());
                    return passengerRepository.save(existingPassenger);
                })
                .orElseThrow(() -> new EntityNotFoundException("Passenger with ID " + id + " not found"));
    }
}
