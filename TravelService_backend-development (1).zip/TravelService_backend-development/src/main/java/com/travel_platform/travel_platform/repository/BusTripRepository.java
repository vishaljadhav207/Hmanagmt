package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BusTripRepository extends JpaRepository<BusTrip, Integer> {
    @Query("SELECT b FROM BusTrip b WHERE b.bus.busId = :busId")
    BusTrip findByBusId(@Param("busId") int busId);

    List<BusTrip> findByBus_UserId(Long userId);



    List<BusTrip> findByBus_BusId(int busId);

    List<BusTrip> findByOriginAndDestinationAndDepartureDate(
            String origin,
            String destination,
            LocalDate departureDate);

    Page<BusTrip> findByBus_UserId(Long userId, Pageable pageable);
}
