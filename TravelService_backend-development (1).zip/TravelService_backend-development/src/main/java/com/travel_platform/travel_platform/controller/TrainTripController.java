package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.FlightTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import com.travel_platform.travel_platform.service.TrainTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/trainTrips")
public class TrainTripController {

    @Autowired
    private TrainTripService trainTripService;

    @PostMapping("/createTrainTrip")
    public ResponseEntity<TrainTrip> createTrainTrip(@RequestBody TrainTrip trainTrip) {
        return trainTripService.createTrainTrip(trainTrip);
    }

    @GetMapping("/getTrainTripById/{id}")
    public ResponseEntity<TrainTrip> getTrainTripById(@PathVariable int id) {
        TrainTrip trip = trainTripService.getTrainTripById(id);
        return ResponseEntity.ok(trip);
    }

    @GetMapping("/getAllTrainTrips")
    public ResponseEntity<List<TrainTrip>> getAllTrainTrips(
            @RequestParam(value = "pageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "pageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "origin",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        List<TrainTrip> trips = trainTripService.getAllTrainTrip(pageNumber, pageSize, sortBy, sortDir);
        return ResponseEntity.ok(trips);
    }

    @DeleteMapping("/deleteTrainTrip/{id}")
    public ResponseEntity<Void> deleteTrainTrip(@PathVariable int id) {
        trainTripService.deleteTrainTrip(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/updateTrainTripById/{id}")
    public ResponseEntity<TrainTrip> updateTrainTripById(@PathVariable int id, @RequestBody TrainTrip trainTrip) {
        TrainTrip updatedTrip = trainTripService.updateTrainTripById(id, trainTrip);
        return ResponseEntity.ok(updatedTrip);
    }

    @GetMapping("/getTrainTripByUserId/{id}")
    public ResponseEntity<List<TrainTrip>> getTrainTripByUserId(@PathVariable Long id) {
        try {
            List<TrainTrip> trips = trainTripService.getTrainTripByUserId(id);
            if (trips.isEmpty()) {
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(trips);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }



//    @GetMapping("/search")
//    public List<TrainTrip> searchBusTrips(
//            @RequestParam(required = false) String origin,
//            @RequestParam(required = false) String destination,
//            @RequestParam(required = false)
//            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate) {
//
//        return trainTripService.searchTrainTrips(origin, destination, departureDate);
//    }

    @GetMapping("/search")
    public List<TrainTrip> searchBusTrips(
            @RequestParam(required = false) String origin,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate) {

        return trainTripService.searchTrainTrips(origin, destination, departureDate);
    }

}
