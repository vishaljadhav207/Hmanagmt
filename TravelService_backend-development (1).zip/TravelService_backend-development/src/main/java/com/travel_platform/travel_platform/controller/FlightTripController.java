package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.dto.FlightSearchRequest;
import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.FlightTrip;
import com.travel_platform.travel_platform.service.FlightTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/flightTrips")
@CrossOrigin(origins = "*")
public class FlightTripController {

    @Autowired
    private FlightTripService flightTripService;

    @PostMapping("/createFlightTrip")
    public ResponseEntity<FlightTrip> createFlightTrip(@RequestBody FlightTrip flightTrip) {
        return flightTripService.createFlightTrip(flightTrip);
    }

    @GetMapping("/getFlightTripById/{id}")
    public ResponseEntity<FlightTrip> getFlightTripById(@PathVariable int id) {
        FlightTrip trip = flightTripService.getFlightTripById(id);
        return ResponseEntity.ok(trip);
    }

    @GetMapping("/getAllFlightTrips")
    public ResponseEntity<List<FlightTrip>> getAllFlightTrips(
            @RequestParam(value = "PageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "PageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "origin",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        List<FlightTrip> trips = flightTripService.getAllFlightTrips(pageNumber, pageSize, sortBy, sortDir);
        return ResponseEntity.ok(trips);
    }

    @DeleteMapping("/deleteFlightTrip/{id}")
    public ResponseEntity<Void> deleteFlightTrip(@PathVariable int id) {
        flightTripService.deleteFlightTrip(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/updateFlightTripById/{id}")
    public ResponseEntity<FlightTrip> updateFlightTripById(@PathVariable int id, @RequestBody FlightTrip flightTrip) {
        FlightTrip updatedTrip = flightTripService.updateFlightTripById(id, flightTrip);
        return ResponseEntity.ok(updatedTrip);
    }

    @GetMapping("/getFlightTripByUserId/{id}")
    public ResponseEntity<List<FlightTrip>> getFlightTripByUserId(@PathVariable Long id) {
        try{
            List<FlightTrip> flightTrips = flightTripService.getFlightTripsByUserId(id);
            return ResponseEntity.ok(flightTrips);
        }
        catch(Exception e){
            return ResponseEntity.noContent().build();
        }
    }



    @GetMapping("/search")
    public List<FlightTrip> searchBusTrips(
            @RequestParam(required = false) String origin,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate) {

        return flightTripService.searchFlightTrips(origin, destination, departureDate);
    }
}
