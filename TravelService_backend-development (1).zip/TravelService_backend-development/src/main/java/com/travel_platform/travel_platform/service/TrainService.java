package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.entity.Train;

import java.util.List;

public interface TrainService {

    Train saveTrain(Train train,String token);
    List<Train> getAllTrains(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deleteTrainById(int id);
    Train getTrainById(int id);
    Train updateTrain(int id, Train train,String token);

    String getTrainNoByTrainId(int id);

    List<Train> getTrainByOrgId(int orgId,int pageNumber, int pageSize, String sortBy, String sortDir);
    List<Train> getTrainsByDepartFromAndDestination(String departFrom, String destination);
    List<Train> getTrainByUserId(Long id);

    List<Train> searchByTrainNo(int trainNo);
    List<Train> searchByTrainName(String trainName);
    List<Train> searchByRailwayZone(String railwayZone);
    List<Train> comprehensiveTrainSearch(Integer trainNo, String trainName, String railwayZone, String departFrom, String destination);
}