package com.travel_platform.travel_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelPlatformApplication.class, args);
	}

}
