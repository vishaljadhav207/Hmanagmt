package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Flight;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FlightRepository extends JpaRepository<Flight, Integer> {

    List<Flight> findByDepartFromAndDestination(String departFrom, String destination);

    Page<Flight> findByOrganization_OrgId(int orgId, Pageable pageable);
    List<Flight> findByUserId(Long id);


}
