package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.PnrGenerator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PnrRepository extends JpaRepository<PnrGenerator,Integer> {
}
