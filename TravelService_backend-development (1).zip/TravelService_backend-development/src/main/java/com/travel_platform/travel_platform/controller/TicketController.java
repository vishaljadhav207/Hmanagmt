package com.travel_platform.travel_platform.controller;
import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.dto.ApiResponse;
import com.travel_platform.travel_platform.entity.Ticket;
import com.travel_platform.travel_platform.service.TicketService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ticket")
@CrossOrigin(origins = "*")
//@Tag(name = "Travel API", description = "All API related to Travel")

public class TicketController {


    @Autowired
    private TicketService ticketService;

    @Authorize({"User"})
    @PostMapping("/saveTicket")
    public ApiResponse<Ticket> saveTrain(@RequestBody Ticket ticket , @RequestHeader("Authorization") String token) {
        try {
            Ticket savedTicket = ticketService.saveTicket(ticket,token);
            return new ApiResponse<>(HttpStatus.OK, "Ticket saved successfully", savedTicket);
        } catch (Exception e) {
           throw new RuntimeException("Server Error , Failed to reserve ticket !! ");

        }
    }

    @GetMapping("/getAllTickets")
    public ApiResponse<List<Ticket>> getAllTickets() {
        try {
            List<Ticket> tickets = ticketService.getAllTicket();
            if (tickets.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No tickets found", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Tickets retrieved successfully", tickets);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving tickets", null);
        }
    }

    @GetMapping("/getTicketById/{id}")
    public ApiResponse<Ticket> getTicketById(@PathVariable Long id) {
        try {
            Ticket ticket = ticketService.getTicketById(id);
            return new ApiResponse<>(HttpStatus.OK, "Ticket found",ticket);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Ticket not found", null);
        }
    }

    @PatchMapping("updateTicketById/{id}")
    public ApiResponse<Ticket> updateTicketById(@PathVariable Long id, @RequestBody Ticket ticket){
        try {
            Ticket updateTicket = ticketService.updateTicket(id, ticket);
            return new ApiResponse<>(HttpStatus.OK, "Ticket updated successfully", updateTicket);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Error updating ticket", null);
        }
    }

    @DeleteMapping("/deleteTicketById/{id}")
    public ApiResponse<Void> deleteTrainById(@PathVariable Long id) {
        try {
            ticketService.deleteTicketById(id);
            return new ApiResponse<>(HttpStatus.NO_CONTENT, "Ticket deleted successfully", null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Ticket not found", null);
        }
    }

    @PatchMapping("/cancleTicket")
    public ApiResponse<Ticket> cancleTicket(@RequestParam long ticketId ){
        try {
            return new ApiResponse<>(HttpStatus.ACCEPTED, "Ticket Was Cancelled ", ticketService.cancleTicket(ticketId));
        }catch(Exception e){
            throw new RuntimeException("Cancelling ticket failed In controller ");
        }
    }

    @GetMapping("/bookingHistory/{userId}")
    public ResponseEntity<List<Ticket>> getAllTicketsByUserId(@PathVariable long userId) {
        List<Ticket> tickets = ticketService.findTicketsByUserId(userId);
        return ResponseEntity.ok(tickets);
    }

}
