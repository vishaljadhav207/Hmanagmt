package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.entity.Train;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import com.travel_platform.travel_platform.service.TrainService;
import com.travel_platform.travel_platform.dto.ApiResponse;
import java.util.List;

@RestController
@RequestMapping("/api/train")
@CrossOrigin(origins = "*")
@Tag(name = "Train API", description = "All API related to Train")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping("/saveTrain")
    public ApiResponse<Train> saveTrain(@RequestBody Train train,@RequestHeader("Authorization") String token) {
        try {
            Train savedTrain = trainService.saveTrain(train,token);
            return new ApiResponse<>(HttpStatus.OK, "Train saved successfully", savedTrain);
        } catch (Exception e) {
            e.printStackTrace(); // Add this to see full stack trace in console
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save train: " + e.getMessage(), null);
        }
    }


    @GetMapping("/getAllTrain")
    public ApiResponse<List<Train>> getAllTrain(
            @RequestParam(value = "pageNumber", defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "pageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "trainNo",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        try {
            List<Train> trains = trainService.getAllTrains(pageNumber, pageSize, sortBy, sortDir);
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains retrieved successfully", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving trains", null);
        }
    }

    @DeleteMapping("/deleteTrainById/{id}")
    public ApiResponse<Void> deleteTrainById(@PathVariable int id) {
        try {
            trainService.deleteTrainById(id);
            return new ApiResponse<>(HttpStatus.NO_CONTENT, "Train deleted successfully", null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Train not found", null);
        }
    }

    @GetMapping("/getTrainById/{id}")
    public ApiResponse<Train> getTrainById(@PathVariable int id) {
        try {
            Train train = trainService.getTrainById(id);
            return new ApiResponse<>(HttpStatus.OK, "Train found", train);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Train not found", null);
        }
    }

    @PutMapping("/updateTrainById/{id}")
    public ApiResponse<Train> updateTrainById(@PathVariable int id, @RequestBody Train train,String token) {
        try {
            Train updatedTrain = trainService.updateTrain(id, train,token);
            return new ApiResponse<>(HttpStatus.OK, "Train updated successfully", updatedTrain);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Error updating train", null);
        }
    }

    @GetMapping("/getTrainNoByTrainId/{id}")
    public ApiResponse<String> getTrainNoByTrainId(@PathVariable int id) {
        try {
            String trainNo = trainService.getTrainNoByTrainId(id);
            return new ApiResponse<>(HttpStatus.ACCEPTED, "TrainNo found", trainNo);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Train not found", null);
        }
    }

    @GetMapping("/getTrainByOrgId/{id}")
    public ApiResponse<List<Train>> getTrainByOrgId(
            @PathVariable int id,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) int pageSize,
            @RequestParam(value = "sortBy", defaultValue = "trainNo", required = false)String sortBy,
            @RequestParam(value = "sortDir", defaultValue = "asc", required = false)String sortDir
    ) {
        try {
            List<Train> trains = trainService.getTrainByOrgId(id, pageNumber , pageSize, sortBy, sortDir); // -1 for 0-based page index
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found for this organization", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains found", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving trains: " + e.getMessage(), null);
        }
    }

    @GetMapping("/by-route/{departFrom}/{destination}")
    public ApiResponse<List<Train>> getTrainByRoute(@PathVariable String departFrom, @PathVariable String destination) {
        try{
            List<Train> trains = trainService.getTrainsByDepartFromAndDestination(departFrom, destination);
            return new ApiResponse<>(HttpStatus.OK, "Trains found", trains);

        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving trains", null);

        }
    }

    //search

    @GetMapping("/searchTrains")
    public ApiResponse<List<Train>> searchTrains(
            @RequestParam(required = false) Integer trainNo,
            @RequestParam(required = false) String trainName,
            @RequestParam(required = false) String railwayZone,
            @RequestParam(required = false) String departFrom,
            @RequestParam(required = false) String destination) {
        try {
            List<Train> trains = trainService.comprehensiveTrainSearch(
                    trainNo, trainName, railwayZone, departFrom, destination);
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found matching the criteria", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains retrieved successfully", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error searching trains", null);
        }
    }

    @GetMapping("/searchByTrainNo/{trainNo}")
    public ApiResponse<List<Train>> searchByTrainNo(@PathVariable int trainNo) {
        try {
            List<Train> trains = trainService.searchByTrainNo(trainNo);
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found with this number", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains found by number", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error searching trains by number", null);
        }
    }

    @GetMapping("/searchByTrainName/{trainName}")
    public ApiResponse<List<Train>> searchByTrainName(@PathVariable String trainName) {
        try {
            List<Train> trains = trainService.searchByTrainName(trainName);
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found with this name", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains found by name", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error searching trains by name", null);
        }
    }

    @GetMapping("/searchByRailwayZone/{railwayZone}")
    public ApiResponse<List<Train>> searchByRailwayZone(@PathVariable String railwayZone) {
        try {
            List<Train> trains = trainService.searchByRailwayZone(railwayZone);
            if (trains.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No trains found in this zone", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Trains found by railway zone", trains);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error searching trains by zone", null);
        }
    }


    @GetMapping("/getTrainByUserId/{id}")
    public ApiResponse<List<Train>> getTrainByUserId(@PathVariable Long id) {
        try{
            List<Train> trains = trainService.getTrainByUserId(id);
            return new ApiResponse<>(HttpStatus.OK, "Trains found", trains);
        }
        catch(Exception e){
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving trains", null);
        }
    }

}