package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.client.UserServiceClient;
import com.travel_platform.travel_platform.entity.*;
import com.travel_platform.travel_platform.repository.BusRepository;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.repository.OrganizationRepository;
import com.travel_platform.travel_platform.service.BusService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BusServiceImpl implements BusService {

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserServiceClient userServiceClient;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    @Override
    public Bus saveBusInfo(Bus bus, String token) {
        if (bus.getUserId() != null && userServiceClient.getUserById(bus.getUserId(), token) == null) {
            throw new IllegalArgumentException("Invalid or unreachable userId: " + bus.getUserId());
        }
        if (bus.getOrgId() != null) {
            Organization organization = organizationRepository.findById(Long.valueOf(bus.getOrgId()))
                    .orElseThrow(() -> new RuntimeException("Organization not found"));
            bus.setOrganization(organization);
        }


        List<ClassType> managedClassTypes = bus.getClassTypes().stream()
                .map(c -> classTypeRepository.findById(Math.toIntExact(c.getClassId()))
                        .orElseThrow(() -> new RuntimeException("ClassType not found: " + c.getClassId())))
                .toList();
        bus.setClassTypes(managedClassTypes);
        return busRepository.save(bus);
    }

    @Override
    public Bus findBusById(int id) {
        return busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with ID: " + id));
    }

    @Override
    public List<Bus> getBusByOrgId(int orgId, int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<Bus> pagebus = (Page<Bus>) busRepository.findByOrganization_OrgId(orgId, pageable);
        return pagebus.getContent();
    }

    @Override
    public List<Bus> findByDepartFromAndDestination(String departFrom,String destination) {
        return busRepository.findByDepartFromAndDestination(departFrom,destination);
    }

    @Override
    public List<Bus> getAll(int pageNumber, int pageSize, String sortBy, String sortDir)
    {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
         Page<Bus> page = busRepository.findAll(pageable);
         return page.getContent();
    }

    @Override
    @Transactional
    public void deleteBus(int id) {
        if (!busRepository.existsById(id)) {
            throw new RuntimeException("Cannot delete. Bus not found with ID: " + id);
        }
        busRepository.deleteById(id);
    }

    @Override
    public Bus updateBus(int id, Bus updatedBus) {
        Bus bus = busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with ID: " + id));

        bus.setBusNo(updatedBus.getBusNo());
        bus.setBusType(updatedBus.getBusType());
        bus.setOperatorName(updatedBus.getOperatorName());
        bus.setDestination(updatedBus.getDestination());
        bus.setDepartFrom(updatedBus.getDepartFrom());
        bus.setUserId(updatedBus.getUserId());

        if (updatedBus.getOrgId() != null) {
            Organization organization = getValidatedBusOrganization(updatedBus.getOrgId());
            bus.setOrganization(organization);
        }

        return busRepository.save(bus);
    }

    @Override
    public long countTotalBuses() {
        return busRepository.count();
    }

    @Override
    public String getBusNoByBusId(int busId) {
        return busRepository.findById(busId)
                .map(bus -> String.valueOf(bus.getBusNo()))
                .orElseThrow(() -> new RuntimeException("Bus not found with ID: " + busId));
    }

    @Override
    public List<Bus> getBusByUserId(Long id) {
        return busRepository.findByUserId(id);
    }

    @Override
    public Bus getBusById(int busId) {
        return busRepository.findById(busId).orElseThrow(() -> new RuntimeException("Bus not found with ID: " + busId));
    }


    @Override
    public List<Bus> searchBuses(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return busRepository.findByBusNoContainingIgnoreCase(searchTerm);
    }


    @Override
    public List<Bus> comprehensiveBusSearch(String busNo, String busType, String operatorName, String departFrom, String destination) {
        return busRepository.findByBusNoContainingIgnoreCaseOrBusTypeContainingIgnoreCaseOrOperatorNameContainingIgnoreCaseOrDepartFromContainingIgnoreCaseOrDestinationContainingIgnoreCase(
                busNo, busType, operatorName, departFrom, destination);
    }


    private Organization getValidatedBusOrganization(Integer orgId) {
        Organization organization = organizationRepository.findById(orgId.longValue())
                .orElseThrow(() -> new RuntimeException("Organization not found with ID: " + orgId));

        if (organization.getType() != OrganizationType.BUS_OPERATOR) {
            throw new IllegalArgumentException("Only organizations of type BUS_OPERATOR can have buses.");
        }

        return organization;
    }
}
