package com.travel_platform.travel_platform.entity;

import com.travel_platform.travel_platform.entity.TransportType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
public class ClassType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "class_id")
    private Long classId;

    @NotEmpty(message = "className must not be empty")
    private String className;

    private int availability;

    @NotEmpty(message = "status must not be empty")
    private String status;

    private float fare;

    @NotNull(message = "transportType must not be null")
    @Enumerated(EnumType.STRING)
    private TransportType transportType; // Enum-based field
}

