package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.dto.ApiResponse;
import com.travel_platform.travel_platform.entity.Bus;
import com.travel_platform.travel_platform.service.BusService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/bus")
@Tag(name = "Bus API", description = "All API related to Bus")
public class BusController {

    @Autowired
    private BusService busService;


//    @Authorize({"User"})
    @PostMapping("/saveBus")
    public ApiResponse<Bus> saveBus(@Valid @RequestBody Bus bus, @RequestHeader(HttpHeaders.AUTHORIZATION) String token) {
        try {
            Bus savedBus = busService.saveBusInfo(bus, token);
            return new ApiResponse<>(HttpStatus.OK, "Bus saved successfully", savedBus);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save bus", null);
        }
    }


    @GetMapping("/getAllBus")
    public ApiResponse<List<Bus>> getAllBus(
            @RequestParam(value = "PageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "PageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "busNo",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        try {
            List<Bus> buses = busService.getAll(pageNumber, pageSize, sortBy, sortDir);
            if (buses.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No buses found", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Buses retrieved successfully", buses);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving buses", null);
        }
    }

    @GetMapping("/getBusById/{id}")
    public ApiResponse<Bus> getBusById(@Valid @PathVariable int id) {
        try {
            Bus bus = busService.findBusById(id);
            return new ApiResponse<>(HttpStatus.OK, "Bus found", bus);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Bus not found", null);
        }
    }

    @PutMapping("/updateBusById/{id}")
    public ApiResponse<Bus> updateBusById(@Valid @PathVariable int id, @RequestBody Bus bus) {
        try {
            Bus updatedBus = busService.updateBus(id, bus);
            return new ApiResponse<>(HttpStatus.OK, "Bus updated successfully", updatedBus);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Error updating bus", null);
        }
    }

    @DeleteMapping("/deleteBusById/{id}")
    public ApiResponse<Void> deleteBusById(@Valid @PathVariable int id) {
        try {
            busService.deleteBus(id);
            return new ApiResponse<>(HttpStatus.NO_CONTENT, "Bus deleted successfully", null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Bus not found", null);
        }
    }

    @GetMapping("/by-route/{departFrom}/{destination}")
    public ApiResponse<List<Bus>> getByDepartFromAndDestination(@RequestParam String departFrom, @RequestParam String destination) {
        try {
            List<Bus> buses = busService.findByDepartFromAndDestination(departFrom, destination);
            if (buses.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No buses found for this destination", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Buses retrieved", buses);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving buses", null);
        }
    }

    @GetMapping("/getBusByOrgId/{id}")
    public ApiResponse<List<Bus>> getBusByOrgId(
            @PathVariable int id,
            @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "busNo",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        try {
            List<Bus> bus = busService.getBusByOrgId(id,pageNumber,pageSize,sortBy,sortDir); // -1 for 0-based page index
            if (bus.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No bus found for this organization", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "bus found", bus);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving bus: " + e.getMessage(), null);
        }
    }

    @GetMapping("/count")
    public ApiResponse<Long> countTotalBuses() {
        try {
            long count = busService.countTotalBuses();
            return new ApiResponse<>(HttpStatus.OK, "Total buses counted successfully", count);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error counting buses", null);
        }
    }
    @GetMapping("/getBusNoById/{busId}")
    public ApiResponse<String> getBusNoByBusId(@PathVariable int busId) {
        try {
            String busNo = busService.getBusNoByBusId(busId);
            return new ApiResponse<>(HttpStatus.OK, "Bus No found", busNo);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Bus not found", null);
        }
    }


    @GetMapping("/searchByBusNo/{busNo}")
    public ApiResponse<List<Bus>> searchBuses(
            @RequestParam(required = false) String busNo,
            @RequestParam(required = false) String busType,
            @RequestParam(required = false) String operatorName,
            @RequestParam(required = false) String departFrom,
            @RequestParam(required = false) String destination) {
        try {
            List<Bus> buses = busService.comprehensiveBusSearch(
                    busNo, busType, operatorName, departFrom, destination);
            if (buses.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No buses found matching the criteria", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "Buses retrieved successfully", buses);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error searching buses", null);
        }
    }

    @GetMapping("/getBusByUserId/{id}")
    public ApiResponse<List<Bus>> getBusByUserId(@PathVariable Long id) {
        try{
            List<Bus> bus =  busService.getBusByUserId(id);
            return new ApiResponse<>(HttpStatus.OK, "Bus found", bus);
        }
        catch(Exception e)
        {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Bus not found", null);
        }
    }
}
