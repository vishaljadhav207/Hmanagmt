package com.travel_platform.travel_platform.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Bus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int busId;

    @NotEmpty(message = "Bus number must not be empty")
    private String busNo;

    @NotEmpty(message = "Bus type must not be empty")
    private String busType;

    @NotEmpty(message = "Operator name must not be empty")
    private String operatorName;

    @NotEmpty(message = "Destination must not be empty")
    private String destination;

    @NotEmpty(message = "Departure location must not be empty")
    private String departFrom;

    private Long userId; // same style as Organization

    @ManyToOne
    @JoinColumn(name = "org_id", referencedColumnName = "orgId")
    @JsonIgnoreProperties({"type"})
    private Organization organization;

    @ManyToMany
    @JoinTable(
            name = "bus_class_types",
            joinColumns = @JoinColumn(name = "bus_id"),
            inverseJoinColumns = @JoinColumn(name = "class_id")
    )
    private List<ClassType> classTypes;

    @Transient
    private Integer  orgId;
}
