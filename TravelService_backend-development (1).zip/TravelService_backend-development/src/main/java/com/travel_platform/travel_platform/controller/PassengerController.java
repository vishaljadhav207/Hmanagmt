package com.travel_platform.travel_platform.controller;


import com.travel_platform.travel_platform.dto.ApiResponse;
import com.travel_platform.travel_platform.entity.Passenger;
import com.travel_platform.travel_platform.entity.Train;
import com.travel_platform.travel_platform.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/passenger")
@CrossOrigin(origins = "*")
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @PostMapping("/savePassenger")
    public ApiResponse<Passenger> savePassenger(@RequestBody Passenger passenger) {
        try {
            Passenger savedPassenger = passengerService.savePassenger(passenger);
            return new ApiResponse<>(HttpStatus.OK, "Passenger saved successfully", savedPassenger);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save Passenger", null);
        }
    }

    @GetMapping("/getAllPassenger")
    public ApiResponse<List<Passenger>> getAllPassenger(
            @RequestParam(value = "pageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "pageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "name",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        try {
            List<Passenger> passengers = passengerService.getAllPassenger(pageNumber, pageSize, sortBy, sortDir);
            if (passengers.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT, "No passengers found", null);
            }
            return new ApiResponse<>(HttpStatus.OK, "passengers retrieved successfully", passengers);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR, "Error retrieving passengers", null);
        }
    }

    @DeleteMapping("/deletePassengerById/{id}")
    public ApiResponse<Void> deletePassengerById(@PathVariable int id) {
        try {
            passengerService.deletePassengerById(id);
            return new ApiResponse<>(HttpStatus.NO_CONTENT, "Passenger deleted successfully", null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Passenger not found", null);
        }
    }

    @GetMapping("/getPassengerById/{id}")
    public ApiResponse<Optional<Passenger>> getPassengerById(@PathVariable int id) {
        try {
            Optional<Passenger> passenger = passengerService.getPassengerById(id);
            return new ApiResponse<>(HttpStatus.OK, "Passenger found", passenger);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Train not found", null);
        }
    }

    @PutMapping("/updatePassengerById/{id}")
    public ApiResponse<Passenger> updatePassengerById(@PathVariable int id, @RequestBody Passenger passenger) {
        try {
            Passenger updatedPassenger = passengerService.updatePassengerById(id,passenger);
            return new ApiResponse<>(HttpStatus.OK, "Passenger updated successfully", updatedPassenger);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND, "Error updating passenger", null);
        }
    }
}
