package com.travel_platform.travel_platform.service;
import com.travel_platform.travel_platform.entity.Bus;
import com.travel_platform.travel_platform.entity.Train;

import java.util.List;

public interface BusService {
    Bus saveBusInfo(Bus bus, String token);
    Bus findBusById(int id);
    List<Bus> getAll(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deleteBus(int id);
    Bus updateBus(int id, Bus updatedBus);
    List<Bus> findByDepartFromAndDestination(String departFrom,String destination);
    List<Bus> getBusByOrgId(int orgId, int pageNumber, int pageSize, String sortBy, String sortDir);
    long countTotalBuses();
    String getBusNoByBusId(int busId);
    List<Bus> searchBuses(String searchTerm);
    List<Bus> comprehensiveBusSearch(String busNo, String busType, String operatorName, String departFrom, String destination);
    List<Bus> getBusByUserId(Long id);


    Bus getBusById(int busId);


}
