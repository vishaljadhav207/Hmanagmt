package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.dto.FlightSearchRequest;
import com.travel_platform.travel_platform.entity.FlightTrip;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;

public interface FlightTripService {
    ResponseEntity<FlightTrip> createFlightTrip(FlightTrip flightTrip);

    FlightTrip getFlightTripById(int id);

    List<FlightTrip> getAllFlightTrips(int pageNumber, int pageSize, String sortBy, String sortDir);

    void deleteFlightTrip(int id);

    FlightTrip updateFlightTripById(int id, FlightTrip flightTrip);

    List<FlightTrip> getFlightTripsByUserId(Long id);



    List<FlightTrip> searchFlightTrips(String origin, String destination, LocalDate departureDate);
}
