package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.dto.BusSearchRequest;
import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;

public interface BusTripService {
    ResponseEntity<BusTrip> createBusTrip(BusTrip busTrip);
    BusTrip getBusTripById(int id);
    List<BusTrip> getAllBusTrips(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deleteBusTrip(int id);
    BusTrip updateBusTripById(int id, BusTrip busTrip);
    List<BusTrip> getBusTripsByUserId(Long id);


    List<BusTrip> getBusTripsByBusId(int busId);

    List<BusTrip> searchBusTrips(String origin, String destination, LocalDate departureDate);
    List<BusTrip> getBookingHistory(Long userId, int pageNumber, int pageSize, String sortBy, String sortDir);
}
