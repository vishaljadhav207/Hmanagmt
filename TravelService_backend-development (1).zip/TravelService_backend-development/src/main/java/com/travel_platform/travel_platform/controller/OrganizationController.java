package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.dto.OrganizationResponseDTO;
import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import com.travel_platform.travel_platform.service.OrganizationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/organizations")
@CrossOrigin(origins = "*")
public class OrganizationController {

    @Autowired
    private OrganizationService organizationService;

    @Authorize("Admin")
    @PostMapping("/create")
    public ResponseEntity<Organization> createOrganization(@RequestBody Organization organization , @RequestHeader("Authorization") String token) {
        Organization createdOrganization = organizationService.createOrganization(organization,token);
        return new ResponseEntity<>(createdOrganization, HttpStatus.CREATED);
    }

    @GetMapping("/getById/{orgId}")
    public ResponseEntity<Organization> getOrganizationById(@PathVariable Long orgId) {
        return ResponseEntity.ok(organizationService.getOrganizationById(orgId));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Organization>> getAllOrganizations(
            @RequestParam(value = "PageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "PageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "type",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        return ResponseEntity.ok(organizationService.getAllOrganizations(pageNumber, pageSize, sortBy, sortDir));
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<List<Organization>> getOrganizationsByType(@PathVariable OrganizationType type) {
        return ResponseEntity.ok(organizationService.getOrganizationsByType(type));
    }

    @PutMapping("/updateById/{orgId}")
    public ResponseEntity<Organization> updateOrganization(
            @PathVariable Long orgId,
            @RequestBody Organization organization) {
        return ResponseEntity.ok(organizationService.updateOrganization(orgId, organization));
    }

    @DeleteMapping("/deleteById/{orgId}")
    public ResponseEntity<Void> deleteOrganization(@PathVariable Long orgId) {
        organizationService.deleteOrganization(orgId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/getWithUser/{orgId}")
    public ResponseEntity<OrganizationResponseDTO> getOrganizationWithUser(@PathVariable Long orgId , String token) {
        return ResponseEntity.ok(organizationService.getOrganizationWithUser(orgId,token));
    }
}
