package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.entity.Flight;

import java.util.List;

public interface FlightService
{
    Flight saveFlight(Flight flight, String token);
    Flight getFlightById(int id);
    List<Flight> getAllFlights(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deleteFlightById(int flightId);
    Flight updateFlight(int flightId,Flight updatedFlight,String token);

    List<Flight> getFlightByOrgId(int orgId,int pageNumber, int pageSize, String sortBy, String sortDir);

    List<Flight> searchFlights(String departFrom, String destination);
    List<Flight> getFlightByUserId(Long id);

    String getFlightNoById(int id );
}
