package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.TransportType;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClassTypeRepository extends JpaRepository<ClassType, Integer> {
    List<ClassType> findByTransportType(TransportType transportType);
}
