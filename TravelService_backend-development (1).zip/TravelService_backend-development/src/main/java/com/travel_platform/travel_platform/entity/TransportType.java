package com.travel_platform.travel_platform.entity;

public enum TransportType {
    TRAIN, BUS, FLIGHT
}
