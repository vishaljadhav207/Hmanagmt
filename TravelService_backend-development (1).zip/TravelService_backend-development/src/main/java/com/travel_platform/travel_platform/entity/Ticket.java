package com.travel_platform.travel_platform.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.hibernate.annotations.Type;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeBinderType;
import org.hibernate.engine.internal.Cascade;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "ticket")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;
    private long userId;  //token
    private String pnrNumber;
    @Enumerated(EnumType.STRING)
    private OrganizationType transportType;

    private int transportId;
    private String classType;   //frontend
    private String seatPreference;
    private List<String> seatNumber ;
    private String boarding;
    private String departure ;
    private LocalDateTime bookingDate;
    private LocalDate journeyDate;  //frontend
    private int waitingNumber ;

    @Enumerated(EnumType.STRING)
    private Status status;  //backend
    private double totalFare;  //frontend

    private int tripId ;  //front end
    //    private LocalDateTime cancellationDate; //backend
    private Long cancellationFee;  //backend
    private Long refundAmount;   //BACKEND
    private boolean isRefunded;

    @OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    private List<Passenger> passengerList;

}
