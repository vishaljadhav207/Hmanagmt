package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PassengerRepository extends JpaRepository<Passenger,Integer> {
}
