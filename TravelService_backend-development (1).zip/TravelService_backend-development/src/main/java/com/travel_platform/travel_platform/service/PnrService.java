package com.travel_platform.travel_platform.service;

public interface PnrService {
    String generatePnr(String transportType , int transportId);
}
