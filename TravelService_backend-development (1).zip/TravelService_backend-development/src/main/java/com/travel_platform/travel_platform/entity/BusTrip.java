package com.travel_platform.travel_platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "bus_trip")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusTrip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int busTripId;

    @NotEmpty(message = "origin must not be empty")
    private String origin;

    @NotEmpty(message = "destination must not be empty")
    private String destination;


    @NotEmpty(message = "departureDate must not be empty")
    private LocalDate departureDate;

    @NotEmpty(message = "arrivalDate must not be empty")
    private LocalDate arrivalDate;

    @NotEmpty(message = "totalRouteDistance must not be empty")
    private int totalRouteDistance;

    @NotNull(message = "bus must not be null")
    @ManyToOne
    @JoinColumn(name = "bus_id", nullable = false)
    private Bus bus;


    @NotEmpty(message = "intermediateStops must not be empty")
    @ElementCollection
    @CollectionTable(name = "bus_trip_stops", joinColumns = @JoinColumn(name = "bus_trip_id"))
    private List<IntermediateStop> intermediateStops;

//    @OneToMany(mappedBy = "busTrip", cascade = CascadeType.ALL)
//    private List<BusBooking> bookings;
}
