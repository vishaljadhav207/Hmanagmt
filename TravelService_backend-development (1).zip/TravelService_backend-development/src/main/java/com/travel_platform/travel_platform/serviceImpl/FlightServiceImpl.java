package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.client.UserServiceClient;
import com.travel_platform.travel_platform.entity.Flight;
import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import com.travel_platform.travel_platform.entity.*;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.repository.FlightRepository;
import com.travel_platform.travel_platform.repository.OrganizationRepository;
import com.travel_platform.travel_platform.service.FlightService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

@Service
public class FlightServiceImpl implements FlightService {

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserServiceClient userServiceClient;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    @Override
    public Flight saveFlight(Flight flight, String token) {
        if (flight.getUserId() != null && userServiceClient.getUserById(flight.getUserId(), token) == null) {
            throw new IllegalArgumentException("Invalid userId: " + flight.getUserId());
        }

        List<ClassType> managedClassTypes = flight.getClassTypes().stream()
                .map(c -> classTypeRepository.findById(Math.toIntExact(c.getClassId()))
                        .orElseThrow(() -> new RuntimeException("ClassType not found: " + c.getClassId())))
                .toList();
        flight.setClassTypes(managedClassTypes);
        Long orgId = flight.getOrganization().getOrgId();

        Organization organization = organizationRepository.findById(orgId)
                .orElseThrow(() -> new RuntimeException("Organization not found with ID: " + orgId));

        if (organization.getType() != OrganizationType.AIRLINE) {
            throw new IllegalArgumentException("Only AIRLINE organizations can have flights.");
        }

        flight.setOrganization(organization);

        return flightRepository.save(flight);
    }

    @Override
    public Flight getFlightById(int flightId) {
        return flightRepository.findById(flightId)
                .orElseThrow(() -> new EntityNotFoundException("Flight with ID " + flightId + " not found"));
    }

    @Override
    public List<Flight> getAllFlights(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
      Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
      Page<Flight> pageFlights = flightRepository.findAll(pageable);
      return pageFlights.getContent();
    }

    @Override
    public void deleteFlightById(int flightId) {
        if (!flightRepository.existsById(flightId)) {
            throw new EntityNotFoundException("Flight with ID " + flightId + " not found");
        }
        flightRepository.deleteById(flightId);
    }

    @Override
    public Flight updateFlight(int flightId, Flight updatedFlight,String token) {
        Optional<Flight> flightOptional = flightRepository.findById(flightId);
        if (flightOptional.isPresent()) {
            Flight existingFlight = flightOptional.get();

            if (updatedFlight.getUserId() != null && userServiceClient.getUserById(updatedFlight.getUserId(),token) == null) {
                throw new IllegalArgumentException("Invalid userId: " + updatedFlight.getUserId());
            }
            existingFlight.setUserId(updatedFlight.getUserId());

            existingFlight.setFlight_no(updatedFlight.getFlight_no());
            existingFlight.setAirline(updatedFlight.getAirline());
            existingFlight.setDestination(updatedFlight.getDestination());
            existingFlight.setDepartFrom(updatedFlight.getDepartFrom());

            return flightRepository.save(existingFlight);
        } else {
            throw new EntityNotFoundException("Flight with ID " + flightId + " not found");
        }
    }

    @Override
    public List<Flight> getFlightByOrgId(int orgId,int pageNumber, int pageSize,String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<Flight> pageflight=flightRepository.findByOrganization_OrgId(orgId,pageable);
        List<Flight> flightList=pageflight.getContent();
        return flightList;
    }

    @Override
    public List<Flight> searchFlights(String departFrom, String destination) {
        return flightRepository.findByDepartFromAndDestination(departFrom, destination);
    }

    @Override
    public String getFlightNoById(int id) {
      return  flightRepository.findById(id)
                .map(flight -> String.valueOf(flight.getFlight_no()))
                .orElseThrow(() -> new RuntimeException("Flight not found "));
    }

    @Override
    public List<Flight> getFlightByUserId(Long id) {
        return flightRepository.findByUserId(id);
    }

}
