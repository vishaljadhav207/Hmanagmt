package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.client.BusServiceClient;
import com.travel_platform.travel_platform.client.FlightServiceClient;
import com.travel_platform.travel_platform.client.TrainServiceClient;
import com.travel_platform.travel_platform.config.UserIdentityDetailsService;
import com.travel_platform.travel_platform.entity.*;
import com.travel_platform.travel_platform.repository.*;
import com.travel_platform.travel_platform.service.PnrService;
import com.travel_platform.travel_platform.service.TicketService;
import com.travel_platform.travel_platform.utils.JwtUtil;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.text.html.Option;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PnrService pnrService;

    @Autowired
    private TrainRepository trainRepository;

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private BusTripRepository busTripRepository;

    @Autowired
    private TrainTripRepository trainTripRepository;

    @Autowired
    private FlightTripRepository flightTripRepository;

    @Autowired
    private TrainServiceClient trainServiceClient;

    @Autowired
    private BusServiceClient busServiceClient;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    @Autowired
    private FlightServiceClient flightServiceClient;


    @Override
    public Ticket saveTicket(Ticket ticket, String token) {
        try {
            long userId = UserIdentityDetailsService.getUserId();
            ticket.setUserId(userId);
            String pnr = pnrService.generatePnr(ticket.getTransportType().name(), ticket.getTransportId());
            ticket.setPnrNumber(pnr);
            ticket.setStatus(Status.CONFIRM);
            ticket.setBookingDate(LocalDateTime.now());

            List<Passenger> passengers = new ArrayList<>();
            int passengerCount = 0;
            for (Passenger passenger : ticket.getPassengerList()) {
                passengers.add(passenger);
                passenger.setPnrNumber(pnr);
                passengerCount++;
            }
            ticket.setPassengerList(passengers);

            if (ticket.getTransportType() == OrganizationType.AIRLINE) {
                Flight flight = flightRepository.findById(ticket.getTransportId()).
                        orElseThrow(() -> new RuntimeException("Flight Not Found !"));
                ticket.setTransportId(Integer.valueOf(flight.getFlight_no()));
                FlightTrip flightTrip = flightTripRepository.findByFlightId(flight.getFlight_id());
                ticket.setTripId(flightTrip.getFlightTripId());
                List<String> seat = flightServiceClient.getAvailableSeats(ticket.getSeatPreference(), ticket.getClassType(), ticket.getTransportId(), passengerCount, token);
                for (ClassType classType : flight.getClassTypes()) {
                    if (classType.getClassName().equalsIgnoreCase(ticket.getClassType())) {
                        float basePrice = classType.getFare();
                        for (IntermediateStop intermediateStop : flightTrip.getIntermediateStops()) {
                            if (intermediateStop.getStopName().equalsIgnoreCase(ticket.getBoarding())) {
                                int startKMS = intermediateStop.getDistanceFromPrevious();
                                for (IntermediateStop intermediateStop1 : flightTrip.getIntermediateStops()) {
                                    if (intermediateStop1.getStopName().equalsIgnoreCase(ticket.getDeparture())) {
                                        int endKMS = intermediateStop.getDistanceFromPrevious();
                                        int totalKMS = endKMS - startKMS;
                                        ticket.setTotalFare((basePrice + totalKMS * 3) * passengerCount);
                                    }
                                }
                            }
                        }
                    }
                }
//              ticket.setSeatNumber(seat);


                for (String s : seat) {
                    if (seat.size() == passengerCount) {
                        ticket.setSeatNumber(seat);
                        ticket.setWaitingNumber(0);
                    } else if (s.trim().isEmpty()) {
                        int baseWaitingNumber = ticketRepository.getMaxWaitingNumberByTransportId(
                                ticket.getTransportId(), ticket.getTransportType());

                        List<String> waiting = new ArrayList<>();

                        for (int i = 0; i < passengerCount; i++) {
                            waiting.add("WL" + (baseWaitingNumber + i + 1));
                        }

                        ticket.setSeatNumber(waiting);
                        ticket.setStatus(Status.WAITING);
                        ticket.setWaitingNumber(baseWaitingNumber + passengerCount);
                    }
                }
                //todo add a waiting list of the seat and also write logic to reserve seat when available
                //todo amount of fare to be decided
            } else if (ticket.getTransportType() == OrganizationType.RAILWAY) {
                Train train = trainRepository.findById(ticket.getTransportId()).
                        orElseThrow(() -> new RuntimeException("Train not Found !!"));
                ticket.setTransportId(train.getTrainNo());
                TrainTrip trainTrip = trainTripRepository.findByTrainId(train.getTrain_id());
                ticket.setTripId(trainTrip.getTrainTripId());
                for (ClassType classType : train.getClassTypes()) {
                    if (classType.getClassName().equalsIgnoreCase(ticket.getClassType())) {
                        float basePrice = classType.getFare();
                        for (IntermediateStop intermediateStop : trainTrip.getIntermediateStops()) {
                            if (intermediateStop.getStopName().equalsIgnoreCase(ticket.getBoarding())) {
                                int startKMS = intermediateStop.getDistanceFromPrevious();
                                for (IntermediateStop intermediateStop1 : trainTrip.getIntermediateStops()) {
                                    if (intermediateStop1.getStopName().equalsIgnoreCase(ticket.getDeparture())) {
                                        int endingKMS = intermediateStop1.getDistanceFromPrevious();
                                        int totalKMS = endingKMS - startKMS;
                                        ticket.setTotalFare((basePrice + totalKMS * 1.2) * passengerCount);
                                    }
                                }
                            }
                        }
                    }
                }

                List<String> seat = trainServiceClient.getAvailableSeat(ticket.getSeatPreference(), ticket.getClassType(), ticket.getTransportId(), passengerCount, token);
                for (String s : seat) {
                    if (seat.size() == passengerCount) {
                        ticket.setSeatNumber(seat);
                        ticket.setWaitingNumber(0);
                    } else if (s.trim().isEmpty()) {
                        int baseWaitingNumber = ticketRepository.getMaxWaitingNumberByTransportId(
                                ticket.getTransportId(), ticket.getTransportType());

                        List<String> waiting = new ArrayList<>();

                        for (int i = 0; i < passengerCount; i++) {
                            waiting.add("WL" + (baseWaitingNumber + i + 1));
                        }

                        ticket.setSeatNumber(waiting);
                        ticket.setStatus(Status.WAITING);
                        ticket.setWaitingNumber(baseWaitingNumber + passengerCount);
                    }
                }
                //todo add a waiting list of the seat and also write logic to reserve seat when available
                //todo amount of fare to be decided

            }




            else if (ticket.getTransportType() == OrganizationType.BUS_OPERATOR) {
                // Get bus details
                Bus bus = busRepository.findById(ticket.getTransportId())
                        .orElseThrow(() -> new RuntimeException("Bus Not Found!"));

                // Get bus trip - now using tripId from frontend
                BusTrip busTrip = busTripRepository.findById(ticket.getTripId())
                        .orElseThrow(() -> new RuntimeException("Bus Trip Not Found!"));

                // Validate the trip belongs to the bus
                if (busTrip.getBus() == null || busTrip.getBus().getBusId() != bus.getBusId()) {
                    throw new RuntimeException("Invalid bus trip combination");
                }

                // Calculate fare

                // Calculate fare - fixed version using totalRouteDistance
                try {
                    // Get base price
                    float basePrice = bus.getClassTypes().stream()
                            .filter(ct -> ct.getClassName().equalsIgnoreCase(ticket.getClassType()))
                            .findFirst()
                            .map(ClassType::getFare)
                            .orElseThrow(() -> new RuntimeException("Class type not found"));

                    // Calculate distance percentages
                    double boardingPercentage = 0.0;
                    double departurePercentage = 1.0; // Default to 100% for destination

                    // Find boarding percentage
                    if (busTrip.getOrigin().equalsIgnoreCase(ticket.getBoarding())) {
                        boardingPercentage = 0.0;
                    } else {
                        int cumulativeDistance = 0;
                        for (IntermediateStop stop : busTrip.getIntermediateStops()) {
                            cumulativeDistance += stop.getDistanceFromPrevious();
                            if (stop.getStopName().equalsIgnoreCase(ticket.getBoarding())) {
                                boardingPercentage = (double) cumulativeDistance / busTrip.getTotalRouteDistance();
                                break;
                            }
                        }
                    }

                    // Find departure percentage
                    if (!busTrip.getDestination().equalsIgnoreCase(ticket.getDeparture())) {
                        int cumulativeDistance = 0;
                        for (IntermediateStop stop : busTrip.getIntermediateStops()) {
                            cumulativeDistance += stop.getDistanceFromPrevious();
                            if (stop.getStopName().equalsIgnoreCase(ticket.getDeparture())) {
                                departurePercentage = (double) cumulativeDistance / busTrip.getTotalRouteDistance();
                                break;
                            }
                        }
                    }

                    // Calculate actual distance
                    int distance = (int) ((departurePercentage - boardingPercentage) * busTrip.getTotalRouteDistance());
                    float totalFare = (basePrice + (distance * 2)) * passengerCount;
                    ticket.setTotalFare(totalFare);

                } catch (Exception e) {
                    throw new RuntimeException("Fare calculation failed: " + e.getMessage());
                }
                // Handle seat selection
                if (ticket.getSeatNumber() != null && !ticket.getSeatNumber().isEmpty()) {
                    // Find the class ID for the selected class type
                    long classId = bus.getClassTypes().stream()
                            .filter(ct -> ct.getClassName().equalsIgnoreCase(ticket.getClassType()))
                            .findFirst()
                            .map(ClassType::getClassId)
                            .orElseThrow(() -> new RuntimeException("Class type not found"));

                    // Update multiple seats at once
                    Map<String, Boolean> seatResults = busServiceClient.updateMultipleSeats(
                            bus.getBusId(),
                            (int) classId,
                            ticket.getSeatNumber(),
                            false,  // mark as unavailable
                            token
                    );

                    // Check for failed seat updates
                    List<String> failedSeats = seatResults.entrySet().stream()
                            .filter(entry -> !entry.getValue())
                            .map(Map.Entry::getKey)
                            .collect(Collectors.toList());

                    if (!failedSeats.isEmpty()) {
                        throw new RuntimeException("Failed to book seats: " + String.join(", ", failedSeats));
                    }

                    ticket.setWaitingNumber(0);
                } else {

      //                   Handle waiting list
                        int baseWaitingNumber = ticketRepository.getMaxWaitingNumberByTransportId(
                                ticket.getTransportId(),
                                ticket.getTransportType()
                        );

                        List<String> waiting = new ArrayList<>();
                        for (int i = 0; i < passengerCount; i++) {
                            waiting.add("WL" + (baseWaitingNumber + i + 1));
                        }

                        ticket.setSeatNumber(waiting);
                        ticket.setStatus(Status.WAITING);
                        ticket.setWaitingNumber(baseWaitingNumber + passengerCount);
                    }
                }



            return ticketRepository.save(ticket);
        } catch (Exception e) {
            throw new RuntimeException("Reservation Failed: " + e.getMessage());
        }
    }







    @Override
    public List<Ticket> getAllTicket() {
        return ticketRepository.findAll();
    }

    @Override
    public Ticket getTicketById(Long id) {
        return ticketRepository.findById(id).orElse(null);
    }

    public Ticket updateTicket(Long id, Ticket updatedTicket){
        Optional<Ticket> optionalTicket = ticketRepository.findById(id);
        if (optionalTicket.isPresent()){
            Ticket existingTicket = optionalTicket.get();

            existingTicket.setTransportType(updatedTicket.getTransportType());
            existingTicket.setBookingDate(updatedTicket.getBookingDate());
            existingTicket.setJourneyDate(updatedTicket.getJourneyDate());
            existingTicket.setBoarding(updatedTicket.getBoarding());
            existingTicket.setDeparture(updatedTicket.getDeparture());

            return ticketRepository.save(existingTicket);
        }else {
            throw new EntityNotFoundException("Ticket not found !");
        }

    }

    @Override
    public void deleteTicketById(Long id) {

        ticketRepository.deleteById(id);
    }

    @Override
    public Ticket cancleTicket(long ticketId) {
       try {
           Ticket ticket = ticketRepository.findById(ticketId).
                   orElseThrow(() -> new RuntimeException("Ticket not Found ! "));

           ticket.setStatus(Status.CANCELLED);
           return ticketRepository.save(ticket);
       }catch(Exception e){
           throw new RuntimeException("Failed to Cancle Ticket ! ");
       }
    }

    public List<Ticket> findTicketsByUserId(long userId) {
        return ticketRepository.findByUserId(userId);
    }
}
