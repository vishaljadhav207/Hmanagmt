package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.OrganizationType;
import com.travel_platform.travel_platform.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

   @Query("SELECT COALESCE(MAX(t.waitingNumber), 0) FROM Ticket t " +
           "WHERE t.transportId = :transportId AND t.transportType = :transportType AND t.status = 'WAITING'")
   int getMaxWaitingNumberByTransportId(@Param("transportId") int transportId,
                                        @Param("transportType") OrganizationType transportType);

   List<Ticket> findByUserId(long userId);

}

