package com.travel_platform.travel_platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int train_id;

    @NotEmpty(message = "trainNo must not be empty")
    private int trainNo;

    @NotEmpty(message = "trainName must not be empty")
    private String trainName;

    @NotEmpty(message = "railwayZone must not be empty")
    private String railwayZone;

    @NotEmpty(message = "numberOfCoaches must not be empty")
    private String numberOfCoaches;

    @NotEmpty(message = "destination must not be empty")
    private String destination;

    @NotEmpty(message = "departFrom must not be empty")
    private String departFrom;
    private Long userId;

    @NotEmpty(message = "organization must not be empty")
    @ManyToOne
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @ManyToMany
    @JoinTable(
            name = "train_class_types",
            joinColumns = @JoinColumn(name = "train_id"),
            inverseJoinColumns = @JoinColumn(name = "class_id")
    )
    private List<ClassType> classTypes;
}


