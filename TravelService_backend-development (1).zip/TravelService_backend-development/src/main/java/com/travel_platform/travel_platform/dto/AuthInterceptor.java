package com.travel_platform.travel_platform.dto;
import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.utils.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.management.RuntimeMBeanException;
import java.nio.file.AccessDeniedException;
import java.util.Arrays;
import java.util.List;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
        if(!(handler instanceof HandlerMethod)){
            return true ;
        }

        String path = request.getRequestURI();
        if (path.matches("/api/user/login") ||
                path.matches("/api/user/register")
                || path.matches("/api/user/verifyOtp/.*")
                || path.matches("/api/user/verifyEmail/.*")
                || path.matches("/api/user/changePassword/.*")
                || path.matches("/api/user/owner/register")
                ||path.matches("/api/train/getTrainNoByTrainId/.*")
                ||path.matches("/api/getClassNameById/.*")
                ||path.matches("/api/organizations/getById/.*")
        ){
            return true; // Skip token check for public endpoints
        }

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if(authHeader == null || !authHeader.startsWith("Bearer ")){
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            throw new RuntimeException("Token Not Found or Invalid ! ");
        }

        String token = authHeader.substring(7);
        try{
            String role = jwtUtil.getRoleFromToken(token);
            request.setAttribute("role" , role);
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Authorize authorize = handlerMethod.getMethodAnnotation(Authorize.class);
            if(authorize != null ){
                String[] allowedRoles = authorize.value();
                if(Arrays.stream(allowedRoles).noneMatch(it->it.matches(role))){
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    throw new RuntimeException("Access Denied !! ");
                }
            }
            return true;
        }catch (Exception e){
            throw new RuntimeException("Authorization Failed  !!");
        }
   }

}
