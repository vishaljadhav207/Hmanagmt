package com.travel_platform.travel_platform.entity;

public enum Status {
    CONFIRM,CANCELLED,WAITING
}
