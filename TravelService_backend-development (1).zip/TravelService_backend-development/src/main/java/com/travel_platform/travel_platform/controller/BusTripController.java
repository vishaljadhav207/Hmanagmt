package com.travel_platform.travel_platform.controller;

import com.travel_platform.travel_platform.config.Authorize;
import com.travel_platform.travel_platform.dto.BusSearchRequest;
import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import com.travel_platform.travel_platform.service.BusTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/busTrips")
@CrossOrigin(origins = "*")
public class BusTripController {

    @Autowired
    private BusTripService busTripService;


    @PostMapping("/createBusTrip")
    public ResponseEntity<BusTrip> createBusTrip(@RequestBody BusTrip busTrip) {
        return busTripService.createBusTrip(busTrip);
    }

    @GetMapping("/getBusTripById/{id}")
    public ResponseEntity<BusTrip> getBusTripById(@PathVariable int id) {
        BusTrip trip = busTripService.getBusTripById(id);
        return ResponseEntity.ok(trip);
    }

    @GetMapping("/getAllBusTrips")
    public ResponseEntity<List<BusTrip>> getAllBusTrips(
            @RequestParam(value = "PageNumber",defaultValue = "0",required = false)int pageNumber,
            @RequestParam(value = "PageSize",defaultValue = "10",required = false)int pageSize,
            @RequestParam(value = "sortBy",defaultValue = "origin",required = false)String sortBy,
            @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir
    ) {
        List<BusTrip> trips = busTripService.getAllBusTrips(pageNumber, pageSize, sortBy, sortDir);
        return ResponseEntity.ok(trips);
    }

    @DeleteMapping("/deleteBusTrip/{id}")
    public ResponseEntity<Void> deleteBusTrip(@PathVariable int id) {
        busTripService.deleteBusTrip(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/updateBusTripById/{id}")
    public BusTrip updateBusTripById(@PathVariable int id, @RequestBody BusTrip busTrip){
        return busTripService.updateBusTripById(id,busTrip);

    }

    @GetMapping("/getBusTripByUserId/{id}")
    public ResponseEntity<List<BusTrip>> getBusTripByUserId(@PathVariable Long id) {
        try{
            List<BusTrip> busTrips = busTripService.getBusTripsByUserId(id);
            return ResponseEntity.ok(busTrips);
        }
        catch(Exception e){
            return ResponseEntity.noContent().build();
        }
    }


    @GetMapping("/getBusTripsByBusId/{busId}")
    public List<BusTrip> getBusTripsByBusId(@PathVariable int busId) {
        return busTripService.getBusTripsByBusId(busId);
    }


    @GetMapping("/search")
    public List<BusTrip> searchBusTrips(
            @RequestParam(required = false) String origin,
            @RequestParam(required = false) String destination,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate) {

        return busTripService.searchBusTrips(origin, destination, departureDate);
    }
}
