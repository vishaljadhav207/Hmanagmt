package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.client.UserServiceClient;
import com.travel_platform.travel_platform.dto.OrganizationResponseDTO;
import com.travel_platform.travel_platform.dto.UserDTO;
import com.travel_platform.travel_platform.entity.Organization;
import com.travel_platform.travel_platform.entity.OrganizationType;
import com.travel_platform.travel_platform.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.travel_platform.travel_platform.repository.OrganizationRepository;
import com.travel_platform.travel_platform.service.OrganizationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizationServiceImpl implements OrganizationService {

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private UserServiceClient userServiceClient;

    @Override
    public Organization createOrganization(Organization organization , String token) {
        if (organizationRepository.existsByOrgName(organization.getOrgName())) {
            throw new IllegalArgumentException("Organization with name " + organization.getOrgName() + " already exists");
        }

        // Validate userId from User Service
        UserDTO user = userServiceClient.getUserById(organization.getUserId(),token);
        if (user == null) {
            throw new IllegalArgumentException("Invalid userId: User not found in User Service");
        }

        return organizationRepository.save(organization);
    }


    @Override
    public Organization getOrganizationById(Long orgId) {
        return organizationRepository.findById(orgId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found with id: " + orgId));
    }

    @Override
    public List<Organization> getAllOrganizations(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort = null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<Organization> organizations = organizationRepository.findAll(pageable);
        return organizations.getContent();
    }

    @Override
    public List<Organization> getOrganizationsByType(OrganizationType type) {
        return organizationRepository.findByType(type);
    }

    @Override
    public Organization updateOrganization(Long orgId, Organization organizationDetails) {
        Organization organization = getOrganizationById(orgId);

        organization.setType(organizationDetails.getType());
        organization.setOrgName(organizationDetails.getOrgName());
        organization.setUserId(organizationDetails.getUserId());
        return organizationRepository.save(organization);
    }

    @Override
    public void deleteOrganization(Long orgId) {
        Organization organization = getOrganizationById(orgId);
        organizationRepository.delete(organization);
    }

    @Override
    public boolean organizationExists(String orgName) {
        return organizationRepository.existsByOrgName(orgName);
    }

    @Override
    public OrganizationResponseDTO getOrganizationWithUser(Long orgId , String token) {
        Organization org = getOrganizationById(orgId);
        UserDTO user = userServiceClient.getUserById(org.getUserId(),token);

        OrganizationResponseDTO dto = new OrganizationResponseDTO();
        dto.setOrgId(org.getOrgId());
        dto.setOrgName(org.getOrgName());
        dto.setType(org.getType());
        dto.setUser(user);
        return dto;
    }
}
