package com.travel_platform.travel_platform.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.time.LocalTime;

@RestControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler(SeatUnavailableException.class)
    public ResponseEntity<ErrorDetails> seatUnavailable(SeatUnavailableException e){
       ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(), HttpStatus.NOT_FOUND.value(),"Seats Unavailable");
       return new ResponseEntity<>(errorDetails,HttpStatus.NOT_FOUND);
  }
}
