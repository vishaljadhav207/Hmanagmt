package com.travel_platform.travel_platform.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
@Entity
public class Passenger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "passenger_id")
    private int passengerId;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "ticket_id", nullable = false)
//    private Ticket ticket;

    @NotEmpty(message = "name must not be empty")
    @Column(name = "name", nullable = false)
    private String name;

    @NotEmpty(message = "age must not be empty")
    @Column(name = "age")
    private int age;

    @NotEmpty(message = "gender must not be empty")
    @Column(name = "gender")
    private String gender;

    @NotEmpty(message = "seatNumber must not be empty")
    @Column(name = "seat_number")
    private String seatNumber;

  @Column(name = "Pnr_number")
    private String pnrNumber;
}
