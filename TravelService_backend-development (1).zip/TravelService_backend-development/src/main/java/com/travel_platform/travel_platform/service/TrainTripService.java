package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.TrainTrip;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.List;

public interface TrainTripService {

    ResponseEntity<TrainTrip> createTrainTrip(TrainTrip trainTrip);
    TrainTrip getTrainTripById(int id);
    List<TrainTrip> getAllTrainTrip(int pageNumber, int pageSize, String sortBy, String sortDir);
    void deleteTrainTrip(int id);
    TrainTrip updateTrainTripById(int id, TrainTrip trainTrip);
    List<TrainTrip> getTrainTripByUserId(Long id);



    List<TrainTrip> searchTrainTrips(String origin, String destination, LocalDate departureDate);
}
