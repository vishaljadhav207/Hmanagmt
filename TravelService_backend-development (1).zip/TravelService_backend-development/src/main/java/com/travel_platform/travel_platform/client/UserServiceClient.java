package com.travel_platform.travel_platform.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.travel_platform.travel_platform.config.UserIdentityDetailsService;
import com.travel_platform.travel_platform.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;

@Service
public class UserServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    private final String USER_SERVICE_BASE_URL = "http://localhost:8080";

    public UserDTO getUserById(Long userId, String token) {
        String url = USER_SERVICE_BASE_URL + "/api/user/users/" + userId;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION, token);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            String response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
            return mapper.readValue(response, UserDTO.class);
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        } catch (Exception e) {
            // Catch all other errors like 500, service unavailable, etc.
            System.err.println("Error calling User Service: " + e.getMessage());
            return null;
        }
    }

}
