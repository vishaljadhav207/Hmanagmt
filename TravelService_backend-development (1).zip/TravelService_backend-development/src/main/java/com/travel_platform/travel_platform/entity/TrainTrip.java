package com.travel_platform.travel_platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "train_trip")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainTrip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int trainTripId;

    @NotEmpty(message = "origin must not be empty")
    private String origin;

    @NotEmpty(message = "destination must not be empty")
    private String destination;

    @NotEmpty(message = "departureDate must not be empty")
    private LocalDate departureDate;

    @NotEmpty(message = "arrivalDate must not be empty")
    private LocalDate arrivalDate;

    @ManyToOne
    @JoinColumn(name = "train_id", nullable = false)
    private Train train;

    @ElementCollection
    @CollectionTable(name = "train_trip_stops", joinColumns = @JoinColumn(name = "train_trip_id"))
    private List<IntermediateStop> intermediateStops;

}
