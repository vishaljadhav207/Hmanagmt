package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.BusTrip;
import com.travel_platform.travel_platform.entity.FlightTrip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface FlightTripRepository extends JpaRepository<FlightTrip,Integer> {
    @Query("SELECT f FROM FlightTrip f WHERE f.flight.id = :flightId")
    FlightTrip findByFlightId(@Param("flightId") int flightId);

    List<FlightTrip> findByFlight_UserId(Long userId);



     List<FlightTrip> findByOriginAndDestinationAndDepartureDate(
        String origin,
        String destination,
        LocalDate departureDate);

}
