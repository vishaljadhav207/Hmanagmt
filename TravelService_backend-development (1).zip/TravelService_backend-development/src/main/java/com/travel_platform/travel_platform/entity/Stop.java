package com.travel_platform.travel_platform.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "stop")
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Stop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int stopId;

    @Enumerated(EnumType.STRING)
    private TransportType transportType;

    private String stopName;
    private LocalDateTime arrivalTime;
    private LocalDateTime departureTime;

    @Enumerated(EnumType.STRING)
    private StopType stopType;

    @ManyToOne
    @JoinColumn(name = "train_id")
    private Train train;

    @ManyToOne
    @JoinColumn(name = "bus_id")
    private Bus bus;

    @ManyToOne
    @JoinColumn(name = "flight_id")
    private Flight flight;

    @ManyToOne
    @JoinColumn(name = "bus_trip_id")
    private BusTrip busTrip;

    @ManyToOne
    @JoinColumn(name = "train_trip_id")
    @JsonBackReference
    private TrainTrip trainTrip;


    @ManyToOne
    @JoinColumn(name = "flight_trip_id")
    @JsonBackReference
    private FlightTrip flightTrip;

    private Integer sequenceNumber;
}
