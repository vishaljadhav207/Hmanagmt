package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.TransportType;

import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.service.ClassTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassTypeServiceImpl implements ClassTypeService {

    @Autowired
    private ClassTypeRepository repository;

    @Override
    public ClassType createClassType(ClassType classType) {
        return repository.save(classType);
    }

    @Override
    public ClassType updateClassType(int id, ClassType classType) {
        return repository.findById(id)
                .map(existing -> {
                    existing.setClassName(classType.getClassName());
                    existing.setAvailability(classType.getAvailability());
                    existing.setStatus(classType.getStatus());
                    existing.setFare(classType.getFare());
                    existing.setTransportType(classType.getTransportType());
                    return repository.save(existing);
                })
                .orElse(null);
    }

    @Override
    public boolean deleteClassType(int id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public ClassType getClassTypeById(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public List<ClassType> getAllClassTypes(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<ClassType> page = repository.findAll(pageable);
        return page.getContent();
    }

    @Override
    public String getClassNameById(int id) {
        return repository.findById(id)
                .map(ClassType::getClassName)
                .orElseThrow(() -> new RuntimeException("Class not found with ID: " + id));
    }

    @Override
    public List<ClassType> getClassTypesByTransportType(TransportType transportType) {
        return repository.findByTransportType(transportType);
    }
}