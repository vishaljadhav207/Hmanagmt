package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.TransportType;


import java.util.List;

public interface ClassTypeService {
    ClassType createClassType(ClassType classType);
    ClassType updateClassType(int id, ClassType classType);
    boolean deleteClassType(int id);
    ClassType getClassTypeById(int id);
    List<ClassType> getAllClassTypes(int pageNumber, int pageSize, String sortBy, String sortDir);
    String getClassNameById(int id);
    List<ClassType> getClassTypesByTransportType(TransportType transportType);
}
