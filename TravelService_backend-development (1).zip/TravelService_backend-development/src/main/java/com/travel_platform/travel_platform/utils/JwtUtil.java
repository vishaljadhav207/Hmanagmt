package com.travel_platform.travel_platform.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class JwtUtil {

    private static final String SECRET_KEY = "y6y7nD1Opa4QHq5XZ8D3bLqIB4CgHlFZ5gIhBX5pUr5WHeGmhrjexXj7t2iqN2rS5fbM8yP6Xf+JHSPYyVgYbg==";

    public long extractUserId(String token){
        Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
        Integer userIdObj = (Integer) claims.get("userId");
        return (long)userIdObj;
    }


    public String extractToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
    private  Date extractExpiration(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
    }

    public boolean validateToken(String token, String email) {
        return (email.equals(extractToken(token)) && !isTokenExpired(token));
    }
    public String getRoleFromToken(String token){
        Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
        String role = (String) claims.get("role");
        return role;
    }
}
