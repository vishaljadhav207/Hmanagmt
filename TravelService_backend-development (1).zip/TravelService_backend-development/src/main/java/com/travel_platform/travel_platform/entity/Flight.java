package com.travel_platform.travel_platform.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int flight_id;

    @NotEmpty(message = "flight_no must not be empty")
    private String flight_no;

    @NotEmpty(message = "airline must not be empty")
    private String airline;

    @NotEmpty(message = "departFrom must not be empty")
    private String departFrom;

    @NotEmpty(message = "destination must not be empty")
    private String destination;

    private Long userId;

    @NotEmpty(message = "organization must not be empty")
    @ManyToOne
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @ManyToMany
    @JoinTable(
            name = "flight_class_types",
            joinColumns = @JoinColumn(name = "flight_id"),
            inverseJoinColumns = @JoinColumn(name = "class_id")
    )
    private List<ClassType> classTypes;
}


