package com.travel_platform.travel_platform.service;

import com.travel_platform.travel_platform.entity.Ticket;

import java.util.List;

public interface TicketService {
    Ticket saveTicket(Ticket ticket , String token);

    List<Ticket> getAllTicket();

    Ticket getTicketById(Long id);

    Ticket updateTicket(Long id, Ticket ticket);

    void deleteTicketById(Long id);

    Ticket cancleTicket(long ticketId);

    List<Ticket> findTicketsByUserId(long userId);
}

