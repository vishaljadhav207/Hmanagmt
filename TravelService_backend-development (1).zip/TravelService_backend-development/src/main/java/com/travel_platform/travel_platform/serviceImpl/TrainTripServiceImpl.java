package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.ClassType;
import com.travel_platform.travel_platform.entity.Train;
import com.travel_platform.travel_platform.entity.TrainTrip;
import com.travel_platform.travel_platform.exception.ResourceNotFoundException;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.repository.TrainTripRepository;
import com.travel_platform.travel_platform.service.TrainService;
import com.travel_platform.travel_platform.service.TrainTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class TrainTripServiceImpl implements TrainTripService {

    @Autowired
    private TrainTripRepository trainTripRepository;
    @Autowired
    private TrainService trainService;
    @Autowired
    private ClassTypeRepository classTypeRepository;

    //    @Override
//    public ResponseEntity<TrainTrip> createTrainTrip(TrainTrip trainTrip) {
//        TrainTrip savedTrip = trainTripRepository.save(trainTrip);
//        return ResponseEntity.ok(savedTrip);
//    }
    @Override
    public ResponseEntity<TrainTrip> createTrainTrip(TrainTrip trainTrip) {
        if (trainTrip.getTrain() == null || trainTrip.getTrain().getTrain_id() == 0) {
            throw new IllegalArgumentException("Train ID is missing or invalid");
        }

        Train managedTrain = trainService.getTrainById(trainTrip.getTrain().getTrain_id());
        trainTrip.setTrain(managedTrain);

        // Save trip
        TrainTrip savedTrip = trainTripRepository.save(trainTrip);
        return ResponseEntity.ok(savedTrip);
    }

    @Override
    public TrainTrip getTrainTripById(int id) {
        return trainTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TrainTrip not found with id: " + id));
    }

    @Override
    public List<TrainTrip> getAllTrainTrip(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort=null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<TrainTrip> trainTripPage = trainTripRepository.findAll(pageable);
        List<TrainTrip> trainTripList = trainTripPage.getContent();
        return trainTripList;
    }

    @Override
    public void deleteTrainTrip(int id) {
        TrainTrip trip = getTrainTripById(id);
        trainTripRepository.delete(trip);
    }

    @Override
    public TrainTrip updateTrainTripById(int id, TrainTrip trainTrip) {
        TrainTrip existingTrip = trainTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TrainTrip not found with id: " + id));

        existingTrip.setOrigin(trainTrip.getOrigin());
        existingTrip.setDestination(trainTrip.getDestination());
        existingTrip.setDepartureDate(trainTrip.getDepartureDate());
        existingTrip.setArrivalDate(trainTrip.getArrivalDate());
        existingTrip.setTrain(trainTrip.getTrain());
        existingTrip.setIntermediateStops(trainTrip.getIntermediateStops());

        return trainTripRepository.save(existingTrip);
    }

    @Override
    public List<TrainTrip> getTrainTripByUserId(Long id) {
        return trainTripRepository.findByTrain_UserId(id);
    }



    @Override
    public List<TrainTrip> searchTrainTrips(String origin, String destination, LocalDate departureDate){
        return trainTripRepository.findByOriginAndDestinationAndDepartureDate(origin, destination, departureDate);
    }

}
