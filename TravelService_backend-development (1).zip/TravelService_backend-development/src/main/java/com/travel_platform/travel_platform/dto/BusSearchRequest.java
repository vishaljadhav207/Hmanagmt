package com.travel_platform.travel_platform.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class BusSearchRequest {
    private String origin;
    private String destination;
    private LocalDate departureDate;

}