package com.travel_platform.travel_platform.entity;

public enum StopType {
    STATION, BUS_STOP, AIRPORT, INTERMEDIATE
}
