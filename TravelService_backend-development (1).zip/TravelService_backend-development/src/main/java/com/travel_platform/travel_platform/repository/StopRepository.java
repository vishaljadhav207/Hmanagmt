package com.travel_platform.travel_platform.repository;

import com.travel_platform.travel_platform.entity.Stop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StopRepository extends JpaRepository<Stop, Integer> {
    List<Stop> findByStopName(String stopName);
    List<Stop> findByBusTripBusTripId(Integer busTripId);
}
