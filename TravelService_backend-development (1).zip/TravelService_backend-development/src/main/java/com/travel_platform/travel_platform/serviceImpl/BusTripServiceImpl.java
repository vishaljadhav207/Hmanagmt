package com.travel_platform.travel_platform.serviceImpl;

import com.travel_platform.travel_platform.dto.BusSearchRequest;
import com.travel_platform.travel_platform.dto.TrainSearchRequest;
import com.travel_platform.travel_platform.entity.*;
import com.travel_platform.travel_platform.exception.ResourceNotFoundException;
import com.travel_platform.travel_platform.repository.BusRepository;
import com.travel_platform.travel_platform.repository.BusTripRepository;
import com.travel_platform.travel_platform.repository.ClassTypeRepository;
import com.travel_platform.travel_platform.service.BusService;
import com.travel_platform.travel_platform.service.BusTripService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.List;

@Service
public  class BusTripServiceImpl implements BusTripService {

    @Autowired
    private BusTripRepository busTripRepository;

    @Autowired
    private BusService busService;

    @Autowired
    private ClassTypeRepository classTypeRepository;

    @Override
    public ResponseEntity<BusTrip> createBusTrip(BusTrip busTrip) {
        if (busTrip.getBus() == null || busTrip.getBus().getBusId() == 0) {
            throw new IllegalArgumentException("Bus ID is missing or invalid");
        }
        Bus managedBus = busService.getBusById(busTrip.getBus().getBusId());
        busTrip.setBus(managedBus);

        BusTrip savedTrip = busTripRepository.save(busTrip);
        return ResponseEntity.ok(savedTrip);
    }

    @Override
    public BusTrip getBusTripById(int id) {
        return busTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BusTrip not found with id: " + id));
    }

    @Override
    public List<BusTrip> getAllBusTrips(int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort = null;
        if(sortDir.equalsIgnoreCase("asc"))
        {
            sort = Sort.by(sortBy).ascending();
        }
        else{
            sort = Sort.by(sortBy).descending();
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<BusTrip> pageBustrip=busTripRepository.findAll(pageable);
        return pageBustrip.getContent();

    }

    @Override
    public void deleteBusTrip(int id) {
        BusTrip trip = getBusTripById(id);
        busTripRepository.delete(trip);
    }

    @Override
    public BusTrip updateBusTripById(int id, BusTrip busTrip) {
        BusTrip existingTrip = busTripRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BusTrip not found with id: " + id));

        existingTrip.setOrigin(busTrip.getOrigin());
        existingTrip.setDestination(busTrip.getDestination());
        existingTrip.setDepartureDate(busTrip.getDepartureDate());
        existingTrip.setArrivalDate(busTrip.getArrivalDate());
        existingTrip.setBus(busTrip.getBus());
        existingTrip.setIntermediateStops(busTrip.getIntermediateStops());
        return busTripRepository.save(existingTrip);
    }

    @Override
    public List<BusTrip> getBusTripsByUserId(Long id) {
        return busTripRepository.findByBus_UserId(id);
    }



    @Override
    public List<BusTrip> getBusTripsByBusId(int busId) {
        return busTripRepository.findByBus_BusId(busId);
    }


    @Override
    public List<BusTrip> searchBusTrips(String origin,String destination,LocalDate departureDate)
    {
        return busTripRepository.findByOriginAndDestinationAndDepartureDate(origin, destination, departureDate);
    }

    @Override
    public List<BusTrip> getBookingHistory(Long userId, int pageNumber, int pageSize, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ?
                Sort.by(sortBy).ascending() :
                Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<BusTrip> page = busTripRepository.findByBus_UserId(userId, pageable);

        return page.getContent();
    }
}
