package com.travel_platform.travel_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
