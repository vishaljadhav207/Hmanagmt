import { use } from "react";
import axiosInstance, { get } from "./axiosInstance";
import { createAsyncThunk } from "@reduxjs/toolkit";


export const createAndAddAmenityToHotel = createAsyncThunk(
  'hotels/createAndAddAmenity',
  async ({ hotelId, amenityName }, { rejectWithValue }) => {
    try {
      // 1. First create the amenity
      const createResponse = await axiosInstance.post('/masterAmenity/create', {
        amenityName
      });
      
      const newAmenityId = createResponse.data.data.id;

      // 2. Then add it to the hotel
      await axiosInstance.post(
        `/masterAmenity/addAmenitiesToHotel/${hotelId}`,
        [newAmenityId] // Pass as array
      );

      // 3. Return the new amenity data
      return createResponse.data.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Add Amenity
export const addAmenities = createAsyncThunk(
  "hotels/addAmenities",
  async (amenityData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post("/masterAmenity/create", amenityData);
      return response.data.data; 
    } catch (error) {
      console.error("Error adding amenity:", error);
      return rejectWithValue(error.response?.data || "Failed to add amenity");
    }
  }
);

export const deleteAmenity = createAsyncThunk(
  "hotels/deleteAmenity",
  async ({ hotelId, amenityId }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(
        `/hotel/hotelAmenity?hotelId=${hotelId}&amenityId=${amenityId}`
      );
      return { hotelId, amenityId }; // Return both IDs for the reducer
    } catch (error) {
      console.error("Error deleting amenity:", error.response?.data || error.message);
      return rejectWithValue({
        message: error.response?.data?.message || "Failed to delete amenity",
        status: error.response?.status
      });
    }
  }
);

export const fetchHotelOwners = createAsyncThunk(
  "hotels/fetchHotelOwners",
  async ({ page = 0, size = 15 } = {}, { rejectWithValue }) => {
    try {
      const response = await get(`/user/allUsers?page=${page}&size=${size}`);
      const users = response.data?.data?.data || [];
      const hotelOwners = users.filter((user) => user.role?.roleId === 1002);
      return hotelOwners;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

export const fetchHotelsByLocation = createAsyncThunk(
  "hotels/fetchHotelsByLocation",
  async (_, { rejectWithValue }) => {
    try {
      const response = await get(`/hotel/hotelLocation`);
      return response.data.data; 
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
export const fetchHotelsByCity = createAsyncThunk(
  "hotels/fetchHotelsByCity",
  async ({ city, hotelRooms = 1, page = 0, size = 20 }) => {
    const response = await get(
      `/hotel/hotelCity?city=${city}&hotelRooms=${hotelRooms}&page=${page}&size=${size}`
    );
    return {
      hotels: response.data.data,
      total: response.data.total,
    };
  }
);
export const getAllHotels = createAsyncThunk(
  "hotels/getAllHotels",
  async ({ page, size }) => { 
    const response = await get(`/hotel/getAll?page=${page}&size=${size}`);
    return response.data.data;
  }
);

// Fetch Hotels by Owner (User ID)
export const fetchHotelsByOwner = createAsyncThunk(
  "hotels/fetchHotelsByOwner",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/hotel/byUserId?userId=${userId}`);
      return response.data.data; // Return the hotels for the specific owner
    } catch (error) {
      console.error("Error fetching hotels by owner:", error);
      return rejectWithValue(error.response?.data || "Failed to fetch hotels by owner");
    }
  }
);

export const fetchHotels = createAsyncThunk(
  "hotels/fetchHotels",
  async ({  city, hotelRooms = 1, page = 0, size = 20  } = {}) => {
    const response = await get(
      `/hotel/hotelCity?city=${city}&hotelRooms=${hotelRooms}&page=${page}&size=${size}`
    );
      return {
        hotels: response.data.data,
        total: response.data.total,
    };
  }
);


// Add this to your existing hotelApi.js
export const uploadHotelImage = createAsyncThunk(
  "hotels/uploadHotelImage",
  async (uploadData, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      formData.append("imageFile", uploadData.image);
      formData.append("hotelId", uploadData.hotelId);

      const response = await axiosInstance.post("/images/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      
      return response.data.data;
    } catch (error) {
      console.error("Error uploading image:", error);
      return rejectWithValue(error.response?.data || "Failed to upload image");
    }
  }
);

// Get images by hotel ID
export const fetchHotelImages = createAsyncThunk(
  "hotels/fetchHotelImages",
  async (hotelId, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/images/getImagesByHotelAndRoom?hotelId=${hotelId}`);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || "Failed to fetch images");
    }
  }
);


//delete image by image id
export const deleteHotelImage = createAsyncThunk(
  "hotels/deleteHotelImage",
  async (imageId, { rejectWithValue }) => {
    try {
      await axiosInstance.delete(`/images/deleteImage/${imageId}`);
      return imageId;
    } catch (error) {
      return rejectWithValue(error.response?.data || "Failed to delete image");
    }
  }
);



// In your hotelApi.js
export const fetchHotelById = createAsyncThunk(
  "hotels/fetchHotelById",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await get(`/hotel/byUserId?userId=${userId}`);
      return response.data; 
    } catch (error) {
      console.error("Error fetching hotel by ID:", error);
      return rejectWithValue(error.response?.data || "Failed to fetch hotel");
    }
  }
);

export const fetchAmenities = createAsyncThunk(
  "hotels/fetchAmenities",
  async ({ page = 0, size = 20 } = {}, { rejectWithValue }) => {
    try {
      const response = await get(`/masterAmenity/getAll?page=${page}&size=${size}`);
      const amenities = response.data?.data?.data || [];
      return amenities;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

export const saveHotel = createAsyncThunk(
  "hotels/saveHotel",
  async (hotelData) => {
    const response = await axiosInstance.post("/hotel/save", hotelData);
    return response.data.data;
  }
);         

export const updateHotel = createAsyncThunk(
  "hotels/updateHotel",
  async (hotelData) => {
    const response = await axiosInstance.put(`/hotel/update/${hotelData.hotelId}`, hotelData);
    return response.data.data;
  }
);
 

export const deleteHotel = createAsyncThunk(
  "hotels/deleteHotel",
  async (hotelId) => {
    await axiosInstance.delete(`/hotel/deleteHotel/${hotelId}`);
    return hotelId;
  }
);

