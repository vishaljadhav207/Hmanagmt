import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";
import axiosInstance from "./axiosInstance";

// Fetch all flights
export const getAllFlights = createAsyncThunk(
  "flights/getAllFlights",
  async ({ page = 0, size = 50 }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/flight/getAllFlight?page=${page}&size=${size}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);


export const getFlightByOrgId = createAsyncThunk(
  "FLights/getByOrgId",
  async ({
    orgId,
    pageNumber,
    pageSize,
    sortBy = "airline",
    sortDir = "asc",
  }) => {
    const response = await travelAxios.get(
      `/flight/getFlightByOrgId/${orgId}?Pagenumber=${pageNumber}&PageSize=${pageSize}&sortBy=${sortBy}&sortDir=${sortDir}`
    );

    return {
      flights: response.data.data,
      totalPages: response.data.totalPages, // This should come from backend
      totalItems: response.data.totalItems, // This should come from backend
    };
  }
);

// Fetch flight supervisors (roleId 3002) - example roleId for flight supervisors
export const fetchFlightSupervisors = createAsyncThunk(
  "flights/fetchFlightSupervisors",
  async ({ page = 0, size = 60 } = {}, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(
        `/user/allUsers?page=${page}&size=${size}`
      );

      console.log("API Response:", response);

      const users =
        response?.data?.data?.data && Array.isArray(response.data.data.data)
          ? response.data.data.data
          : [];

      const supervisors = users.filter((user) => user.role?.roleId === 3002);

      return supervisors;
    } catch (err) {
      console.error("Error fetching flight supervisors:", err);

      return rejectWithValue(err.response?.data?.message || err.message);
    }
  }
);

// Save a new flight
export const saveFlight = createAsyncThunk(
  "flights/saveFlight",
  async (flightData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/flight/saveFlight", flightData);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// Update an existing flight
export const updateFlight = createAsyncThunk(
  "flights/updateFlight",
  async ({ flightId, ...flightData }, { rejectWithValue }) => {
    try {
      const payload = {
        ...flightData,
        flight_id: flightId,
      };

      const response = await travelAxios.put(
        `/flight/updateFlight/${flightId}`,
        payload
      );

      return {
        ...response.data.data,
        flight_id: flightId,
      };
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message);
    }
  }
);

// Delete a flight
export const deleteFlight = createAsyncThunk(
  "flights/deleteFlight",
  async (flightId, { rejectWithValue }) => {
    try {
      await travelAxios.delete(`/flight/deleteFlightById/${flightId}`);
      return flightId;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchFlightsByUserId = createAsyncThunk(
  "flights/fetchByUserId",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/flight/getFlightByUserId/${userId}`
      );
      return response.data.data; // Return the data array directly
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);
