import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";
import axiosInstance from "./axiosInstance";
import seatAxios from "./seatAxios";
import axios from "axios";

const API_BASE_URL = "http://localhost:8082/api";

export const getAllBuses = createAsyncThunk(
  "buses/getAllBuses",
  async ({ page = 0, size = 50 }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/busTrips/getAllBusTrips?page=${page}&size=${size}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to fetch buses"
      );
    }
  }
);

export const fetchBusSupervisors = createAsyncThunk(
  "buses/fetchBusSupervisors",
  async ({ page = 0, size = 60 } = {}, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(
        `/user/allUsers?page=${page}&size=${size}`
      );

      const users = response?.data?.data?.data || [];
      const supervisors = users.filter((user) => user.role?.roleId === 4002);

      return supervisors;
    } catch (err) {
      return rejectWithValue(err.message || "Failed to fetch bus supervisors");
    }
  }
);


export const saveBus = createAsyncThunk(
  "buses/saveBus",
  async (busData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/bus/saveBus", busData);
      return response.data; // Ensure this returns the full bus object with busId
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to save bus"
      );
    }
  }
);

// busApi.js
export const getClassTypesByTransportType = createAsyncThunk(
  "buses/getClassTypesByTransportType",
  async (type, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/getClassTypesByTransportType?type=${type}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message ||
          err.message ||
          "Failed to fetch class types"
      );
    }
  }
);




export const updateBus = createAsyncThunk(
  "buses/updateBus",
  async ({ busId, ...busData }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.put(
        `/bus/updateBusById/${busId}`,
        busData
      );
      return { ...response.data, busId }; // Explicitly include busId in response
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to update bus"
      );
    }
  }
);

export const getBusByOrgId = createAsyncThunk(
  "buses/getByOrgId",
  async ({ orgId, pageNumber, pageSize, sortBy, sortDir }) => {
    const response = await travelAxios.get(
      `/bus/getBusByOrgId/${orgId}?pageNumber=${pageNumber}&pageSize=${pageSize}` +
        (sortBy ? `&sortBy=${sortBy}` : "") +
        (sortDir ? `&sortDir=${sortDir}` : "")
    );

    return {
      buses: response.data.data,
      totalPages: response.data.totalPages || 1,
      totalItems: response.data.totalItems || response.data.data.length,
    };
  }
);


export const deleteBus = createAsyncThunk(
  "buses/deleteBus",
  async (busId, { rejectWithValue }) => {
    try {
      await travelAxios.delete(`/bus/deleteBusById/${busId}`);
      return busId;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to delete bus"
      );
    }
  }
);

export const getBusTripById = createAsyncThunk(
  "buses/getBusTripById",
  async (busTripId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/busTrips/getBusTripById/${busTripId}`
      );
      console.log(response.data, "bus trip data api");
      return response.data;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to fetch bus trip"
      );
    }
  }
);

export const savePassenger = createAsyncThunk(
  "buses/savePassenger",
  async (passengerData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/passenger/savePassenger", passengerData);
      return response.data;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to save passenger"
      );
    }
  }
);

export const saveTicket = createAsyncThunk(
  "tickets/saveTicket",
  async (ticketData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/ticket/saveTicket", ticketData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      return response.data;
    } catch (err) {
      // Enhanced error handling
      if (err.code === 'ERR_NETWORK') {
        return rejectWithValue("Network error - please check your connection");
      }
      if (err.response?.status === 403) {
        return rejectWithValue("CORS error detected - check backend configuration");
      }
      return rejectWithValue(
        err.response?.data?.message || 
        err.message || 
        "Failed to save ticket"
      );
    }
  }
);

export const getAllBusSeats = createAsyncThunk(
  "buses/getAllBusSeats",
  async ({ rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${API_BASE_URL}/bus-seats/getAllBusSeat`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getBusTripsByUserId = createAsyncThunk(
  "busTrips/getBusTripsByUserId",
  async (userId, { rejectWithValue }) => {
    try {
       const response = await travelAxios.get(`/busTrips/getBusTripByUserId/${userId}`);
      console.log("API Response:", response.data); 
      return response.data; 
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message ||
          err.message ||
          "Failed to fetch bus trips"
      );
    }
  }
);

export const getBusByUserId = createAsyncThunk(
  "/bus/getBusByUserId",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(`/bus/getBusByUserId/${userId}`);
      console.log("API Response:", response.data);
      return response.data.data; 
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message || "Failed to fetch bus trips");
    }
  }
);

export const getBusTripsByBusId = createAsyncThunk(

  "busTrips/getBusTripsByBusId",
  async (busId, { rejectWithValue }) => {
    try {
      if (!busId) {
        throw new Error("Bus ID is required");
      }
      const response = await travelAxios.get(
        `/busTrips/getBusTripsByBusId/${busId}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);
export const deleteBusTrip = createAsyncThunk(
  "busTrips/deleteBusTrip",
  async (busTripId) => {
    await travelAxios.delete(`/busTrips/deleteBusTrip/${busTripId}`);
    return busTripId;
  }
);

export const createBusTrip = createAsyncThunk(
  "busTrips/createBusTrip",
  async (tripData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post('/busTrips/createBusTrip', tripData);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message || "Failed to create trip");
    }
  }
);
export const updateBusTrip = createAsyncThunk(
  "busTrips/updateBusTripById",
  async ({ tripId, tripData }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.put(
        `/busTrips/updateBusTripById/${tripId}`,
        tripData
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message || "Failed to update trip");
    }
  }
);
