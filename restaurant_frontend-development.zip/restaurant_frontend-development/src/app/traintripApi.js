import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";
import seatAxios from "./seatAxios";

// Fetch all train trips
export const getAllTrainTrips = createAsyncThunk(
  "traintrips/getAllTraintrips",
  async ({ page = 0, size = 10 }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/trainTrips/getAllTrainTrips?page=${page}&size=${size}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);
// Add this to your existing traintripApi.js
export const saveTickett = createAsyncThunk(
  "tickets/saveTickett",
  async (ticketData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/ticket/saveTicket", ticketData);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);
export const getTrainTripById = createAsyncThunk(
  "traintrips/getTrainTripById",
  async (trainTripId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/trainTrips/getTrainTripById/${trainTripId}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);
export const getTrainTripsByUserId = createAsyncThunk(
  "traintrips/getTrainTripsByUserId",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/trainTrips/getTrainTripByUserId/${userId}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const updateTrainTrip = createAsyncThunk(
  "traintrips/updateTrainTripById",
  async ({ trainTripId, updatedData }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.put(
        `/trainTrips/updateTrainTripById/${trainTripId}`,
        updatedData
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const deleteTrain = createAsyncThunk(
  "traintrips/deleteTrainTrip",
  async (trainId, { rejectWithValue }) => {
    try {
      await travelAxios.delete(`/trainTrips/deleteTrainTrip/${trainId}`);
      return trainId;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const getTrainSeatsByTrainId = createAsyncThunk(
  "traintrips/getTrainSeatsByTrainId",
  async (trainId, { rejectWithValue }) => {
    try {
      const response = await seatAxios.get(
        `/train-seats/getTrainSeatsByTrainId?trainId=${trainId}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);


export const searchTrainTrips = createAsyncThunk(
  "traintrips/searchTrainTrips",
  async (searchData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get("/trainTrips/search", {
        params: {
          origin: searchData.origin,
          destination: searchData.destination,
          departureDate: searchData.departureDate
        }
      });
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

export const addTrainTrip = createAsyncThunk(
  "trainTrips/createTrainTrip",
  async (trainTripData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post(
        "/trainTrips/createTrainTrip",
        trainTripData
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);