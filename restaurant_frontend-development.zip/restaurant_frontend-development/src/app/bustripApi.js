import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";


// Fetch all train trips 
export const getAllBusTrips = createAsyncThunk(
    "busTrips/getAllBusTrips",
    async ({ page = 0, size = 10 }, { rejectWithValue }) => {
      try {
        const response = await travelAxios.get(
          `/busTrips/getAllBusTrips?page=${page}&size=${size}`
        );
        return response.data;
      } catch (err) {
        return rejectWithValue(err.message);
      }
    }
  );

  // Add this to your existing traintripApi.js
  export const saveTickett = createAsyncThunk(
    "tickets/saveTickett",
    async (ticketData, { rejectWithValue }) => {
      try {
        const response = await travelAxios.post("/ticket/saveTicket", ticketData);
        return response.data;
      } catch (err) {
        return rejectWithValue(err.response?.data || err.message);
      }
    }
  );

 export const getBusTripById = createAsyncThunk(
  "buses/getBusTripById",
  async (busTripId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(`/busTrips/getBusTripById/${busTripId}`);
      console.log(response.data,"bus trip data api");
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message || "Failed to fetch bus trip");
    }
  }
);

export const searchBusTrips = createAsyncThunk(
  "busTrips/searchBusTrips",
  async (searchData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get("busTrips/search", {
        params: {
          origin: searchData.origin,
          destination: searchData.destination,
          departureDate: searchData.departureDate
        }
      });
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);