import { KEY } from "../utils/Constant";
import axiosInstance from "./axiosInstance";

const getAuthToken = () => {
  return localStorage.getItem(KEY.TOKEN);
};

export const addBookingRecord = async (bookingData) => {
  try {
    const token = getAuthToken();

    const response = await axiosInstance.post(
      `/booking/addRecord`,
      bookingData
    );
    console.log("Booking response:", response.data);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

export const getBookingRecords = async () => {
  try {
    const token = getAuthToken();

    const response = await axiosInstance.get(`/booking/getRecords`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

export const fetchHotelImage = async (hotelId) => {
  try {
    const response = await axiosInstance.get(
      `/images/getImageById/${hotelId}`,
      {
        responseType: "blob",
      }
    );
    return URL.createObjectURL(response.data);
  } catch (error) {
    console.error("Error fetching image:", error);
    return "/placeholder-image.jpg";
  }
};

export const createBooking = addBookingRecord;
