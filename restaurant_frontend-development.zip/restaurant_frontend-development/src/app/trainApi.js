import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";
import axiosInstance from "./axiosInstance";

// Fetch all trains
export const getAllTrains = createAsyncThunk(
  "trains/getAllTrains",
  async ({ page = 0, size = 50 }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/train/getAllTrain?page=${page}&size=${size}`
      );
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);
export const getTrainByUserId = createAsyncThunk(
  "trains/getTrainByUserId",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get(
        `/train/getTrainByUserId/${userId}`
      );
      console.log(response, "response at getTrainByUserId");
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const getTrainsByOrgId = createAsyncThunk(
  "trains/getTrainsByOrgId",
  async (
    {
      orgId,
      pageNumber = 0,
      pageSize = 10,
      sortBy = "trainNo",
      sortDir = "asc",
    },
    { rejectWithValue }
  ) => {
    try {
      const response = await travelAxios.get(
        `/train/getTrainByOrgId/${orgId}`,
        {
          params: {
            pageNumber,
            pageSize,
            sortBy,
            sortDir,
          },
        }
      );

      // Handle both direct data and nested data structures
      const responseData = response.data?.data || response.data;

      return {
        trains: Array.isArray(responseData)
          ? responseData
          : responseData.content || [],
        totalPages: response.data?.totalPages || responseData.totalPages || 1,
        totalItems:
          response.data?.totalElements || responseData.totalElements || 0,
        currentPage: pageNumber,
      };
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message);
    }
  }
);

// Add this to your existing traintripApi.js
export const saveTickett = createAsyncThunk(
  "tickets/saveTickett",
  async (ticketData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/ticket/saveTicket", ticketData);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);
export const fetchTrainSupervisors = createAsyncThunk(
  "trains/fetchTrainSupervisors",
  async ({ page = 0, size = 60 } = {}, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(
        `/user/allUsers?page=${page}&size=${size}`
      );

      const users = response?.data?.data?.data || [];

      const supervisors = users.filter((user) => user?.role?.roleId === 2002);

      return supervisors;
    } catch (err) {
      console.error("Error fetching supervisors:", err);
      return rejectWithValue(err.response?.data?.message || err.message);
    }
  }
);

// Save a new train
export const saveTrain = createAsyncThunk(
  "trains/saveTrain",
  async (trainData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post("/train/saveTrain", trainData);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// Update an existing train
export const updateTrain = createAsyncThunk(
  "trains/updateTrain",
  async ({ train_id, ...trainData }, { rejectWithValue }) => {
    try {
      const payload = {
        ...trainData,
        train_id,
      };

      const response = await travelAxios.put(
        `/train/updateTrainById/${train_id}`,
        payload
      );

      return {
        ...response.data.data,
        train_id,
      };
    } catch (err) {
      return rejectWithValue(err.response?.data?.message || err.message);
    }
  }
);

// Delete a train
export const deleteTrain = createAsyncThunk(
  "trains/deleteTrain",
  async (train_id, { rejectWithValue }) => {
    try {
      await travelAxios.delete(`/train/deleteTrainById/${train_id}`);
      return train_id;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);
