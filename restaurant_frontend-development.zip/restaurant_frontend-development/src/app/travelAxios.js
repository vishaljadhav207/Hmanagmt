import axios from "axios";

const travelAxios = axios.create({
  baseURL: "http://localhost:8081/api/", 
  timeout: 60000,
  headers: {
    "Content-Type": "application/json",
    
  },
});

travelAxios.interceptors.request.use(
  (config) => {
    const accessToken = localStorage.getItem("TOKEN");

    if (accessToken) {
      config.headers["Authorization"] = `Bearer ${accessToken}`;
      config.headers["Access-Control-Allow-Origin"] = "*";
    }
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
    } else {
      config.headers["Content-Type"] = "application/json";
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const get = (url, config) => {
  return new Promise((resolve, reject) => {
    travelAxios
      .get(url, config)
      .then((result) => {
        if (result.status === 200) {
          resolve(result);
        } else {
          reject(result.data);
        }
      })
      .catch((error) => {
        if (error.response && error.response.status === 401) {
          localStorage.removeItem(KEY.USER_INFO);
          localStorage.removeItem(KEY.TOKEN);
          dispatch(logout());
        }
        reject(error);
      });
  });
};

const successStatuses = [200, 201];
const isSuccessful = (responseStatus) =>
  includes(successStatuses, responseStatus);

export const post = (url, data) => {
  return new Promise((resolve, reject) => {
    travelAxios
      .post(url, data)
      .then((result) => {
        if (isSuccessful(result.status)) {
          resolve(result.data);
        }
      })
      .catch((error) => {
        reject(error.response);
      });
  });
};
export default travelAxios;
