import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
const token = localStorage.getItem("TOKEN");

export const fetchOrganizations = createAsyncThunk(
  "organization/fetchOrganizations",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:8081/api/organizations/getAll`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log(response, "reponse at organizations");
      if (response && response?.status === 200) {
        return response?.data;
      }
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
export const getOrganizationsByType = createAsyncThunk(
  "organization/getOrganizationsByType",
  async (type, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `http://localhost:8081/api/organizations/type/${type}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log(response, "reponse at organizationsByType");
      if (response && response?.status === 200) {
        return response?.data;
      }
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
