import { createAsyncThunk } from "@reduxjs/toolkit";
import travelAxios from "./travelAxios";


// Fetch all train trips 
export const getAllFlightTrips = createAsyncThunk(
    "flighttrips/getAllFlightTrips",
    async ({ page = 0, size = 10 }, { rejectWithValue }) => {
      try {
        const response = await travelAxios.get(
          `/flightTrips/getAllFlightTrips?page=${page}&size=${size}`
        );
        return response.data;
      } catch (err) {
        return rejectWithValue(err.message);
      }
    }
  );

  // Add this to your existing traintripApi.js
  export const saveTickett = createAsyncThunk(
    "tickets/saveTickett",
    async (ticketData, { rejectWithValue }) => {
      try {
        const response = await travelAxios.post("/ticket/saveTicket", ticketData);
        return response.data;
      } catch (err) {
        return rejectWithValue(err.response?.data || err.message);
      }
    }
  );
  export const getFlightTripById = createAsyncThunk(
    "flighttrips/getFlightTripById",
    async (flightTripId, { rejectWithValue }) => {
      try {
        const response = await travelAxios.get(`/flightTrips/getFlightTripById/${flightTripId}`);
        return response.data;
      } catch (err) {
        return rejectWithValue(err.response?.data || err.message);
      }
    }
  );
  
  
   export const getFlightTripsByUserId = createAsyncThunk(
    "flighttrips/getFlightTripsByUserId",
    async (userId, { rejectWithValue }) => {
      try {
        const response = await travelAxios.get(`/flightTrips/getFlightTripByUserId/${userId}`);
        return response.data;
      } catch (err) {
        return rejectWithValue(err.message);
      }
    }
  );
  

export const createFlightTrip = createAsyncThunk(
  'flightTrip/createFlightTrip',
  async (flightTripData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.post('/flightTrips/createFlightTrip', flightTripData);
      console.log("Flight Trip Created:", response.data);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response.data);
    }
  }
);
export const updateFlightTrip = createAsyncThunk(
  'flightTrips/updateFlightTrip',
  async ({ flightTripId, updatedData }, { rejectWithValue }) => {
    try {
      const response = await travelAxios.put(
        `/flightTrips/updateFlightTripById/${flightTripId}`,
        updatedData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);
export const deleteFlightTrip = createAsyncThunk(
  'flightTrips/deleteFlightTrip',
  async (flightTripId, { rejectWithValue }) => {
    try {
      await travelAxios.delete(`/flightTrips/deleteFlightTrip/${flightTripId}`);
      return flightTripId;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const searchFlightTrips = createAsyncThunk(
  "flighttrips/searchFlightTrips",
  async (searchData, { rejectWithValue }) => {
    try {
      const response = await travelAxios.get("/flightTrips/search", {
        params: {
          origin: searchData.origin,
          destination: searchData.destination,
          departureDate: searchData.departureDate
        }
      });
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

  



  