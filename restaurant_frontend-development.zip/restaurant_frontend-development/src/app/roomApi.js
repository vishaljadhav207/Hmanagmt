import axiosInstance from "./axiosInstance";

export const fetchRooms = async (page, size) => {
  try {
    const response = await axiosInstance.get(`/getRooms?page=${page}&size=${size}`);
    return response.data; 
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to fetch rooms');
  }
};

export const fetchRoomsByHotelId = async (hotelId) => {
  try {
    const response = await axiosInstance.get(`/getRoomsByHotelId?hotelId=${hotelId}`);
    // Always return an array
    return Array.isArray(response.data) ? response.data : response.data?.data || [];
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Failed to fetch rooms');
  }
};


export const addRoomAPI = async (roomData) => {
  try {
    const response = await axiosInstance.post('/addRoom', roomData);
    return response.data;
  } catch (error) {
    throw new Error('Error adding room');
  }
};


export const updateRoomAPI = async (roomId, roomData) => {
  try {
    const response = await axiosInstance.patch(`/updateRoom/${roomId}`, roomData);
    console.log('Room update response:', response); // 👈 ADD THIS
    return response.data;
  } catch (error) {
    console.error('Room update failed:', error.response || error); // 👈 ADD THIS
    throw new Error(error.response?.data?.message || 'Error updating room');
  }
};


export const deleteRoomAPI = async (roomId) => {
  try {
    const response = await axiosInstance.delete(`/deleteRoom/${roomId}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Error deleting room');
  }
};