import { createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance, { post, get } from "./axiosInstance";
import { KEY } from "../utils/Constant";
import Swal from "sweetalert2";
import axios from "axios";
const token = localStorage.getItem("TOKEN");

export const loginUser = createAsyncThunk(
  "user/login",
  async (data, { rejectWithValue }) => {
    try {
      const response = await post("/user/login", data);
      console.log(response, "response");
      if (response) {
        const token = response.data.token;
        localStorage.setItem(KEY.TOKEN, token);
        localStorage.setItem(KEY.USER_INFO, JSON.stringify(response.data));
        axiosInstance.defaults.headers.common["Authorization"] =
          "Bearer " + token;
        return response;
      }
    } catch (error) {
      return rejectWithValue(
        error.data?.error || "Login failed, please try again."
      );
    }
  }
);

export const registerUser = createAsyncThunk(
  "user/register",
  async (data, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post("/user/register", data);
      if (response.status === 200) {
        return response.data;
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error || "Registration failed, please try again."
      );
    }
  }
);
export const registerOrgOwner = createAsyncThunk(
  "user/registerOrgOwner",
  async (data, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post("/user/registerOrgOwner", data);
      if (response.status === 200) {
        console.log(response, "response at org owner");
        return response.data;
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error || "Registration failed, please try again."
      );
    }
  }
);

// Fetch all users
export const fetchUsers = createAsyncThunk(
  "user/fetchUsers",
  async ({ page, size }) => {
    const response = await get(`/user/allUsers?page=${page}&size=${size}`);
    return response.data.data;
  }
);

// Fetch  AdminProfile by id
export const fetchUserById = createAsyncThunk("user/users", async (adminId) => {
  const response = await get(`/user/users/${adminId}`);

  return response.data;
});

export const updateUser = createAsyncThunk(
  "user/updateUser",
  async (userData) => {
    try {
      const response = await axiosInstance.put(
        `/user/updateUser/${userData.id}`,
        {
          firstName: userData.firstName,
          lastName: userData.lastName,
          mobile: userData.mobile,
          email: userData.email,
        }
      );

      return response.data;
    } catch (error) {
      throw error;
    }
  }
);

// Add this to your userApi.js
export const deleteUser = createAsyncThunk(
  "user/deleteUser",
  async (userId, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(
        `/user/usersDelete/${userId}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

export const verifyEmail = createAsyncThunk(
  "user/verifyEmail",
  async (data, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(`user/verifyEmail/${data}`);

      if (response && response.status === 200) {
        Swal.fire({
          title: "Success!",
          text: "OTP has been sent successfully",
          icon: "success",
          customClass: {
            popup: "small-icon-popup",
          },
        });
        return response?.data;
      }
    } catch {
      Swal.fire({
        title: "Error!",
        text: error?.message || "Email Format not Valid",
        icon: "error",
        customClass: {
          popup: "small-icon-popup",
        },
      });
      return rejectWithValue(
        error.response?.data?.error || "Registration failed, please try again."
      );
    }
  }
);
// VrifyOTP
export const verifyOtp = createAsyncThunk(
  "user/verifyOtp",
  async ({ otp, email }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(
        `user/verifyOtp/${otp}/${email}`
      );
      if (response && response.status === 200) {
        return response?.data;
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data || "OTP authentication failed"
      );
    }
  }
);

export const registerOwner = createAsyncThunk(
  "user/registerOwner",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(
        "/user/HotelOwner/register",
        userData
      );
      if (response.data) {
        return response.data;
      } else {
        return rejectWithValue("Invalid response from server");
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error || "Failed to register owner."
      );
    }
  }
);
export const registerSupervisor = createAsyncThunk(
  "user/registerSupervisor",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(
        "/user/trainSupervisor/register",
        userData
      );
      if (response.data) {
        return response.data;
      } else {
        return rejectWithValue("Invalid response from server");
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error || "Failed to register owner."
      );
    }
  }
);
export const registerflightSupervisor = createAsyncThunk(
  "user/registerflightSupervisor",
  async (userData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(
        "/user/flightsupervisor/register",
        userData
      );
      if (response.data) {
        return response.data;
      } else {
        return rejectWithValue("Invalid response from server");
      }
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error || "Failed to register owner."
      );
    }
  }
);

export const registerbusSupervisor = createAsyncThunk(
  "user/registerbusSupervisor",
  async (userData, thunkAPI) => {
    try {
      const response = await axiosInstance.post(
        "user/busSupervisor/register",
        userData
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(
        error.response?.data?.message || "Failed"
      );
    }
  }
);

export const submitContact = createAsyncThunk(
  "contact/submitContact",
  async (contactData, { rejectWithValue }) => {
    try {
      // Fix this line - remove the line break and "POST" from the URL string
      const response = await axiosInstance.post(
        "/contact/addContact",
        contactData
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error ||
          "Failed to submit contact, please try again."
      );
    }
  }
);

export const saveOrganization = createAsyncThunk(
  "/organizations/create",
  async (organizationData, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        "http://localhost:8081/api/organizations/create",
        organizationData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log(response, "response at saveOrganization");
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.error ||
          "Failed to Create Organization , Please Try Again ."
      );
    }
  }
);

export const getAllContacts = createAsyncThunk(
  "user/getAllContacts",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get("/contact/getContact");
      return response.data.data; // Adjust based on your actual API response
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

export const getUsersByOrganization = createAsyncThunk(
  "user/getUsersByOrganization",
  async ({ orgId }, thunkAPI) => {
    try {
      const response = await axiosInstance.get(
        `/user/getUsersByOrganization/${orgId}`
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response?.data || error.message);
    }
  }
);

export const getSupervisorByOrgId = createAsyncThunk(
  "users/getSupervisorByOrgId",
  async ({ orgId, roleId }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get("/user/getSupervisorByOrgId", {
        params: { orgId, roleId },
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response?.data?.data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

// Add these to your existing userApi.js
export const updateContactReply = createAsyncThunk(
  "user/updateContactReply",
  async ({ email, adminReply }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(
        `/contact/updateContact?email=${email}`,
        { adminReply }
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

export const getUserbyRole = createAsyncThunk(
  "user/getByRole",
  async (type) => {
    {
      const response = await get(`/user/getByRole?Type=${type}`);
      console.log(response, "response at api");
      return response.data.data;
    }
  }
);

export const deleteContact = createAsyncThunk(
  "contact/deleteContact",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(
        `/contact/deleteContact${id}`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data);
    }
  }
);

// Change Password
export const changePassword = createAsyncThunk(
  "user/changePassword",
  async ({ email, payload }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(
        `user/changePassword/${email}`,
        payload
      );

      if (response && response.data?.statusCode === 200) {
        Swal.fire({
          title: "Success!",
          text: "Password Changed successfully",
          icon: "success",
          customClass: {
            popup: "small-icon-popup",
          },
        });
        return response;
      }
    } catch {
      Swal.fire({
        title: "Incorrect Password!",
        text: "Password Mismatch ",
        icon: "Incorrect",
        customClass: {
          popup: "small-icon-popup",
        },
      });
      return rejectWithValue(
        error.response?.data?.error || "Registration failed, please try again."
      );
    }
  }
);
