import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
// import store from './redux/store'
import { Provider } from 'react-redux'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import AppLayout from './applayout/AppLayout.jsx'
import Store from './store/Store.js'

import React from 'react';
import ReactDOM from 'react-dom/client';

import './i18n'; 

// ReactDOM.createRoot(document.getElementById('root')).render(<App />);


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={Store}>
      <App />
    </Provider>
  </StrictMode>,
)
