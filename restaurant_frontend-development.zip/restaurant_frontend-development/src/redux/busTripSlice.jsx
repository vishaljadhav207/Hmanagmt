import { createSlice } from '@reduxjs/toolkit';
import { getAllBusTrips, getBusTripById, saveTickett } from '../app/bustripApi';


const initialState = {
    bustrip: [],
    selectedBusTrip: null, 
    selectedTicket: null,
    userBusTrip: [],      
    status: "idle",
    error: null,
    currentPage: 0,
    totalPages: 1,  
    pageSize: 10,
  };
  
  const busTripSlice = createSlice({
    name: "bustrip", 
    initialState,
    reducers: {
      setCurrentPage: (state, action) => {
        state.currentPage = action.payload;
      },
      setPageSize: (state, action) => {
        state.pageSize = action.payload;
        state.currentPage = 0;
      },
      resetBusTripState: (state) => {
        state.bustrip = [];
        state.selectedBusTrip = null;
        state.userBusTrip = [];
        state.status = "idle";
        state.error = null;
        state.currentPage = 0;
        state.totalPages = 1;
        state.pageSize = 10;
      },
    },
    extraReducers: (builder) => {
      builder
      
        .addCase(getAllBusTrips.pending, (state) => {
          state.status = "loading";
        })
        .addCase(getAllBusTrips.fulfilled, (state, action) => {
          state.status = "succeeded";
          state.bustrip = action.payload || [];
          state.totalPages = 1; 
        })
        .addCase(getAllBusTrips.rejected, (state, action) => {
          state.status = "failed";
          state.error = action.payload;
        })
        .addCase(saveTickett.pending, (state) => {
          state.status = "loading";
        })
        .addCase(saveTickett.fulfilled, (state, action) => {
          state.status = "succeeded";
          state.selectedTicket = action.payload.data;
        })
        .addCase(saveTickett.rejected, (state, action) => {
          state.status = "failed";
          state.error = action.payload;
        })
  
        .addCase(getBusTripById.pending, (state) => {
          state.status = "loading";
          state.getBusTripById = null;
        })
        .addCase(getBusTripById.fulfilled, (state, action) => {
          state.status = "succeeded";
          state.selectedBusTrip = action.payload;
        })
        .addCase(getBusTripById.rejected, (state, action) => {
          state.status = "failed";
          state.error = action.payload;
        });
  
      
    },
  });
  
  export const { setCurrentPage, setPageSize, resetBusTripState } = busTripSlice.actions;
  export default busTripSlice.reducer;
  