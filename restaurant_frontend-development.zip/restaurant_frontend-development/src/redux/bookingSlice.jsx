// src/store/slices/bookingsSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { addBookingRecord, getBookingRecords } from "../app/bookingApi";

// Async thunk for adding a booking record
export const addBooking = createAsyncThunk(
  "bookings/addBooking",
  async (bookingData, { rejectWithValue }) => {
    try {
      const response = await addBookingRecord(bookingData);
      return response;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const fetchBookings = createAsyncThunk(
  "bookings/fetchBookings",
  async (_, { rejectWithValue }) => {
    try {
      const response = await getBookingRecords();
      return response;
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

const initialState = {
  bookings: [],
  loading: false,
  error: null,
  success: false,
};

const bookingsSlice = createSlice({
  name: "bookings",
  initialState,
  reducers: {
    resetBookingState: (state) => {
      state.loading = false;
      state.error = null;
      state.success = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(addBooking.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(addBooking.fulfilled, (state, action) => {
        state.loading = false;
        state.success = true;
        state.bookings.push(action.payload);
      })
      .addCase(addBooking.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error.message;
      })
      .addCase(fetchBookings.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBookings.fulfilled, (state, action) => {
        state.loading = false;
        state.bookings = action.payload;
      })
      .addCase(fetchBookings.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error.message;
      });
  },
});

export const { resetBookingState } = bookingsSlice.actions;
export default bookingsSlice.reducer;
