import { createSlice } from "@reduxjs/toolkit";
import {
  fetchOrganizations,
  getOrganizationsByType,
} from "../app/organizationApis";

const initialState = {
  organizations: [],
  organizationsByType: [],
  error: null,
  loading: false,
  status: "idle",
};

const organizationSlice = createSlice({
  name: "organization",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchOrganizations.pending, (state) => {
        state.loading = true;
        state.error = false;
      })
      .addCase(fetchOrganizations.fulfilled, (state, action) => {
        state.loading = false;
        state.organizations = action.payload;
        state.error = null;
      })
      .addCase(fetchOrganizations.rejected, (state, action) => {
        state.error = action.payload;
        state.organizations = [];
        state.loading = false;
      })
      .addCase(getOrganizationsByType.pending, (state) => {
        state.loading = true;
        state.error = false;
      })
      .addCase(getOrganizationsByType.fulfilled, (state, action) => {
        state.loading = false;
        state.organizationsByType = action.payload;
        state.error = null;
      })
      .addCase(getOrganizationsByType.rejected, (state, action) => {
        state.error = action.payload;
        state.organizations = [];
        state.loading = false;
      });
  },
});

export const organizationState = (state) => state.organization;

export default organizationSlice.reducer;
