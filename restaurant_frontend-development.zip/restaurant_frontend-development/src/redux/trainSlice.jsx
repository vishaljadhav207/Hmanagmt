import { createSlice } from "@reduxjs/toolkit";
import {
  getAllTrains,
  getTrainsByOrgId,
  fetchTrainSupervisors,
  saveTrain,
  updateTrain,
  deleteTrain,
  getTrainByUserId,
} from "../app/trainApi";

const initialState = {
  trains: [],
  trainByUserId: null,
  supervisors: [],
  status: "idle",
  loading: false,
  error: null,
  currentPage: 0,
  totalPages: 1,
  pageSize: 10,
  totalItems: 0,
  sortBy: "trainNo",
  sortDir: "asc",
};

const trainSlice = createSlice({
  name: "trains",
  initialState,
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
      state.currentPage = 0;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    setSortDir: (state, action) => {
      state.sortDir = action.payload;
    },
    setTrainError: (state, action) => {
      state.error = action.payload;
    },
    resetTrainState: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllTrains.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllTrains.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.trains = action.payload.data || [];
        state.totalPages = action.payload.totalPages || 1;
      })
      .addCase(getAllTrains.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(getTrainsByOrgId.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(getTrainsByOrgId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.trains = action.payload.trains;
        state.totalPages = action.payload.totalPages;
        state.totalItems = action.payload.totalItems;
        state.currentPage = action.payload.currentPage;
      })
      .addCase(getTrainsByOrgId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload || "Something went wrong.";
      })
      .addCase(fetchTrainSupervisors.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTrainSupervisors.fulfilled, (state, action) => {
        state.loading = false;
        state.supervisors = action.payload;
      })
      .addCase(fetchTrainSupervisors.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error.message;
      })

      .addCase(saveTrain.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveTrain.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.trains = [action.payload, ...state.trains];
      })
      .addCase(saveTrain.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(updateTrain.pending, (state) => {
        state.status = "loading";
      })
      .addCase(updateTrain.fulfilled, (state, action) => {
        state.status = "succeeded";
        const updatedTrain = action.payload;
        state.trains = state.trains.map((t) =>
          Number(t.train_id) === Number(updatedTrain.train_id)
            ? updatedTrain
            : t
        );
      })
      .addCase(updateTrain.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(deleteTrain.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteTrain.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.trains = state.trains.filter(
          (train) => train.train_id !== action.payload
        );
      })
      .addCase(deleteTrain.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(getTrainByUserId.pending, (state) => {
        state.loading = true;
        state.status = "loading";
      })
      .addCase(getTrainByUserId.fulfilled, (state, action) => {
        state.loading = false;
        state.status = "succeeded";
        state.trainByUserId = action.payload;
      })
      .addCase(getTrainByUserId.rejected, (state, action) => {
        state.loading = false;
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const {
  setCurrentPage,
  setPageSize,
  setSortBy,
  setSortDir,
  clearError,
} = trainSlice.actions;

export default trainSlice.reducer;

export const selectAllTrains = (state) => state.trains.trains;
export const selectTrainData = (state) => state.trains.trainByUserId;
export const selectTrainLoading = (state) => state.trains.loading;
export const selectTrainSupervisors = (state) => state.trains.supervisors;
export const selectTrainStatus = (state) => state.trains.status;
export const selectTrainError = (state) => state.trains.error;
export const selectCurrentPage = (state) => state.trains.currentPage;
export const selectTotalPages = (state) => state.trains.totalPages;
export const selectPageSize = (state) => state.trains.pageSize;
