import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { get, post } from '../app/axiosInstance';


export const fetchUserHistory = createAsyncThunk('history/fetchUserHistory', async (userId) => {
  try {
    const response = await get(`/booking/history?userId=${userId}`);
    console.log('Fetched data:', response.data);  // Add this line to log the response data
    return response.data; 
  } catch (error) {
    console.error('Error fetching history:', error);  // Log the error to see what's happening
    throw Error(error.response?.data?.message || 'Failed to fetch user history');
  }
});

export const addRating = createAsyncThunk(
  "userHistory/addRating",
  async (ratingData, { rejectWithValue }) => {
    try {
      const response = await post("/ratings/addRating", ratingData); // Adjust the URL
      if (response.status === 200) {
        return response.ratingData;
    } // Return the response data if successful
    } catch (error) {
      return rejectWithValue(error.response.data); // Return the error if it fails
    }
  }
);

const historySlice = createSlice({
  name: 'history',
  initialState: {
    history: [],
    filteredHistory: [],
    status: 'idle',  // 'idle', 'loading', 'succeeded', 'failed'
    error: null,
  },
  reducers: {
    setFilteredHistory: (state, action) => {
      state.filteredHistory = action.payload;
      console.log('filteredHistory: ', state.filteredHistory);
    },
    filterHistory: (state, action) => {
      const filter = action.payload;
      if (filter === 'All') {
        state.filteredHistory = state.history;
      } else {
        state.filteredHistory = state.history.filter(item => item.status === filter);
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUserHistory.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchUserHistory.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.history = action.payload || []; // Ensure payload is an array
        state.filteredHistory = action.payload || [];
        console.log('Updated history state:', state.history); // Debug the state
      })
      .addCase(fetchUserHistory.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
       .addCase(addRating.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addRating.fulfilled, (state, action) => {
        state.status = "succeeded";
        
        // Check if history is an array before performing the map operation
        if (Array.isArray(state.history)) {
          const updatedHistory = state.history.map((item) =>
            item.bookingId === action.payload.bookingId
              ? { ...item, rating: action.payload.rating, comment: action.payload.comment }
              : item
          );
          state.history = updatedHistory;
          state.filteredHistory = updatedHistory;
        } else {
          console.error('Error: state.history is not an array:', state.history);
        }
      })
      
      .addCase(addRating.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload || action.error.message;
      });
  },
});

export const { setFilteredHistory,filterHistory } = historySlice.actions;

export default historySlice.reducer;
