import { createSlice } from "@reduxjs/toolkit";
import {
  getAllTrainTrips,
  getTrainTripById,
  getTrainTripsByUserId,
  updateTrainTrip,
  deleteTrain,
  saveTickett,
  getTrainSeatsByTrainId,
  addTrainTrip,
} from "../app/traintripApi";

const initialState = {
  traintrip: [],
  selectedseats: null,
  selectedTrainTrip: null,
  selectedTicket: null,
  trainTripsByUserId: [],
  status: "idle",
  error: null,
  currentPage: 0,
  totalPages: 1,
  pageSize: 10,
};

const traintripSlice = createSlice({
  name: "traintrip",
  initialState,
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
      state.currentPage = 0;
    },
    resetTrainTripState: (state) => {
      state.traintrip = [];
      state.selectedseats = null;
      state.selectedTrainTrip = null;
      state.userTrainTrips = [];
      state.status = "idle";
      state.error = null;
      state.currentPage = 0;
      state.totalPages = 1;
      state.pageSize = 10;
    },
  },
  extraReducers: (builder) => {
    builder
  
      .addCase(getAllTrainTrips.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllTrainTrips.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.traintrip = action.payload || [];
        state.totalPages = 1;
      })
      .addCase(getAllTrainTrips.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(saveTickett.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveTickett.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedTicket = action.payload.data;
      })
      .addCase(saveTickett.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(getTrainTripById.pending, (state) => {
        state.status = "loading";
        state.selectedTrainTrip = null;
      })
      .addCase(getTrainTripById.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedTrainTrip = action.payload;
      })
      .addCase(getTrainTripById.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

     
      .addCase(getTrainTripsByUserId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getTrainTripsByUserId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.trainTripsByUserId = action.payload || [];
      })
      .addCase(getTrainTripsByUserId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })


      .addCase(updateTrainTrip.pending, (state) => {
        state.status = "loading";
      })

      .addCase(updateTrainTrip.fulfilled, (state, action) => {
        state.status = "succeeded";
        const updated = action.payload;
        const index = state.trainTripsByUserId.findIndex(
          (t) => t.trainTripId === updated.trainTripId
        );
        if (index !== -1) {
          state.trainTripsByUserId[index] = updated;
        }
      })
      .addCase(updateTrainTrip.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

    
      .addCase(deleteTrain.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteTrain.fulfilled, (state, action) => {
        state.status = "succeeded";
        const deletedId = action.payload;
        state.traintrip = state.traintrip.filter((t) => t.id !== deletedId);
      })
      .addCase(deleteTrain.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
    
      .addCase(getTrainSeatsByTrainId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getTrainSeatsByTrainId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedseats = action.payload || [];
      })
      .addCase(getTrainSeatsByTrainId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(addTrainTrip.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addTrainTrip.fulfilled, (state, action) => {
        state.status = "succeeded";
          state.traintrip.push(action.payload);
      })
      .addCase(addTrainTrip.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const { setCurrentPage, setPageSize, resetTrainTripState } =
  traintripSlice.actions;
export default traintripSlice.reducer;
export const trainTripState = (state) => state.traintrip;
export const selecttrainTrips = (state) => state.traintrip;
