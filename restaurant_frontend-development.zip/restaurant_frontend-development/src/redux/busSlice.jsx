import { createSlice } from "@reduxjs/toolkit";
import {
  getAllBuses,
  fetchBusSupervisors,
  saveBus,
  updateBus,
  deleteBus,
  getBusTripById,
  saveTicket,
  getAllBusSeats,
  deleteBusTrip,
  getBusTripsByUserId,
  getBusByOrgId,
  getBusTripsByBusId,
  createBusTrip,
  updateBusTrip,
  getClassTypesByTransportType,
  getBusByUserId,
} from "../app/busApi";

const initialState = {
  buses: [],
  seats: [],
  busTrips: [],
  seatsStatus: "idle",
  seatsError: null,
  supervisors: [],
  status: "idle",
  passengers: [],
  passengerStatus: "idle",
  passengerError: null,
  error: null,
  ticketStatus: "idle",
  ticketError: null,
  bookedTicket: null,
  currentPage: 0,
  totalPages: 1,
  totalItems: 0,
  pageSize: 10,
  sortBy: "busNo",
  sortDir: "asc",
  loading: false,
};

const busSlice = createSlice({
  name: "buses",
  initialState,
  reducers: {
    setBusCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setBusPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    setSortDir: (state, action) => {
      state.sortDir = action.payload;
    },
    resetBusState: () => initialState,
    clearError: (state) => {
      state.error = null;
    },
    clearTicketStatus: (state) => {
      state.ticketStatus = "idle";
      state.ticketError = null;
    },
    resetBookedTicket: (state) => {
      state.bookedTicket = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllBuses.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllBuses.fulfilled, (state, action) => {
        console.log("Buses fetched:", action.payload);
        state.status = "succeeded";
        state.buses = action.payload || [];
      })
      .addCase(getAllBuses.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(fetchBusSupervisors.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchBusSupervisors.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.supervisors = action.payload || [];
      })
      .addCase(fetchBusSupervisors.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      // Save Bus
      .addCase(saveBus.pending, (state) => {
        state.status = "saving";
      })
      .addCase(saveBus.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.buses = [action.payload, ...state.buses]; 
      })
      .addCase(saveBus.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      // Update Bus
      .addCase(updateBus.pending, (state) => {
        state.status = "updating";
      })
      .addCase(updateBus.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.buses = state.buses.map((bus) =>
          bus.busId === action.payload.busId ? action.payload : bus
        );
      })
      .addCase(updateBus.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(getBusByOrgId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getBusByOrgId.fulfilled, (state, action) => {
        state.buses = action.payload.buses;
        state.totalPages = action.payload.totalPages;
        state.totalItems = action.payload.totalItems;
        state.status = "succeeded";
      })
      .addCase(getBusByOrgId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })

      //get transport
      .addCase(getClassTypesByTransportType.pending, (state) => {
        state.classTypesLoading = true;
        state.classTypesError = null;
      })
      .addCase(getClassTypesByTransportType.fulfilled, (state, action) => {
        state.classTypesLoading = false;
        state.classTypes = action.payload;
      })
      .addCase(getClassTypesByTransportType.rejected, (state, action) => {
        state.classTypesLoading = false;
        state.classTypesError = action.payload;
      })

      // Delete Bus
      .addCase(deleteBus.pending, (state) => {
        state.status = "deleting";
      })
      .addCase(deleteBus.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.buses = state.buses.filter((bus) => bus.busId !== action.payload);
        state.currentPage = 0;
      })
      .addCase(deleteBus.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(getBusTripById.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getBusTripById.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedBus = action.payload;
      })
      .addCase(getBusTripById.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(saveTicket.pending, (state) => {
        state.ticketStatus = "loading";
        state.ticketError = null;
      })
      .addCase(saveTicket.fulfilled, (state, action) => {
        state.ticketStatus = "succeeded";
        state.bookedTicket = action.payload;
      })
      .addCase(saveTicket.rejected, (state, action) => {
        state.ticketStatus = "failed";
        state.ticketError = action.payload;
      })
      .addCase(getAllBusSeats.pending, (state) => {
        state.seatsStatus = "loading";
        state.seatsError = null;
      })
      .addCase(getAllBusSeats.fulfilled, (state, action) => {
        state.seatsStatus = "succeeded";
        state.seats = Array.isArray(action.payload) ? action.payload : [];
      })
      .addCase(getAllBusSeats.rejected, (state, action) => {
        state.seatsStatus = "failed";
        state.seatsError = action.payload || "Failed to fetch seats";
      })
      .addCase(getBusByUserId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getBusByUserId.fulfilled, (state, action) => {
           state.buses = action.payload || [];
        state.status = "succeeded";
        state.busTrips = action.payload || [];
        console.log("Redux State Updated:", state.busTrips);
      })
      .addCase(getBusByUserId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(getBusTripsByUserId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getBusTripsByUserId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.busTrips = action.payload || [];
        console.log("Redux State Updated with user trips:", state.busTrips);
      })
      .addCase(getBusTripsByUserId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(deleteBusTrip.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteBusTrip.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.busTrips = state.busTrips.filter(
          (trip) => trip.busTripId !== action.payload
        );
      })
      .addCase(deleteBusTrip.rejected, (state, action) => {
        state.status = "failed";
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : action.payload?.message || "Failed to delete trip";
      })
      .addCase(createBusTrip.pending, (state) => {
        state.status = "loading";
      })
      .addCase(createBusTrip.fulfilled, (state, action) => {
        state.busTrips.push(action.payload);
        state.status = "succeeded";
      })
      .addCase(createBusTrip.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(updateBusTrip.pending, (state) => {
        state.status = "loading";
      })
      .addCase(updateBusTrip.fulfilled, (state, action) => {
        const index = state.busTrips.findIndex(
          (trip) => trip.busTripId === action.payload.busTripId
        );
        if (index !== -1) {
          state.busTrips[index] = action.payload;
        }
        state.status = "succeeded";
      })
      .addCase(updateBusTrip.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      });
  },
});

export const {
  setBusCurrentPage,
  setBusPageSize,
  setSortBy,
  setSortDir,
  resetBusState,
  clearError,
  clearTicketStatus,
  resetBookedTicket,
} = busSlice.actions;

export default busSlice.reducer;

export const selectAllBuses = (state) => state.buses.buses;
export const selectBusById = (state, busId) =>
  state.buses.buses.find((bus) => bus.busId === busId);
export const selectBusSupervisors = (state) => state.buses.supervisors;
export const selectBusStatus = (state) => state.buses.status;
export const selectBusError = (state) => state.buses.error;
export const selectCurrentPage = (state) => state.buses.currentPage;
export const selectTotalPages = (state) => state.buses.totalPages;
export const selectPageSize = (state) => state.buses.pageSize;
export const selectTicketStatus = (state) => state.buses.ticketStatus;
export const selectTicketError = (state) => state.buses.ticketError;
export const selectBookedTicket = (state) => state.buses.bookedTicket;
export const selectBusTrips = (state) => state.buses.busTrips;
export const selectBusTripStatus = (state) => state.buses.status;
