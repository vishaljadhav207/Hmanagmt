import { createSlice } from "@reduxjs/toolkit";
import {
  getAllFlights,
  getFlightByOrgId,
  fetchFlightSupervisors,
  saveFlight,
  updateFlight,
  deleteFlight,
  fetchFlightsByUserId,
} from "../app/flightApi";

const initialState = {
  flights: [],
  selectedFlight: [],
  supervisors: [],
  loading: false,
  status: "idle",
  error: null,
  currentPage: 0,
  totalPages: 1,
  pageSize: 10,
  sortBy: "airline",
  sortDir: "asc",
  totalItems: 0,
};

const flightSlice = createSlice({
  name: "flights",
  initialState,
  reducers: {
    setFlightCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setFlightPageSize: (state, action) => {
      state.pageSize = action.payload;
      state.currentPage = 0;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    setSortDir: (state, action) => {
      state.sortDir = action.payload;
    },
    resetFlightState: () => initialState,
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllFlights.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllFlights.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flights = action.payload.data || [];
        state.totalPages = action.payload.totalPages || 1;
      })
      .addCase(getAllFlights.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(getFlightByOrgId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getFlightByOrgId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flights = action.payload.flights || [];
        state.totalPages = action.payload.totalPages || 1;
        state.totalItems = action.payload.totalItems || 0; // Add this
      })
      .addCase(getFlightByOrgId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(fetchFlightSupervisors.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchFlightSupervisors.fulfilled, (state, action) => {
        state.loading = false;
        state.supervisors = action.payload;
      })
      .addCase(fetchFlightSupervisors.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error.message;
      })

      .addCase(saveFlight.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveFlight.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flights = [action.payload, ...state.flights];
      })
      .addCase(saveFlight.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(updateFlight.pending, (state) => {
        state.status = "loading";
      })
      .addCase(updateFlight.fulfilled, (state, action) => {
        state.status = "succeeded";
        const updatedFlight = action.payload;
        state.flights = state.flights.map((f) =>
          f.flight_id === updatedFlight.flight_id ? updatedFlight : f
        );
      })
      .addCase(updateFlight.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(deleteFlight.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteFlight.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flights = state.flights.filter(
          (flight) => flight.flight_id !== action.payload
        );
      })
      .addCase(deleteFlight.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(fetchFlightsByUserId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchFlightsByUserId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flights = action.payload; 
        state.selectedFlight = action.payload;
      })
      .addCase(fetchFlightsByUserId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload?.message || action.error.message;
      });
  },
});

// ✅ Exporting the correct action creators
export const {
  setFlightCurrentPage,
  setFlightPageSize,
  setSortBy,
  setSortDir,
  resetFlightState,
  clearError,
} = flightSlice.actions;

// ✅ Selectors
export const selectAllFlights = (state) => state.flights.flights;
export const selectFlightSupervisors = (state) => state.flights.supervisors;
export const selectFlightStatus = (state) => state.flights.status;
export const selectFlightError = (state) => state.flights.error;
export const selectFlightLoading = (state) => state.flights.loading;
export const selectFlightCurrentPage = (state) => state.flights.currentPage;
export const selectFlightTotalPages = (state) => state.flights.totalPages;
export const selectFlightPageSize = (state) => state.flights.pageSize;
export const selectSortBy = (state) => state.flights.sortBy;
export const selectSortDir = (state) => state.flights.sortDir;
export const selectTotalItems = (state) => state.flights.totalItems;
export const selectCurrentFlight = (state) => state.flights.selectedFlight;

export default flightSlice.reducer;
