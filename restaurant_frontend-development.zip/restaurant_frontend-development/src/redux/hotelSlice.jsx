import { createSlice } from "@reduxjs/toolkit";
import {
  fetchHotels,
  fetchAmenities,
  saveHotel,
  updateHotel,
  deleteHotel,
  fetchHotelOwners, addAmenities, deleteAmenity, fetchHotelById, fetchHotelsByOwner, uploadHotelImage, fetchHotelImages, deleteHotelImage, createAndAddAmenityToHotel,
  fetchHotelsByLocation,
  fetchHotelsByCity,
  getAllHotels,
} from "../app/hotelApi";

const hotelSlice = createSlice({
  name: "hotels",
  initialState: {
    hotels: [],
    cities: [],
    // amenities: [],
    selectedHotel: null,
    hotelImages: [],
    imagesLoading: false,
    imagesError: null,
    imageUploadStatus: 'idle', // 'idle', 'loading', 'succeeded', 'failed'
    uploadedImage: null,
    owners: [],
    locations: [],
    status: "idle",
    error: null,
    currentPage: 0,
    totalPages: 0,
    pageSize: 5,
  },
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    resetImageUploadStatus: (state) => {
      state.imageUploadStatus = 'idle';
    },
    clearHotelImages: (state) => {
      state.hotelImages = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createAndAddAmenityToHotel.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(createAndAddAmenityToHotel.fulfilled, (state, action) => {
        state.status = 'succeeded';

        //add new amenity to selected hotel
        if (state.selectedHotel?.data?.[0]) {
          state.selectedHotel.data[0].amenities = [
            ...(state.selectedHotel.data[0].amenities || []),
            action.payload
          ];
        }
      })
      .addCase(createAndAddAmenityToHotel.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload?.message || action.error.message;
      })
      .addCase(uploadHotelImage.pending, (state) => {
        state.imageUploadStatus = 'loading';
      })
      .addCase(uploadHotelImage.fulfilled, (state, action) => {
        state.imageUploadStatus = 'succeeded';
        state.uploadedImage = action.payload;
      })
      .addCase(uploadHotelImage.rejected, (state, action) => {
        state.imageUploadStatus = 'failed';
        state.error = action.error.message;
      })
      // Fetch Hotel Images Cases
      .addCase(fetchHotelImages.pending, (state) => {
        state.imagesLoading = true;
        state.imagesError = null;
      })
      .addCase(fetchHotelImages.fulfilled, (state, action) => {
        state.imagesLoading = false;
        state.hotelImages = action.payload;
      })
      .addCase(fetchHotelImages.rejected, (state, action) => {
        state.imagesLoading = false;
        state.imagesError = action.error.message;
      })
      .addCase(fetchHotelById.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchHotelById.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.selectedHotel = action.payload;
      })
      .addCase(fetchHotelById.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      //delete image by image id
      .addCase(deleteHotelImage.pending, (state) => {
        state.imagesLoading = true;
      })
      .addCase(deleteHotelImage.fulfilled, (state, action) => {
        state.imagesLoading = false;
        state.hotelImages = state.hotelImages.filter(
          image => image.id !== action.payload
        );
      })
      .addCase(deleteHotelImage.rejected, (state, action) => {
        state.imagesLoading = false;
        state.imagesError = action.error.message;
      })
      .addCase(fetchHotels.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotels.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = action.payload.hotels;
        state.cities = action.payload.cities;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(fetchHotels.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(getAllHotels.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllHotels.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = action.payload.data;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(getAllHotels.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchHotelsByCity.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotelsByCity.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.rooms = action.payload.hotels;
        state.totalPages = Math.ceil(action.payload.total / state.pageSize);
      })
      .addCase(fetchHotelsByCity.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(saveHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        if (action.payload) {
          state.hotels.push(action.payload); 
        }
      })
      .addCase(saveHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(updateHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(updateHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        const updatedHotel = action.payload;
        const index = state.hotels.findIndex(
          (hotel) => hotel.hotelId === updatedHotel.hotelId
        );
        if (index !== -1) {
          state.hotels[index] = updatedHotel;
        }
      })
      .addCase(updateHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error =
          action.payload || "Failed to update hotel. Please try again.";
      })
      .addCase(deleteHotel.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteHotel.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = state.hotels.filter(
          (hotel) => hotel.hotelId !== action.payload
        );
      })
      .addCase(deleteHotel.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchHotelsByLocation.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotelsByLocation.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.locations = action.payload;
      })
      .addCase(fetchHotelsByLocation.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      // Add Amenityde
      .addCase(addAmenities.pending, (state) => {
        state.status = "loading";
      })
      .addCase(addAmenities.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.amenities.push(action.payload); // Add the new amenity to the amenities list
      })
      .addCase(addAmenities.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      // Delete Amenity
      .addCase(deleteAmenity.pending, (state) => {
        state.status = "loading";
      })
      .addCase(deleteAmenity.fulfilled, (state, action) => {
        state.status = "succeeded";
        const { hotelId, amenityId } = action.payload;
        
        // Remove the amenity from the selected hotel's amenities array
        if (state.selectedHotel?.data?.[0]?.hotelId === hotelId) {
          state.selectedHotel.data[0].amenities = state.selectedHotel.data[0].amenities.filter(
            amenity => amenity.id !== amenityId
          );
        }
      })
      .addCase(deleteAmenity.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchHotelsByOwner.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchHotelsByOwner.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.hotels = action.payload; // Store only the owner's hotels
      })
      .addCase(fetchHotelsByOwner.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })

      .addCase(fetchHotelOwners.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHotelOwners.fulfilled, (state, action) => {
        state.loading = false;
        state.owners = action.payload;
      })
      .addCase(fetchHotelOwners.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(fetchAmenities.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAmenities.fulfilled, (state, action) => {
        state.loading = false;
        state.amenities = action.payload;
      })
      .addCase(fetchAmenities.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
      
  },
});

export const { setCurrentPage, setPageSize, resetImageUploadStatus } = hotelSlice.actions;

export default hotelSlice.reducer;
