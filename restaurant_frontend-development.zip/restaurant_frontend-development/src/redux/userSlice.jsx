import { createSlice } from "@reduxjs/toolkit";
import {
  fetchUsers,
  loginUser,
  registerOwner,
  registerUser,
  submitContact,
  verifyOtp,
  verifyEmail,
  changePassword,
  getAllContacts,
  updateContactReply,
  deleteContact,
  registerSupervisor,
  registerOrgOwner,
  getUserbyRole,
  getSupervisorByOrgId,
  getUsersByOrganization,
} from "../app/userApi";
import { KEY } from "../utils/Constant";
import { ConnectingAirportsOutlined } from "@mui/icons-material";

const getLoggedInUserInfo = () => {
  let data = localStorage.getItem(KEY.USER_INFO);

  if (data) {
    data = JSON.parse(data);
  }
  return data;
};

const initialState = {
  data: [],
  userByRole: [],
  supervisorByOrg: [],
  loading: false,
  error: false,
  message: null,
  userInfo: getLoggedInUserInfo(),
  regResponse: null,
  totalUsersCount: 0,
  currentPage: 0,
  pageSize: 5,
  adminId: null,
  contactInfo: null,
  contacts: [],
  contactsLoading: false,
  contactsError: null,
  emailVerificationStatus: null,
  passwordChangeStatus: null,
  verifyOtpStatus: null,
  ResetPasswordSubmit: null,
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    resetMessage: (state) => {
      state.loading = false;
      state.message = "";
    },

    logout: (state) => {
      state.userInfo = null;
      state.message = "";
    },
    setPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    setAdminId: (state, action) => {
      state.adminId = action.payload;
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload.data || [];
        state.totalUsersCount = action.payload.total || 0;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      .addCase(registerOwner.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.error = false;
        state.data.push(payload.data);
      })
      .addCase(registerOwner.pending, (state) => {
        state.loading = true;
      })
      .addCase(registerOwner.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = true;
        state.message = payload;
      })

      .addCase(registerSupervisor.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.error = false;
        state.data.push(payload.data);
      })
      .addCase(registerSupervisor.pending, (state) => {
        state.loading = true;
      })
      .addCase(registerSupervisor.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = true;
        state.message = payload;
      })
      .addCase(registerOrgOwner.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.error = false;
        state.data.push(payload.data);
      })
      .addCase(registerOrgOwner.pending, (state) => {
        state.loading = true;
      })
      .addCase(registerOrgOwner.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = true;
        state.message = payload;
      })
      .addCase(getUserbyRole.fulfilled, (state, action) => {
        state.loading = false;
        state.userByRole = action.payload || [];
      })
      .addCase(getUserbyRole.pending, (state) => {
        state.loading = true;
      })
      .addCase(getUserbyRole.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // login
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
        state.userInfo = null;
        state.message = "";
      })
      .addCase(loginUser.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.userInfo = payload.data;
        state.message = payload.message;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loading = false;
        state.userInfo = null;
        state.message = action.payload;
      })

      // Register
      .addCase(registerUser.pending, (state) => {
        state.loading = true;
        state.regResponse = null;
        state.message = "";
      })
      .addCase(registerUser.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.regResponse = payload;
        state.message = payload.message;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loading = false;
        state.regResponse = null;
        state.message = action.payload;
      })
      .addCase(submitContact.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(submitContact.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.contactInfo = payload;
        state.message = "Contact submitted successfully!";
      })
      .addCase(submitContact.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(getAllContacts.pending, (state) => {
        state.contactsLoading = true;
        state.contactsError = null;
      })
      .addCase(getAllContacts.fulfilled, (state, { payload }) => {
        state.contactsLoading = false;
        state.contacts = payload;
      })
      .addCase(getAllContacts.rejected, (state, { payload }) => {
        state.contactsLoading = false;
        state.contactsError = payload;
      })

      //VerifyEmail
      .addCase(verifyEmail.pending, (state) => {
        state.loading = true;
        state.emailVerificationStatus = null;
        state.message = "";
      })
      .addCase(verifyEmail.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.emailVerificationStatus = payload;
        state.message = payload.message;
      })
      .addCase(verifyEmail.rejected, (state, action) => {
        state.loading = false;
        state.emailVerificationStatus = null;
        state.error = action.payload;
      })
      // change password
      .addCase(changePassword.pending, (state) => {
        state.loading = true;
        state.passwordChangeStatus = null;
        state.message = "";
      })
      .addCase(changePassword.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.passwordChangeStatus = payload;
        state.message = payload.message;
      })
      .addCase(changePassword.rejected, (state, action) => {
        state.loading = false;
        state.passwordChangeStatus = null;
        state.message = action.payload;
      })
      //verifyOtp
      .addCase(verifyOtp.pending, (state) => {
        state.loading = true;
        state.verifyOtpStatus = null;
        state.message = "";
      })
      .addCase(verifyOtp.fulfilled, (state, { payload }) => {
        state.loading = false;
        state.verifyOtpStatus = payload;
        state.message = payload.message;
      })
      .addCase(verifyOtp.rejected, (state, action) => {
        state.loading = false;
        state.verifyOtpStatus = action.payload;
        state.message = action.payload;
        state.error = action.payload;
      })

      .addCase(updateContactReply.pending, (state) => {
        state.contactsLoading = true;
      })
      .addCase(updateContactReply.fulfilled, (state, { payload }) => {
        state.contactsLoading = false;
        const index = state.contacts.findIndex(
          (contact) => contact.id === payload.id
        );
        if (index !== -1) {
          state.contacts[index] = {
            ...state.contacts[index],
            adminReply:
              typeof payload.adminReply === "string"
                ? payload.adminReply
                : JSON.stringify(payload.adminReply),
          };
        }
      })
      .addCase(updateContactReply.rejected, (state, { payload }) => {
        state.contactsLoading = false;
        state.contactsError = payload;
      })
      .addCase(deleteContact.pending, (state) => {
        state.contactsLoading = true;
      })
      .addCase(deleteContact.fulfilled, (state, { payload }) => {
        state.contactsLoading = false;

        state.contacts = state.contacts.filter(
          (contact) => contact.id !== payload.id && contact._id !== payload.id
        );
      })
      .addCase(deleteContact.rejected, (state, { payload }) => {
        state.contactsLoading = false;
        state.contactsError = payload;
      })
      .addCase(getSupervisorByOrgId.pending, (state) => {
        state.loading = true;
      })
      .addCase(getSupervisorByOrgId.fulfilled, (state, action) => {
        state.loading = false;
        state.supervisorByOrg = action.payload;
      })
      .addCase(getSupervisorByOrgId.rejected, (state, { payload }) => {
        state.loading = false;
        state.error = payload;
      })
      .addCase(getUsersByOrganization.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getUsersByOrganization.fulfilled, (state, action) => {
        state.loading = false;
        state.usersByOrg = action.payload;
      })
      .addCase(getUsersByOrganization.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "Failed to fetch users by org";
      });
  },
});

export const { resetMessage, logout, setPage, setPageSize, setAdminId } =
  userSlice.actions;
export const userState = (state) => state.user;

export default userSlice.reducer;
