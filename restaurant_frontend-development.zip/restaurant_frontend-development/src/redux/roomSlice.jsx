import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { addRoomAPI,  deleteRoomAPI,  fetchRoomsByHotelId, updateRoomAPI } from '../app/roomApi';
import axiosInstance from '../app/axiosInstance';


export const addRoom = createAsyncThunk(
  'rooms/addRoom',
  async (roomData, { rejectWithValue }) => {
    try {
      const response = await addRoomAPI(roomData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const getRoomsByHotelId = createAsyncThunk(
  'rooms/getRoomsByHotelId',
  async (hotelId, { rejectWithValue }) => {
    try {
      const response = await fetchRoomsByHotelId(hotelId);
      return response; 
    
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const getRooms = createAsyncThunk(
  "/getRoomsByHotelId",
  async (hotelId) => {
    try {
      const response = await axiosInstance.get(
        `/getRoomsByHotelId?hotelId=${hotelId}` 
      );
      return response.data.data;
    } catch (error) {
      throw error;
    }
  }
);

export const getImages = createAsyncThunk(
  "images/getImagesByHotelAndRoom",
  async ({ hotelId }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(
        `/images/getImagesByHotelAndRoom?hotelId=${hotelId}`
      );
      return response.data?.data || [];
    } catch (error) {
      console.error("Image fetch error:", error);
      return rejectWithValue(error.message);
    }
  }
);
// ✅ Fix here
export const updateRoom = createAsyncThunk(
  'rooms/updateRoom',
  async ({ roomId, roomData }, { rejectWithValue }) => {
    try {
      const data = await updateRoomAPI(roomId, roomData);  // <-- FIXED
      return data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);


export const deleteRoom = createAsyncThunk(
  'rooms/deleteRoom',
  async (roomId, { rejectWithValue }) => {
    try {
      await deleteRoomAPI(roomId);
      return roomId;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);



const roomSlice = createSlice({
  name: "rooms",
  initialState: {
    rooms: [], 
    selectedRoomType: "Single Room", 
    images: [], 
    status: "idle", 
    error: null,
    roomPrice: 0,
    roomCount: 1, 
    totalPrice: 0, 
    currentPage: 0, 
    pageSize: 10, 
  },
  
  reducers: {
    setSelectedRoomId: (state, action) => {
      state.selectedRoomId = action.payload;
    },
    setPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    setSelectedRoomType: (state, action) => {
      state.selectedRoomType = action.payload; 
      const selectedRoom = state.rooms.find(
        (room) => room.type === action.payload
      ); 
      if (selectedRoom) {
        state.roomPrice = selectedRoom.price; 
      }
    },
    setRoomPrice: (state, action) => {
      state.roomPrice = action.payload;
    },
    setRoomCount: (state, action) => {
      state.roomCount = action.payload; 
    },
    calculateTotalPrice: (state) => {
      state.totalPrice = state.roomPrice * state.roomCount; 
    },
    addRoomToState(state, action) {
      state.rooms.push(action.payload); 
    },
  },
  extraReducers: (builder) => {
    builder
    .addCase(getRoomsByHotelId.pending, (state) => {
      state.status = 'loading';
    })
.addCase(getRoomsByHotelId.fulfilled, (state, action) => {
  state.status = 'succeeded';
  state.rooms = Array.isArray(action.payload) ? action.payload : [];
  state.error = null;
})
    .addCase(getRoomsByHotelId.rejected, (state, action) => {
      state.status = 'failed';
      state.error = action.error.message || 'Failed to load rooms';
    })
      .addCase(getRooms.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getRooms.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.rooms = action.payload; 
       
        const defaultRoom = action.payload.find(
          (room) => room.type === "Single Room"
        );
        if (defaultRoom) {
          state.roomPrice = defaultRoom.price; 
        } else {
          state.roomPrice = 0; 
        }
      })
      .addCase(getRooms.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })

      .addCase(getImages.pending, (state) => {
        console.log("Images fetch pending");
        state.status = "loading";
      })
      .addCase(getImages.fulfilled, (state, action) => {
       
        if (JSON.stringify(state.images) !== JSON.stringify(action.payload)) {
          state.images = action.payload;
        }
        state.status = "succeeded";
      })
      .addCase(getImages.rejected, (state, action) => {
        console.log("Images fetch failed:", action.payload);
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(addRoom.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(addRoom.fulfilled, (state, action) => {
        state.status = 'succeeded';
      
        state.rooms = [action.payload, ...state.rooms];
      })
      .addCase(addRoom.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload || action.error.message; 
      })
     .addCase(updateRoom.pending, (state) => {
      state.status = 'loading';
    })
    .addCase(updateRoom.fulfilled, (state, action) => {
      state.status = 'succeeded';
      // Update the specific room in state
      const updatedRoom = action.payload;
      state.rooms = state.rooms.map(room => 
        room.roomId === updatedRoom.roomId ? updatedRoom : room
      );
    })
    .addCase(updateRoom.rejected, (state, action) => {
      state.status = 'failed';
      state.error = action.payload;
    })
    .addCase(deleteRoom.pending, (state) => {
      state.status = 'loading';
    })
    .addCase(deleteRoom.fulfilled, (state, action) => {
      state.status = 'succeeded';
      // Remove the deleted room from state
      state.rooms = state.rooms.filter(room => room.roomId !== action.payload);
    })
    .addCase(deleteRoom.rejected, (state, action) => {
      state.status = 'failed';
      state.error = action.payload;
    });
  },
});

export const {
  setSelectedRoomType,
  setSelectedRoomId,
  setPage,
  setRoomPrice,
  setRoomCount,
  calculateTotalPrice,
  setPageSize,
} = roomSlice.actions;

export default roomSlice.reducer;
