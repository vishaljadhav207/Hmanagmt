import { createSlice } from '@reduxjs/toolkit';
import { createFlightTrip, deleteFlightTrip, getAllFlightTrips, getFlightTripById, getFlightTripsByUserId, saveTickett, updateFlightTrip } from '../app/flighttripApi';

const initialState = {
  flighttrip: [],
  addFlightTrip: [],
  selectedFlightTrip: null,
  selectedTicket: null,
  userFlightTrip: [],
  status: "idle",
  error: null,
  currentPage: 0,
  totalPages: 1,
  pageSize: 10,
};

const flighttripSlice = createSlice({
  name: "flighttrip",
  initialState,
  reducers: {
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
      state.currentPage = 0;
    },
    resetFlightTripState: (state) => {
      state.flighttrip = [];
      state.selectedFlightTrip = null;
      state.userFlightTrip = [];
      state.status = "idle";
      state.error = null;
      state.currentPage = 0;
      state.totalPages = 1;
      state.pageSize = 10;
    },
  },
  extraReducers: (builder) => {
    builder

      .addCase(getAllFlightTrips.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getAllFlightTrips.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.flighttrip = action.payload || [];
        state.totalPages = 1;
      })
      .addCase(getAllFlightTrips.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(saveTickett.pending, (state) => {
        state.status = "loading";
      })
      .addCase(saveTickett.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedTicket = action.payload.data;
      })
      .addCase(saveTickett.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })

      .addCase(getFlightTripById.pending, (state) => {
        state.status = "loading";
        state.getFlightTripById = null;
      })
      .addCase(getFlightTripById.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.selectedFlightTrip = action.payload;
      })
      .addCase(getFlightTripById.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(getFlightTripsByUserId.pending, (state) => {
        state.status = "loading";
      })
      .addCase(getFlightTripsByUserId.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.userFlightTrip = action.payload || [];
      })
      .addCase(getFlightTripsByUserId.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload;
      })
      .addCase(createFlightTrip.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(createFlightTrip.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.flighttrip = action.payload;
      })
      .addCase(createFlightTrip.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload || action.error.message;
      })
      .addCase(deleteFlightTrip.pending, (state) => {
        state.deleteStatus = 'loading';
      })
      .addCase(deleteFlightTrip.fulfilled, (state, action) => {
        state.deleteStatus = 'succeeded';
        // Remove the deleted trip from the state
        state.userFlightTrip = state.userFlightTrip.filter(
          trip => trip.flightTripId !== action.payload
        );
      })
      .addCase(deleteFlightTrip.rejected, (state, action) => {
        state.deleteStatus = 'failed';
        state.deleteError = action.payload;
      })
      // Add this to your extraReducers in flighttripSlice.js
      .addCase(updateFlightTrip.pending, (state) => {
        state.updateStatus = 'loading';
      })
      .addCase(updateFlightTrip.fulfilled, (state, action) => {
        state.updateStatus = 'succeeded';
        // Update the trip in the state
        const index = state.userFlightTrip.findIndex(
          trip => trip.flightTripId === action.payload.flightTripId
        );
        if (index !== -1) {
          state.userFlightTrip[index] = action.payload;
        }
      })
      .addCase(updateFlightTrip.rejected, (state, action) => {
        state.updateStatus = 'failed';
        state.updateError = action.payload;
      });;


  },
});

export const { setCurrentPage, setPageSize, resetTrainTripState } = flighttripSlice.actions;
export default flighttripSlice.reducer;
export const flightTripState = (state) => state.flighttrip;
export const selectFlightTrip = (state) => state.userFlightTrip;
export const selectFlightTripStatus = (state) => state.flightTrip.status;
export const selectFlightTripError = (state) => state.flightTrip.error;
