import React from "react";

// Card Component

export const Card = ({ children }) => (
  <div className="rounded-xl border bg-white p-6 shadow-md   dark:bg-gray-500-800">
    {children}
  </div>
);

export const CardContent = ({ children}) => (
  <div className="mt-2">{children}</div>
);


