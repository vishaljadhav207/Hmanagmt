import React, { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Chip,
  Grid,
  Stack,
  Divider,
  Avatar,
  Paper,
  Pagination,
  CircularProgress,
  Alert,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import UpdateIcon from "@mui/icons-material/Update";
import TrainIcon from "@mui/icons-material/Train";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAllTrainTrips } from "../app/traintripApi";
import { setCurrentPage } from "../redux/trainTripSlice";
import seatAxios from "../app/seatAxios";

const TrainListing = ({ searchResults }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { traintrip, status, error, currentPage, totalPages, pageSize } =
    useSelector((state) => state.traintrip);

  const [seatsData, setSeatsData] = useState([]);
  const [loadingSeats, setLoadingSeats] = useState(false);
  const [seatAvailability, setSeatAvailability] = useState({});
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
  
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    dispatch(getAllTrainTrips({ page: currentPage, size: pageSize }));
  }, [dispatch, currentPage, pageSize]);

  useEffect(() => {
    const fetchSeatsData = async () => {
      setLoadingSeats(true);
      try {
        const response = await seatAxios.get("/train-seats/getAllTrainSeats");
        setSeatsData(response.data);

        const availabilityMap = {};
        response.data.forEach((seat) => {
          const key = `${seat.trainId}-${seat.classId}`;
          availabilityMap[key] = {
            total: seat.layout.seatMap.length,
            available: seat.layout.seatMap.filter((s) => s.available).length,
          };
        });
        setSeatAvailability(availabilityMap);
      } catch (err) {
        console.error("Error fetching seats data:", err);
      } finally {
        setLoadingSeats(false);
      }
    };

    fetchSeatsData();
  }, []);

  const handlePageChange = (event, newPage) => {
    dispatch(setCurrentPage(newPage - 1));
  };

  const handleCardClick = (trainTripId, fare) => {
    navigate("/train-booking", {
      state: { trainTripId, fare },
    });
  };

  const formatDate = (dateString) => {
    const options = { day: "2-digit", month: "short", year: "numeric" };
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", options).toUpperCase();
  };

  const calculateDuration = (
    departureDate,
    departureTime,
    arrivalDate,
    arrivalTime
  ) => {
    const depart = new Date(`${departureDate}T${departureTime}`);
    const arrive = new Date(`${arrivalDate}T${arrivalTime}`);
    const diffMs = arrive - depart;

    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}h ${minutes}m`;
  };

  const getAvailableSeats = (trainId, classId) => {
    if (loadingSeats) return { status: "loading", available: 0, total: 0 };

    const key = `${trainId}-${classId}`;
    const seatInfo = seatAvailability[key];

    if (!seatInfo) return { status: "not-available", available: 0, total: 0 };

    if (seatInfo.available === 0) {
      return { status: "sold-out", available: 0, total: seatInfo.total };
    }

    return {
      status: "available",
      available: seatInfo.available,
      total: seatInfo.total,
    };
  };

  const isFutureTrip = (trip) => {
    const firstStop = trip.intermediateStops[0];
    const departureTime = firstStop
      ? firstStop.departureTime.split("T")[1].substring(0, 5)
      : "08:00";
    
    const tripDateTime = new Date(`${trip.departureDate}T${departureTime}`);
    return tripDateTime > currentTime;
  };

  if (status === "loading") {
    return (
      <Container
        maxWidth="xl"
        sx={{ py: 4, display: "flex", justifyContent: "center" }}
      >
        <CircularProgress />
      </Container>
    );
  }

  if (status === "failed") {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }


  const filterFutureTrips = (trips) => {
    return Array.isArray(trips) ? trips.filter(trip => isFutureTrip(trip)) : [];
  };


  const trainsToShow = Array.isArray(searchResults) 
    ? filterFutureTrips(searchResults)
    : filterFutureTrips(Array.isArray(traintrip) ? traintrip : []);

  if (trainsToShow.length === 0) {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Alert severity="info">No upcoming trains available for the selected criteria.</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" fontWeight="bold" align="center" gutterBottom>
        🚆 Available Trains
      </Typography>

      <Stack spacing={4}>
        {trainsToShow.map((trip, index) => {
          const firstStop = trip.intermediateStops[0];
          const lastStop =
            trip.intermediateStops[trip.intermediateStops.length - 1];

          const departureTime = firstStop
            ? firstStop.departureTime.split("T")[1].substring(0, 5)
            : "08:00";
          const arrivalTime = lastStop
            ? lastStop.arrivalTime.split("T")[1].substring(0, 5)
            : "18:00";

          const duration = calculateDuration(
            trip.departureDate,
            departureTime,
            trip.arrivalDate,
            arrivalTime
          );

          return (
            <Card key={index} variant="outlined" sx={{ borderRadius: 2 }}>
              <CardContent>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  mb={2}
                >
                  <Box display="flex" alignItems="center" gap={1}>
                    <Avatar sx={{ bgcolor: "primary.main" }}>
                      <TrainIcon />
                    </Avatar>
                    <Typography variant="h6" fontWeight="bold">
                      {trip.train.trainName}
                    </Typography>
                  </Box>
                  <Chip label={`#${trip.train.trainNo}`} color="secondary" />
                </Box>

                <Box
                  display="flex"
                  justifyContent="space-between"
                  flexWrap="wrap"
                  mb={2}
                >
                  <Typography variant="body2">
                    Journey Date:{" "}
                    <strong>{formatDate(trip.departureDate)}</strong>
                  </Typography>
                  <Typography variant="body2">
                    Train No: <strong>{trip.train.trainNo}</strong>
                  </Typography>
                </Box>

                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} md={4}>
                    <Box display="flex" alignItems="center" gap={1}>
                      <AccessTimeIcon color="action" />
                      <Typography variant="subtitle1">
                        {departureTime}
                      </Typography>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      <LocationOnIcon fontSize="small" /> {trip.origin}
                    </Typography>
                  </Grid>
                  <Grid item xs={12} md={4} textAlign="center">
                    <Typography variant="body2" color="text.secondary">
                      Duration: {duration}
                    </Typography>
                    <Divider sx={{ my: 1 }} />
                    <Typography variant="caption" color="text.secondary">
                      {trip.intermediateStops.length - 1} intermediate stops
                    </Typography>
                  </Grid>
                  <Grid item xs={12} md={4} textAlign="right">
                    <Box display="flex" justifyContent="flex-end" gap={1}>
                      <AccessTimeIcon color="action" />
                      <Typography variant="subtitle1">{arrivalTime}</Typography>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      <LocationOnIcon fontSize="small" /> {trip.destination}
                    </Typography>
                  </Grid>
                </Grid>

                <Box
                  sx={{
                    display: "flex",
                    overflowX: "auto",
                    gap: 2,
                    py: 2,
                    scrollSnapType: "x mandatory",
                    "& > *": { scrollSnapAlign: "start" },
                  }}
                >
                  {trip.train?.classTypes.map((cls, clsIndex) => {
                    const seatStatus = getAvailableSeats(
                      trip.train.trainNo,
                      cls.classId
                    );

                    return (
                      <Paper
                        key={clsIndex}
                        elevation={3}
                        sx={{
                          minWidth: 250,
                          p: 2,
                          borderRadius: 2,
                          cursor: "pointer",
                          transition: "0.3s",
                          ":hover": { boxShadow: 6 },
                          border:
                            seatStatus.status === "sold-out" ||
                            seatStatus.status === "not-available"
                              ? "1px solid #ff6b6b"
                              : "1px solid #e0e0e0",
                        }}
                        onClick={() =>
                          handleCardClick(trip.trainTripId, cls.fare)
                        }
                      >
                        <Box
                          display="flex"
                          justifyContent="space-between"
                          mb={1}
                        >
                          <Typography variant="subtitle1" fontWeight="medium">
                            {cls.className}
                          </Typography>
                          <Chip
                            label={
                              cls.status === "pending" ? "REGULAR" : "TATKAL"
                            }
                            size="small"
                            color={
                              cls.status === "pending" ? "success" : "error"
                            }
                            variant="outlined"
                          />
                        </Box>

                        <Typography variant="h6" color="primary">
                          ₹{cls.fare}
                        </Typography>

                        <Box mt={1}>
                          <Typography variant="body2">
                            <strong>Seats:</strong>{" "}
                            {(() => {
                              switch (seatStatus.status) {
                                case "loading":
                                  return "Loading...";
                                case "not-available":
                                  return (
                                    <span style={{ color: "red" }}>
                                      Not available
                                    </span>
                                  );
                                case "sold-out":
                                  return (
                                    <span style={{ color: "red" }}>
                                      Sold out (Total: {seatStatus.total})
                                    </span>
                                  );
                                case "available":
                                  return (
                                    <>
                                      <span style={{ color: "green" }}>
                                        {seatStatus.available} available
                                      </span>
                                      <br />
                                      <small>
                                        Total seats: {seatStatus.total}
                                      </small>
                                    </>
                                  );
                                default:
                                  return "N/A";
                              }
                            })()}
                          </Typography>

                          <Box
                            display="flex"
                            alignItems="center"
                            mt={1}
                            color="success.main"
                          >
                            <CheckCircleIcon
                              fontSize="small"
                              sx={{ mr: 0.5 }}
                            />
                            <Typography variant="caption">
                              {cls.className === "General"
                                ? "No Refund"
                                : "Free Cancellation"}
                            </Typography>
                          </Box>

                          <Box
                            display="flex"
                            alignItems="center"
                            mt={1}
                            color="text.secondary"
                          >
                            <UpdateIcon fontSize="small" sx={{ mr: 0.5 }} />
                            <Typography variant="caption">
                              Updated just now
                            </Typography>
                          </Box>
                        </Box>
                      </Paper>
                    );
                  })}
                </Box>
              </CardContent>
            </Card>
          );
        })}
      </Stack>

      {!searchResults && totalPages > 1 && (
        <Box sx={{ display: "flex", justifyContent:"center", mt: 4 }}>
          <Pagination
            count={totalPages}
            page={currentPage + 1}
            onChange={handlePageChange}
            color="primary"
            showFirstButton
            showLastButton
          />
        </Box>
      )}
    </Container>
  );
};

export default TrainListing;