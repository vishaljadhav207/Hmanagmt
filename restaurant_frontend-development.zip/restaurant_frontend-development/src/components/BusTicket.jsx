import React from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Divider,
  Chip,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Button,
  Paper,
  Stack,
  IconButton,
  Badge,
} from "@mui/material";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import {
  DirectionsBus as BusIcon,
  Person as PersonIcon,
  Event as DateIcon,
  ConfirmationNumber as TicketIcon,
  Payment as PaymentIcon,
  LocationOn as LocationIcon,
  Schedule as TimeIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Print as PrintIcon,
  ArrowBack as BackIcon,
  Check as CheckIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  Download as DownloadIcon,
} from "@mui/icons-material";
import { useLocation, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import QRCode from "react-qr-code";
import Swal from "sweetalert2";

const BusTicket = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const ticketData = location.state?.ticket?.data;
  const busData = location.state?.ticket?.busData || ticketData?.busData;

  if (!ticketData) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "80vh",
          textAlign: "center",
          p: 3,
        }}
      >
        <Typography variant="h5" color="error" gutterBottom>
          No Ticket Found
        </Typography>
        <Typography variant="body1" sx={{ mb: 3 }}>
          We couldn't find your ticket details. Please check your booking
          history or try again.
        </Typography>
        <Button
          variant="contained"
          onClick={() => navigate("/bus")}
          startIcon={<BackIcon />}
        >
          Back to Bus Booking
        </Button>
      </Box>
    );
  }

  const {
    pnrNumber,
    transportType,
    transportId,
    classType,
    seatPreference,
    seatNumber,
    boarding,
    departure,
    bookingDate,
    journeyDate,
    status,
    totalFare,
    passengerList = [],
    waitingNumber,
  } = ticketData;

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "PPPp");
    } catch {
      return "N/A";
    }
  };

  const formatTime = (dateString) => {
    try {
      return format(new Date(dateString), "h:mm a");
    } catch {
      return "N/A";
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case "CONFIRM":
        return <CheckIcon color="success" />;
      case "WAITING":
        return <WarningIcon color="warning" />;
      case "CANCELLED":
        return <ErrorIcon color="error" />;
      default:
        return <CheckIcon color="info" />;
    }
  };

  const handleDownloadTicket = () => {
    Swal.fire({
      title: "Download Ticket",
      text: "This will download your ticket as a PDF file",
      icon: "info",
      showCancelButton: true,
      confirmButtonColor: "#5A2360",
      cancelButtonColor: "#6c757d",
      confirmButtonText: "Download",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.isConfirmed) {
        const input = document.getElementById("ticket-container");
        html2canvas(input, {
          scale: 2,
          logging: true,
          useCORS: true,
          allowTaint: true,
        }).then((canvas) => {
          const imgData = canvas.toDataURL("image/png");
          const pdf = new jsPDF("p", "mm", "a4");
          const imgWidth = 210;
          const pageHeight = 295;
          const imgHeight = (canvas.height * imgWidth) / canvas.width;
          let heightLeft = imgHeight;
          let position = 0;

          pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;

          while (heightLeft >= 0) {
            position = heightLeft - imgHeight;
            pdf.addPage();
            pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
          }

          pdf.save(`BusTicket_${pnrNumber}.pdf`);
        });
      }
    });
  };

  return (
    <Box sx={{ maxWidth: 800, mx: "auto", my: 4 }} id="ticket-container">
      <Paper elevation={3} sx={{ borderRadius: 3, overflow: "hidden" }}>
        {/* Header with Back Button */}
        <Box
          sx={{
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            bgcolor: "#f5f5f5",
          }}
        >
          <IconButton onClick={() => navigate("/bus")}>
            <BackIcon />
          </IconButton>
          <Typography variant="h6">Your Booking Details</Typography>
          <Box sx={{ width: 40 }} /> {/* Spacer for alignment */}
        </Box>

        {/* Ticket Header */}
        <Box
          sx={{
            background: "linear-gradient(135deg, #5A2360 0%, #3f51b5 100%)",
            color: "white",
            p: 3,
            textAlign: "center",
            position: "relative",
            overflow: "hidden",
            "&:before": {
              content: '""',
              position: "absolute",
              top: -50,
              right: -50,
              width: 100,
              height: 100,
              borderRadius: "50%",
              bgcolor: "rgba(255,255,255,0.1)",
            },
            "&:after": {
              content: '""',
              position: "absolute",
              bottom: -30,
              left: -30,
              width: 80,
              height: 80,
              borderRadius: "50%",
              bgcolor: "rgba(255,255,255,0.1)",
            },
          }}
        >
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            position="relative"
            zIndex={1}
          >
            <Box>
              <Typography variant="h4" component="h1" gutterBottom>
                Booking Confirmed
              </Typography>
              <Typography variant="subtitle1">
                E-Ticket / Boarding Pass
              </Typography>
            </Box>
            <Avatar sx={{ bgcolor: "white", width: 56, height: 56 }}>
              <BusIcon color="primary" fontSize="large" />
            </Avatar>
          </Stack>
        </Box>

        {/* PNR and Status */}
        <Box sx={{ p: 3, bgcolor: "background.paper", position: "relative" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <TicketIcon color="primary" />
                <Box>
                  <Typography variant="overline" color="text.secondary">
                    PNR Number
                  </Typography>
                  <Typography variant="h6">{pnrNumber}</Typography>
                </Box>
              </Stack>
            </Grid>
            <Grid item xs={12} md={6}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <DateIcon color="primary" />
                <Box>
                  <Typography variant="overline" color="text.secondary">
                    Booking Date
                  </Typography>
                  <Typography variant="h6">
                    {formatDate(bookingDate)}
                  </Typography>
                </Box>
              </Stack>
            </Grid>
          </Grid>

          <Box sx={{ mt: 2, display: "flex", gap: 1, alignItems: "center" }}>
            <Badge
              badgeContent={getStatusIcon()}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
            >
              <Chip
                label={status}
                color={
                  status === "CONFIRM"
                    ? "success"
                    : status === "WAITING"
                    ? "warning"
                    : "error"
                }
                sx={{
                  fontWeight: "bold",
                  pl: 3,
                  position: "relative",
                }}
              />
            </Badge>
            {waitingNumber > 0 && (
              <Chip
                label={`WL ${waitingNumber}`}
                color="warning"
                sx={{ fontWeight: "bold" }}
              />
            )}
          </Box>

          {/* QR Code */}
          <Box
            sx={{
              position: "absolute",
              right: 16,
              top: 16,
              display: { xs: "none", md: "block" },
            }}
          >
            <QRCode
              value={`PNR: ${pnrNumber}, Bus: ${busData?.busNo}, Date: ${journeyDate}`}
              size={80}
              level="H"
            />
          </Box>
        </Box>

        <Divider />

        {/* Journey Details */}
        <Box sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom sx={{ mb: 3 }}>
            Journey Details
          </Typography>

          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card variant="outlined" sx={{ height: "100%" }}>
                <CardContent>
                  <Stack direction="row" spacing={2} alignItems="center">
                    <LocationIcon color="primary" />
                    <Box>
                      <Typography variant="overline" color="text.secondary">
                        From
                      </Typography>
                      <Typography variant="h6">{boarding}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {formatTime(journeyDate)}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={6}>
              <Card variant="outlined" sx={{ height: "100%" }}>
                <CardContent>
                  <Stack direction="row" spacing={2} alignItems="center">
                    <LocationIcon color="primary" />
                    <Box>
                      <Typography variant="overline" color="text.secondary">
                        To
                      </Typography>
                      <Typography variant="h6">{departure}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {formatTime(busData?.arrivalDate)}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          <Card variant="outlined" sx={{ mt: 3 }}>
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={6} md={3}>
                  <Typography variant="overline" color="text.secondary">
                    Bus Operator
                  </Typography>
                  <Typography>{busData?.operatorName}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="overline" color="text.secondary">
                    Bus Type
                  </Typography>
                  <Typography>{classType}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="overline" color="text.secondary">
                    Bus Number
                  </Typography>
                  <Typography>{busData?.busNo}</Typography>
                </Grid>
                <Grid item xs={6} md={3}>
                  <Typography variant="overline" color="text.secondary">
                    Seat Preference
                  </Typography>
                  <Typography>{seatPreference || "N/A"}</Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Box>

        <Divider />

        {/* Passenger Details */}
        <Box sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Passenger Details
          </Typography>

          <List>
            {passengerList.map((passenger, index) => (
              <ListItem
                key={index}
                divider
                sx={{
                  bgcolor: "#f9f9f9",
                  borderRadius: 1,
                  mb: 1,
                }}
              >
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: "#5A2360" }}>
                    <PersonIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={passenger.name}
                  secondary={`${passenger.gender}, ${passenger.age} years`}
                />
                <Chip
                  label={passenger.seatNumber || "WL"}
                  color={passenger.seatNumber ? "primary" : "warning"}
                  variant="outlined"
                />
              </ListItem>
            ))}
          </List>
        </Box>

        <Divider />

        {/* Fare Details */}
        <Box sx={{ p: 3 }}>
          <Typography variant="h6" gutterBottom>
            Fare Details
          </Typography>

          <Card variant="outlined">
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography>Base Fare</Typography>
                </Grid>
                <Grid item xs={6} sx={{ textAlign: "right" }}>
                  <Typography>₹{totalFare - 200}</Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography>Taxes & Fees</Typography>
                </Grid>
                <Grid item xs={6} sx={{ textAlign: "right" }}>
                  <Typography>₹200</Typography>
                </Grid>

                <Grid item xs={12}>
                  <Divider sx={{ my: 1 }} />
                </Grid>

                <Grid item xs={6}>
                  <Typography variant="subtitle1">Total Amount</Typography>
                </Grid>
                <Grid item xs={6} sx={{ textAlign: "right" }}>
                  <Typography variant="subtitle1">₹{totalFare}</Typography>
                </Grid>
              </Grid>

              <Box sx={{ mt: 2, textAlign: "right" }}>
                <Chip
                  label="PAID"
                  color="success"
                  variant="outlined"
                  size="small"
                />
              </Box>
            </CardContent>
          </Card>
        </Box>

        {/* Contact Information */}
        <Box sx={{ p: 3, bgcolor: "#f5f5f5" }}>
          <Typography variant="h6" gutterBottom>
            Contact Information
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Box display="flex" alignItems="center">
                <PhoneIcon color="primary" sx={{ mr: 1 }} />
                <Typography>Customer Support: 1800-123-4567</Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Box display="flex" alignItems="center">
                <EmailIcon color="primary" sx={{ mr: 1 }} />
                <Typography>Email: support@busbooking.com</Typography>
              </Box>
            </Grid>
          </Grid>
        </Box>

        {/* Footer */}
        <Box
          sx={{
            p: 2,
            bgcolor: "grey.100",
            display: "flex",
            justifyContent: "center",
            gap: 2,
            flexWrap: "wrap",
          }}
        >
          <Button
            variant="contained"
            onClick={handleDownloadTicket}
            startIcon={<DownloadIcon />}
            sx={{
              minWidth: 200,
              background: "linear-gradient(135deg, #5A2360 0%, #3f51b5 100%)",
            }}
          >
            Download Ticket
          </Button>
          <Button
            variant="outlined"
            onClick={() => navigate("/bus")}
            startIcon={<BusIcon />}
            sx={{ minWidth: 200 }}
          >
            Book Another Ticket
          </Button>
        </Box>
      </Paper>
    </Box>
  );
};

export default BusTicket;
