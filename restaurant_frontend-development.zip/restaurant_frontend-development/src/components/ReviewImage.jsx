import React from "react";
import img1 from "../assets/room1.jpg";

const ReviewImage = () => (
  <div className="absolute top-4 right-4 w-24 h-24 sm:w-32 sm:h-32 lg:w-40 lg:h-40 overflow-hidden rounded-lg shadow-md border-2 border-white">
    <img
      src={img1}
      alt="Hotel"
      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
    />
  </div>
);

export default ReviewImage;
