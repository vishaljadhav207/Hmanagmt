"use client";
import train1 from "../assets/train.jpg";
import train2 from "../assets/train2.jpg";
import train3 from "../assets/train3.jpg";
import train4 from "../assets/train4.jpg";
import hotel1 from "../assets/homeImg1.jpg";
import hotel2 from "../assets/homeImg2.jpg";
import flight1 from "../assets/flight1.jpg";
import flight2 from "../assets/flight2.jpg";
import bus1 from "../assets/bus1.jpg";
import bus2 from "../assets/bus2.jpg";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  Grid3X3,
  List,
  Train,
  Hotel,
  Plane,
  Bus,
  Clock,
  Star,
  ArrowRight,
  ChevronsDown,
  ChevronsUp,
} from "lucide-react";
import { Button } from "@mui/material";

const TrainOffersCard = () => {
  const [activeTab, setActiveTab] = useState("All Offers");
  const [showAllOffers, setShowAllOffers] = useState(false);
  const navigate = useNavigate();
  // Category configurations with colors and icons
  const categoryConfig = {
    Trains: {
      color: "bg-green-500",
      bgColor: "bg-green-50",
      textColor: "text-green-700",
      borderColor: "border-green-200",
      icon: Train,
      label: "Train",
    },
    Hotels: {
      color: "bg-purple-500",
      bgColor: "bg-purple-50",
      textColor: "text-purple-700",
      borderColor: "border-purple-200",
      icon: Hotel,
      label: "Hotel",
    },
    Flights: {
      color: "bg-blue-500",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
      borderColor: "border-blue-200",
      icon: Plane,
      label: "Flight",
    },
    Bus: {
      color: "bg-orange-500",
      bgColor: "bg-orange-50",
      textColor: "text-orange-700",
      borderColor: "border-orange-200",
      icon: Bus,
      label: "Bus",
    },
  };

  const allOffers = [
    {
      category: "Trains",
      offers: [
        {
          id: 1,
          image: train1,
          title: "Book Train Tickets with FLAT ₹500 OFF*",
          description: "on Trip Guarantee",
          originalPrice: "₹2,500",
          discountedPrice: "₹2,000",
          discount: "20% OFF",
          validTill: "31 Dec 2024",
          rating: 4.5,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/train",
          category: "Trains",
          isPopular: true,
        },
        {
          id: 2,
          image: train2,
          title: "Weekend Special Discount",
          description: "Extra 10% OFF* on all train bookings",
          originalPrice: "₹1,800",
          discountedPrice: "₹1,620",
          discount: "10% OFF",
          validTill: "15 Jan 2025",
          rating: 4.2,
          buttonText: "AVAIL OFFER",
          buttonVariant: "primary",
          navigateTo: "/train",
          category: "Trains",
          isPopular: false,
        },
        {
          id: 3,
          image: train3,
          title: "Early Bird Discount",
          description: "15% OFF on bookings made 30 days in advance",
          originalPrice: "₹3,000",
          discountedPrice: "₹2,550",
          discount: "15% OFF",
          validTill: "28 Feb 2025",
          rating: 4.7,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/train",
          category: "Trains",
          isPopular: true,
        },
        {
          id: 4,
          image: train4,
          title: "Student Special",
          description: "Extra savings for student travelers",
          originalPrice: "₹1,500",
          discountedPrice: "₹1,200",
          discount: "20% OFF",
          validTill: "30 Jun 2025",
          rating: 4.3,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/train",
          category: "Trains",
          isPopular: false,
        },
      ],
    },
    {
      category: "Hotels",
      offers: [
        {
          id: 5,
          image: hotel1,
          title: "Luxury Stays at 40% OFF*",
          description: "Premium hotels with breakfast included",
          originalPrice: "₹8,000",
          discountedPrice: "₹4,800",
          discount: "40% OFF",
          validTill: "31 Mar 2025",
          rating: 4.8,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/hotel",
          category: "Hotels",
          isPopular: true,
        },
        {
          id: 6,
          image: hotel2,
          title: "Weekend Getaway Deals",
          description: "Special packages for 2 nights/3 days",
          originalPrice: "₹12,000",
          discountedPrice: "₹9,600",
          discount: "20% OFF",
          validTill: "15 Apr 2025",
          rating: 4.6,
          buttonText: "VIEW DETAILS",
          buttonVariant: "secondary",
          navigateTo: "/hotel",
          category: "Hotels",
          isPopular: false,
        },
      ],
    },
    {
      category: "Flights",
      offers: [
        {
          id: 7,
          image: flight1,
          title: "International Flights from ₹15,999*",
          description: "Including all taxes and fees",
          originalPrice: "₹25,000",
          discountedPrice: "₹15,999",
          discount: "36% OFF",
          validTill: "31 Jan 2025",
          rating: 4.4,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/flight",
          category: "Flights",
          isPopular: true,
        },
        {
          id: 8,
          image: flight2,
          title: "Domestic Flight Offers",
          description: "Up to 25% OFF* on select routes",
          originalPrice: "₹8,000",
          discountedPrice: "₹6,000",
          discount: "25% OFF",
          validTill: "28 Feb 2025",
          rating: 4.1,
          buttonText: "VIEW OFFERS",
          buttonVariant: "secondary",
          navigateTo: "/flight",
          category: "Flights",
          isPopular: false,
        },
      ],
    },
    {
      category: "Bus",
      offers: [
        {
          id: 9,
          image: bus1,
          title: "AC Bus Tickets at 15% OFF*",
          description: "On all overnight journeys",
          originalPrice: "₹1,200",
          discountedPrice: "₹1,020",
          discount: "15% OFF",
          validTill: "31 Dec 2024",
          rating: 4.0,
          buttonText: "BOOK NOW",
          buttonVariant: "primary",
          navigateTo: "/bus",
          category: "Bus",
          isPopular: false,
        },
        {
          id: 10,
          image: bus2,
          title: "Bus + Hotel Combo",
          description: "Save up to ₹2000* on package deals",
          originalPrice: "₹5,000",
          discountedPrice: "₹3,000",
          discount: "40% OFF",
          validTill: "15 Mar 2025",
          rating: 4.5,
          buttonText: "VIEW PACKAGES",
          buttonVariant: "secondary",
          navigateTo: "/bus",
          category: "Bus",
          isPopular: true,
        },
      ],
    },
  ];

  const renderOffers = () => {
    if (activeTab === "All Offers") {
      return allOffers.flatMap((category) => category.offers);
    }
    const category = allOffers.find((cat) => cat.category === activeTab);
    return category ? category.offers : [];
  };

  const offers = renderOffers();
  const initialOffers = offers.slice(0, 4);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setShowAllOffers(false);
  };

  const handleCardClick = (navigateTo) => {
    navigate(navigateTo);
  };
  const toggleShowAllOffers = () => {
    setShowAllOffers(!showAllOffers);
  };

  const getCategoryConfig = (category) => {
    return categoryConfig[category] || categoryConfig.Trains;
  };

  // Split cards into two columns for parallel display
  const leftColumnCards = initialOffers.slice(0, 2);
  const rightColumnCards = initialOffers.slice(2, 4);

  // Split all offers into two columns for expanded view
  const leftColumnAllCards = offers.filter((_, index) => index % 2 === 0);
  const rightColumnAllCards = offers.filter((_, index) => index % 2 === 1);

  const renderCard = (offer, index, isCompact = false) => {
    const config = getCategoryConfig(offer.category);
    const IconComponent = config.icon;

    return (
      <div
        key={offer.id}
        className={`bg-white border-l-4 ${config.color} border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:scale-[1.02] animate-slideInUp`}
        style={{ animationDelay: `${index * 150}ms` }}
        onClick={() => handleCardClick(offer.navigateTo)}
      >
        <div className="flex">
          {/* Image Section */}
          <div
            className={`relative ${
              isCompact ? "w-30 h-40" : "w-30 h-40"
            } flex-shrink-0`}
          >
            <img
              src={offer.image || "/placeholder.svg"}
              alt={offer.title}
              width={isCompact ? 128 : 160}
              height={isCompact ? 96 : 112}
              className="w-full h-full object-cover"
            />
            {/* Category Badge on Image */}
            <div
              className={`absolute ${
                isCompact ? "top-1 left-1" : "top-2 left-2"
              }`}
            ></div>
            {/* Discount Badge */}
            <div
              className={`absolute ${
                isCompact ? "top-1 right-1" : "top-2 right-2"
              } bg-red-500 text-white text-xs font-bold ${
                isCompact ? "px-1 py-0.5" : "px-2 py-1"
              } rounded`}
            >
              {offer.discount}
            </div>
            {/* Popular Badge */}
            {offer.isPopular && (
              <div
                className={`absolute ${
                  isCompact ? "bottom-1 left-1" : "bottom-2 left-2"
                } bg-yellow-400 text-yellow-900 text-xs font-bold ${
                  isCompact ? "px-1 py-0.5" : "px-2 py-1"
                } rounded flex items-center gap-1`}
              >
                <Star
                  className={`${
                    isCompact ? "w-2 h-2" : "w-3 h-3"
                  } fill-current`}
                />
                {isCompact ? "Hot" : "Popular"}
              </div>
            )}
          </div>

          {/* Content Section */}
          <div
            className={`flex-1 ${
              isCompact ? "p-3" : "p-4"
            } flex flex-col justify-between`}
          >
            <div>
              <div className="flex items-start justify-between mb-1">
                <h3
                  className={`font-bold ${
                    isCompact ? "text-sm" : "text-base"
                  } text-gray-800 line-clamp-2 flex-1 pr-2`}
                >
                  {offer.title}
                </h3>
                <div
                  className={`${isCompact ? "w-2 h-2" : "w-3 h-3"} ${
                    config.color
                  } rounded-full flex-shrink-0`}
                ></div>
              </div>
              <p
                className={`text-gray-600 ${
                  isCompact ? "text-xs mb-2 line-clamp-1" : "text-sm mb-2"
                }`}
              >
                {offer.description}
              </p>

              {/* Rating and Validity */}
              <div
                className={`flex items-center ${
                  isCompact ? "gap-1 mb-2" : "gap-2 mb-2"
                }`}
              >
                <Star
                  className={`${
                    isCompact ? "w-2 h-2" : "w-3 h-3"
                  } fill-yellow-400 text-yellow-400`}
                />
                <span
                  className={`${
                    isCompact ? "text-xs" : "text-sm"
                  } font-medium text-gray-700`}
                >
                  {offer.rating}
                </span>
                <span className="text-xs text-gray-400">•</span>
                <Clock
                  className={`${
                    isCompact ? "w-2 h-2" : "w-3 h-3"
                  } text-gray-500`}
                />
                <span className="text-xs text-gray-500">
                  {isCompact
                    ? offer.validTill.split(" ")[0] +
                      " " +
                      offer.validTill.split(" ")[1]
                    : offer.validTill}
                </span>
              </div>
            </div>

            {/* Price and Action Section */}
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <span
                  className={`${
                    isCompact ? "text-sm" : "text-base"
                  } font-bold text-gray-900`}
                >
                  {offer.discountedPrice}
                </span>
                <span className="text-xs text-gray-500 line-through">
                  {offer.originalPrice}
                </span>
              </div>
              <Button
                size="sm"
                className={`${config.color} hover:opacity-90 text-white ${
                  isCompact ? "px-2 py-1 text-xs" : "px-3 py-2 text-sm"
                } flex items-center gap-1`}
              >
                {isCompact ? "Book" : offer.buttonText}
                <ArrowRight
                  className={`${isCompact ? "w-2 h-2" : "w-3 h-3"}`}
                />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-2xl font-bold text-gray-800">Offers</h2>
          <div className="flex items-center gap-2">
            {showAllOffers ? (
              <List className="w-5 h-5 text-blue-600" />
            ) : (
              <Grid3X3 className="w-5 h-5 text-blue-600" />
            )}
            <span className="text-sm text-gray-600">
              {showAllOffers ? "All Offers" : "Featured"}
            </span>
          </div>
        </div>
        <div className="flex flex-wrap gap-5 text-sm font-medium border-b pb-4">
          {["Trains", "Hotels", "Flights", "Bus", "All Offers"].map((tab) => {
            const config = getCategoryConfig(tab);
            const IconComponent = config.icon;
            return (
              <span
                key={tab}
                className={`cursor-pointer pb-3 px-1 transition-colors flex items-center gap-2 ${
                  activeTab === tab
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-blue-600"
                }`}
                onClick={() => handleTabChange(tab)}
              >
                {tab !== "All Offers" && (
                  <>
                    <div
                      className={`w-2 h-2 rounded-full ${config.color}`}
                    ></div>
                    <IconComponent className="w-4 h-4" />
                  </>
                )}
                {tab}
              </span>
            );
          })}
        </div>
      </div>

      {/* Don't Miss Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 mb-8">
        <h3 className="font-bold text-gray-700 mb-1">DON'T MISS:</h3>
        <p className="text-gray-600">
          Grab up to 50% OFF* on stays, FREE* meals on flights & more
        </p>
      </div>

      {/* Offers Display */}
      <div className="mb-6 relative">
        <div
          className={`transition-all duration-500 ease-in-out ${
            showAllOffers
              ? "opacity-100 transform translate-y-0"
              : "opacity-100 transform translate-y-0"
          }`}
        >
          {!showAllOffers ? (
            // Initial View - 2 pairs of cards in parallel columns
            <div className="bg-gray-50 rounded-xl p-7 border-2 border-dashed border-gray-200">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-700">
                  Featured Offers
                </h3>
                <span className="text-sm text-gray-500 bg-white px-3 py-1 rounded-full">
                  {initialOffers.length} offers
                </span>
              </div>

              {/* Two Column Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fadeIn">
                {/* Left Column - First Pair */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2"></h4>
                  {leftColumnCards.map((offer, index) =>
                    renderCard(offer, index, true)
                  )}
                </div>

                {/* Right Column - Second Pair */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2"></h4>
                  {rightColumnCards.map((offer, index) =>
                    renderCard(offer, index + 2, true)
                  )}
                </div>
              </div>
            </div>
          ) : (
            // Full View - All offers in parallel columns with scrolling
            <div className>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-700">
                  All Offers
                </h3>
                <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                  {offers.length} offers
                </span>
              </div>

              {/* Two Column Layout for All Offers */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column - Even indexed offers */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Column A ({leftColumnAllCards.length} offers)
                  </h4>
                  {leftColumnAllCards.map((offer, index) =>
                    renderCard(offer, index * 2, false)
                  )}
                </div>

                {/* Right Column - Odd indexed offers */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    Column B ({rightColumnAllCards.length} offers)
                  </h4>
                  {rightColumnAllCards.map((offer, index) =>
                    renderCard(offer, index * 2 + 1, false)
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* View All Offers Button */}
      <div className="flex justify-center">
        <Button
          onClick={toggleShowAllOffers}
          variant={showAllOffers ? "outline" : "default"}
          className={`flex items-center gap-2 px-8 py-3 transition-all duration-300 transform hover:scale-105 active:scale-95 ${
            showAllOffers
              ? "text-blue-600 border-blue-600 hover:bg-blue-50"
              : "bg-blue-600 hover:bg-blue-700 text-white"
          }`}
        >
          {showAllOffers ? (
            <>
              <Grid3X3 className="w-4 h-4" />
              Show Featured
              <ChevronsUp className="w-4 h-4 transition-transform duration-300" />
            </>
          ) : (
            <>
              <List className="w-4 h-4" />
              View All Offers ({offers.length})
              <ChevronsDown className="w-4 h-4 transition-transform duration-300" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default TrainOffersCard;
