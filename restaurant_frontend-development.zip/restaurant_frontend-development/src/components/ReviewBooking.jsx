import React, { useState } from "react";
import { createBooking } from "../app/bookingApi";
import BookingDetails from "./BookingDetails";
import MealOptions from "./MealOptions";
import ImportantInfo from "./ImportantInfo";
import GuestDetails from "./GuestDetails";
import TripSecure from "./TripSecure";
import PriceSummary from "./PriceSummary";
import HotelInfo from "./HotelInfo";
import { useLocation } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import SuccessModal from "./SuccessModal";

export const ReviewBooking = () => {
  const [tripSecure, setTripSecure] = useState(false);
  const [mealOption, setMealOption] = useState("Room Only");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const location = useLocation();
  const { hotelName, hotelAdd, hotelId, selectedCity } = location.state || {};
  
  const [pricing, setPricing] = useState({
    basePrice: 0,
    taxes: 629,
    mealPrice: 0,
    tripProtection: 0,
    totalPrice: 0
  });

  const [bookingDetails, setBookingDetails] = useState({
    checkInDate: "",
    checkOutDate: "",
    numberOfAdults: 2,
    roomsNeeded: 1,
    roomType: "Single",
    paymentMethod: "",
  });

  const [guestDetails, setGuestDetails] = useState({
    title: "Mr",
    firstName: "",
    lastName: "",
    gender: "Male",
    age: "",
    nationality: "Indian",
    govIdType: "Aadhar",
    govIdNumber: "",
    email: "",
    mobile: "",
    gstNumber: "",
  });

  const resetForm = () => {
    setTripSecure(false);
    setMealOption("Room Only");
    setPricing({
      basePrice: 0,
      taxes: 629,
      mealPrice: 0,
      tripProtection: 0,
      totalPrice: 0
    });
    setBookingDetails({
      checkInDate: "",
      checkOutDate: "",
      numberOfAdults: 2,
      roomsNeeded: 1,
      roomType: "Single",
      paymentMethod: "",
    });
    setGuestDetails({
      title: "Mr",
      firstName: "",
      lastName: "",
      gender: "Male",
      age: "",
      nationality: "Indian",
      govIdType: "Aadhar",
      govIdNumber: "",
      email: "",
      mobile: "",
      gstNumber: "",
    });
  };

  const getMealPrice = (option) => {
    switch (option) {
      case "Add Breakfast": return 470;
      case "Add Breakfast + Lunch/Dinner": return 1645;
      default: return 0;
    }
  };

  const handleBookingDetailsChange = (details) => {
    setBookingDetails(details);
    
    const basePrice = details.basePrice || 0;
    const totalPrice = basePrice + 
                       pricing.taxes + 
                       pricing.mealPrice + 
                       pricing.tripProtection;
    
    setPricing(prev => ({
      ...prev,
      basePrice,
      totalPrice
    }));
  };

  const handleMealOptionChange = (e) => {
    const option = e.target.value;
    const mealPrice = getMealPrice(option);
    
    setMealOption(option);
    setPricing(prev => ({
      ...prev,
      mealPrice,
      totalAmount: prev.basePrice + prev.taxes + mealPrice + prev.tripProtection
    }));
  };

  const toggleTripSecure = () => {
    const tripProtection = !tripSecure ? 59 : 0;
    setTripSecure(!tripSecure);
    setPricing(prev => ({
      ...prev,
      tripProtection,
      totalPrice: prev.basePrice + prev.taxes + prev.mealPrice + tripProtection
    }));
  };

  const handleGuestDetailsChange = (e) => {
    const { name, value } = e.target;
    setGuestDetails(prev => ({ ...prev, [name]: value }));
  };

  const handlePaymentMethodChange = (e) => {
    setBookingDetails(prev => ({ ...prev, paymentMethod: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const payload = {
        ...bookingDetails,
        hotelId,
        city: selectedCity,
        guest: [{
          firstName: guestDetails.firstName,
          lastName: guestDetails.lastName,
          gender: guestDetails.gender,
          age: guestDetails.age,
          nationality: guestDetails.nationality,
          phoneNumber: guestDetails.mobile,
          govIdType: guestDetails.govIdType,
          govIdNumber: guestDetails.govIdNumber,
        }],
        totalPrice: pricing.totalPrice
      };

      const response = await createBooking(payload);
      if (response) {
        toast.success("Booking submitted successfully!");
        setIsModalOpen(true);
        setIsSuccess(true);
        resetForm();
      }
    } catch (error) {
      setSubmitError(error.message || "Booking failed");
      toast.error("Booking submission failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="review-booking bg-gray-50 min-h-screen py-8 relative">
      {isSubmitting && (
        <div className="absolute inset-0 bg-opacity-50 flex items-center justify-center z-50">
          <div className="flex flex-col items-center">
            <div className="animate-spin rounded-full h-15 w-15 border-t-4 border-b-4 border-black"></div>
          </div>
        </div>
      )}
      <div className={`container mx-auto px-4 sm:px-6 lg:px-8 ${isSubmitting ? "blur-sm" : ""}`}>
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Review Your Booking</h1>
          <p className="text-gray-600 mt-2">Please verify your details before proceeding to payment</p>
        </div>

        {submitError && (
          <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            {submitError}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-2/3 space-y-6">
              <HotelInfo hotelName={hotelName} hotelAdd={hotelAdd} selectedCity={selectedCity} hotelId={hotelId} />
              <BookingDetails 
                mealOption={mealOption} 
                onDetailsChange={handleBookingDetailsChange} 
                bookingDetails={bookingDetails}
              />
              <MealOptions mealOption={mealOption} handleMealOptionChange={handleMealOptionChange} />
              <ImportantInfo />
              <GuestDetails
                guestDetails={guestDetails}
                handleGuestDetailsChange={handleGuestDetailsChange}
                paymentMethod={bookingDetails.paymentMethod}
                handlePaymentMethodChange={handlePaymentMethodChange}
              />
              <TripSecure tripSecure={tripSecure} toggleTripSecure={toggleTripSecure} />
            </div>

            <div className="lg:w-1/3">
              <div className="sticky top-4 space-y-6">
                <PriceSummary
                  basePrice={pricing.basePrice}
                  taxes={pricing.taxes}
                  mealPrice={pricing.mealPrice}
                  tripProtection={pricing.tripProtection}
                  totalPrice={pricing.totalPrice}
                  duration={bookingDetails.duration || 1}
                />
                {isSuccess ? (
                  <button
                    type="button"
                    className="w-full py-4 px-6 bg-green-600 text-white font-bold rounded-lg shadow-md"
                    disabled
                  >
                    Booking Successful!
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-lg shadow-md transition-all duration-300 ${
                      isSubmitting ? "opacity-70 cursor-not-allowed" : "hover:from-blue-700 hover:to-indigo-700 hover:scale-[1.02]"
                    }`}
                  >
                    {isSubmitting ? "Processing..." : `Pay ₹${pricing.totalPrice.toLocaleString()}`}
                  </button>
                )}
              </div>
            </div>
          </div>
        </form>
        <SuccessModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </div>
    </div>
  );
};

export default ReviewBooking;