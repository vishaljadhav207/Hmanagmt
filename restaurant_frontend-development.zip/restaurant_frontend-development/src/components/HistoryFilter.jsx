import { useState } from "react";

const HistoryFilter = ({ onFilterChange }) => {
  const [filter, setFilter] = useState("All");

  const statusMap = {
    All: "All",
    Completed: "CHECKED_OUT",
    Checked_In: "CHECKED_IN",
    Pending: "PENDING",
    Cancelled: "CANCELLED",
    Booked: "BOOKED",
    Rejected: "REJECTED",
  };

  const handleChange = (e) => {
    const selectedValue = e.target.value;
    setFilter(selectedValue);
    onFilterChange(statusMap[selectedValue] || selectedValue);
  };

  return (
    <div className="filter mb-4">
      <label htmlFor="status-filter" className="block text-white font-semibold mb-2">
        Filter by status:
      </label>
      <select
        id="status-filter"
        value={filter}
        onChange={handleChange}
        className="block w-2xs p-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:border-blue-300"
      >
        <option value="All">All</option>
        <option value="Completed">Completed</option>
        <option value="Pending">Pending</option>
        <option value="Cancelled">Cancelled</option>
        <option value="Booked">Booked</option>
        <option value="Rejected">Rejected</option>
      </select>
    </div>
  );
};

export default HistoryFilter;