import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { getRooms } from "../redux/roomSlice";

const Price = ({ hotelId, roomCount, selectedRoomType, roomPrice }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { hotelId: paramHotelId } = useParams(); // Get hotelId from URL params
  const { rooms, status, error } = useSelector((state) => state.rooms);

  const [localRoomPrice, setLocalRoomPrice] = useState(0);
  const [hotelName, setHotelName] = useState("");
  const [hotelAdd, setHotelAdd] = useState("");
  const [hotelCity, setHotelCity] = useState("");

  // Use the prop hotelId if available, otherwise use the param
  const effectiveHotelId = hotelId || paramHotelId;

  useEffect(() => {
    if (effectiveHotelId) {
      dispatch(getRooms(effectiveHotelId)).then((response) => {
        const hotelData = response.payload[0]?.hotel;
        setHotelName(hotelData?.hotelName || "Nisarg Hotel");
        setHotelAdd(hotelData?.hotelAdd || "");
        setHotelCity(hotelData?.city || "");
      });
    }
  }, [dispatch, effectiveHotelId]);

  useEffect(() => {
    if (rooms.length > 0 && selectedRoomType) {
      const selectedRoom = rooms.find(
        (room) => room.roomType === selectedRoomType
      );
      if (selectedRoom) {
        setLocalRoomPrice(selectedRoom.roomBasePrice || 0);
      }
    }
  }, [selectedRoomType, rooms]);

  const roomTotalPrice = localRoomPrice * (roomCount || 1);

  const handleBuyNow = () => {
    navigate("/review-booking", {
      state: {
        hotelName: hotelName,
        hotelAdd: hotelAdd,
        hotelId: effectiveHotelId,
        selectedCity: hotelCity,
      },
    });
  };

  const amenities = [
    "Complimentary 2 Pint(s) of Beer",
    "Happy Hours with 1+1 offer",
    "Free Breakfast",
  ];

  if (status === "loading") return <div>Loading price information...</div>;
  if (status === "failed") return <div>Error: {error}</div>;

  return (
    <div className="flex justify-center items-center">
      <section className="bg-white dark:bg-gray-900 w-full max-w-sm">
        <div className="flex flex-col mx-auto text-center text-gray-900 bg-white border border-gray-100 rounded-lg shadow dark:border-gray-600 xl:p-8 dark:bg-gray-800 dark:text-white">
          <h1 className="mb-4 text-2xl font-bold">{hotelName}</h1>

          {hotelAdd && (
            <p className="font-light text-black sm:text-lg dark:text-gray-400">
              Address: {hotelAdd}
            </p>
          )}

          <p className="font-light text-black sm:text-lg dark:text-gray-400">
            Number of Rooms: {roomCount || 1}
          </p>

          <p className="font-light text-black sm:text-lg dark:text-gray-400">
            Room Type: {selectedRoomType || "Single Room"}
          </p>

          <div className="flex items-baseline justify-center my-8">
            <span className="mr-2 text-5xl font-extrabold">
              ₹{roomTotalPrice.toLocaleString()}
            </span>
            <span className="text-gray-500 dark:text-gray-400">/Night</span>
          </div>

          <ul role="list" className="mb-8 space-y-4 text-left">
            {amenities.map((amenity, index) => (
              <li key={index} className="flex items-center space-x-3 ml-4">
                {" "}
                {/* Added ml-4 for left margin */}
                <svg
                  className="flex-shrink-0 w-5 h-5 text-green-500 dark:text-green-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                    clipRule="evenodd"
                  ></path>
                </svg>
                <span>{amenity}</span>
              </li>
            ))}
          </ul>

          <button
            onClick={handleBuyNow}
            className="text-white bg-fuchsia-950 hover:bg-purple-800 focus:ring-4 focus:ring-purple-200 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:text-white dark:focus:ring-purple-900 transition-colors duration-200"
            disabled={!selectedRoomType}
          >
            Buy Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default Price;
