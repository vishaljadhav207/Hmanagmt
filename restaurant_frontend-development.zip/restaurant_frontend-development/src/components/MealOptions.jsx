import React from "react";

const MealOptions = ({ mealOption, handleMealOptionChange }) => {
  const options = [
    {
      value: "Room Only",
      label: "Room Only",
      price: 0,
    },
    {
      value: "Add Breakfast",
      label: "Add Breakfast",
      price: 470,
    },
    {
      value: "Add Breakfast + Lunch/Dinner",
      label: "Add Breakfast + Lunch/Dinner",
      price: 1645,
    },
  ];

  return (
    <div className="meal-options mb-8 p-6 bg-white rounded-xl shadow-md border border-gray-100">
      <h3 className="text-2xl font-semibold mb-6 text-gray-800 border-b pb-2">
        Upgrade Your Stay
      </h3>
      <div className="space-y-4">
        {options.map((option) => (
          <label
            key={option.value}
            className={`flex items-start p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
              mealOption === option.value
                ? "border-blue-500 bg-blue-50"
                : "border-gray-200 hover:border-blue-300"
            }`}
          >
            <input
              type="radio"
              name="meal"
              value={option.value}
              checked={mealOption === option.value}
              onChange={handleMealOptionChange}
              className="mt-1 mr-3"
            />
            <div className="flex-1">
              <div className="font-medium text-gray-800">{option.label}</div>
              {option.price > 0 && (
                <div className="text-sm text-gray-600 mt-1">
                  ₹{option.price.toLocaleString()} for all guests
                </div>
              )}
            </div>
          </label>
        ))}
      </div>
    </div>
  );
};

export default MealOptions;
