import React from "react";

const TripSecure = ({ tripSecure, toggleTripSecure }) => (
  <div className="trip-secure mb-8 p-6 bg-white rounded-xl shadow-md border border-gray-100">
    <h3 className="text-2xl font-semibold mb-6 text-gray-800 border-b pb-2">
      Secure Your Trip
    </h3>
    <div className="p-4 bg-blue-50 rounded-lg">
      <div className="flex items-start">
        <input
          type="checkbox"
          checked={tripSecure}
          onChange={toggleTripSecure}
          className="mt-1 mr-3 h-5 w-5 text-blue-600 rounded focus:ring-blue-500"
        />
        <div>
          <div className="flex items-center">
            <span className="font-medium text-gray-800">
              Yes, secure my trip
            </span>
            <span className="ml-2 px-2 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded">
              ₹59 per guest
            </span>
          </div>
          <p className="text-sm text-gray-600 mt-1">Enjoy a Worry-Free Stay</p>
          <p className="text-xs text-gray-500 mt-2">
            Non Refundable | 18% GST Included
          </p>
        </div>
      </div>
    </div>
  </div>
);

export default TripSecure;
