import React, { useState, useRef, useEffect } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { Card, CardBody, Alert } from "@material-tailwind/react";
import DatePicker from "./DatePicker";
import DropDownSelector from "./DropDownSelector";
import { useDispatch } from "react-redux";
import { searchTrainTrips, getAllTrainTrips } from "../app/traintripApi";
import {
  ExclamationCircleIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";

function TrainBookingTabs({ onBookingSubmit }) {
  const [travelDate, setTravelDate] = useState(new Date());
  const [isTravelDateOpen, setIsTravelDateOpen] = useState(false);
  const [calendarPosition, setCalendarPosition] = useState({ top: 0, left: 0 });
  const [selectedClass, setSelectedClass] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [stations, setStations] = useState([]);
  const [sourceStation, setSourceStation] = useState("");
  const [destinationStation, setDestinationStation] = useState("");
  const dispatch = useDispatch();

  const calendarRef = useRef(null);

  useEffect(() => {
    const fetchStations = async () => {
      try {
        const result = await dispatch(
          getAllTrainTrips({ page: 0, size: 1000 })
        );
        const trips = result.payload || [];

        const origins = trips.map((t) => t.origin);
        const destinations = trips.map((t) => t.destination);
        const uniqueStations = Array.from(
          new Set([...origins, ...destinations])
        ).filter(Boolean);
        setStations(uniqueStations);

        setSourceStation(uniqueStations[0] || "");
        setDestinationStation(uniqueStations[1] || "");
      } catch (err) {
        setError("Failed to load stations.");
      }
    };
    fetchStations();
  }, [dispatch]);

  const handleDateChange = (newDate) => {
    setTravelDate(newDate);
    setIsTravelDateOpen(false);
  };

  const toggleCalendar = (e) => {
    const rect = e.target.getBoundingClientRect();
    setCalendarPosition({
      top: rect.bottom + window.scrollY + 10,
      left: rect.left + window.scrollX,
    });
    setIsTravelDateOpen(true);
  };

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const submitData = async () => {
    if (!sourceStation || !destinationStation) {
      setError("Please select both FROM and TO stations.");
      return;
    }
    setError(null);
    setSuccess(null);
    setIsLoading(true);

    try {
      const searchData = {
        origin: sourceStation,
        destination: destinationStation,
        departureDate: formatDate(travelDate),
        className: selectedClass,
      };

      const result = await dispatch(searchTrainTrips(searchData));
      if (result.payload && result.payload.length > 0) {
        setSuccess(
          `Found ${result.payload.length} trains matching your search!`
        );
        if (onBookingSubmit) {
          onBookingSubmit({
            ...searchData,
            searchResults: result.payload,
          });
        }
      } else {
        setError(
          "No trains found matching your search criteria. Please try different options."
        );
        if (onBookingSubmit) {
          onBookingSubmit({
            ...searchData,
            searchResults: [],
          });
        }
      }
    } catch (error) {
      setError("Failed to search for trains. Please try again later.");
      if (onBookingSubmit) {
        onBookingSubmit({
          searchResults: [],
          error: "Search failed",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center p-4 gap-4">
      {error && (
        <Alert
          color="red"
          icon={<ExclamationCircleIcon className="h-6 w-6" />}
          className="w-full max-w-5xl rounded-lg"
        >
          {error}
        </Alert>
      )}

      {success && (
        <Alert
          color="green"
          icon={<CheckCircleIcon className="h-6 w-6" />}
          className="w-full max-w-5xl rounded-lg"
        >
          {success}
        </Alert>
      )}

      <Card className="w-full max-w-5xl bg-[#320D36] text-white shadow-lg rounded-xl p-6 relative">
        <CardBody className="flex flex-col md:flex-row items-center justify-between gap-4">
          <DropDownSelector
            label="FROM"
            value={sourceStation}
            onChange={(e) => setSourceStation(e.target.value)}
            label1="Select Origin"
            options={stations}
            className="w-full md:w-1/3 h-25 pt-5.5 bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer"
          />

          <DropDownSelector
            label="TO"
            value={destinationStation}
            onChange={(e) => setDestinationStation(e.target.value)}
            label1="Select Destination"
            options={stations}
            className="w-full md:w-1/3 h-25 pt-5.5 bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer"
          />

          <DatePicker
            onClick={toggleCalendar}
            label="TRAVEL DATE"
            date={travelDate}
            className="w-full md:w-1/3 h-25 bg-[#5A2360] pt-5.5 text-white p-4 rounded-lg text-center cursor-pointer"
          />

          <div
            onClick={submitData}
            className="w-full md:w-1/3 h-25 pt-5.5 bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer hover:bg-[#6A2C70] transition-colors"
          >
            <button
              type="submit"
              className="py-3 cursor-pointer"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg
                    className="animate-spin h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Searching...
                </span>
              ) : (
                "Search Trains"
              )}
            </button>
          </div>
        </CardBody>
      </Card>

      {isTravelDateOpen && (
        <div
          ref={calendarRef}
          style={{
            position: "absolute",
            top: calendarPosition.top,
            left: calendarPosition.left,
          }}
          className="border rounded-sm shadow-lg z-50 bg-white"
        >
          <Calendar
            onChange={handleDateChange}
            value={travelDate}
            minDate={new Date()}
            className="react-calendar"
          />
        </div>
      )}
    </div>
  );
}

export default TrainBookingTabs;
