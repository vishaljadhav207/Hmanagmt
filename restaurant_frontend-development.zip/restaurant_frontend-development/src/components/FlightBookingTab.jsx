import React, { useRef, useState, useEffect } from "react";
import Calendar from "react-calendar";
import { GoArrowSwitch } from "react-icons/go";
import "react-calendar/dist/Calendar.css";
import { Card, CardBody, Alert } from "@material-tailwind/react";
import DropDownSelector from "./DropDownSelector";
import flightImage from "../assets/flight2.avif";
import { useDispatch } from "react-redux";
import { searchFlightTrips, getAllFlightTrips } from "../app/flighttripApi";
import {
  ExclamationCircleIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";
import axios from "axios";
import DatePicker from "./DatePicker";

const FlightBookingTab = ({ onBookingSubmit }) => {
  const [cityFrom, setCityFrom] = useState("");
  const [cityTo, setCityTo] = useState("");
  const [departureDate, setDepartureDate] = useState(new Date());
  const [calendarPosition, setCalendarPosition] = useState({ top: 0, left: 0 });
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [classSelected, setClassSelected] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [airports, setAirports] = useState([]);
  const dispatch = useDispatch();
  const calendarRef = useRef(null);

  useEffect(() => {
    const fetchAirports = async () => {
      try {
        const result = await dispatch(
          getAllFlightTrips({ page: 0, size: 1000 })
        );
        const trips = result.payload || [];
        const origins = trips.map((t) => t.origin);
        const destinations = trips.map((t) => t.destination);
        const uniqueAirports = Array.from(
          new Set([...origins, ...destinations])
        ).filter(Boolean);
        setAirports(uniqueAirports);
        setCityFrom(uniqueAirports[0] || "");
        setCityTo(uniqueAirports[1] || "");
      } catch (err) {
        setError("Failed to load airports.");
      }
    };
    fetchAirports();
  }, [dispatch]);

  const handleDateChange = (newDate) => {
    setDepartureDate(newDate);
    setIsCalendarOpen(false);
  };

  const toggleCalendar = (e) => {
    const rect = e.target.getBoundingClientRect();
    setCalendarPosition({
      top: rect.bottom + window.scrollY + 10,
      left: rect.left + window.scrollX,
    });
    setIsCalendarOpen(true);
  };

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const submitData = async () => {
    if (!cityFrom || !cityTo) {
      setError("Please select both FROM and TO airports.");
      return;
    }
    setError(null);
    setSuccess(null);
    setIsLoading(true);

    try {
      const searchData = {
        origin: cityFrom,
        destination: cityTo,
        departureDate: formatDate(departureDate),
        className: classSelected,
      };

      const result = await dispatch(searchFlightTrips(searchData));
      const trips = result.payload || [];

      const filteredTrips = classSelected
        ? trips.filter((trip) =>
            trip.classTypes.some((cls) => cls.className === classSelected)
          )
        : trips;

      if (filteredTrips.length > 0) {
        setSuccess(
          `Found ${filteredTrips.length} flights matching your search!`
        );
        if (onBookingSubmit) {
          onBookingSubmit(
            filteredTrips.map((trip) => ({
              ...trip,
              classTypes: classSelected
                ? trip.classTypes.filter(
                    (cls) => cls.className === classSelected
                  )
                : trip.classTypes,
            }))
          );
        }
      } else {
        setError(
          "No flights found matching your search criteria. Please try different options."
        );
        if (onBookingSubmit) {
          onBookingSubmit([]);
        }
      }
    } catch (error) {
      setError("Failed to search for flights. Please try again later.");
      if (onBookingSubmit) {
        onBookingSubmit([]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-[300px] pt-15 pb-10">
      <div className="absolute inset-0 z-0 ">
        <img
          src={flightImage}
          alt="Flight background"
          className="w-full h-[400px] object-cover"
        />
      </div>
      <div className="text-center text-3xl text-white font-extrabold font-sans md:font-serif font-boldmb-2 scale-x-110 drop-shadow-xs">
        <div>Take Off On Your</div>
        <div className="text-5xl">Flights</div>
      </div>
      <div className="relative z-10 flex justify-center p-4">
        <Card className="w-full max-w-5xl bg-[#320D36] text-white shadow-lg rounded-xl p-6">
          {error && (
            <Alert
              color="red"
              icon={<ExclamationCircleIcon className="h-6 w-6" />}
              className="w-full max-w-5xl rounded-lg mb-4"
            >
              {error}
            </Alert>
          )}

          {success && (
            <Alert
              color="green"
              icon={<CheckCircleIcon className="h-6 w-6" />}
              className="w-full max-w-5xl rounded-lg mb-4"
            >
              {success}
            </Alert>
          )}

          {isCalendarOpen && (
            <div
              ref={calendarRef}
              style={{
                position: "absolute",
                top: "9rem",
                left: "27.5rem",
              }}
              className="z-50 bg-white text-black rounded shadow-lg"
            >
              <Calendar
                onChange={handleDateChange}
                value={departureDate}
                minDate={new Date()}
                className="react-calendar"
              />
            </div>
          )}

          <CardBody className="flex flex-col md:flex-row items-center justify-between gap-4">
            <DropDownSelector
              label="FROM"
              value={cityFrom}
              onChange={(e) => setCityFrom(e.target.value)}
              label1="Select Origin"
              options={airports}
              className="w-full md:w-1/3 bg-[#5A2360] text-white py-4 px-4 rounded-lg text-center cursor-pointer"
            />

            <GoArrowSwitch
              className="text-white text-5xl hidden md:block cursor-pointer hover:rotate-180 transition-transform duration-300"
              onClick={() => {
                const temp = cityFrom;
                setCityFrom(cityTo);
                setCityTo(temp);
              }}
            />

            <DropDownSelector
              label="TO"
              value={cityTo}
              onChange={(e) => setCityTo(e.target.value)}
              label1="Select Destination"
              options={airports}
              className="w-full md:w-1/3 bg-[#5A2360] text-white py-4 px-4 rounded-lg text-center cursor-pointer"
            />

            <DatePicker
              onClick={toggleCalendar}
              label="DEPARTURE DATE"
              date={departureDate}
              className="w-full md:w-1/3 bg-[#5A2360] text-white py-4 px-4 rounded-lg text-center cursor-pointer"
            />
            <div
              onClick={submitData}
              className="w-full md:w-1/3 bg-[#5A2360] text-white py-4 px-4 rounded-lg text-center cursor-pointer hover:bg-[#6A2C70] transition-colors flex items-center justify-center"
            >
              <button
                type="submit"
                className="w-full py-3 cursor-pointer bg-transparent text-white"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg
                      className="animate-spin h-5 w-5 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Searching...
                  </span>
                ) : (
                  "Search Flights"
                )}
              </button>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default FlightBookingTab;
