import React, { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Chip,
  Grid,
  Stack,
  Divider,
  Avatar,
  Paper,
  Pagination,
  CircularProgress,
  Alert,
  Collapse,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Tooltip,
  Button,
} from "@mui/material";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import UpdateIcon from "@mui/icons-material/Update";
import FlightIcon from "@mui/icons-material/Flight";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import StopIcon from "@mui/icons-material/Stop";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAllFlightTrips } from "../app/flighttripApi";

import seatAxios from "../app/seatAxios";
import { setCurrentPage } from "../redux/hotelSlice";

const FlightListing = ({ searchResults }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { flighttrip, status, error, currentPage, totalPages, pageSize } =
    useSelector((state) => state.flighttrip);

  const [seatsData, setSeatsData] = useState([]);
  const [loadingSeats, setLoadingSeats] = useState(false);
  const [expandedStops, setExpandedStops] = useState({});


  const filterCurrentAndFutureTrips = (trips) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0); 
    
    return trips.filter(trip => {
      const departureDate = new Date(trip.departureDate);
      return departureDate >= today;
    }).sort((a, b) => new Date(a.departureDate) - new Date(b.departureDate));
  };

  
  const isToday = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

 
  useEffect(() => {
    if (!searchResults) {
      const today = new Date().toISOString().split('T')[0]; 
      dispatch(
        getAllFlightTrips({
          page: currentPage,
          size: pageSize,
          departureAfter: today,
        })
      );
    }
  }, [dispatch, currentPage, pageSize, searchResults]);

  useEffect(() => {
    const fetchSeatsData = async () => {
      setLoadingSeats(true);
      try {
        const response = await seatAxios.get("/flight-seats/getAllFlightSeat");
        setSeatsData(response.data);
      } catch (err) {
        console.error("Error fetching seats data:", err);
      } finally {
        setLoadingSeats(false);
      }
    };

    fetchSeatsData();
  }, []);

  const handlePageChange = (event, newPage) => {
    dispatch(setCurrentPage(newPage - 1));
  };

  const handleCardClick = (flightTripId, className, fare) => {
    navigate("/flight-booking", { state: { flightTripId, className, fare } });
  };

  const formatDate = (dateString) => {
    const options = { day: "2-digit", month: "short", year: "numeric" };
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", options).toUpperCase();
  };

  const formatTime = (timeString) => {
    if (!timeString) return "N/A";
 
    const timePart = timeString.includes('T') 
      ? timeString.split('T')[1] 
      : timeString;
    return timePart.substring(0, 5);
  };

  const calculateDuration = (departureTime, arrivalTime) => {
    if (!departureTime || !arrivalTime) return "N/A";
    
    const depart = new Date(`2000-01-01T${departureTime}`);
    const arrive = new Date(`2000-01-01T${arrivalTime}`);
    
 
    if (arrive < depart) {
      arrive.setDate(arrive.getDate() + 1);
    }
    
    const diffMs = arrive - depart;
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}h ${minutes}m`;
  };

  const toggleStopsExpansion = (flightTripId) => {
    setExpandedStops((prev) => ({
      ...prev,
      [flightTripId]: !prev[flightTripId],
    }));
  };

  const getAvailableSeats = (flightNo, className, journeyDate) => {
    if (loadingSeats) return { status: "loading", available: 0, total: 0 };

    if (!seatsData || seatsData.length === 0) {
      return { status: "not-available", available: 0, total: 0 };
    }

    const formattedDate = journeyDate?.split('T')[0];
    const seatInfo = seatsData.find(
      (seat) =>
        seat.flightNo === flightNo.toString() &&
        seat.className.toLowerCase() === className.toLowerCase() &&
        (!seat.journeyDate || seat.journeyDate === formattedDate)
    );

    if (!seatInfo) {
      return { status: "not-available", available: 0, total: 0 };
    }

    const totalSeats = seatInfo.layout.seatMap.length;
    const availableSeats = seatInfo.layout.seatMap.filter(
      (seat) => seat.available
    ).length;

    return {
      status: availableSeats > 0 ? "available" : "sold-out",
      available: availableSeats,
      total: totalSeats,
    };
  };

  if (status === "loading") {
    return (
      <Container maxWidth="xl" sx={{ py: 4, display: "flex", justifyContent: "center" }}>
        <CircularProgress />
      </Container>
    );
  }

  if (status === "failed") {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  const flightsToShow = searchResults && Array.isArray(searchResults) 
    ? filterCurrentAndFutureTrips(searchResults) 
    : filterCurrentAndFutureTrips(flighttrip);

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" fontWeight="bold" align="center" gutterBottom>
        ✈️ Available Flights
      </Typography>

      {flightsToShow.length === 0 ? (
        <Alert severity="info" sx={{ mt: 2 }}>
          No flights available for today or future dates. Please try a different search.
        </Alert>
      ) : (
        <>
          <Stack spacing={4}>
            {flightsToShow.map((trip, index) => {
              const firstStop = trip.intermediateStops[0];
              const lastStop = trip.intermediateStops[trip.intermediateStops.length - 1];
              
              const departureTime = firstStop ? firstStop.departureTime : trip.departureTime;
              const arrivalTime = lastStop ? lastStop.arrivalTime : trip.arrivalTime;
              
              const duration = calculateDuration(
                formatTime(departureTime),
                formatTime(arrivalTime)
              );

              return (
                <Card
                  key={index}
                  variant="outlined"
                  sx={{ borderRadius: 2, boxShadow: 3 }}
                >
                  <CardContent>
                    {/* Header */}
                    <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                      <Box display="flex" alignItems="center" gap={1}>
                        <Avatar sx={{ bgcolor: "primary.main" }}>
                          <FlightIcon />
                        </Avatar>
                        <Typography variant="h6" fontWeight="bold">
                          {trip.flight?.airline || "Unknown Airline"}
                        </Typography>
                        {isToday(trip.departureDate) && (
                          <Chip label="Today" color="primary" size="small" />
                        )}
                      </Box>
                      <Chip
                        label={`#${trip.flight?.flight_no || "N/A"}`}
                        color="secondary"
                        variant="outlined"
                      />
                    </Box>

                    {/* Departure Info */}
                    <Box display="flex" justifyContent="space-between" flexWrap="wrap" mb={2}>
                      <Typography variant="body2">
                        Departure: <strong>{formatDate(trip.departureDate)}</strong>
                      </Typography>
                      <Typography variant="body2">
                        Aircraft: <strong>{trip.flight?.aircraftType || "Standard"}</strong>
                      </Typography>
                    </Box>

                    {/* Grid Info */}
                    <Grid container spacing={2} alignItems="center">
                      <Grid item xs={12} md={4}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <AccessTimeIcon color="action" />
                          <Typography variant="subtitle1">
                            {formatTime(departureTime)}
                          </Typography>
                        </Box>
                        <Typography variant="caption" color="text.secondary">
                          <LocationOnIcon fontSize="small" /> {trip.origin}
                        </Typography>
                      </Grid>
                      <Grid item xs={12} md={4} textAlign="center">
                        <Typography variant="body2" color="text.secondary">
                          {duration}
                        </Typography>
                        <Divider sx={{ my: 1 }} />
                        <Typography variant="caption" color="text.secondary">
                          {trip.intermediateStops?.length || 0} stops
                        </Typography>
                      </Grid>
                      <Grid item xs={12} md={4} textAlign="right">
                        <Box display="flex" justifyContent="flex-end" gap={1}>
                          <AccessTimeIcon color="action" />
                          <Typography variant="subtitle1">
                            {formatTime(arrivalTime)}
                          </Typography>
                        </Box>
                        <Typography variant="caption" color="text.secondary">
                          <LocationOnIcon fontSize="small" /> {trip.destination}
                        </Typography>
                      </Grid>
                    </Grid>

                    {/* Intermediate Stops */}
                    {trip.intermediateStops?.length > 0 && (
                      <Box mt={2}>
                        <Box
                          display="flex"
                          alignItems="center"
                          sx={{ cursor: "pointer" }}
                          onClick={() => toggleStopsExpansion(trip.flightTripId)}
                        >
                          <Typography variant="subtitle2" fontWeight="bold">
                            View Flight Route
                          </Typography>
                          <IconButton size="small">
                            {expandedStops[trip.flightTripId] ? (
                              <ExpandLessIcon />
                            ) : (
                              <ExpandMoreIcon />
                            )}
                          </IconButton>
                        </Box>
                        <Collapse in={expandedStops[trip.flightTripId]}>
                          <List dense sx={{ mt: 1 }}>
                            <ListItem sx={{ py: 0 }}>
                              <ListItemIcon sx={{ minWidth: 32 }}>
                                <StopIcon fontSize="small" color="primary" />
                              </ListItemIcon>
                              <ListItemText
                                primary={trip.origin}
                                secondary={`Departure: ${formatTime(departureTime)}`}
                              />
                            </ListItem>
                            
                            {trip.intermediateStops.map((stop, stopIdx) => (
                              <ListItem key={stopIdx} sx={{ py: 0 }}>
                                <ListItemIcon sx={{ minWidth: 32 }}>
                                  <StopIcon fontSize="small" color="action" />
                                </ListItemIcon>
                                <ListItemText
                                  primary={stop.stopName}
                                  secondary={
                                    <>
                                      Arr: {formatTime(stop.arrivalTime)}, Dep:{" "}
                                      {formatTime(stop.departureTime)}
                                    </>
                                  }
                                />
                              </ListItem>
                            ))}
                            
                            <ListItem sx={{ py: 0 }}>
                              <ListItemIcon sx={{ minWidth: 32 }}>
                                <StopIcon fontSize="small" color="secondary" />
                              </ListItemIcon>
                              <ListItemText
                                primary={trip.destination}
                                secondary={`Arrival: ${formatTime(arrivalTime)}`}
                              />
                            </ListItem>
                          </List>
                        </Collapse>
                      </Box>
                    )}

                    {/* Class Types */}
                    <Box
                      sx={{
                        display: "flex",
                        overflowX: "auto",
                        gap: 2,
                        py: 2,
                        scrollSnapType: "x mandatory",
                        "& > *": { scrollSnapAlign: "start" },
                      }}
                    >
                      {trip.flight?.classTypes?.map((cls, clsIndex) => {
                        const seatStatus = getAvailableSeats(
                          trip.flight.flight_no,
                          cls.className,
                          trip.departureDate
                        );

                        return (
                          <Tooltip
                            key={clsIndex}
                            title={`Click to book ${cls.className} class`}
                            arrow
                          >
                            <Paper
                              elevation={3}
                              sx={{
                                minWidth: 250,
                                p: 2,
                                borderRadius: 2,
                                cursor: "pointer",
                                transition: "0.3s",
                                ":hover": {
                                  boxShadow: 6,
                                  transform: "translateY(-2px)",
                                },
                                border:
                                  seatStatus.status === "sold-out" ||
                                  seatStatus.status === "not-available"
                                    ? "1px solid #ff6b6b"
                                    : "1px solid #e0e0e0",
                              }}
                              onClick={() =>
                                handleCardClick(
                                  trip.flightTripId,
                                  cls.className,
                                  cls.fare
                                )
                              }
                            >
                              <Box
                                display="flex"
                                justifyContent="space-between"
                                mb={1}
                              >
                                <Typography variant="subtitle1" fontWeight="medium">
                                  {cls.className}
                                </Typography>
                                <Chip
                                  label={
                                    cls.status === "pending" ? "REGULAR" : "TATKAL"
                                  }
                                  size="small"
                                  color={
                                    cls.status === "pending" ? "success" : "error"
                                  }
                                  variant="outlined"
                                />
                              </Box>

                              <Typography variant="h6" color="primary">
                                ₹{cls.fare}
                              </Typography>

                              <Box mt={1}>
                                <Typography variant="body2">
                                  <strong>Seats:</strong>{" "}
                                  {(() => {
                                    switch (seatStatus.status) {
                                      case "loading":
                                        return "Loading...";
                                      case "not-available":
                                        return (
                                          <span style={{ color: "red" }}>
                                            Not available
                                          </span>
                                        );
                                      case "sold-out":
                                        return (
                                          <span style={{ color: "red" }}>
                                            Sold out
                                          </span>
                                        );
                                      case "available":
                                        return (
                                          <>
                                            <span style={{ color: "green" }}>
                                              {seatStatus.available} available
                                            </span>
                                            <br />
                                            <small>
                                              Total seats: {seatStatus.total}
                                            </small>
                                          </>
                                        );
                                      default:
                                        return "N/A";
                                    }
                                  })()}
                                </Typography>

                                <Box
                                  display="flex"
                                  alignItems="center"
                                  mt={1}
                                  color="success.main"
                                >
                                  <CheckCircleIcon
                                    fontSize="small"
                                    sx={{ mr: 0.5 }}
                                  />
                                  <Typography variant="caption">
                                    {cls.className === "Economy"
                                      ? "No Refund"
                                      : "Free Cancellation"}
                                  </Typography>
                                </Box>

                                <Box
                                  display="flex"
                                  alignItems="center"
                                  mt={1}
                                  color="text.secondary"
                                >
                                  <UpdateIcon fontSize="small" sx={{ mr: 0.5 }} />
                                  <Typography variant="caption">
                                    Updated just now
                                  </Typography>
                                </Box>
                              </Box>
                            </Paper>
                          </Tooltip>
                        );
                      })}
                    </Box>

                    {/* View Details Button at Bottom Right */}
                    <Box display="flex" justifyContent="flex-end" mt={2}>
                      <Button
                        variant="contained"
                        onClick={() =>
                          handleCardClick(trip.flightTripId, null, null)
                        }
                      >
                        Book Now
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              );
            })}
          </Stack>

          {!searchResults && totalPages > 1 && (
            <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
              <Pagination
                count={totalPages}
                page={currentPage + 1}
                onChange={handlePageChange}
                color="primary"
                showFirstButton
                showLastButton
              />
            </Box>
          )}
        </>
      )}
    </Container>
  );
};

export default FlightListing;