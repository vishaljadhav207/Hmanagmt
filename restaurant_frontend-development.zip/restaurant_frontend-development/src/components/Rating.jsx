import React, { useState } from "react";
import { FaStar, FaTimes } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";  
import { addRating } from "../redux/userHistorySlice";  

const Rating = ({ isOpen, onClose, selectedItem, onSubmit }) => {
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;
  

  const [hoveredRating, setHoveredRating] = useState(0);
  const [selectedRating, setSelectedRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (selectedRating === 0) return; 
    if (!userId || !selectedItem || !selectedItem.bookingId) {
      console.error("Missing user information or selected item details");
      return;
    }

    setIsSubmitting(true);

    const ratingData = {
      bookingId: selectedItem.bookingId,
      userId: userId,
      rating: selectedRating,
      comment: comment,
    };

    // Dispatch the action to submit the rating
    dispatch(addRating(ratingData))
      .then(() => {
        setSelectedRating(0);
        setHoveredRating(0);
        setComment("");
        setIsSubmitting(false);
        onClose(); 
        onSubmit(selectedRating); // Pass the rating back to the parent component
      })
      .catch((error) => {
        console.error("Error submitting rating:", error);
        setIsSubmitting(false);
      });
  };

  return (
    <div className="fixed inset-0 bg-opacity-30 backdrop-blur-sm flex justify-center items-center z-50 transition-opacity duration-300">
      <div className="bg-white p-4 rounded-lg shadow-lg w-72 max-w-sm transform transition-all duration-300 scale-95 hover:scale-100">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h2 className="text-lg font-bold text-gray-800">Rate Your Stay</h2>
            <p className="text-sm text-gray-600 mt-1">How was your experience?</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
            aria-label="Close"
          >
            <FaTimes size={16} />
          </button>
        </div>

        <div className="flex justify-center my-4">
          {[1, 2, 3, 4, 5].map((rating) => (
            <button
              key={rating}
              className={`mx-1 text-2xl transition-all duration-200 ${
                rating <= (hoveredRating || selectedRating)
                  ? "text-yellow-400 transform scale-110"
                  : "text-gray-300"
              }`}
              onMouseEnter={() => setHoveredRating(rating)}
              onMouseLeave={() => setHoveredRating(0)}
              onClick={() => setSelectedRating(rating)}
              aria-label={`Rate ${rating} star${rating !== 1 ? "s" : ""}`}
            >
              <FaStar />
            </button>
          ))}
        </div>

        <div className="mb-4">
          <label htmlFor="comment" className="block text-sm text-gray-700 mb-1">
            Share your experience (optional)
          </label>
          <textarea
            id="comment"
            rows="2"
            className="w-full px-3 py-1.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-yellow-400 focus:border-transparent text-sm transition-all"
            placeholder="What did you like most?"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSubmit}
            disabled={selectedRating === 0 || isSubmitting}
            className={`px-4 py-1.5 rounded-md text-sm transition-all ${
              selectedRating === 0
                ? "bg-gray-300 cursor-not-allowed"
                : "bg-yellow-500 hover:bg-yellow-600 text-white"
            } flex items-center`}
          >
            {isSubmitting ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Submitting...
              </>
            ) : (
              "Submit"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Rating;
