
import React from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { KEY } from "../utils/Constant";
import AppButton from "./AppButton";
import image from "../assets/hotelLogo.png";
import "./Navbar.css";
import { logout } from "../redux/userSlice";
import LanguageSwitcher from "./LanguageSwitcher";
import { useTranslation } from "react-i18next";

// Import icons
import {
  FaHotel,
  FaTrain,
  FaBus,
  FaPlane,
  FaHome,
  FaInfoCircle,
  FaHistory,
  FaEnvelope,
  FaNewspaper,
  FaUser,
  FaSignOutAlt,
} from "react-icons/fa";

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const handleLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem(KEY.USER_INFO);
    localStorage.removeItem(KEY.TOKEN);
    dispatch(logout());
    navigate("/", { replace: true });
  };

  const isHomeOrTabSelected =
    location.pathname === "/" ||
    location.pathname === "/hotel" ||
    location.pathname === "/train" ||
    location.pathname === "/bus" ||
    location.pathname === "/flight";

  return (
    <>
      {/* Main Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center bg-[#081123] h-[11vh]">
        <div className="h-full pl-2 flex items-center">
          <img src={image} alt="hotelLogo" className="h-[80%] object-contain" />
        </div>

        {/* Desktop navigation */}
        <div className="hidden lg:flex flex-grow h-full justify-between">
          <div className="flex h-full items-center ml-10">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive || isHomeOrTabSelected
                    ? "bg-[#5A2360] font-semibold"
                    : "hover:bg-[#5A2360]"
                }`
              }
            >
               <FaHome className="mr-2" /> {t("navbar.home")}
            </NavLink>

            <NavLink
              to="/about-us"
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive ? "bg-[#5A2360] font-semibold" : "hover:bg-[#5A2360]"
                }`
              }
            >
              <FaInfoCircle className="mr-2" /> {t("navbar.aboutUs")}
            </NavLink>

            <NavLink
              to="/history"
              state={{ tab: "hotel" }} 
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive ? "bg-[#5A2360] font-semibold" : "hover:bg-[#5A2360]"
                }`
              }
            >
              <FaHistory className="mr-2" />{t("navbar.history")}
            </NavLink>

            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive ? "bg-[#5A2360] font-semibold" : "hover:bg-[#5A2360]"
                }`
              }
            >
               <FaEnvelope className="mr-2" />{t("navbar.contact")}
            </NavLink>

            <NavLink
              to="/news"
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive ? "bg-[#5A2360] font-semibold" : "hover:bg-[#5A2360]"
                }`
              }
            >
                 <FaNewspaper className="mr-2" />{t("navbar.news")}
            </NavLink>

            <NavLink
              to="/profile"
              className={({ isActive }) =>
                `flex items-center h-full px-10 text-white text-[16px] ${
                  isActive ? "bg-[#5A2360] font-semibold" : "hover:bg-[#5A2360]"
                }`
              }
            >
              <FaUser className="mr-2" />{t("navbar.profile")}
            </NavLink>
          </div>

          <div className="flex items-center pr-4">
            <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <LanguageSwitcher />
          </div>
            <AppButton
              onClick={handleLogout}
              className="bg-fuchsia-950 hover:bg-fuchsia-900 text-white py-2 px-4 font-medium rounded flex items-right"
              title={
                <>
                  <FaSignOutAlt className="mr-2" /> {t("navbar.logout")}
                </>
              }
            />
          </div>

          {/* <div className="flex items-center h-full text-white mr-4 w-full justify-center">
            <LanguageSwitcher />
          </div> */}
        </div>
      </nav>
      {isHomeOrTabSelected && (
        <div className="fixed top-[11vh] left-100 right-100 z-40 bg-[#5A2360] py-2 border-b mt-[1px] rounded-lg shadow-lg">
          <div className="container mx-auto px-4">
            <div className="flex justify-center">
              <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-full shadow-inner border border-purple-200 dark:border-gray-600 backdrop-blur-sm bg-opacity-80">
                <NavLink
                  to="/hotel"
                  end
                  className={({ isActive }) =>
                    `flex items-center px-6 py-2 rounded-full transition-all ${
                      isActive
                        ? "bg-[#5A2360] text-white font-medium shadow-md"
                        : "text-gray-600 hover:bg-gray-100"
                    }`
                  }
                >
                  <FaHotel className="mr-2" />
                  <span>{t("navbar.hotel")}</span>
                </NavLink>

                <NavLink
                  to="/train"
                  className={({ isActive }) =>
                    `flex items-center px-6 py-2 rounded-full transition-all ${
                      isActive
                        ? "bg-[#5A2360] text-white font-medium shadow-md"
                        : "text-gray-600 hover:bg-gray-100"
                    }`
                  }
                >
                  <FaTrain className="mr-2" />
                  <span>{t("navbar.train")}</span>
                </NavLink>

                <NavLink
                  to="/bus"
                  className={({ isActive }) =>
                    `flex items-center px-6 py-2 rounded-full transition-all ${
                      isActive
                        ? "bg-[#5A2360] text-white font-medium shadow-md"
                        : "text-gray-600 hover:bg-gray-100"
                    }`
                  }
                >
                  <FaBus className="mr-2" />
                  <span>{t("navbar.bus")}</span>
                </NavLink>

                <NavLink
                  to="/flight"
                  className={({ isActive }) =>
                    `flex items-center px-6 py-2 rounded-full transition-all ${
                      isActive
                        ? "bg-[#5A2360] text-white font-medium shadow-md"
                        : "text-gray-600 hover:bg-gray-100"
                    }`
                  }
                >
                  <FaPlane className="mr-2" />
                  <span>{t("navbar.flight")}</span>
                </NavLink>
              </div>
            </div>
            
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;