import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getRooms } from "../redux/roomSlice";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { FaCircleNotch, FaMapMarkerAlt } from "react-icons/fa";
import mapImage from "../assets/map.png";

export const Map = ({ hotelName }) => {
  const dispatch = useDispatch();
  const { selectedRoomId, rooms, status, error } = useSelector(
    (state) => state.rooms
  );

  const [loading, setLoading] = useState(true);

  // Fetch room data based on selectedRoomId
  useEffect(() => {
    if (status === "idle" && selectedRoomId) {
      dispatch(getRooms(selectedRoomId));
    }
  }, [dispatch, status, selectedRoomId]);

  // Set loading state to false when the status is succeeded
  useEffect(() => {
    if (status === "succeeded") {
      setLoading(false);
    }
  }, [status]);

  // Find room data by selectedRoomId
  const roomData = rooms.find((room) => room.hotelId === selectedRoomId) || {};

  // Log roomData to check if address exists
  useEffect(() => {
    console.log("roomData:", roomData); // Check the structure of roomData
  }, [roomData]);

  return (
    <div>
      {/* Toast Container */}
      <ToastContainer />

      {/* Loader Section */}
      {status === "loading" || loading ? (
        <div className="flex justify-center items-center h-40">
          <FaCircleNotch className="animate-spin text-blue-500 text-4xl" />
        </div>
      ) : (
        <>
          {/* Map Section */}
          <div className="bg-white overflow-hidden max-w-sm mx-auto mt-6">
            <div className="flex flex-col space-y-4  rounded-2xl">
              <div className="flex flex-row justify-evenly">
                <div className="bg-blue-500 text-white text-2xl font-semibold py-2 px-4 rounded-lg mt-1">
                  3.9
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  Very Good (2040 RATINGS)
                </p>
                <button className="text-sm text-blue-500 mt-2 font-bold">
                  All Reviews
                </button>
              </div>

              <div className="flex flex-row justify-evenly">
                {/* Map icon with background image */}
                <div
                  className="h-12 w-16 flex items-center justify-center bg-blue-500 rounded-lg"
                  style={{
                    backgroundImage: `url(${mapImage})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }}
                >
                  <FaMapMarkerAlt className="text-blue-500 text-3xl" />
                </div>

                <div className="flex flex-col">
                  <p className="text-xl font-semibold">
                    {/* If roomData.hotelName exists, use it; otherwise, use hotelName prop */}
                    {roomData.hotelName || hotelName || "Hotel Name"}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    {/* Check for hotelAdd and use an alternative if missing */}
                    {roomData.hotel?.hotelAdd || roomData.address || ""}
                  </p>
                </div>
                <button className="text-sm text-blue-500 mt-2 font-bold ml-20">
                  See on Map
                </button>
              </div>
            </div>
          </div>

          {/* Error Handling Section */}
          {status === "failed" ? (
            <>
              <div className="text-center text-red-500 font-semibold">
                Error: {error}
              </div>
              {toast.error(error || "Failed to load data!")}
            </>
          ) : rooms.length === 0 ? (
            <div className="text-center text-gray-500">
              No room data available for the selected hotel.
            </div>
          ) : null}
        </>
      )}
    </div>
  );
};

export default Map;
