import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getBusTripById, saveTicket } from "../app/busApi";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { clearTicketStatus, resetBookedTicket } from "../redux/busSlice";

const ClockIcon = ({ className }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
  </svg>
);

const InfoIcon = ({ className }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
  </svg>
);

const BusDetails = ({ busDetails }) => {
  if (!busDetails) return null;

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    const date = new Date(dateTime);
    return date.toLocaleString('en-US', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
      month: 'short',
      day: 'numeric'
    });
  };

  const calculateDuration = (departure, arrival) => {
    if (!departure || !arrival) return "N/A";
    const dep = new Date(departure);
    const arr = new Date(arrival);
    const diff = arr - dep;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <h2 className="text-xl font-bold text-gray-800">{busDetails.bus?.operatorName || "Bus Operator"}</h2>
        </div>
        <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
          {busDetails.bus?.busType || "AC Sleeper"}
        </span>
      </div>

      <div className="mb-4">
        <p className="text-gray-600 text-sm">
          <InfoIcon className="w-4 h-4 inline mr-1" />
          Updated 1 hour ago
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="text-center">
          <p className="font-bold text-gray-900">{formatDateTime(busDetails.departureDateTime).split(',')[0]}</p>
          <p className="text-sm text-gray-600">{formatDateTime(busDetails.departureDateTime).split(',')[1]}</p>
          <p className="text-sm font-medium">{busDetails.origin}</p>
        </div>

        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center">
            <div className="h-px bg-gray-300 w-16"></div>
            <ClockIcon className="w-5 h-5 mx-2 text-gray-500" />
            <div className="h-px bg-gray-300 w-16"></div>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {calculateDuration(busDetails.departureDateTime, busDetails.arrivalDateTime)}
          </p>
        </div>

        <div className="text-center">
          <p className="font-bold text-gray-900">{formatDateTime(busDetails.arrivalDateTime).split(',')[0]}</p>
          <p className="text-sm text-gray-600">{formatDateTime(busDetails.arrivalDateTime).split(',')[1]}</p>
          <p className="text-sm font-medium">{busDetails.destination}</p>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">Seat Type: {busDetails.bus?.seatType || "Sleeper"}</span>
          <span className="text-sm font-medium text-gray-700">Rating: {busDetails.bus?.rating || "4.5"}/5</span>
          <span className="text-sm font-medium text-green-600">Available: {busDetails.availableSeats || "20"}</span>
        </div>
      </div>
    </div>
  );
};

const BookingDetails = ({ bookingDetails, onDetailsChange }) => {
  const handleChange = (e) => {
    onDetailsChange({
      ...bookingDetails,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Booking Details</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Departure Date</label>
          <input
            type="date"
            name="departureDate"
            value={bookingDetails.departureDate}
            onChange={handleChange}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Seat Type</label>
          <select
            name="seatType"
            value={bookingDetails.seatType}
            onChange={handleChange}
            className="w-full p-2 border border-gray-300 rounded-md"
          >
            <option value="Sleeper">Sleeper</option>
            <option value="Semi-Sleeper">Semi-Sleeper</option>
            <option value="Seater">Seater</option>
            <option value="AC">AC</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
          <select
            name="paymentMethod"
            value={bookingDetails.paymentMethod}
            onChange={handleChange}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Payment Method</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Debit Card">Debit Card</option>
            <option value="Net Banking">Net Banking</option>
            <option value="UPI">UPI</option>
            <option value="Wallet">Wallet</option>
          </select>
        </div>
      </div>
    </div>
  );
};

const CancellationOptions = ({ cancellationOption, onOptionChange }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Cancellation Options</h2>
      
      <div className="space-y-4">
        <div className="flex items-start">
          <input
            type="radio"
            id="zeroCharges"
            name="cancellationOption"
            value="zeroCharges"
            checked={cancellationOption === "zeroCharges"}
            onChange={() => onOptionChange("zeroCharges")}
            className="mt-1 mr-2"
          />
          <label htmlFor="zeroCharges" className="flex-1">
            <span className="font-medium">Zero cancellation charges</span>
            <p className="text-sm text-gray-600">Get full ticket fare refund on cancellation for just ₹99 per person</p>
          </label>
        </div>
        
        <div className="flex items-start">
          <input
            type="radio"
            id="payFees"
            name="cancellationOption"
            value="payFees"
            checked={cancellationOption === "payFees"}
            onChange={() => onOptionChange("payFees")}
            className="mt-1 mr-2"
          />
          <label htmlFor="payFees" className="flex-1">
            <span className="font-medium">Pay fees on cancellation</span>
            <p className="text-sm text-gray-600">Standard cancellation charges will apply</p>
          </label>
        </div>
      </div>
      
      <div className="mt-4 p-3 bg-blue-50 rounded-md">
        <p className="text-sm text-blue-800">
          <InfoIcon className="w-4 h-4 inline mr-1" />
          25% of our users cancel their ticket due to change in plans.
        </p>
      </div>
    </div>
  );
};

const TravellerDetails = ({ travellers, onAddTraveller, onRemoveTraveller }) => {
  const [showForm, setShowForm] = useState(false);
  const [traveller, setTraveller] = useState({
    name: "",
    age: "",
    gender: "Male",
    seatPreference: "",
    idType: "Aadhar",
    idNumber: ""
  });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!traveller.name) newErrors.name = "Name is required";
    if (!traveller.age) newErrors.age = "Age is required";
    if (!traveller.gender) newErrors.gender = "Gender is required";
    if (!traveller.idNumber) newErrors.idNumber = "ID Number is required";
    return newErrors;
  };

  const handleChange = (e) => {
    setTraveller({
      ...traveller,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    
    onAddTraveller(traveller);
    setTraveller({
      name: "",
      age: "",
      gender: "Male",
      seatPreference: "",
      idType: "Aadhar",
      idNumber: ""
    });
    setShowForm(false);
    setErrors({});
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Traveller Details</h2>
      
      {travellers.length > 0 && (
        <div className="mb-4 space-y-2">
          {travellers.map((t, index) => (
            <div key={index} className="flex justify-between items-center p-3 border border-gray-200 rounded-md">
              <div>
                <p className="font-medium">{t.name} ({t.age} yrs, {t.gender})</p>
                <p className="text-sm text-gray-600">ID: {t.idType} - {t.idNumber}</p>
                {t.seatPreference && <p className="text-sm text-gray-600">Seat: {t.seatPreference}</p>}
              </div>
              <button
                onClick={() => onRemoveTraveller(index)}
                className="text-red-600 hover:text-red-800"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
      
      {showForm ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                name="name"
                value={traveller.name}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md"
              />
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
              <input
                type="number"
                name="age"
                value={traveller.age}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md"
              />
              {errors.age && <p className="text-red-500 text-xs mt-1">{errors.age}</p>}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
              <div className="flex space-x-4">
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="gender"
                    value="Male"
                    checked={traveller.gender === "Male"}
                    onChange={handleChange}
                    className="mr-2"
                  />
                  Male
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="gender"
                    value="Female"
                    checked={traveller.gender === "Female"}
                    onChange={handleChange}
                    className="mr-2"
                  />
                  Female
                </label>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Seat Preference</label>
              <select
                name="seatPreference"
                value={traveller.seatPreference}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                <option value="">No Preference</option>
                <option value="Window">Window</option>
                <option value="Aisle">Aisle</option>
                <option value="Upper Deck">Upper Deck</option>
                <option value="Lower Deck">Lower Deck</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ID Type</label>
              <select
                name="idType"
                value={traveller.idType}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                <option value="Aadhar">Aadhar</option>
                <option value="PAN">PAN</option>
                <option value="Passport">Passport</option>
                <option value="Voter ID">Voter ID</option>
                <option value="Driving License">Driving License</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ID Number</label>
              <input
                type="text"
                name="idNumber"
                value={traveller.idNumber}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md"
              />
              {errors.idNumber && <p className="text-red-500 text-xs mt-1">{errors.idNumber}</p>}
            </div>
          </div>
          
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add Traveller
            </button>
          </div>
        </form>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + Add Traveller
        </button>
      )}
    </div>
  );
};

const ContactInfo = ({ contactDetails, onDetailsChange }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Contact Information</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <input
            type="email"
            name="email"
            value={contactDetails.email}
            onChange={onDetailsChange}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
            <input
              type="tel"
              name="mobile"
              value={contactDetails.mobile}
              onChange={onDetailsChange}
              className="w-full p-2 border border-gray-300 rounded-md"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact</label>
            <input
              type="tel"
              name="emergencyContact"
              value={contactDetails.emergencyContact}
              onChange={onDetailsChange}
              className="w-full p-2 border border-gray-300 rounded-md"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const TravelAdvisory = ({ termsAccepted, onTermsChange }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Travel Advisory</h2>
      
      <div className="p-3 bg-yellow-50 rounded-md mb-4">
        <p className="text-sm text-yellow-800">
          <InfoIcon className="w-4 h-4 inline mr-1" />
          Please read health advisories by relevant authorities before traveling.
        </p>
      </div>
      
      <div className="flex items-start">
        <input
          type="checkbox"
          id="termsAccepted"
          checked={termsAccepted}
          onChange={onTermsChange}
          className="mt-1 mr-2"
          required
        />
        <label htmlFor="termsAccepted" className="text-sm">
          By proceeding with the booking, I confirm that I have read and I accept the 
          Cancellation & Refund Policy, Privacy Policy, User Agreement and Terms of Service
        </label>
      </div>
    </div>
  );
};

const FareSummary = ({ 
  basePrice, 
  taxes, 
  serviceCharge, 
  cancellationProtection, 
  totalPrice,
  passengerCount
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Fare Summary</h2>
      
      <div className="space-y-2">
        <div className="flex justify-between">
          <span>Base fare ({passengerCount} {passengerCount === 1 ? 'passenger' : 'passengers'})</span>
          <span>₹{(basePrice * passengerCount).toLocaleString()}</span>
        </div>
        
        <div className="flex justify-between">
          <span>Taxes and fees</span>
          <span>₹{(taxes * passengerCount).toLocaleString()}</span>
        </div>
        
        <div className="flex justify-between">
          <span>Service charge</span>
          <span>₹{(serviceCharge * passengerCount).toLocaleString()}</span>
        </div>
        
        {cancellationProtection > 0 && (
          <div className="flex justify-between">
            <span>Cancellation protection</span>
            <span>₹{(cancellationProtection * passengerCount).toLocaleString()}</span>
          </div>
        )}
        
        <div className="border-t border-gray-200 my-2"></div>
        
        <div className="flex justify-between font-bold text-lg">
          <span>Total Amount</span>
          <span>₹{totalPrice.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

const SuccessModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
            <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mt-3">Booking Successful!</h3>
          <div className="mt-2">
            <p className="text-sm text-gray-500">
              Your bus tickets have been booked successfully. You will receive a confirmation email shortly.
            </p>
          </div>
          <div className="mt-4">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex justify-center px-4 py-2 text-sm font-medium text-blue-900 bg-blue-100 border border-transparent rounded-md hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-500"
            >
              Got it, thanks!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const BusBooking = () => {
  const [cancellationOption, setCancellationOption] = useState("zeroCharges");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { busTripId } = location.state || {};

  
  const busDetails = useSelector((state) => state.buses.selectedBus);
  const busStatus = useSelector((state) => state.buses.status);
  const busError = useSelector((state) => state.buses.error);
  const ticketStatus = useSelector((state) => state.buses.ticketStatus);
  const ticketError = useSelector((state) => state.buses.ticketError);
  const bookedTicket = useSelector((state) => state.buses.bookedTicket);

  console.log("bookedTicket", bookedTicket);

  const [pricing, setPricing] = useState({
    basePrice: busDetails?.price || 1200,
    taxes: 100,
    serviceCharge: 50,
    cancellationProtection: 0,
    totalPrice: 0
  });

  const [bookingDetails, setBookingDetails] = useState({
    departureDate: "",
    seatType: "Sleeper",
    boardingPoint: "Main Station",
    paymentMethod: "",
  });

  const [travellers, setTravellers] = useState([]);
  const [contactDetails, setContactDetails] = useState({
    email: "",
    mobile: "",
    emergencyContact: "",
  });

  useEffect(() => {
    if (busTripId) {
      dispatch(getBusTripById(busTripId));
    }
    return () => {
      dispatch(clearTicketStatus());
      dispatch(resetBookedTicket());
    };
  }, [busTripId, dispatch]);

  useEffect(() => {
    if (busDetails?.price) {
      const basePrice = busDetails.price;
      const cancellationProtection = cancellationOption === "zeroCharges" ? 99 : 0;
      const passengerCount = travellers.length || 1;
      
      setPricing({
        basePrice,
        taxes: 100,
        serviceCharge: 50,
        cancellationProtection,
        totalPrice: (basePrice + 100 + 50 + cancellationProtection) * passengerCount
      });
    }
  }, [busDetails, cancellationOption, travellers.length]);

  useEffect(() => {
    if (ticketStatus === "succeeded" && bookedTicket) {
      toast.success("Ticket booked successfully!");
      navigate('/booking-confirmation', { state: { ticket: bookedTicket } });
    } else if (ticketStatus === "failed") {
      toast.error(ticketError || "Failed to book ticket");
    }
  }, [ticketStatus, bookedTicket, ticketError, navigate]);

  const handleBookingDetailsChange = (details) => {
    setBookingDetails(details);
  };

  const handleCancellationOptionChange = (option) => {
    const cancellationProtection = option === "zeroCharges" ? 99 : 0;
    setCancellationOption(option);
    setPricing(prev => ({
      ...prev,
      cancellationProtection,
      totalPrice: (prev.basePrice + prev.taxes + prev.serviceCharge + cancellationProtection) * (travellers.length || 1)
    }));
  };

  const handleContactDetailsChange = (e) => {
    const { name, value } = e.target;
    setContactDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleAddTraveller = (traveller) => {
    setTravellers([...travellers, traveller]);
    setPricing(prev => ({
      ...prev,
      totalPrice: (prev.basePrice + prev.taxes + prev.serviceCharge + prev.cancellationProtection) * (travellers.length + 1)
    }));
  };

  const handleRemoveTraveller = (index) => {
    const updatedTravellers = [...travellers];
    updatedTravellers.splice(index, 1);
    setTravellers(updatedTravellers);
    setPricing(prev => ({
      ...prev,
      totalPrice: (prev.basePrice + prev.taxes + prev.serviceCharge + prev.cancellationProtection) * (updatedTravellers.length || 1)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (travellers.length === 0) {
      toast.error("Please add at least one traveller");
      return;
    }
    
    if (!termsAccepted) {
      toast.error("Please accept the terms and conditions");
      return;
    }
    
    if (!bookingDetails.paymentMethod) {
      toast.error("Please select a payment method");
      return;
    }

    setIsSubmitting(true);

    const ticketData = {
      busTripId,
      busId: busDetails?.bus?.busId,
      departureDate: bookingDetails.departureDate,
      seatType: bookingDetails.seatType,
      boardingPoint: bookingDetails.boardingPoint,
      paymentMethod: bookingDetails.paymentMethod,
      travellers,
      contactInfo: contactDetails,
      fareDetails: {
        baseFare: pricing.basePrice,
        taxes: pricing.taxes,
        serviceFee: pricing.serviceCharge,
        cancellationProtection: pricing.cancellationProtection,
        totalAmount: pricing.totalPrice
      },
      cancellationOption
    };

    try {
      await dispatch(saveTicket(ticketData)).unwrap();
    } catch (error) {
      console.error("Booking error:", error);
      setSubmitError(error || "Booking failed");
      toast.error("Booking submission failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (busStatus === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (busStatus === "failed") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center text-red-500">
          <p className="text-xl">Error loading bus details</p>
          <p>{busError || "Please try again later"}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bus-booking bg-gray-50 min-h-screen py-8 relative">
      {isSubmitting && (
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
        </div>
      )}

      <div className={`container mx-auto px-4 sm:px-6 lg:px-8 ${isSubmitting ? "blur-sm" : ""}`}>
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Confirm Your Bus Booking</h1>
          <p className="text-gray-600 mt-2">Please verify your details before proceeding to payment</p>
        </div>

        {submitError && (
          <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            {submitError}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-2/3 space-y-6">
              {busDetails && <BusDetails busDetails={busDetails} />}
              
              <BookingDetails 
                bookingDetails={bookingDetails}
                onDetailsChange={handleBookingDetailsChange}
              />
              
              <CancellationOptions 
                cancellationOption={cancellationOption}
                onOptionChange={handleCancellationOptionChange}
              />
              
              <TravellerDetails
                travellers={travellers}
                onAddTraveller={handleAddTraveller}
                onRemoveTraveller={handleRemoveTraveller}
              />
              
              <ContactInfo
                contactDetails={contactDetails}
                onDetailsChange={handleContactDetailsChange}
              />
              
              <TravelAdvisory 
                termsAccepted={termsAccepted}
                onTermsChange={(e) => setTermsAccepted(e.target.checked)}
              />
            </div>

            <div className="lg:w-1/3">
              <div className="sticky top-4 space-y-6">
                <FareSummary
                  basePrice={pricing.basePrice}
                  taxes={pricing.taxes}
                  serviceCharge={pricing.serviceCharge}
                  cancellationProtection={pricing.cancellationProtection}
                  totalPrice={pricing.totalPrice}
                  passengerCount={travellers.length || 1}
                />
                
                <button
                  type="submit"
                  disabled={isSubmitting || !termsAccepted || travellers.length === 0}
                  className={`w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-lg shadow-md transition-all duration-300 ${
                    isSubmitting || !termsAccepted || travellers.length === 0 
                      ? "opacity-70 cursor-not-allowed" 
                      : "hover:from-blue-700 hover:to-indigo-700 hover:scale-[1.02]"
                  }`}
                >
                  {isSubmitting ? "Processing..." : `Pay ₹${pricing.totalPrice.toLocaleString()}`}
                </button>
              </div>
            </div>
          </div>
        </form>
        <SuccessModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </div>
    </div>
  );
};

export default BusBooking;