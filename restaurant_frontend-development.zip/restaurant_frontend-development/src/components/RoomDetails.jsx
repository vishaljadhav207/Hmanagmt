import { useParams } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { setSelectedRoomId } from "../redux/roomSlice";
import Image from "./Image";
import Amenity from "./Amenity";
import Price from "./Price";
import Map from "./Map"; 

const RoomDetails = () => {
  const { hotelId } = useParams(); 
  const dispatch = useDispatch();
  const [totalPrice, setTotalPrice] = useState(0);
  const [hotelName, setHotelName] = useState("");
  const [roomCount, setRoomCount] = useState(1);
  const [selectedRoomType, setSelectedRoomType] = useState(null);
  const [roomPrice, setRoomPrice] = useState(0);
  const [hotelAdd, setHotelAdd] = useState("");

  
  useEffect(() => {
    if (hotelId) {
      dispatch(setSelectedRoomId(hotelId));
    }
  }, [dispatch, hotelId]);

 

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto p-2 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          
          <div className="col-span-2 space-y-3">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
              <Image hotelId={hotelId} /> 
            </div>

            <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
              <h2 className="text-2xl font-semibold mb-3 text-gray-800 text-center">
                Amenities & Options
              </h2>


              <Amenity
                setTotalPrice={setTotalPrice}
                setHotelName={setHotelName}
                roomCount={roomCount}
                setRoomCount={setRoomCount}
                selectedRoomType={selectedRoomType}
                setSelectedRoomType={setSelectedRoomType}
                setRoomPrice={setRoomPrice}
              />
            </div>
          </div>

          
          <div className="space-y-3 sticky top-3 h-fit">
            <div className="bg-white rounded-lg shadow-sm border border-blue-100 p-4">
              <Price
                hotelId={hotelId}
                roomCount={roomCount}
                selectedRoomType={selectedRoomType}
                roomPrice={roomPrice}
                hotelName={hotelName}
                hotelAdd={hotelAdd}
              />
            </div>

            <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200 h-40">
              <Map hotelName={hotelName} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default RoomDetails;
