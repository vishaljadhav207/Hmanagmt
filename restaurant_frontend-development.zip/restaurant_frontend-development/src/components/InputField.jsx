import React, { useState } from "react";
import { Input, Textarea } from "@material-tailwind/react";
import "./InputField.css";


function InputField({ type, placeholder, name, value, onChange, className, inputContainerClassName, error }) {
  return (

    <div >
      {type === "textarea" ? (
        <Textarea
          type="text"
          placeholder={placeholder}
          name={name}
          value={value}
          onChange={onChange}
          className={`border border-gray-300 bg-purple-50 placeholder:italic text-gray-900 shadow-lg shadow-gray-900/5 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100 rounded-none ${className}`}
          labelProps={{
            className: "hidden",
          }}
          containerProps={{ className: "min-w-[100px]" }}
        />
      ) : (
        <>
          <Input
            type={type}
            placeholder={placeholder}
            name={name}
            value={value}
            onChange={onChange}
            className={`border border-gray-300 bg-purple-50 placeholder:italic text-gray-900 shadow-lg shadow-gray-900/5 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100 rounded-none ${className}`}
            labelProps={{
              className: "hidden",
            }}
            containerProps={{ className: "min-w-[100px]" }}
          />
          <div>
            <p className="text-xs text-red-600">{error}</p>
          </div>
        </>
      )}
    </div>
  );
}

export default InputField;
