// import React from "react";
// import { FaLock, FaPlus, FaRegHeart, FaPlane } from "react-icons/fa";
// import { useNavigate } from "react-router-dom";

// const FlightCard = ({ flight }) => {0
//   const navigate = useNavigate();
   
//   const handleBookNow = () => {
//     navigate("/flight-booking");
//   }

//   return (
//     <>
//       <div className="flight-card bg-white rounded-xl shadow-sm hover:shadow-md border border-gray-100 overflow-hidden transition-all duration-200 hover:border-blue-100 mb-4">
//         <div className="flex flex-col md:flex-row">
//           {/* Left Section - Airline & Price */}
//           <div className="md:w-1/4 p-4 bg-blue-50 flex flex-col justify-between">
//             <div>
//               <div className="flex items-center mb-3">
//                 <div className="bg-white p-1.5 rounded-lg shadow-xs mr-3">
//                   <img
//                     src={`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROfDAomiknZlBo4-HvUnfYdIKBbfhQRLwaCg&s=${flight.airline.substring(
//                       0,
//                       3
//                     )}`}
//                     alt={flight.airline}
//                     className="h-6"
//                   />
//                 </div>
//                 <div>
//                   <h3 className="font-semibold text-gray-800">
//                     {flight.airline}
//                   </h3>
//                   <p className="text-xs text-gray-500">{flight.flightNumber}</p>
//                 </div>
//               </div>

//               <div className="text-xs bg-white px-2 py-1 rounded-full border border-gray-200 text-blue-600 font-medium inline-block mb-3">
//                 {flight.duration}
//               </div>
//             </div>

//             <div>
//               <div className="flex items-baseline">
//                 <span className="text-2xl font-bold text-red-600">
//                   ₹{flight.price.toLocaleString()}
//                 </span>
//                 <span className="text-xs text-gray-500 ml-1">/adult</span>
//               </div>
//               <div className="text-xs text-green-600 mt-1 flex items-center">
//                 <FaLock className="mr-1 text-xs" />
//                 <span>
//                   Lock from{" "}
//                   <span className="font-medium">
//                     ₹{flight.lockPrice.toLocaleString()}
//                   </span>
//                 </span>
//               </div>
//             </div>
//           </div>

//           {/* Middle Section - Flight Route */}
//           <div className="md:w-2/4 p-4 border-t md:border-t-0 md:border-r border-gray-100">
//             <div className="flex justify-between items-center h-full">
//               {/* Departure */}
//               <div className="text-left">
//                 <div className="text-2xl font-bold text-gray-900">
//                   {flight.departureTime}
//                 </div>
//                 <div className="text-sm font-medium text-gray-600">
//                   {flight.departureCity}
//                 </div>
//                 <div className="text-xs text-gray-400 mt-1">
//                   {flight.departureDate}
//                 </div>
//               </div>

//               {/* Stops */}
//               <div className="flex flex-col items-center px-2 mx-2">
//                 <div className="relative">
//                   <div className="absolute top-1/2 left-0 right-0 h-px bg-gray-200"></div>
//                   <div className="relative z-10 bg-white px-2">
//                     {flight.stops === 0 ? (
//                       <FaPlane className="text-blue-500 rotate-45" />
//                     ) : (
//                       <div className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full whitespace-nowrap">
//                         {flight.stops} stop{flight.stops > 1 ? "s" : ""} •{" "}
//                         {flight.viaCity}
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               </div>

//               {/* Arrival */}
//               <div className="text-right">
//                 <div className="text-2xl font-bold text-gray-900">
//                   {flight.arrivalTime}
//                 </div>
//                 <div className="text-sm font-medium text-gray-600">
//                   {flight.arrivalCity}
//                   {flight.nextDay && (
//                     <span className="text-xs bg-blue-100 text-blue-800 ml-1 px-1 rounded-full">
//                       +1
//                     </span>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Right Section - Actions */}
//           <div className="md:w-1/4 p-4 bg-gray-50 flex flex-col justify-between">
//             <div className="flex flex-col space-y-2">
//               <button className="text-sm bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors" onClick={handleBookNow}>
//                 Book Now
//               </button>
//               <button className="text-sm border border-blue-600 text-blue-600 hover:bg-blue-50 px-4 py-2 rounded-lg font-medium transition-colors">
//                 Details
//               </button>
//             </div>

//             {flight.discount > 0 && (
//               <div className="mt-3 text-xs text-center bg-gradient-to-r from-orange-50 to-yellow-50 text-orange-600 py-1.5 px-2 rounded">
//                 Use <span className="font-bold">{flight.couponCode}</span> &
//                 save ₹{flight.discount}
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// const FlightListing = () => {
//   const flights = [
//     {
//       id: 1,
//       airline: "IndiGo",
//       flightNumber: "6E 5056, 6E 1067",
//       departureTime: "21:20",
//       departureCity: "Mumbai",
//       departureDate: "14 Apr, Fri",
//       duration: "10h 35m",
//       stops: 1,
//       viaCity: "Hyderabad",
//       arrivalTime: "09:25",
//       arrivalCity: "Bangkok",
//       nextDay: true,
//       price: 14193,
//       lockPrice: 409,
//       discount: 850,
//       couponCode: "MMTDEALS",
//     },
//     {
//       id: 2,
//       airline: "Air India",
//       flightNumber: "AI 887",
//       departureTime: "08:15",
//       departureCity: "Delhi",
//       departureDate: "14 Apr, Fri",
//       duration: "4h 20m",
//       stops: 0,
//       viaCity: "",
//       arrivalTime: "12:35",
//       arrivalCity: "Mumbai",
//       nextDay: false,
//       price: 7890,
//       lockPrice: 299,
//       discount: 500,
//       couponCode: "AISALE",
//     },
//     {
//       id: 3,
//       airline: "Vistara",
//       flightNumber: "UK 945",
//       departureTime: "15:40",
//       departureCity: "Bangalore",
//       departureDate: "14 Apr, Fri",
//       duration: "7h 15m",
//       stops: 1,
//       viaCity: "Delhi",
//       arrivalTime: "22:55",
//       arrivalCity: "London",
//       nextDay: false,
//       price: 35600,
//       lockPrice: 999,
//       discount: 1200,
//       couponCode: "VISTARA12",
//     },
//     {
//       id: 4,
//       airline: "SpiceJet",
//       flightNumber: "SG 723",
//       departureTime: "11:30",
//       departureCity: "Kolkata",
//       departureDate: "14 Apr, Fri",
//       duration: "2h 45m",
//       stops: 0,
//       viaCity: "",
//       arrivalTime: "14:15",
//       arrivalCity: "Delhi",
//       nextDay: false,
//       price: 6540,
//       lockPrice: 349,
//       discount: 400,
//       couponCode: "SPICYCHEAP",
//     },
//     {
//       id: 5,
//       airline: "GoAir",
//       flightNumber: "G8 432",
//       departureTime: "06:20",
//       departureCity: "Chennai",
//       departureDate: "15 Apr, Sat",
//       duration: "5h 30m",
//       stops: 1,
//       viaCity: "Bangalore",
//       arrivalTime: "11:50",
//       arrivalCity: "Dubai",
//       nextDay: false,
//       price: 18750,
//       lockPrice: 599,
//       discount: 750,
//       couponCode: "GOAIR50",
//     },
//     {
//       id: 6,
//       airline: "Emirates",
//       flightNumber: "EK 512",
//       departureTime: "02:15",
//       departureCity: "Mumbai",
//       departureDate: "15 Apr, Sat",
//       duration: "9h 10m",
//       stops: 0,
//       viaCity: "",
//       arrivalTime: "05:25",
//       arrivalCity: "Dubai",
//       nextDay: false,
//       price: 22400,
//       lockPrice: 899,
//       discount: 1000,
//       couponCode: "EMIRATES10",
//     },
//     {
//       id: 7,
//       airline: "Qatar Airways",
//       flightNumber: "QR 678",
//       departureTime: "19:45",
//       departureCity: "Delhi",
//       departureDate: "14 Apr, Fri",
//       duration: "14h 20m",
//       stops: 1,
//       viaCity: "Doha",
//       arrivalTime: "10:05",
//       arrivalCity: "New York",
//       nextDay: true,
//       price: 48700,
//       lockPrice: 1299,
//       discount: 1500,
//       couponCode: "QATAR15",
//     },
//     {
//       id: 8,
//       airline: "AirAsia",
//       flightNumber: "AK 321",
//       departureTime: "13:10",
//       departureCity: "Bangalore",
//       departureDate: "14 Apr, Fri",
//       duration: "3h 55m",
//       stops: 0,
//       viaCity: "",
//       arrivalTime: "17:05",
//       arrivalCity: "Kuala Lumpur",
//       nextDay: false,
//       price: 11200,
//       lockPrice: 499,
//       discount: 600,
//       couponCode: "ASIA600",
//     },
//     {
//       id: 9,
//       airline: "Singapore Airlines",
//       flightNumber: "SQ 532",
//       departureTime: "23:30",
//       departureCity: "Mumbai",
//       departureDate: "14 Apr, Fri",
//       duration: "11h 45m",
//       stops: 0,
//       viaCity: "",
//       arrivalTime: "12:15",
//       arrivalCity: "Singapore",
//       nextDay: true,
//       price: 27800,
//       lockPrice: 799,
//       discount: 900,
//       couponCode: "SINGAPORE9",
//     },
//   ];

//   return (
//     <div className="max-w-6xl mx-auto px-4 py-8">
//       <div className="space-y-4">
//         {flights.map((flight) => (
//           <FlightCard key={flight.id} flight={flight} />
//         ))}
//       </div>
//     </div>
//   );
// };

// export default FlightListing;
