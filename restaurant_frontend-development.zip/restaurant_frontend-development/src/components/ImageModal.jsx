import React from "react";

const ImageModal = ({
  images,
  currentImageIndex,
  setCurrentImageIndex,
  closeModal,
  prevImage,
  nextImage,
}) => {
  return (
    <div
      className="fixed inset-0 backdrop-blur-sm flex justify-center items-center z-50 transition-opacity"
      onClick={closeModal} // Close modal when clicking outside
    >
      <div
        className="p-6 rounded-lg shadow-lg w-1/2 relative" // Set width to 1/2 of the page
        onClick={(e) => e.stopPropagation()} // Prevent closing the modal when clicking inside
      >
        {/* Close Carousel Button */}
        <button
          onClick={closeModal}
          className="absolute top-4 right-4 text-xl font-bold text-gray-600"
        >
          ×
        </button>

        {/* Carousel Controls */}
        <div className="relative flex justify-center items-center mb-6">
          <button
            onClick={prevImage}
            className="absolute left-4 text-white text-2xl font-semibold bg-opacity-50 rounded-full p-2"
          >
            &lt;
          </button>

          {/* Display the selected image */}
          <img
            src={images[currentImageIndex]}
            alt={`Room Image ${currentImageIndex + 1}`}
            className="w-full h-auto rounded-2xl shadow-lg" // Use full width and auto height
          />

          <button
            onClick={nextImage}
            className="absolute right-4 text-white text-2xl font-semibold bg-opacity-50 rounded-full p-2"
          >
            &gt;
          </button>
        </div>

        {/* Thumbnails Below the Carousel */}
        <div className="flex justify-center space-x-4 mt-4">
          {images.map((image, index) => (
            <img
              key={index}
              src={image}
              className="w-10 h-10 rounded-2xl shadow-lg cursor-pointer object-cover"
              onClick={() => setCurrentImageIndex(index)} // Jump to clicked image
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImageModal;
