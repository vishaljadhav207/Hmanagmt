import React from "react";
import GridTable from "./GridTable";
import { useState } from "react";

const OrgDashboard = () => {
  const [rows, setRows] = useState([]);
  const columns = [
    { field: "id", headerName: "ID", width: 150 },
    { field: "firstName", headerName: "First Name", width: 250 },
    { field: "lastName", headerName: "Last Name", width: 250 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "mobile", headerName: "Phone No", width: 250 },
    { field: "role", headerName: "Role", width: 250 },
  ];

  console.log("at orgDashboard");

  return (
    <>
      <GridTable
        rowData={rows}
        columnData={columns}
        actions={["DELETE", "EDIT", "VIEW"]}
        onClickAdd={() => {}}
        onClick={() => {}}
        hideAddButton={false}
        toolTipName={"Add "}
        topActionButtonTitle="Add Organization"
        // currentPage={currentPage}
        // totalPages={totalPages}
        // pageSize={pageSize}
        // onPageChange={handlePageChange}
        // onPageSizeChange={handlePageSizeChange}
        // getRowId={(row) => row.userId}
      />
    </>
  );
};

export default OrgDashboard;
