import React from 'react'
import GridTable from './GridTable';
import { useState } from 'react';

export default function TrainSeatmgmt() {
    const [rows, setRows] = useState([]);
    const columns = [
        { field: "id", headerName: "ID", width: 150 },
        { field: "trainNo", headerName: "Train No", width: 250 },
        { field: "trainName", headerName: "Train Name", width: 250 },
        { field: "passengerName", headerName: "Passenger Name", width: 250 },
        { field: "email", headerName: "Email", width: 250 },
        { field: "mobile", headerName: "Phone No", width: 250 },]

  return (
    

    <div>
        <GridTable
        rowData={null}
        columnData={columns}
        actions={["DELETE", "EDIT", "VIEW"]}
        onClickAdd={() => {}}
        onClick ={() => {}}
        hideAddButton={true}
        
        />

      
    </div>
  )
}
