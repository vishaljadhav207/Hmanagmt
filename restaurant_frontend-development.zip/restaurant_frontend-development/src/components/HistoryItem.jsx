import React, { useState } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Typography,
  Chip,
  Button,
} from "@material-tailwind/react";
import { FaTimes } from "react-icons/fa";
import {
  XCircleIcon,
  CheckCircleIcon,
  ClockIcon,
} from "@heroicons/react/24/solid";
import { HotelIcon } from "lucide-react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import axiosInstance from "../app/axiosInstance";

const statusMap = {
  PENDING: {
    text: "Pending",
    color: "amber",
    icon: <ClockIcon className="h-5 w-5 text-amber-500" />,
  },
  CHECKED_OUT: {
    text: "Completed",
    color: "green",
    icon: <CheckCircleIcon className="h-5 w-5 text-green-500" />,
  },
  CANCELLED: {
    text: "Cancelled",
    color: "red",
    icon: <XCircleIcon className="h-5 w-5 text-red-500" />,
  },
  BOOKED: {
    text: "Booked",
    color: "blue",
    icon: <CheckCircleIcon className="h-5 w-5 text-blue-500" />,
  },
  REJECTED: {
    text: "Rejected",
    color: "red",
    icon: <XCircleIcon className="h-5 w-5 text-red-500" />,
  },
  CHECKED_IN: {
    text: "Checked In",
    color: "indigo",
    icon: <CheckCircleIcon className="h-5 w-5 text-indigo-500" />,
  },
};

const Detail = ({ label, value }) => (
  <div>
    <Typography variant="small" color="blue-gray" className="font-medium">
      {label}
    </Typography>
    <Typography variant="paragraph" color="gray">
      {value || "N/A"}
    </Typography>
  </div>
);

const HistoryItem = ({
  item,
  isRatingPending,
  onRatingClick,
  onCancelSuccess,
}) => {
  const [expanded, setExpanded] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const baseURL = axiosInstance.defaults.baseURL;
  const { userInfo } = useSelector((state) => state.user);
  const token = userInfo?.token;

  const statusInfo = statusMap[item.status] || {
    text: "Unknown",
    color: "gray",
    icon: <ClockIcon className="h-5 w-5 text-gray-500" />,
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const options = { year: "numeric", month: "short", day: "numeric" };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleCancelBooking = async () => {
    if (!cancelReason) {
      toast.error("Please provide a cancellation reason");
      return;
    }
    setIsSubmitting(true);
    try {
      const payload = {
        bookingId: item.bookingId,
        action: "cancel",
        remark: cancelReason,
      };
      const response = await axiosInstance.put(
        `${baseURL}booking/updateBookingStatus`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      if (response.data?.statusCode === 200) {
        toast.success("Booking cancelled successfully");
        setIsCancelModalOpen(false);
        setCancelReason("");
        if (onCancelSuccess) onCancelSuccess(item.bookingId);
      } else {
        throw new Error(response.data?.message || "Failed to cancel booking");
      }
    } catch (error) {
      let errorMessage = error.message;
      if (error.response) {
        errorMessage =
          error.response.data?.message ||
          error.response.data?.error ||
          error.message;
        if (error.response.data?.errors) {
          errorMessage +=
            ": " + Object.values(error.response.data.errors).join(", ");
        }
      } else if (error.request) {
        errorMessage = "No response received from server";
      }
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full rounded-lg shadow-lg mb-6">
      <CardHeader
        floated={false}
        shadow={false}
        className="rounded-t-lg p-0 overflow-hidden relative bg-[#5A2360] h-32 flex items-center"
      >
        <div className="flex items-center gap-4 px-6 py-4 w-full">
          <div className="bg-white/20 rounded-full p-3 flex items-center justify-center">
            <HotelIcon className="h-8 w-8 text-white" />
          </div>
          <div>
            <Typography variant="h5" color="white" className="font-bold">
              {item.hotelName || "Unknown Hotel"}
            </Typography>
            <Typography variant="small" color="white" className="opacity-80">
              {item.city}
            </Typography>
          </div>
          <div className="ml-auto flex items-center gap-2 ">
            <Chip
              value={statusInfo.text}
              color={statusInfo.color}
              className="text-white font-medium"
            />
            {statusInfo.icon}
          </div>
        </div>
      </CardHeader>
      <CardBody className="p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <Typography variant="h6" className="font-bold text-[#081123]">
              ₹{Math.round(item.totalPrice * 1.18)}
            </Typography>
            <Typography variant="small" color="gray">
              Booking ID: {item.bookingId}
            </Typography>
          </div>
          <div className="text-right">
            <Typography variant="small" color="gray">
              Room Type: {item.roomType}
            </Typography>
            <Typography variant="small" color="gray">
              Payment: {item.paymentStatus}
            </Typography>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <Detail label="Check-in" value={formatDate(item.checkInDate)} />
          <Detail label="Check-out" value={formatDate(item.checkOutDate)} />
          <Detail label="Adults" value={item.numberOfAdults || 0} />
          <Detail label="Rooms" value={item.roomsNeeded || 0} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <Detail label="Room Type" value={item.roomType} />
          <Detail label="Payment Status" value={item.paymentStatus} />
          <Detail label="Payment Method" value={item.paymentMethod} />
          <Detail label="Booking Status" value={statusInfo.text} />
        </div>
        <div className="flex justify-between items-center mt-6">
          <Button
            variant="text"
            size="sm"
            onClick={() => setExpanded((v) => !v)}
            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white rounded"
          >
            {expanded ? "Hide Details" : "Show Details"}
          </Button>
          {item.status !== "CANCELLED" &&
            item.status !== "CHECKED_OUT" &&
            item.status !== "REJECTED" && (
              <Button
                color="red"
                size="sm"
                onClick={() => setIsCancelModalOpen(true)}
                className="ml-2"
              >
                Cancel Booking
              </Button>
            )}
        </div>
        {expanded && (
          <div className="mt-6 border-t pt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <Detail label="Booking ID" value={item.bookingId} />
            <Detail
              label="Guest"
              value={item.numberOfAdults || "Not assigned"}
            />
            <Detail label="Room Type" value={item.roomType} />
            <Detail label="Payment Status" value={item.paymentStatus} />
            <Detail label="Payment Method" value={item.paymentMethod} />
            <Detail label="Booking Status" value={statusInfo.text} />
            <Detail
              label="Check-in Date"
              value={formatDate(item.checkInDate)}
            />
            <Detail
              label="Check-out Date"
              value={formatDate(item.checkOutDate)}
            />
          </div>
        )}
      </CardBody>


      {isCancelModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm flex justify-center items-center z-50 transition-opacity duration-300">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">
                Cancel Booking #{item.bookingId}
              </h3>
              <button
                onClick={() => setIsCancelModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
                disabled={isSubmitting}
              >
                <FaTimes />
              </button>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for cancellation (required)
              </label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows="4"
                placeholder="Please provide the reason for cancellation..."
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                required
                disabled={isSubmitting}
              />
            </div>
            <div className="flex justify-end space-x-3">
              <Button
                variant="text"
                color="gray"
                onClick={() => setIsCancelModalOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                color="red"
                onClick={handleCancelBooking}
                disabled={isSubmitting || !cancelReason}
                className="flex items-center"
              >
                {isSubmitting ? (
                  <>
                    <svg
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  "Confirm Cancellation"
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </Card>
  );
};

export default HistoryItem;
