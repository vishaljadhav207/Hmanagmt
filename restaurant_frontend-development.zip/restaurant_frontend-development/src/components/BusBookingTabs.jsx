import React, { useRef, useState, useEffect } from "react";
import Calendar from "react-calendar";
import { GoArrowSwitch } from "react-icons/go";
import "react-calendar/dist/Calendar.css";
import { Card, CardBody, Alert, Button } from "@material-tailwind/react";
import {
  ExclamationCircleIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/solid";
import { useDispatch } from "react-redux";
import { searchBusTrips, getAllBusTrips } from "../app/bustripApi";
import DropDownSelector from "./DropDownSelector";
import DatePicker from "./DatePicker";
import travelAxios from "../app/travelAxios";

const BusBookingTabs = ({ onBookingSubmit }) => {
  const [cityFrom, setCityFrom] = useState("");
  const [cityTo, setCityTo] = useState("");
  const [departureDate, setDepartureDate] = useState(new Date());
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [classSelected, setClassSelected] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [stations, setStations] = useState([]);
  const [classTypes, setClassTypes] = useState([]);
  const [isFetchingClasses, setIsFetchingClasses] = useState(true);

  const dispatch = useDispatch();
  const calendarRef = useRef(null);

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const result = await dispatch(getAllBusTrips({ page: 0, size: 1000 }));
        const trips = result.payload || [];
        const origins = trips.map((t) => t.origin);
        const destinations = trips.map((t) => t.destination);
        const uniqueStations = Array.from(
          new Set([...origins, ...destinations])
        ).filter(Boolean);

        setStations(uniqueStations);
        setCityFrom(uniqueStations[0] || "");
        setCityTo(uniqueStations[1] || "");

        setIsFetchingClasses(true);
        const response = await travelAxios.get("getAllClassType");
        if (response.data && Array.isArray(response.data)) {
          const filtered = response.data.filter(
            (item) => item.transportType === "BUS"
          );
          const types = filtered.map((type) => type.className);
          setClassTypes(types);
        } else {
          setError("Invalid response format for class types");
        }
      } catch (err) {
        setError("Failed to load initial data");
      } finally {
        setIsFetchingClasses(false);
      }
    };

    fetchInitialData();
  }, [dispatch]);

  const handleDateChange = (newDate) => {
    setDepartureDate(newDate);
    setIsCalendarOpen(false);
  };

  const toggleCalendar = (e) => {
    e.preventDefault();
    setIsCalendarOpen(true);
  };

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const submitSearch = async () => {
    if (!cityFrom || !cityTo) {
      setError("Please select both FROM and TO stations.");
      return;
    }

    setError(null);
    setSuccess(null);
    setIsLoading(true);

    try {
      const searchData = {
        origin: cityFrom,
        destination: cityTo,
        departureDate: formatDate(departureDate),
      };

      const result = await dispatch(searchBusTrips(searchData));

      if (result.error) {
        throw new Error(result.error.message || "Search failed");
      }

      if (result.payload?.length > 0) {
        setSuccess(`Found ${result.payload.length} buses!`);
        if (onBookingSubmit) {
          onBookingSubmit({
            ...searchData,
            searchResults: result.payload,
            success: true,
          });
        }
      } else {
        setError(
          "No buses found matching your criteria. Try different dates or stations."
        );
        if (onBookingSubmit) {
          onBookingSubmit({
            ...searchData,
            searchResults: [],
            error: "No results found",
          });
        }
      }
    } catch (err) {
      setError(
        err.message || "Failed to search buses. Please try again later."
      );
      if (onBookingSubmit) {
        onBookingSubmit({
          searchResults: [],
          error: err.message,
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative min-h-[300px] pt-15 pb-10">
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/bus-bk-images/img2.jpg"
          alt="Bus background"
          className="w-full h-[400px] object-cover"
        />
        <div className="absolute h-[400px] inset-0 bg-black/20"></div>
      </div>
      <div className="text-center text-3xl text-white font-extrabold  font-sans md:font-serif font-boldmb-2 scale-x-110 drop-shadow-xs">
        <div>Your Journey</div>
        <div className="text-5xl">Just a Click Away!</div>
      </div>
      {error && (
        <Alert
          color="red"
          icon={<ExclamationCircleIcon className="h-6 w-6" />}
          className="w-full max-w-5xl mx-auto mt-4 rounded-lg"
        >
          {error}
        </Alert>
      )}

      {success && (
        <Alert
          color="green"
          icon={<CheckCircleIcon className="h-6 w-6" />}
          className="w-full max-w-5xl mx-auto mt-4 rounded-lg"
        >
          {success}
        </Alert>
      )}

      <div className="relative z-10 flex justify-center p-4">
        <Card className="w-full max-w-5xl bg-[#320D36] text-white shadow-lg rounded-xl p-6">
          {isCalendarOpen && (
            <div
              ref={calendarRef}
              style={{
                position: "absolute",
                top: "9rem",
                left: "27.5rem",
                zIndex: 50,
              }}
              className="bg-white text-black rounded shadow-lg"
            >
              <Calendar
                onChange={handleDateChange}
                value={departureDate}
                minDate={new Date()}
                className="react-calendar"
              />
            </div>
          )}

          <CardBody className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-col md:flex-row w-full gap-4">
              <DropDownSelector
                label="FROM"
                value={cityFrom}
                onChange={(e) => setCityFrom(e.target.value)}
                label1="Select Origin"
                options={stations}
                className="w-full md:w-1/4 bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer"
              />

              <div className="flex items-center justify-center md:w-auto">
                <GoArrowSwitch
                  className="text-white text-4xl md:text-5xl mx-2 cursor-pointer"
                  onClick={() => {
                    const temp = cityFrom;
                    setCityFrom(cityTo);
                    setCityTo(temp);
                  }}
                />
              </div>

              <DropDownSelector
                label="TO"
                value={cityTo}
                onChange={(e) => setCityTo(e.target.value)}
                label1="Select Destination"
                options={stations}
                className="w-full md:w-1/4 bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer"
              />

              <DatePicker
                onClick={toggleCalendar}
                label="DEPARTURE DATE"
                date={departureDate}
                className="w-full md:w-1/4 h-25 bg-[#5A2360] pt-5.5 text-white p-4 rounded-lg text-center cursor-pointer"
              />

              <div
                onClick={submitSearch}
                className="w-full md:w-1/4 bg-[#5A2360] pt-5.5 text-white p-4 rounded-lg text-center cursor-pointer hover:bg-[#6A2C70] transition-colors"
              >
                <button
                  type="submit"
                  className="py-3 w-full"
                  disabled={
                    isLoading || isFetchingClasses || classTypes.length === 0
                  }
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg
                        className="animate-spin h-5 w-5 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Searching...
                    </span>
                  ) : (
                    "Search Bus"
                  )}
                </button>
              </div>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default BusBookingTabs;
