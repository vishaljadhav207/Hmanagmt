import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getImages } from "../redux/roomSlice";
import axiosInstance from "../app/axiosInstance";
import ImageModal from "./ImageModal"; 

const Image = ({ hotelId }) => {
  const dispatch = useDispatch();
  const { images, status, error } = useSelector((state) => state.rooms);

 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

 
  useEffect(() => {
    if (hotelId) {
      dispatch(getImages({ hotelId }));
    } else {
      console.error("Missing hotelId");
    }
  }, [hotelId]);

  console.log("Images:", images);
  console.log("hotelId:", hotelId);

  
  const baseUrl = axiosInstance.defaults.baseURL;

  const imageList = images.length > 0 ? images : ["defaultImage.jpg"];

 
  const openModal = (index) => {
    setCurrentImageIndex(index);
    setIsModalOpen(true);
  };

 
  const closeModal = () => {
    setIsModalOpen(false);
  };


  const nextImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === imageList.length - 1 ? 0 : prevIndex + 1
    );
  };


  const prevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? imageList.length - 1 : prevIndex - 1
    );
  };

  const extraImagesCount = imageList.length > 3 ? imageList.length - 3 : 0;

  return (
    <div>
      <div className="flex flex-row items-center space-x-4">
   
        <div className="w-full lg:w-2/3 relative">
{        console.log('baseUrl: ', `${baseUrl}images/getImages?hotel_id=${hotelId}&imageName=${imageList[0].imageName}`)}
          {imageList.length > 0 && (
            <div className="relative">
              <img
                src={`${baseUrl}images/getImages?hotel_id=${hotelId}&imageName=${imageList[0].imageName}`}
                alt="Large Image"
                className="w-full h-auto rounded-2xl shadow-lg cursor-pointer"
                onClick={() => openModal(0)} 
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = "/placeholder-image.jpg";
                }}
              />
            
              {extraImagesCount > 0 && (
                <div className="absolute top-0 right-0 bg-black text-white px-3 py-1 rounded-bl-xl opacity-75">
                  {`+${extraImagesCount} More`}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex flex-col space-y-4 w-full lg:w-1/3">
          {imageList.slice(1, 3).map((image, index) => {
            const imageUrl = `${baseUrl}images/getImages?hotel_id=${hotelId}&imageName=${image.imageName}`;
            return (
              <div key={index} className="relative group">
                <img
                  src={imageUrl}
                  alt={`Small Image ${index + 1}`}
                  className="w-full h-auto rounded-2xl shadow-lg cursor-pointer"
                  onClick={() => openModal(index + 1)} 
                />
              </div>
            );
          })}
        </div>
      </div>

      {isModalOpen && (
        <ImageModal
          images={imageList.map(
            (image) =>
              `${baseUrl}images/getImages?hotel_id=${hotelId}&imageName=${image.imageName}`
          )}
          currentImageIndex={currentImageIndex}
          setCurrentImageIndex={setCurrentImageIndex}
          closeModal={closeModal}
          prevImage={prevImage}
          nextImage={nextImage}
        />
      )}
    </div>
  );
};

export default Image;