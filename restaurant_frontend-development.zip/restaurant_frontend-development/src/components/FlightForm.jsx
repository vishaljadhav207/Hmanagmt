import React, { useEffect, useState } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  MenuItem,
  Box,
  Grid,
  Paper,
  Alert,
  CircularProgress,
  IconButton,
  Divider,
  Card,
  CardContent,
} from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getFlightTripById } from "../app/flighttripApi";
import { saveTickett } from "../app/flighttripApi";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import RemoveCircleIcon from "@mui/icons-material/RemoveCircle";

const FlightForm = () => {
  const { state } = useLocation();
  const { flightTripId } = state || {};
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const { selectedFlightTrip, status, error, selectedTicket } = useSelector((state) => state.flighttrip);

  const [formData, setFormData] = useState({
    transportType: "AIRLINE",
    transportId: flightTripId,
    classType: "Economy",
    seatPreference: "Window",
    boarding: "",
    departure: "",
    journeyDate: "",
    totalFare: 0,
    cancellationFee: 0,
    refundAmount: 0,
    refunded: true,
    passengerList: [
      {
        name: "",
        age: "",
        gender: "",
        pnrNumber: "",
        seatPreference: "Window"
      }
    ],
  });

  const [passengerCount, setPassengerCount] = useState(1);

  useEffect(() => {
    if (flightTripId) {
      dispatch(getFlightTripById(flightTripId));
    }
  }, [dispatch, flightTripId]);

  useEffect(() => {
    if (selectedFlightTrip) {
      setFormData((prev) => ({  
        ...prev,
        transportId: selectedFlightTrip.flight?.flight_id,
        journeyDate: selectedFlightTrip.departureDate,
        totalFare: selectedFlightTrip.flight?.classTypes?.[0]?.fare || 0,
        boarding: selectedFlightTrip.origin,
        departure: selectedFlightTrip.destination,
        classType: selectedFlightTrip.flight?.classTypes?.[0]?.className || "Economy",
      }));
    }
  }, [selectedFlightTrip]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePassengerChange = (index, e) => {
    const { name, value } = e.target;
    const updatedPassengers = [...formData.passengerList];
    updatedPassengers[index] = {
      ...updatedPassengers[index],
      [name]: value
    };
    setFormData(prev => ({
      ...prev,
      passengerList: updatedPassengers
    }));
  };

  const addPassenger = () => {
    if (passengerCount < 9) { // Limiting to 9 passengers for demo
      setPassengerCount(passengerCount + 1);
      setFormData(prev => ({
        ...prev,
        passengerList: [
          ...prev.passengerList,
          {
            name: "",
            age: "",
            gender: "",
            pnrNumber: "",
            seatPreference: "Window"
          }
        ]
      }));
    }
  };

  const removePassenger = (index) => {
    if (passengerCount > 1) {
      setPassengerCount(passengerCount - 1);
      const updatedPassengers = [...formData.passengerList];
      updatedPassengers.splice(index, 1);
      setFormData(prev => ({
        ...prev,
        passengerList: updatedPassengers
      }));
    }
  };

  const calculateTotalFare = () => {
    const baseFare = selectedFlightTrip?.flight?.classTypes?.find(
      cls => cls.className === formData.classType
    )?.fare || 0;
    return baseFare * passengerCount;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Update total fare before submission
    const updatedFormData = {
      ...formData,
      totalFare: calculateTotalFare()
    };
    await dispatch(saveTickett(updatedFormData));
    if (selectedTicket) {
      navigate("/ticket", { state: { ticket: selectedTicket } });
    }
  };

  if (status === "loading" && !selectedFlightTrip) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, textAlign: "center" }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Paper sx={{ p: 4, mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          ✈️ Book Your Flight Ticket
        </Typography>

        {selectedFlightTrip && (
          <Card sx={{ mb: 3, backgroundColor: "#f5f5f5" }}>
            <CardContent>
              <Typography variant="h6">{selectedFlightTrip.flight.airline}</Typography>
              <Typography variant="body2">
                #{selectedFlightTrip.flight.flightNo} — {selectedFlightTrip.origin} to {selectedFlightTrip.destination}
              </Typography>
              <Typography variant="body2">
                Departure: {new Date(selectedFlightTrip.departureDate).toLocaleString()}
              </Typography>
              <Typography variant="body2">
                Duration: {selectedFlightTrip.duration} • {selectedFlightTrip.flight.aircraftType}
              </Typography>
              <Typography variant="h6" sx={{ mt: 1 }}>
                Total Fare: ₹{calculateTotalFare()} ({passengerCount} {passengerCount > 1 ? "passengers" : "passenger"})
              </Typography>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <TextField
                label="Boarding Airport"
                name="boarding"
                value={formData.boarding}
                onChange={handleChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Destination Airport"
                name="departure"
                value={formData.departure}
                onChange={handleChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Journey Date"
                name="journeyDate"
                type="date"
                InputLabelProps={{ shrink: true }}
                value={formData.journeyDate}
                onChange={handleChange}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Class Type"
                name="classType"
                value={formData.classType}
                onChange={handleChange}
                select
                fullWidth
              >
                {selectedFlightTrip?.flight?.classTypes?.map((cls, idx) => (
                  <MenuItem key={idx} value={cls.className}>
                    {cls.className} - ₹{cls.fare}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>

          <Box sx={{ mt: 4 }}>
            <Typography variant="h6" gutterBottom>
              Passenger Details ({passengerCount})
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            {formData.passengerList.map((passenger, index) => (
              <Card key={index} sx={{ mb: 3, p: 2 }}>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Typography variant="subtitle1">Passenger {index + 1}</Typography>
                  {index > 0 && (
                    <IconButton 
                      color="error" 
                      onClick={() => removePassenger(index)}
                      aria-label="remove passenger"
                    >
                      <RemoveCircleIcon />
                    </IconButton>
                  )}
                </Box>
                <Grid container spacing={2}>
                  <Grid item xs={12} md={4}>
                    <TextField
                      label="Full Name"
                      name="name"
                      value={passenger.name}
                      onChange={(e) => handlePassengerChange(index, e)}
                      fullWidth
                      required
                    />
                  </Grid>
                  <Grid item xs={6} md={2}>
                    <TextField
                      label="Age"
                      name="age"
                      type="number"
                      value={passenger.age}
                      onChange={(e) => handlePassengerChange(index, e)}
                      fullWidth
                      required
                      inputProps={{ min: 1, max: 120 }}
                    />
                  </Grid>
                  <Grid item xs={6} md={3}>
                    <TextField
                      label="Gender"
                      name="gender"
                      value={passenger.gender}
                      onChange={(e) => handlePassengerChange(index, e)}
                      select
                      fullWidth
                      required
                    >
                      <MenuItem value="Male">Male</MenuItem>
                      <MenuItem value="Female">Female</MenuItem>
                      <MenuItem value="Other">Other</MenuItem>
                    </TextField>
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <TextField
                      label="Seat Preference"
                      name="seatPreference"
                      value={passenger.seatPreference}
                      onChange={(e) => handlePassengerChange(index, e)}
                      select
                      fullWidth
                    >
                      <MenuItem value="Window">Window</MenuItem>
                      <MenuItem value="Aisle">Aisle</MenuItem>
                      <MenuItem value="Middle">Middle</MenuItem>
                    </TextField>
                  </Grid>
                </Grid>
              </Card>
            ))}

            <Box textAlign="center" mt={2}>
              <Button 
                variant="outlined" 
                startIcon={<AddCircleIcon />}
                onClick={addPassenger}
                disabled={passengerCount >= 9}
              >
                Add Passenger
              </Button>
            </Box>
          </Box>

          <Box mt={4}>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary" 
              fullWidth
              size="large"
              sx={{ py: 1.5 }}
            >
              Pay ₹{calculateTotalFare()} & Book Tickets
            </Button>
          </Box>
        </form>

        {status === "failed" && error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            ❌ {error}
          </Alert>
        )}
      </Paper>
    </Container>
  );
};

export default FlightForm;