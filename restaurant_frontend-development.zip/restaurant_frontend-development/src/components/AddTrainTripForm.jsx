import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTrainTrip, getTrainTripsByUserId } from "../app/traintripApi";
import { getTrainByUserId } from "../app/trainApi"; 
import Swal from 'sweetalert2';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  Typography,
  Divider,
  Box,
  IconButton,
  Paper,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress
} from "@mui/material";
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Train as TrainIcon
} from "@mui/icons-material";

const AddTrainTripForm = ({ open, onClose, userId, onSuccess }) => {
  const dispatch = useDispatch();
  const [newTrip, setNewTrip] = useState({
    tripId: "",
    origin: "",
    destination: "",
    departureDate: "",
    arrivalDate: "",
    train: { train_id: "" },
    intermediateStops: []
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [trains, setTrains] = useState([]);
  const [trainsLoading, setTrainsLoading] = useState(false);

 
  useEffect(() => {
    const fetchTrains = async () => {
      if (userId) {
        setTrainsLoading(true);
        try {
          const response = await dispatch(getTrainByUserId(userId)).unwrap();
          setTrains(response.data || []);
        } catch (error) {
          console.error("Failed to fetch trains:", error);
        } finally {
          setTrainsLoading(false);
        }
      }
    };

    fetchTrains();
  }, [dispatch, userId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTrip(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTrainChange = (e) => {
    const trainId = e.target.value;
    setNewTrip(prev => ({
      ...prev,
      train: { train_id: trainId }
    }));
  };

  const handleAddStop = () => {
    setNewTrip(prev => ({
      ...prev,
      intermediateStops: [
        ...prev.intermediateStops,
        {
          stopName: "",
          arrivalTime: "",
          departureTime: "",
          distanceFromPrevious: 0,
          sequence: prev.intermediateStops.length + 1
        }
      ]
    }));
  };

  const handleStopChange = (index, field, value) => {
    const updatedStops = [...newTrip.intermediateStops];
    updatedStops[index][field] = value;
    setNewTrip(prev => ({
      ...prev,
      intermediateStops: updatedStops
    }));
  };

  const handleRemoveStop = (index) => {
    const updatedStops = newTrip.intermediateStops.filter((_, i) => i !== index);
    setNewTrip(prev => ({
      ...prev,
      intermediateStops: updatedStops.map((stop, idx) => ({
        ...stop,
        sequence: idx + 1
      }))
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!newTrip.origin) newErrors.origin = "Origin is required";
    if (!newTrip.destination) newErrors.destination = "Destination is required";
    if (!newTrip.departureDate) newErrors.departureDate = "Departure date is required";
    if (!newTrip.arrivalDate) newErrors.arrivalDate = "Arrival date is required";
    if (!newTrip.train.train_id) newErrors.train = "Train selection is required";
    if (newTrip.intermediateStops.length === 0) newErrors.intermediateStops = "At least one intermediate stop is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  useEffect(() => {
    if (!open) {
      setNewTrip({
        tripId: "",
        origin: "",
        destination: "",
        departureDate: "",
        arrivalDate: "",
        train: { train_id: "" },
        intermediateStops: []
      });
      setErrors({});
    }
  }, [open]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsSubmitting(true);

    try {
      const payload = {
        origin: newTrip.origin,
        destination: newTrip.destination,
        departureDate: newTrip.departureDate,
        arrivalDate: newTrip.arrivalDate,
        train: { train_id: Number(newTrip.train.train_id) },
        intermediateStops: newTrip.intermediateStops.map((stop, idx) => ({
          stopName: stop.stopName,
          arrivalTime: stop.arrivalTime,
          departureTime: stop.departureTime,
          distanceFromPrevious: Number(stop.distanceFromPrevious) || 0,
          sequence: idx + 1
        }))
      };

      await dispatch(addTrainTrip(payload)).unwrap();

      if (userId) {
        await dispatch(getTrainTripsByUserId(userId));
      }

       Swal.fire({
      icon: 'success',
      title: 'Added!',
      text: 'Train trip added successfully.',
      timer: 2000,
      showConfirmButton: false
    });
      if (onSuccess) onSuccess();
      onClose();
      
    } catch (error) {
      setErrors({
        submit: error.message || "Failed to add train trip"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center">
          <TrainIcon sx={{ mr: 1 }} />
          <Typography variant="h6">Add New Train Trip</Typography>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <Typography variant="h6">Basic Information</Typography>
              <Divider />
            </Grid>

            {/* Train Selection Dropdown */}
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="train-select-label">Select Train</InputLabel>
                <Select
                  labelId="train-select-label"
                  id="train-select"
                  value={newTrip.train.train_id}
                  onChange={handleTrainChange}
                  label="Select Train"
                  error={!!errors.train}
                  required
                >
                  {trainsLoading ? (
                    <MenuItem disabled>
                      <CircularProgress size={24} />
                    </MenuItem>
                  ) : trains.length > 0 ? (
                    trains.map((train) => (
                      <MenuItem key={train.train_id} value={train.train_id}>
                        {train.trainName} (No: {train.trainNo})
                      </MenuItem>
                    ))
                  ) : (
                    <MenuItem disabled>No trains available</MenuItem>
                  )}
                </Select>
                {errors.train && (
                  <Typography color="error" variant="caption">
                    {errors.train}
                  </Typography>
                )}
              </FormControl>
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Origin"
                name="origin"
                value={newTrip.origin}
                onChange={handleInputChange}
                error={!!errors.origin}
                helperText={errors.origin}
                required
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Destination"
                name="destination"
                value={newTrip.destination}
                onChange={handleInputChange}
                error={!!errors.destination}
                helperText={errors.destination}
                required
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Departure Date"
                type="date"
                name="departureDate"
                value={newTrip.departureDate}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                error={!!errors.departureDate}
                helperText={errors.departureDate}
                inputProps={{
                  min: new Date().toISOString().split("T")[0], 
                }}
                required
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Arrival Date"
                type="date"
                name="arrivalDate"
                value={newTrip.arrivalDate}
                onChange={handleInputChange}
                InputLabelProps={{ shrink: true }}
                error={!!errors.arrivalDate}
                helperText={errors.arrivalDate}
                inputProps={{
                  min: new Date().toISOString().split("T")[0], 
                }}
                required
              />
            </Grid>

            {/* Intermediate Stops */}
            <Grid item xs={12}>
              <Box display="flex" justifyContent="space-between">
                <Typography variant="h6">Stops</Typography>
                <Button onClick={handleAddStop} variant="outlined" startIcon={<AddIcon />}>
                  Add Stop
                </Button>
              </Box>
              <Divider sx={{ my: 1 }} />
            </Grid>

            {newTrip.intermediateStops.map((stop, index) => (
              <Grid item xs={12} key={index}>
                <Paper elevation={2} sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="subtitle1">Stop #{index + 1}</Typography>
                    <IconButton onClick={() => handleRemoveStop(index)} color="error">
                      <DeleteIcon />
                    </IconButton>
                  </Box>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Stop Name"
                        value={stop.stopName}
                        onChange={(e) => handleStopChange(index, 'stopName', e.target.value)}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Arrival Time"
                        type="datetime-local"
                        value={stop.arrivalTime}
                        onChange={(e) => handleStopChange(index, 'arrivalTime', e.target.value)}
                        InputLabelProps={{ shrink: true }}
                        inputProps={{
                          min: new Date().toISOString().slice(0, 16), 
                        }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Departure Time"
                        type="datetime-local"
                        value={stop.departureTime}
                        onChange={(e) => handleStopChange(index, 'departureTime', e.target.value)}
                        InputLabelProps={{ shrink: true }}
                        inputProps={{
                          min: new Date().toISOString().slice(0, 16), 
                        }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Distance from Previous (km)"
                        type="number"
                        value={stop.distanceFromPrevious}
                        onChange={(e) => handleStopChange(index, 'distanceFromPrevious', e.target.value)}
                        required
                      />
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            ))}

            <Grid item xs={12}>
              <DialogActions>
                <Button onClick={onClose} color="secondary">
                  Cancel
                </Button>
                <Button type="submit" variant="contained" color="primary" disabled={isSubmitting}>
                  {isSubmitting ? "Adding..." : "Add Trip"}
                </Button>
              </DialogActions>
            </Grid>
          </Grid>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddTrainTripForm;