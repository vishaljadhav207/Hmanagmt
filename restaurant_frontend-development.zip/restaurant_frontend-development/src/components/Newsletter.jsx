import React from "react";
import { Input, Typography } from "@material-tailwind/react";
import AppButton from "./AppButton";
import { useTranslation } from "react-i18next";

function Newsletter() {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col md:flex-row gap-8 justify-center py-10 px-6 bg-gray-50">
      {/* Left Section: Newsletter Information */}
      <div className="flex-1 max-w-md text-center md:text-left">
        <Typography className="font-mono text-gray-500 text-left">
          {t("newsletter.platform")}
        </Typography>
        <Typography
          className="text-left font-serif text-2xl sm:text-3xl md:text-4xl font-semibold mb-4"
          color="black-light"
          variant="h2"
        >
          {t("newsletter.title")}
        </Typography>
        <Typography className="text-justify mt-4 font-normal !text-lg !text-gray-500">
          <ul className="list-disc list-inside space-y-2">
            <li>{t("newsletter.description.item1")}</li>
            <li>{t("newsletter.description.item2")}</li>
            <li>{t("newsletter.description.item3")}</li>
          </ul>
        </Typography>
      </div>

      {/* Right Section: Email Subscription */}
      <div className="flex-1 max-w-lg flex items-center justify-center">
        <div className="flex flex-col md:flex-row items-center justify-center w-full space-y-4 md:space-y-0">
          <div className="w-full md:w-3/4 flex justify-center md:justify-start">
            <Input
              type="email"
              placeholder={t("newsletter.placeholder")}
              name="email"
              className="!border !border-gray-300 placeholder:italic bg-white text-gray-900 shadow-lg shadow-gray-900/5 ring-4 ring-transparent placeholder:text-gray-500 placeholder:opacity-100 focus:!border-gray-900 focus:ring-gray-900/10 rounded-none py-3 px-4 w-full md:w-72"
              labelProps={{
                className: "hidden",
              }}
              containerProps={{ className: "min-w-[100px]" }}
            />
          </div>
          <div className="w-full md:w-auto flex justify-center md:justify-start">
            <AppButton
              color="lightBlue"
              ripple="light"
              className="rounded-none ml-0 w-full md:w-40 py-3 text-lg"
              title={t("newsletter.subscribe")}
            ></AppButton>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Newsletter;