import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getRooms } from "../redux/roomSlice";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  FaSwimmer,
  FaDumbbell,
  FaChild,
  FaGamepad,
  FaConciergeBell,
  FaUtensils,
  FaCocktail,
  FaSpa,
  FaHotel,
  FaCircleNotch,
} from "react-icons/fa";

const iconMap = {
  "swimming pool": <FaSwimmer className="text-black w-6 h-6" />,
  gym: <FaDumbbell className="text-black w-6 h-6" />,
  "kids play area": <FaChild className="text-black w-6 h-6" />,
  "indoor games": <FaGamepad className="text-black w-6 h-6" />,
  restaurant: <FaUtensils className="text-black w-6 h-6" />,
  "24-hour room service": <FaConciergeBell className="text-black w-6 h-6" />,
  bar: <FaCocktail className="text-black w-6 h-6" />,
  lounge: <FaSpa className="text-black w-6 h-6" />,
  yoga: <FaHotel className="text-black w-6 h-6" />,
  "butler services": <FaConciergeBell className="text-black w-6 h-6" />,
  spa: <FaSpa className="text-black w-6 h-6" />,
};

const Amenity = ({
  setTotalPrice,
  setHotelName,
  roomCount,
  setRoomCount,
  selectedRoomType,
  setSelectedRoomType,
  setRoomPrice: updateRoomPrice, // Rename the prop to avoid conflict
}) => {
  const dispatch = useDispatch();
  const {
    rooms,
    status,
    error,
    selectedRoomId: hotelId,
  } = useSelector((state) => state.rooms);

  const [localRoomPrice, setLocalRoomPrice] = useState(0); // Renamed state variable

  useEffect(() => {
    if (hotelId) {
      dispatch(getRooms(hotelId));
    }
  }, [dispatch, hotelId]);

  useEffect(() => {
    if (rooms.length > 0) {
      const defaultRoom =
        rooms.find((room) => room.roomType === "Single") || rooms[0];

      if (!selectedRoomType) {
        setSelectedRoomType(defaultRoom.roomType);
        setLocalRoomPrice(defaultRoom.roomBasePrice || 0); // Set initial price in local state
        updateRoomPrice(defaultRoom.roomBasePrice || 0); // Update price in parent
      }

      setHotelName(rooms[0]?.hotel?.hotelName);
    }
  }, [
    rooms,
    selectedRoomType,
    setSelectedRoomType,
    setHotelName,
    updateRoomPrice,
  ]);

  useEffect(() => {
    setTotalPrice(localRoomPrice * roomCount);
  }, [localRoomPrice, roomCount, setTotalPrice]);

  const handleRoomTypeChange = (e) => {
    const selectedType = e.target.value;
    setSelectedRoomType(selectedType);

    const roomData = rooms.find((room) => room.roomType === selectedType);
    if (roomData) {
      setLocalRoomPrice(roomData.roomBasePrice || 0); // Update local state
      updateRoomPrice(roomData.roomBasePrice || 0); // Update price in parent
    }
  };

  const handleRoomCountChange = (increment) => {
    setRoomCount((prev) => Math.max(prev + increment, 1));
  };

  const amenities = rooms.length > 0 ? rooms[0]?.hotel?.amenities || [] : [];
  const hotelOwner = rooms.length > 0 ? rooms[0]?.hotel?.hotelOwner : null;
  const ownerName = hotelOwner
    ? `${hotelOwner.firstName} ${hotelOwner.lastName}`
    : "Owner Name Not Available";
  const ownerMobile = hotelOwner
    ? hotelOwner.mobile
    : "Mobile Number Not Available";

  return (
    <div className="max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-md">
      <ToastContainer />

      {status === "loading" ? (
        <div className="flex justify-center items-center h-40">
          <FaCircleNotch className="animate-spin text-blue-500 text-4xl" />
        </div>
      ) : status === "failed" ? (
        <div className="text-center text-red-500 font-semibold">
          Error: {error}
        </div>
      ) : (
        status === "succeeded" && (
          <div className="flex flex-col md:flex-row gap-8">
            {/* Left Section */}
            <section className="flex flex-col w-full md:w-1/2 space-y-6">
              <div className="space-y-1">
                <label className=" text-lg font-medium text-gray-700 flex items-center">
                  <svg
                    className="w-5 h-5 mr-2 text-blue-500"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                    />
                  </svg>
                  Room Type
                </label>
                <div className="relative">
                  <select
                    value={selectedRoomType}
                    onChange={handleRoomTypeChange}
                    className="block w-full pl-4 pr-10 py-3 text-lg text-gray-800 bg-white border-2 border-gray-300 rounded-lg shadow-sm appearance-none focus:border-fuchsia-950 focus:ring-2 focus:ring-blue-200 focus:outline-none transition-all duration-200 hover:border-fuchsia-950"
                  >
                    {rooms.map((room, index) => (
                      <option key={index} value={room.roomType}>
                        {room.roomType}
                      </option>
                    ))}
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <svg
                      className="w-6 h-6 text-gray-500"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-xl font-semibold text-blue-800">
                  ₹{localRoomPrice.toLocaleString()}{" "}
                  <span className="text-sm font-normal text-gray-600">
                    / night
                  </span>
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Number of Rooms
                </label>
                <div className="flex items-center">
                  <button
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-l-lg hover:bg-gray-200 transition-colors duration-200"
                    onClick={() => handleRoomCountChange(-1)}
                  >
                    -
                  </button>
                  <span className="px-6 py-2 bg-gray-50 border-t border-b border-gray-200 text-center font-medium">
                    {roomCount}
                  </span>
                  <button
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-r-lg hover:bg-gray-200 transition-colors duration-200"
                    onClick={() => handleRoomCountChange(1)}
                  >
                    +
                  </button>
                </div>
              </div>
            </section>

            <section className="flex flex-col w-full md:w-1/2 space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-3">
                  Amenities
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {amenities.map((amenity, index) => (
                    <div
                      key={index}
                      className="flex flex-col items-center p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors duration-200"
                    >
                      <div className="p-2 bg-blue-100 rounded-full">
                        {iconMap[amenity.amenityName?.toLowerCase()] || (
                          <FaCircleNotch className="text-gray-500 w-5 h-5" />
                        )}
                      </div>
                      <p className="text-sm font-medium text-center mt-2 text-gray-700">
                        {amenity.amenityName}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 ">
                <h3 className="text-lg font-semibold text-blue-800 mb-2">
                  Owner Contact Information
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <svg
                      className="w-5 h-5 text-blue-500 mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                      />
                    </svg>
                    <span className="text-gray-700">{ownerName}</span>
                  </div>
                  <div className="flex items-center">
                    <svg
                      className="w-5 h-5 text-blue-500 mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                      />
                    </svg>
                    <span className="text-gray-700">{ownerMobile}</span>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )
      )}
    </div>
  );
};

export default Amenity;
