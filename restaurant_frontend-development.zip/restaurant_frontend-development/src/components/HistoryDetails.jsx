import React from "react";

const HistoryDetails = ({ item, onClose }) => {
 
  return (
    <div className="history-details-modal">
      <h2 className="text-xl font-semibold">Details for Hotel {formatHotel(item.hotelName) || 'Unknown Hotel'}</h2>
      <p><strong>Check-in Date:</strong> {formatDate(item.checkInDate)}</p>
      <p><strong>Check-out Date:</strong> {formatDate(item.checkOutDate)}</p>
      <p><strong>Status:</strong> {formatBookingStatus(item.status)}</p>
      <p><strong>User ID:</strong> {item.userId || 'N/A'}</p>
      <p><strong>City:</strong> {item.city || 'N/A'}</p>
      <p><strong>No. of Adults:</strong> {item.numberOfAdults || 0}</p>
      <p><strong>No. of Rooms:</strong> {item.roomsNeeded || 0}</p>
      <p><strong>Room Type:</strong> {item.roomType || 'N/A'}</p>
      <p><strong>Room No:</strong> {item.roomId || 'Not assigned'}</p>
      <p><strong>Total Price:</strong> ${item.totalPrice || '0.00'}</p>
      <p><strong>Payment Status:</strong> {item.paymentStatus || 'N/A'}</p>
      <p><strong>Payment Method:</strong> {item.paymentMethod || 'N/A'}</p>
      <p><strong>Booking Status:</strong> {item.BookingStatus || 'N/A'}</p>
      <button onClick={onClose}>Close</button>
    </div>
  );
};

export default HistoryDetails;
