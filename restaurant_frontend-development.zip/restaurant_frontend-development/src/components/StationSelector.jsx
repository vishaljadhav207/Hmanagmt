import React, { useState } from "react";

const StationSelector = ({ onStationChange, station, label, address }) => {


  const handleInputChange = (e) => {
    onStationChange({
      target : {
        value : e.target.value
      }
    });
  };

  return (
    <div className="relative w-full md:w-1/3">
      <div 
        className="bg-[#5A2360] text-white p-4 rounded-lg text-center cursor-pointer"
        
      >
        <label className="block text-sm font-medium mb-2 text-left">{label}</label>
       
        <input
        type="text"
        placeholder={`Enter ${label.toLowerCase()}...`}
        name={label.toLowerCase()}
        value={station}
        onChange={handleInputChange}
        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
      />

      </div>

     
    </div>
  );
};

export default StationSelector;