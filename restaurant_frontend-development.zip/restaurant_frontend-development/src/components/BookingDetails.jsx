import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import DatePicker from "./DatePicker";
import { toast } from "react-toastify";

const BookingDetails = ({ mealOption, onDetailsChange }) => {
  const { rooms } = useSelector((state) => state.rooms);
  const [bookingDetails, setBookingDetails] = useState({
    checkIn: null,
    checkOut: null,
    duration: 1,
    guests: 2,
    roomType: "",
    roomCount: 1,
    roomBasePrice: 0,
  });

  // Initialize with first available room
  useEffect(() => {
    if (rooms.length > 0 && !bookingDetails.roomType) {
      const defaultRoom = rooms[0];
      updateRoomDetails(defaultRoom.roomType, defaultRoom.roomBasePrice);
    }
  }, [rooms]);

  const formatDateForAPI = (date) => {
    if (!date) return "";
    return date.toISOString().split("T")[0];
  };

  const updateRoomDetails = (roomType, roomBasePrice) => {
    const newDetails = {
      ...bookingDetails,
      roomType,
      roomBasePrice,
    };
    setBookingDetails(newDetails);
    calculateAndSendPrices(newDetails);
  };

  const calculateAndSendPrices = (details) => {
    const duration = details.duration || 1;
    const basePrice = details.roomBasePrice * details.roomCount * duration;
    
    onDetailsChange({
      ...details,
      basePrice,
      duration,
      numberOfAdults: details.guests,
      roomsNeeded: details.roomCount,
      checkInDate: formatDateForAPI(details.checkIn),
      checkOutDate: formatDateForAPI(details.checkOut),
    });
  };

  const handleDateChange = (date, field) => {
    if (!date) return;

    const newDetails = {
      ...bookingDetails,
      [field]: date
    };

    // Calculate duration if both dates exist
    if (field === 'checkOut' && newDetails.checkIn) {
      const diffTime = Math.abs(newDetails.checkOut - newDetails.checkIn);
      newDetails.duration = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    } else if (field === 'checkIn' && newDetails.checkOut) {
      const diffTime = Math.abs(newDetails.checkOut - newDetails.checkIn);
      newDetails.duration = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    setBookingDetails(newDetails);
    calculateAndSendPrices(newDetails);
  };

  const handleRoomTypeChange = (e) => {
    const roomType = e.target.value;
    const selectedRoom = rooms.find(room => room.roomType === roomType);
    updateRoomDetails(roomType, selectedRoom.roomBasePrice);
  };

  const handleRoomCountChange = (e) => {
    const roomCount = parseInt(e.target.value);
    const newDetails = {
      ...bookingDetails,
      roomCount
    };
    setBookingDetails(newDetails);
    calculateAndSendPrices(newDetails);
  };

  const handleGuestChange = (e) => {
    const guests = parseInt(e.target.value);
    const newDetails = {
      ...bookingDetails,
      guests
    };
    setBookingDetails(newDetails);
    calculateAndSendPrices(newDetails);
  };

  return (
    <div className="booking-details mb-8 p-6 bg-white rounded-xl shadow-md border border-gray-100">
      <h2 className="text-2xl font-semibold mb-6 text-gray-800 border-b pb-2">
        Booking Details
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="p-4 bg-blue-50 rounded-lg">
          <label className="block text-gray-700 mb-2">Check In</label>
          <input
            type="date"
            onChange={(e) => handleDateChange(new Date(e.target.value), 'checkIn')}
            min={new Date().toISOString().split("T")[0]}
            className="w-full p-2 border rounded-md"
          />
        </div>

        <div className="p-4 bg-blue-50 rounded-lg">
          <label className="block text-gray-700 mb-2">Check Out</label>
          <input
            type="date"
            onChange={(e) => handleDateChange(new Date(e.target.value), 'checkOut')}
            min={bookingDetails.checkIn ? bookingDetails.checkIn.toISOString().split("T")[0] : new Date().toISOString().split("T")[0]}
            className="w-full p-2 border rounded-md"
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <label className="text-gray-600">Duration:</label>
          <span className="font-medium">
            {bookingDetails.duration} Night{bookingDetails.duration !== 1 ? "s" : ""}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <label className="text-gray-600">Guests:</label>
          <select
            value={bookingDetails.guests}
            onChange={handleGuestChange}
            className="p-2 border rounded-md w-40"
          >
            {[1, 2, 3, 4, 5, 6].map(num => (
              <option key={num} value={num}>{num} {num === 1 ? "Adult" : "Adults"}</option>
            ))}
          </select>
        </div>

        <div className="flex justify-between items-center">
          <label className="text-gray-600">Room Type:</label>
          <select
            value={bookingDetails.roomType}
            onChange={handleRoomTypeChange}
            className="p-2 border rounded-md w-40"
          >
            {rooms.map(room => (
              <option key={room.roomType} value={room.roomType}>
                {room.roomType}
              </option>
            ))}
          </select>
        </div>

        <div className="flex justify-between items-center">
          <label className="text-gray-600">No. of Rooms:</label>
          <select
            value={bookingDetails.roomCount}
            onChange={handleRoomCountChange}
            className="p-2 border rounded-md w-40"
          >
            {[1, 2, 3, 4, 5].map(num => (
              <option key={num} value={num}>{num}</option>
            ))}
          </select>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-600">Meal Plan:</span>
          <span className="font-medium">{mealOption}</span>
        </div>
      </div>
    </div>
  );
};

export default BookingDetails;