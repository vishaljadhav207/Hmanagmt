import { Carousel } from "@material-tailwind/react";
import img1 from "../assets/room1.jpg";
import img2 from "../assets/room2.jpg";
import img3 from "../assets/room3.jpg";
import img4 from "../assets/room5.jpg";
import img5 from "../assets/room6.jpg";
import img6 from "../assets/room7.jpg";
import img7 from "../assets/room8.jpg";
import train1 from "../assets/train.jpg";
import train2 from "../assets/train2.jpg";
import hotel1 from "../assets/homeImg1.jpg";
import hotel2 from "../assets/homeImg2.jpg";
import flight1 from "../assets/flight1.jpg";
import flight2 from "../assets/flight2.jpg";
import bus1 from "../assets/bus1.jpg";
import bus2 from "../assets/bus2.jpg";
import Marquee from "react-fast-marquee";
const images = [
  img1, img2,flight1, img3,train2, img4, img5, img6, img7,bus1,hotel1,hotel2,flight2,train1,bus2
];
export function CarouselCustomNavigation() {
  return (
    <div className="rounded-none mb-10 bg-[#282428] bg-opacity-10 p-10">
      <Marquee gradient={false} speed={40}>
        {images.map((image, index) => (
          <img
            key={index}
            src={image}
            alt={`image ${index + 1}`}
            className="h-60 w-60 object-cover mr-4"
          />
        ))}
      </Marquee>
    </div>
  );
}