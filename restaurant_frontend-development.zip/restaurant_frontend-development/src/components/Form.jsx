import React, { useEffect, useState } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  MenuItem,
  Box,
  Grid,
  Paper,
  Alert,
  CircularProgress,
} from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getTrainTripById, saveTickett } from "../app/traintripApi";

const Form = () => {
  const { state } = useLocation();
  const { trainTripId } = state || {};
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const { selectedTrainTrip, status, error, selectedTicket } = useSelector((state) => state.traintrip);

  const [formData, setFormData] = useState({
    transportType: "RAILWAY",
    transportId: trainTripId,
    classType: "AC",
    seatPreference: "window",
    boarding: "",
    departure: "",
    journeyDate: "",
    totalFare: 0,
    cancellationFee: 0,
    refundAmount: 0,
    refunded: true,
    passengerList: [{ name: "", age: "", gender: "", pnrNumber: "" }],
  });

  useEffect(() => {
    if (trainTripId) {
      dispatch(getTrainTripById(trainTripId));
    }
  }, [dispatch, trainTripId]);

  useEffect(() => {
    if (selectedTrainTrip) {
      setFormData((prev) => ({
        ...prev,
        transportId: selectedTrainTrip.train?.train_id,
        journeyDate: selectedTrainTrip.departureDate,
        totalFare: selectedTrainTrip.train?.classTypes?.[0]?.fare || 0,
        boarding: selectedTrainTrip.origin,
        departure: selectedTrainTrip.destination,
        classType: selectedTrainTrip.train?.classTypes?.[0]?.className || "AC",
      }));
    }
  }, [selectedTrainTrip]); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePassengerChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      passengerList: [{ ...prev.passengerList[0], [name]: value }],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await dispatch(saveTickett(formData));
    if (selectedTicket) {
      navigate("/ticket", { state: { ticket: selectedTicket } });
    }
  };

  if (status === "loading" && !selectedTrainTrip) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, textAlign: "center" }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Paper sx={{ p: 4, mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          🚆 Book Your Train Ticket
        </Typography>

        {selectedTrainTrip && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="h6">{selectedTrainTrip.train.trainName}</Typography>
            <Typography variant="body2">
              #{selectedTrainTrip.train.trainNo} — {selectedTrainTrip.origin} to {selectedTrainTrip.destination}
            </Typography>
            <Typography variant="body2">
              Journey Date: {new Date(selectedTrainTrip.departureDate).toDateString()}
            </Typography>
            <Typography variant="body2">Base Fare: ₹{formData.totalFare}</Typography>
          </Box>
        )}

        <form onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <TextField
                label="Boarding Station"
                name="boarding"
                value={formData.boarding}
                onChange={handleChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Destination"
                name="departure"
                value={formData.departure}
                onChange={handleChange}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Journey Date"
                name="journeyDate"
                type="date"
                InputLabelProps={{ shrink: true }}
                value={formData.journeyDate}
                onChange={handleChange}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Class Type"
                name="classType"
                value={formData.classType}
                onChange={handleChange}
                select
                fullWidth
              >
                {selectedTrainTrip?.train?.classTypes?.map((cls, idx) => (
                  <MenuItem key={idx} value={cls.className}>
                    {cls.className} - ₹{cls.fare}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Seat Preference"
                name="seatPreference"
                value={formData.seatPreference}
                onChange={handleChange}
                select
                fullWidth
              >
                <MenuItem value="window">Window</MenuItem>
                <MenuItem value="aisle">Aisle</MenuItem>
                <MenuItem value="sleeper">Sleeper</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={12}>
              <Typography variant="h6">Passenger Details</Typography>
            </Grid>
            <Grid item xs={4}>
              <TextField
                label="Name"
                name="name"
                value={formData.passengerList[0].name}
                onChange={handlePassengerChange}
                fullWidth
              />
            </Grid>
            <Grid item xs={4}>
              <TextField
                label="Age"
                name="age"
                type="number"
                value={formData.passengerList[0].age}
                onChange={handlePassengerChange}
                fullWidth
              />
            </Grid>
            <Grid item xs={4}>
              <TextField
                label="Gender"
                name="gender"
                value={formData.passengerList[0].gender}
                onChange={handlePassengerChange}
                select
                fullWidth
              >
                <MenuItem value="Male">Male</MenuItem>
                <MenuItem value="Female">Female</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </TextField>
            </Grid>
          </Grid>
          <Box mt={4}>
            <Button type="submit" variant="contained" color="primary" fullWidth>
              Pay & Book
            </Button>
          </Box>
        </form>

        {status === "failed" && error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            ❌ {error}
          </Alert>
        )}
      </Paper>
    </Container>
  );
};

export default Form;
