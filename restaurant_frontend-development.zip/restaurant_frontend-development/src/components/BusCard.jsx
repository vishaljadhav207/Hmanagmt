import React, { useState } from "react";
import { FaBusAlt, FaChair } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { format, parseISO, differenceInMinutes, isValid } from "date-fns";

const calculateDuration = (departureDateTime, arrivalDateTime) => {
  if (!departureDateTime || !arrivalDateTime) return "N/A";

  const departureDate = parseISO(departureDateTime);
  const arrivalDate = parseISO(arrivalDateTime);

  if (!isValid(departureDate)) return "N/A";

  const totalMinutes = differenceInMinutes(arrivalDate, departureDate);
  const hours = Math.floor(Math.abs(totalMinutes) / 60);
  const minutes = Math.abs(totalMinutes) % 60;
  return `${hours}h ${minutes}m`;
};

const BusCard = ({
  bus,
  onToggleSeats,
  isExpanded,
  seats,
  seatsStatus,
  seatsError,
  classId,
}) => {
  const navigate = useNavigate();
  const [selectedSeats, setSelectedSeats] = useState([]);
  console.log();

  const handleBookNow = () => {
    if (selectedSeats.length === 0) {
      alert("Please select at least one seat");
      return;
    }

    navigate("/bus-booking", {
      state: {
        busTripId: bus.busTripId,
        selectedSeats: selectedSeats,
        classId: classId,
        fare: getFareForClass(classId),
      },
    });
  };

  const handleSeatSelection = (seatNumber) => {
    setSelectedSeats((prev) => {
      if (prev.includes(seatNumber)) {
        return prev.filter((s) => s !== seatNumber);
      } else {
        return [...prev, seatNumber];
      }
    });
  };

  const getFareForClass = (classId) => {
    const classType = bus.classTypes.find((cls) => cls.classId === classId);
    return classType ? classType.fare : "N/A";
  };

  const departureDate = bus?.departureDateTime
    ? parseISO(bus.departureDateTime)
    : null;
  const arrivalDate = bus?.arrivalDateTime
    ? parseISO(bus.arrivalDateTime)
    : null;

  const formattedBus = {
    busTripId: bus.busTripId,
    busId: bus.bus?.busId,
    operator: bus.bus?.operatorName || "Unknown Operator",
    busType: bus.bus?.busType || "Standard",
    busNo: bus.bus?.busNo || "",
    departureCity: bus.origin,
    arrivalCity: bus.destination,
    departureTime: isValid(departureDate)
      ? format(departureDate, "HH:mm")
      : "N/A",
    arrivalTime: isValid(arrivalDate) ? format(arrivalDate, "HH:mm") : "N/A",
    departureDate: isValid(departureDate)
      ? format(departureDate, "dd MMM, EEE")
      : "N/A",
    duration: calculateDuration(bus.departureDateTime, bus.arrivalDateTime),
    fare: getFareForClass(classId),
    amenities: bus.bus?.amenities || [],
  };

  const renderAmenities = () => {
    if (!formattedBus.amenities || formattedBus.amenities.length === 0)
      return null;

    return (
      <div className="flex flex-wrap gap-2 mt-2">
        {formattedBus.amenities.map((amenity, index) => (
          <span
            key={index}
            className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-600"
          >
            {amenity}
          </span>
        ))}
      </div>
    );
  };

  const renderSeatLayout = () => {
    if (!isExpanded) return null;

    if (seatsStatus === "loading") {
      return (
        <div className="text-center py-4 animate-pulse">
          Loading seat information...
        </div>
      );
    }

    if (seatsStatus === "failed") {
      return (
        <div className="text-center py-4 text-red-500">
          {seatsError || "Failed to load seat information"}
        </div>
      );
    }

    if (!seats || !seats.layout || !seats.layout.seatMap) {
      return (
        <div className="text-center py-4 text-gray-500">
          No seat information available
        </div>
      );
    }

    // Group seats by row
    const seatsByRow = {};
    seats.layout.seatMap.forEach((seat) => {
      const rowNumber = seat.seatNumber.match(/^\d+/)?.[0] || "0";
      if (!seatsByRow[rowNumber]) {
        seatsByRow[rowNumber] = [];
      }
      seatsByRow[rowNumber].push(seat);
    });

    return (
      <div className="mt-4 border-t pt-4">
        <h4 className="font-medium mb-3">Seat Layout - {seats.className}</h4>
        <div className="space-y-4">
          {Object.entries(seatsByRow).map(([row, rowSeats]) => (
            <div key={row} className="flex flex-col items-center">
              <div className="text-xs text-gray-500 mb-1">Row {row}</div>
              <div className="flex gap-2">
                {rowSeats.map((seat) => (
                  <div
                    key={seat.seatNumber}
                    className={`w-10 h-10 flex flex-col items-center justify-center rounded border 
                      ${
                        !seat.available
                          ? "bg-red-50 border-red-200 text-red-800 cursor-not-allowed"
                          : selectedSeats.includes(seat.seatNumber)
                          ? "bg-blue-100 border-blue-300 text-blue-800"
                          : "bg-green-50 border-green-200 text-green-800 hover:bg-green-100 cursor-pointer"
                      }`}
                    onClick={() =>
                      seat.available && handleSeatSelection(seat.seatNumber)
                    }
                    title={`Seat ${seat.seatNumber} - ${seat.type} - ${
                      seat.available ? "Available" : "Booked"
                    }`}
                  >
                    <FaChair className="text-sm" />
                    <span className="text-xs mt-1">
                      {seat.seatNumber.split("-")[0]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {selectedSeats.length > 0 && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <h5 className="font-medium text-blue-800">Selected Seats:</h5>
            <div className="flex flex-wrap gap-2 mt-2">
              {selectedSeats.map((seat, index) => (
                <span
                  key={index}
                  className="bg-blue-100 text-blue-800 px-2 py-1 rounded"
                >
                  {seat}
                </span>
              ))}
            </div>
            <div className="mt-2 font-medium">
              Total Fare: ₹{formattedBus.fare * selectedSeats.length}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bus-card bg-white rounded-xl shadow-sm hover:shadow-md border border-gray-100 overflow-hidden transition-all duration-200 hover:border-purple-200 mb-4 w-full">
      <div className="flex flex-col md:flex-row">
        {/* Left Section - Bus Info */}
        <div className="md:w-1/4 p-4 bg-purple-50 flex flex-col justify-between">
          <div>
            <div className="flex justify-center items-center mt-5 mb-3">
              <div className="bg-white p-2 rounded-lg shadow mr-3">
                <FaBusAlt className="text-[#5A2360] text-xl" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-800">
                  {formattedBus.operator}
                </h3>
                <p className="text-xs text-gray-500">
                  {formattedBus.busType} | {formattedBus.busNo}
                </p>
              </div>
            </div>
            <div className="flex flex-col space-y-1">
              <div className="text-xs bg-white px-2 py-1 rounded-full border border-gray-200 text-[#5A2360] font-medium inline-block">
                Duration: {formattedBus.duration}
              </div>
              <div className="text-xs bg-white px-2 py-1 rounded-full border border-gray-200 text-[#5A2360] font-medium inline-block">
                Fare: ₹{formattedBus.fare}
              </div>
            </div>
            {renderAmenities()}
          </div>
        </div>

        {/* Middle Section - Route Info */}
        <div className="md:w-2/4 p-4 border-t md:border-t-0 md:border-r border-gray-100">
          <div className="flex justify-between items-center h-full">
            <div className="text-left">
              <div className="text-2xl font-bold text-gray-900">
                {formattedBus.departureTime}
              </div>
              <div className="text-sm font-medium text-gray-600">
                {formattedBus.departureCity}
              </div>
              <div className="text-xs text-gray-400 mt-1">
                {formattedBus.departureDate}
              </div>
            </div>

            <div className="text-center mx-4">
              <div className="bg-purple-100 text-[#5A2360] px-3 py-1 rounded-full text-xs">
                {formattedBus.duration}
              </div>
            </div>

            <div className="text-right">
              <div className="text-2xl font-bold text-gray-900">
                {formattedBus.arrivalTime}
              </div>
              <div className="text-sm font-medium text-gray-600">
                {formattedBus.arrivalCity}
              </div>
            </div>
          </div>
          {renderSeatLayout()}
        </div>

        {/* Right Section - Actions */}
        <div className="md:w-1/4 p-4 bg-gray-50 flex flex-col justify-center">
          <div className="flex flex-col space-y-2">
            <button
              className="text-sm bg-[#5A2360] hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
              onClick={handleBookNow}
            >
              Book Now
            </button>
            <button
              className="text-sm bg-white border border-[#5A2360] text-[#5A2360] px-4 py-2 rounded-lg font-medium transition-colors"
              onClick={onToggleSeats}
            >
              {isExpanded ? "Hide Seats" : "View Seats"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusCard;
