import React from "react";

const PriceSummary = ({
  basePrice,
  taxes,
  mealPrice,
  tripProtection,
  totalPrice,
  duration = 1
}) => (
  <div className="price-summary mb-8 p-6 bg-white rounded-xl shadow-md border border-gray-100">
    <h3 className="text-2xl font-semibold mb-6 text-gray-800 border-b pb-2">
      Price Summary
    </h3>
    <div className="space-y-3 mb-4">
      <div className="flex justify-between">
        <span className="text-gray-600">Base Price ({duration} Night{duration > 1 ? 's' : ''})</span>
        <span className="font-medium">₹{basePrice.toLocaleString()}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-600">Taxes & Fees</span>
        <span className="font-medium">₹{taxes.toLocaleString()}</span>
      </div>
      {mealPrice > 0 && (
        <div className="flex justify-between">
          <span className="text-gray-600">Meal Add-ons</span>
          <span className="font-medium">₹{mealPrice.toLocaleString()}</span>
        </div>
      )}
      {tripProtection > 0 && (
        <div className="flex justify-between">
          <span className="text-gray-600">Trip Protection</span>
          <span className="font-medium">
            ₹{tripProtection.toLocaleString()}
          </span>
        </div>
      )}
    </div>
    <div className="border-t pt-4">
      <div className="flex justify-between text-lg font-bold">
        <span>Total Amount</span>
        <span className="text-blue-600">₹{totalPrice.toLocaleString()}</span>
      </div>
      <p className="text-sm text-gray-500 mt-2">Inclusive of all taxes</p>
    </div>
  </div>
);

export default PriceSummary;
