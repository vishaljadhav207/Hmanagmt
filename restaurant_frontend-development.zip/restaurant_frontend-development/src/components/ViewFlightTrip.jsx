import {
  Modal,
  Box,
  Typography,
  IconButton,
  Grid,
  Card,
  CardContent,
  Divider,
  List,
  ListItem,
  ListItemText,
  Stack,
  Chip
} from '@mui/material';
import { Close as CloseIcon } from '@mui/icons-material';

const modalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '80%',
  maxWidth: 900,
  maxHeight: '90vh',
  overflowY: 'auto',
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
  borderRadius: 2
};

const ViewFlightTrip = ({ open, onClose, selectedFlight }) => {
  if (!selectedFlight) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="flight-details-modal"
      aria-describedby="flight-details-description"
    >
      <Box sx={modalStyle}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h5" component="h2">
            Flight Trip Details
          </Typography>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box>

        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Flight Information
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Trip ID:</Typography>
                    <Typography>{selectedFlight.flightTripId}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Flight No:</Typography>
                    <Typography>{selectedFlight.flight?.flight_no}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Airline:</Typography>
                    <Typography>{selectedFlight.flight?.airline}</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Departure:</Typography>
                    <Typography>
                      {new Date(selectedFlight.departureDate).toLocaleDateString()}
                      <br />
                      <Typography variant="caption">
                        {new Date(selectedFlight.departureDate).toLocaleTimeString()}
                      </Typography>
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Arrival:</Typography>
                    <Typography>
                      {new Date(selectedFlight.arrivalDate).toLocaleDateString()}
                      <br />
                      <Typography variant="caption">
                        {new Date(selectedFlight.arrivalDate).toLocaleTimeString()}
                      </Typography>
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="subtitle2">Route:</Typography>
                    <Stack direction="row" alignItems="center" spacing={1}>
                      <Chip label={selectedFlight.origin} size="small" color="primary" />
                      <Typography variant="caption">→</Typography>
                      <Chip label={selectedFlight.destination} size="small" color="secondary" />
                    </Stack>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Organization Details
                </Typography>
                <Divider sx={{ mb: 2 }} />
                {selectedFlight.flight?.organization ? (
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2">Organization ID:</Typography>
                      <Typography>{selectedFlight.flight.organization.orgId}</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2">Type:</Typography>
                      <Typography>{selectedFlight.flight.organization.type}</Typography>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography variant="subtitle2">Name:</Typography>
                      <Typography>{selectedFlight.flight.organization.orgName}</Typography>
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="subtitle2">User ID:</Typography>
                      <Typography>{selectedFlight.flight.organization.userId}</Typography>
                    </Grid>
                  </Grid>
                ) : (
                  <Typography>No organization information available</Typography>
                )}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Intermediate Stops
                </Typography>
                <Divider sx={{ mb: 2 }} />
                {selectedFlight.intermediateStops?.length > 0 ? (
                  <List dense>
                    {selectedFlight.intermediateStops.map((stop, index) => (
                      <ListItem key={index} divider>
                        <ListItemText
                          primary={`Stop ${index + 1}: ${stop.stopName}`}
                          secondary={
                            <>
                              <Typography component="span" variant="body2">
                                Arrival: {new Date(stop.arrivalTime).toLocaleString()}
                              </Typography>
                              <br />
                              <Typography component="span" variant="body2">
                                Departure: {new Date(stop.departureTime).toLocaleString()}
                              </Typography>
                            </>
                          }
                        />
                      </ListItem>
                    ))}
                  </List>
                ) : (
                  <Typography>No intermediate stops</Typography>
                )}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Class Types
                </Typography>
                <Divider sx={{ mb: 2 }} />
                {selectedFlight?.flight?.classTypes?.length > 0 ? (
                  <List dense>
                    {selectedFlight?.flight?.classTypes.map((classType, index) => (
                      <ListItem key={index} divider>
                        <ListItemText
                          primary={`${classType.className} Class`}
                          secondary={
                            <>
                              
                              <br />
                              <Typography component="span" variant="body2">
                                Fare: {classType.fare.toFixed(2)}
                              </Typography>
                            </>
                          }
                        />
                      </ListItem>
                    ))}
                  </List>
                ) : (
                  <Typography>No class information available</Typography>
                )}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </Modal>
  );
};

export default ViewFlightTrip;