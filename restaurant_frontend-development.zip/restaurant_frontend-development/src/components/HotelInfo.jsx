import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getRooms } from "../redux/roomSlice";
import axiosInstance from "../app/axiosInstance";

const HotelInfo = ({ hotelId, hotelName, hotelAdd, selectedCity }) => {
  const dispatch = useDispatch();
  const { rooms, status, error } = useSelector((state) => state.rooms);
  const [imageUrl, setImageUrl] = useState("");

  useEffect(() => {
    if (hotelId) {
      dispatch(getRooms(hotelId));
      fetchImage(hotelId);
    }
  }, [dispatch, hotelId]);

  const fetchImage = async (hotelId) => {
    try {
     
      const response = await axiosInstance.get(`images/getImageById/${hotelId}`, {
        responseType: "blob",
      });
  
      
      const imageUrl = URL.createObjectURL(response.data);
      console.log("Fetched Image URL:", imageUrl); 
  
      setImageUrl(imageUrl);
    } catch (error) {
      console.error("Error fetching image:", error);
      setImageUrl("/placeholder-image.jpg"); 
    }
  };

  if (status === "loading") return <div>Loading hotel details...</div>;
  if (status === "failed") return <div>Error: {error}</div>;

  return (
    <div className="hotel-info mb-8 bg-white rounded-xl shadow-lg relative border border-gray-100 overflow-hidden">
      {imageUrl && (
        <div className="w-full h-64 overflow-hidden">
          <img
            src={imageUrl}
            alt="Hotel"
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = "/placeholder-image.jpg";
            }}
          />
        </div>
      )}
      <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="text-center">
          <h1 className="hotel-name text-3xl font-bold mb-2 text-gray-800">
            {hotelName || rooms[0]?.hotel?.name || "Hotel Regent Laguna"}
          </h1>
          <p className="text-gray-600 mb-1">{selectedCity || hotelAdd}</p>
        </div>
      </div>
    </div>
  );
};

export default HotelInfo;
