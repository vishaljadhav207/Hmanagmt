import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getTrainTripsByUserId, deleteTrain, updateTrainTrip } from "../app/traintripApi";
 
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  IconButton,
  Typography,
  Box,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  Chip,
  Grid,
  List,
  ListItem,
  ListItemText,
  Stack,
  Snackbar,
  Alert,
  CircularProgress,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete
} from "@mui/material";
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
  Add as AddIcon,
  Train as TrainIcon,
  LocationOn as LocationIcon,
  Class as ClassIcon,
  Business as OrganizationIcon,
} from "@mui/icons-material";
import { GridCloseIcon } from "@mui/x-data-grid";
import AddTrainTripForm from "./AddTrainTripForm";
import { trainTripState } from "../redux/trainTripSlice";
import Swal from 'sweetalert2';
 
const formatDateForInput = (dateStr) => {
  if (!dateStr) return '';
  return dateStr.slice(0, 16);
};
 
const TrainTripList = () => {
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;
  const { trainTripsByUserId, status, error } = useSelector(trainTripState);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [tripToDelete, setTripToDelete] = useState(null);
  const [tripToEdit, setTripToEdit] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });
 
 
  const [stations] = useState([
    { id: 1, name: 'Mumbai Central' },
    { id: 2, name: 'Delhi Junction' },
 
  ]);
 
  useEffect(() => {
    if (userId) {
      dispatch(getTrainTripsByUserId(userId));
    }
  }, [dispatch, userId]);
 
  const handleAction = (action, trip) => {
    if (action === "view") {
      setSelectedTrip(trip);
      setOpenDialog(true);
    } else if (action === "delete") {
      setTripToDelete(trip);
      setDeleteConfirmOpen(true);
    } else if (action === "edit") {
 
      setTripToEdit({
        ...trip,
        departureDate: formatDateForInput(trip.departureDate),
        arrivalDate: formatDateForInput(trip.arrivalDate),
        classTypes: trip.classTypes ? trip.classTypes.map(ct => ({ ...ct })) : []
      });
      setEditModalOpen(true);
    }
  };
 
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedTrip(null);
  };
 
  const handleEditModalClose = () => {
    setEditModalOpen(false);
    setTripToEdit(null);
  };
 
  const handleDelete = async () => {
    try {
      await dispatch(deleteTrain(tripToDelete.trainTripId)).unwrap();
      setSnackbar({
        open: true,
        message: "Train trip deleted successfully",
        severity: "success",
      });
      dispatch(getTrainTripsByUserId(userId));
        Swal.fire({
      icon: 'success',
      title: 'Deleted!',
      text: 'Train trip deleted successfully.',
      timer: 2000,
      showConfirmButton: false
    });
    } catch (error) {
      setSnackbar({
        open: true,
        message: error?.message || "Failed to delete train trip",
        severity: "error",
      });
    } finally {
      setDeleteConfirmOpen(false);
      setTripToDelete(null);
    }
  };
 
  const handleUpdate = async (e) => {
    e.preventDefault();
 
 
    const intermediateStops = (tripToEdit.intermediateStops || []).map(stop => ({
      ...stop,
      arrivalTime: stop.arrivalTime.length <= 5
        ? new Date(`${tripToEdit.departureDate.slice(0, 10)}T${stop.arrivalTime}`).toISOString()
        : stop.arrivalTime,
      departureTime: stop.departureTime.length <= 5
        ? new Date(`${tripToEdit.departureDate.slice(0, 10)}T${stop.departureTime}`).toISOString()
        : stop.departureTime,
    }));
 
    const train = { train_id: tripToEdit.train?.train_id };
 
 
    const classTypes = (tripToEdit.classTypes || []).map(ct => ({
      classId: ct.classId
    }));
 
    const payload = {
      origin: tripToEdit.origin,
      destination: tripToEdit.destination,
      departureDate: tripToEdit.departureDate ? new Date(tripToEdit.departureDate).toISOString() : null,
      arrivalDate: tripToEdit.arrivalDate ? new Date(tripToEdit.arrivalDate).toISOString() : null,
      train,
      intermediateStops,
      classTypes,
    };
 
    try {
      await dispatch(updateTrainTrip({
        trainTripId: tripToEdit.trainTripId,
        updatedData: payload
      })).unwrap();
 
      dispatch(getTrainTripsByUserId(userId));
      setEditModalOpen(false);
      setTripToEdit(null);
        Swal.fire({
      icon: 'success',
      title: 'Updated!',
      text: 'Train trip updated successfully.',
      timer: 2000,
      showConfirmButton: false
    });
    } catch (error) {
      setSnackbar({
        open: true,
        message: error?.message || "Failed to update train trip",
        severity: "error",
      });
    }
  };
 
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTripToEdit(prev => ({
      ...prev,
      [name]: value
    }));
  };
 
  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };
 
 
 
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 3 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Train Trips
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => setAddModalOpen(true)}
        >
          Add Trip
        </Button>
 
 
        <AddTrainTripForm
          open={addModalOpen}
          onClose={() => {
            setAddModalOpen(false);
          }}
          userId={userId}
          onSuccess={() => {
            setSnackbar({
              open: true,
              message: "Train trip added successfully",
              severity: "success"
            });
          }}
        />
 
      </Box>
 
      {status === "loading" && !trainTripsByUserId?.length ? (
        <Box display="flex" justifyContent="center" my={4}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      ) : (
        <TableContainer component={Paper} elevation={3}>
          <Table sx={{ minWidth: 650 }} aria-label={"train trips table"}>
            <TableHead sx={{ backgroundColor: "primary.main" }}>
 
              <TableRow>
                <TableCell sx={{ color: "white" }}>Train Trip ID</TableCell>
                <TableCell sx={{ color: "white" }}>Departure</TableCell>
                <TableCell sx={{ color: "white" }}>Destination</TableCell>
                <TableCell sx={{ color: "white" }}>Departure Date</TableCell>
                <TableCell sx={{ color: "white" }}>Arrival Date</TableCell>
                <TableCell sx={{ color: "white" }}>Train No</TableCell>
                <TableCell sx={{ color: "white" }}>Train Name</TableCell>
                <TableCell sx={{ color: "white" }} align="center">
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {trainTripsByUserId?.map((trip) => (
 
                <TableRow
                  key={trip.trainTripId}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell>{trip.trainTripId}</TableCell>
 
                  <TableCell>{trip.origin}</TableCell>
                  <TableCell>{trip.destination}</TableCell>
                  <TableCell>{trip.departureDate}</TableCell>
                  <TableCell>{trip.arrivalDate}</TableCell>
                  <TableCell>{trip.train?.trainNo}</TableCell>
                  <TableCell>{trip.train?.trainName}</TableCell>
                  <TableCell align="center">
                    <IconButton
                      color="info"
                      onClick={() => handleAction("view", trip)}
                    >
                      <VisibilityIcon />
                    </IconButton>
                    <IconButton
                      color="warning"
                      onClick={() => handleAction("edit", trip)}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      color="error"
                      onClick={() => handleAction("delete", trip)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
 
      {trainTripsByUserId?.length === 0 && status !== "loading" && (
        <Typography variant="body1" align="center" sx={{ mt: 3 }}>
          No train trips found. Add a new trip to get started.
        </Typography>
      )}
 
      {/* Edit Train Trip Modal */}
      <Dialog
        open={editModalOpen}
        onClose={handleEditModalClose}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: 'primary.main',
          color: 'white',
          pr: 2
        }}>
          <Box display="flex" alignItems="center">
            <TrainIcon sx={{ mr: 1, color: 'white' }} />
            <Typography variant="h6">
              Edit Train Trip {tripToEdit?.trainTripId}
            </Typography>
          </Box>
          <IconButton onClick={handleEditModalClose} sx={{ color: 'white' }}>
            <GridCloseIcon />
          </IconButton>
        </DialogTitle>
 
        <DialogContent dividers sx={{ pt: 2 }}>
          {tripToEdit && (
            <Box component="form" onSubmit={handleUpdate}>
              <Grid container spacing={3}>
 
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Origin Station"
                    name="origin"
                    value={formatDateForInput(tripToEdit.origin)}
                    onChange={handleInputChange}
                    sx={{ mb: 3 }}
                  />
                </Grid>
 
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Destination Station"
                    name="destination"
                    value={formatDateForInput(tripToEdit.destination)}
                    onChange={handleInputChange}
                    sx={{ mb: 3 }}
                  />
                </Grid>
 
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Departure Date"
                    type="date"
                    name="departureDate"
                    value={formatDateForInput(tripToEdit.departureDate)}
                    onChange={handleInputChange}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    inputProps={{
                      min: new Date().toISOString().split("T")[0],
                    }}
                    sx={{ mb: 3 }}
                    required
                  />
                </Grid>
 
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Arrival Date"
                    type="date"
                    name="arrivalDate"
                    value={formatDateForInput(tripToEdit.arrivalDate)}
                    onChange={handleInputChange}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    inputProps={{
                      min: new Date().toISOString().split("T")[0],
                    }}
                    sx={{ mb: 3 }}
                    required
                  />
                </Grid>
 
              </Grid>
              {/* Intermediate Stops Section */}
              <Typography variant="h6" sx={{ mb: 2 }}>
                Stops
              </Typography>
              {(tripToEdit.intermediateStops || []).map((stop, idx) => (
                <Box key={idx} sx={{ mb: 2, p: 2, border: '1px solid #eee', borderRadius: 1 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Stop Name"
                        value={stop.stopName}
                        onChange={e => {
                          const newStops = tripToEdit.intermediateStops.map((s, i) =>
                            i === idx ? { ...s, stopName: e.target.value } : s
                          );
                          setTripToEdit(prev => ({ ...prev, intermediateStops: newStops }));
                        }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Arrival Time"
                        type="datetime-local"
                        value={formatDateForInput(stop.arrivalTime)}
                        onChange={(e) => {
                          const newStops = tripToEdit.intermediateStops.map((s, i) =>
                            i === idx ? { ...s, arrivalTime: e.target.value } : s
                          );
                          setTripToEdit((prev) => ({ ...prev, intermediateStops: newStops }));
                        }}
                        InputLabelProps={{ shrink: true }}
                        inputProps={{
                          min: new Date().toISOString().slice(0, 16),
                        }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Departure Time"
                        type="datetime-local"
                        value={formatDateForInput(stop.departureTime)}
                        onChange={e => {
                          const newStops = tripToEdit.intermediateStops.map((s, i) =>
                            i === idx ? { ...s, departureTime: e.target.value } : s
                          );
                          setTripToEdit(prev => ({ ...prev, intermediateStops: newStops }));
                        }}
                        InputLabelProps={{ shrink: true }}
                          inputProps={{
                          min: new Date().toISOString().slice(0, 16),
                        }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={3}>
                      <TextField
                        fullWidth
                        label="Distance from Previous (km)"
                        type="number"
                        value={stop.distanceFromPrevious ?? ''}
                        onChange={e => {
                          const newStops = tripToEdit.intermediateStops.map((s, i) =>
                            i === idx ? { ...s, distanceFromPrevious: e.target.value } : s
                          );
                          setTripToEdit(prev => ({ ...prev, intermediateStops: newStops }));
                        }}
                        InputLabelProps={{ shrink: true }}
                        required
                      />
 
                    </Grid>
                    <Grid item xs={12} md={1} sx={{ display: 'flex', alignItems: 'center' }}>
                      <Button
                        color="error"
                        onClick={() => {
                          const newStops = tripToEdit.intermediateStops.filter((_, i) => i !== idx);
                          setTripToEdit(prev => ({ ...prev, intermediateStops: newStops }));
                        }}
                      >
                        Remove
                      </Button>
                    </Grid>
                  </Grid>
 
                </Box>
              ))}
              <Button
                variant="outlined"
                onClick={() => {
                  setTripToEdit(prev => ({
                    ...prev,
                    intermediateStops: [
                      ...(prev.intermediateStops || []),
                      {
                        stopName: '',
                        arrivalTime: new Date().toISOString().slice(0, 16),
                        departureTime: new Date().toISOString().slice(0, 16)
                      }
                    ]
                  }));
                }}
                sx={{ mb: 2 }}
              >
                Add Stop
              </Button>
              <DialogActions sx={{ mt: 2 }}>
                <Button
                  onClick={handleEditModalClose}
                  color="secondary"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={status === "loading"}
                  startIcon={status === "loading" ? <CircularProgress size={20} /> : null}
                >
                  {status === "loading" ? "Updating..." : "Update Trip"}
                </Button>
              </DialogActions>
            </Box>
          )}
        </DialogContent>
      </Dialog>
 
 
      {/* View Trip Details Dialog */}
      <Dialog
        open={openDialog}
        onClose={handleCloseDialog}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            height: '90vh',
            maxHeight: '900px',
            overflow: 'hidden'
          }
        }}
      >
        {selectedTrip && (
          <>
            <DialogTitle sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              backgroundColor: 'primary.main',
              color: 'white',
              pr: 2
            }}>
              <Box display="flex" alignItems="center">
                <TrainIcon sx={{ mr: 1, color: 'white' }} />
                <Typography variant="h6">
                  {selectedTrip.train?.trainName} (Train No:{" "}
                  {selectedTrip.train?.trainNo})
                </Typography>
              </Box>
              <IconButton onClick={handleCloseDialog} sx={{ color: 'white' }}>
                <GridCloseIcon />
              </IconButton>
            </DialogTitle>
 
            <DialogContent dividers sx={{ overflow: 'hidden' }}>
              <Box sx={{
                height: '100%',
                overflowY: 'auto',
                pr: 1,
                '&::-webkit-scrollbar': {
                  width: '6px',
                },
                '&::-webkit-scrollbar-thumb': {
                  backgroundColor: 'primary.main',
                  borderRadius: '3px',
                }
              }}>
                <Grid container spacing={2} sx={{ p: 2 }}>
                  {/* Route Information */}
                  <Grid item xs={12} md={4}>
                    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
                      <Typography variant="h6" gutterBottom sx={{
                        display: 'flex',
                        alignItems: 'center',
                        color: 'primary.main'
                      }}>
                        <LocationIcon sx={{ mr: 1 }} />
                        Route Information
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      <Stack spacing={2}>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Origin
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.origin}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Destination
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.destination}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Departure Date
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.departureDate}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Arrival Date
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.arrivalDate}
                          </Typography>
                        </Box>
                      </Stack>
                    </Paper>
                  </Grid>
 
                  {/* Train Information */}
                  <Grid item xs={12} md={4}>
                    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
                      <Typography variant="h6" gutterBottom sx={{
                        display: 'flex',
                        alignItems: 'center',
                        color: 'primary.main'
                      }}>
                        <TrainIcon sx={{ mr: 1 }} />
                        Train Details
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      <Stack spacing={2}>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Train ID
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.train_id}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Railway Zone
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.railwayZone}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Number of Coaches
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.numberOfCoaches}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Departure From
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.departFrom}
                          </Typography>
                        </Box>
                      </Stack>
                    </Paper>
                  </Grid>
 
                  {/* Organization Information */}
                  <Grid item xs={12} md={4}>
                    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
                      <Typography variant="h6" gutterBottom sx={{
                        display: 'flex',
                        alignItems: 'center',
                        color: 'primary.main'
                      }}>
                        <OrganizationIcon sx={{ mr: 1 }} />
                        Organization
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      <Stack spacing={2}>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Organization Name
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.organization?.orgName}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Organization Type
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.organization?.type}
                          </Typography>
                        </Box>
                        <Box>
                          <Typography variant="subtitle2" color="text.secondary">
                            Organization ID
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedTrip.train?.organization?.orgId}
                          </Typography>
                        </Box>
                      </Stack>
                    </Paper>
                  </Grid>
 
                  {/* Intermediate Stops */}
                  <Grid item xs={12} md={6}>
                    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
                      <Typography variant="h6" gutterBottom sx={{
                        display: 'flex',
                        alignItems: 'center',
                        color: 'primary.main'
                      }}>
                        <LocationIcon sx={{ mr: 1 }} />
                        Intermediate Stops
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      {selectedTrip.intermediateStops?.length > 0 ? (
                        <List dense sx={{ maxHeight: 200, overflow: 'auto' }}>
                          {selectedTrip.intermediateStops.map((stop, index) => (
                            <ListItem key={index} sx={{ px: 0 }}>
                              <ListItemText
                                primary={
                                  <Typography sx={{ fontWeight: 500 }}>
                                    {index + 1}. {stop.stopName}
                                  </Typography>
                                }
                                secondary={
                                  <Box component="span" sx={{ display: 'block' }}>
                                    <Typography
                                      component="span"
                                      variant="body2"
                                      color="text.secondary"
                                      display="block"
                                    >
                                      Arrival: {stop.arrivalTime}
                                    </Typography>
                                    <Typography
                                      component="span"
                                      variant="body2"
                                      color="text.secondary"
                                      display="block"
                                    >
                                      Departure: {stop.departureTime}
                                    </Typography>
                                  </Box>
                                }
                              />
                            </ListItem>
                          ))}
                        </List>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          No intermediate stops
                        </Typography>
                      )}
                    </Paper>
                  </Grid>
 
                  {/* Class Types */}
                  <Grid item xs={12} md={6}>
                    <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
                      <Typography variant="h6" gutterBottom sx={{
                        display: 'flex',
                        alignItems: 'center',
                        color: 'primary.main'
                      }}>
                        <ClassIcon sx={{ mr: 1 }} />
                        Available Classes
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      {selectedTrip.train?.classTypes?.length > 0 ? (
                        <Box sx={{
                          display: 'grid',
                          gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
                          gap: 2
                        }}>
                          {selectedTrip.train?.classTypes.map((classType, index) => (
                            <Paper key={index} elevation={2} sx={{ p: 2 }}>
                              <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                                {classType.className}
                              </Typography>
                              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                                <Box>
                                  <Typography variant="caption" color="text.secondary">
                                    Availability
                                  </Typography>
                                  <Typography variant="body2">
                                    {classType.availability}
                                  </Typography>
                                </Box>
                                <Box>
                                  <Typography variant="caption" color="text.secondary">
                                    Fare
                                  </Typography>
                                  <Typography variant="body2">
                                    ₹{classType.fare}
                                  </Typography>
                                </Box>
 
                              </Box>
                            </Paper>
                          ))}
                        </Box>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          No class information available
                        </Typography>
                      )}
                    </Paper>
                  </Grid>
                </Grid>
              </Box>
            </DialogContent>
          </>
        )}
      </Dialog>
 
 
 
      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteConfirmOpen}
        onClose={() => setDeleteConfirmOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            Are you sure you want to delete this train trip? This action cannot be undone.
          </Typography>
          {tripToDelete && (
            <Box sx={{ mt: 2, p: 2, backgroundColor: 'background.default', borderRadius: 1 }}>
              <Typography variant="subtitle2">Trip Details:</Typography>
              <Typography variant="body2">
                Train No: {tripToDelete.train?.trainNo} ({tripToDelete.origin} to {tripToDelete.destination})
              </Typography>
              <Typography variant="body2">
                Departure: {tripToDelete.departureDate}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setDeleteConfirmOpen(false)}
            disabled={status === "loading"}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDelete}
            color="error"
            variant="contained"
            disabled={status === "loading"}
            startIcon={status === "loading" ? <CircularProgress size={20} /> : null}
          >
            {status === "loading" ? "Deleting..." : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>
 
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};
 
export default TrainTripList;
 