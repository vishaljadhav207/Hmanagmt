import React, { useState } from 'react';

const ClassFilter = ({ onFilterChange }) => {
  const [selectedClasses, setSelectedClasses] = useState([]);

  const classOptions = [
    { id: '1A', name: '1st Class AC - 1A', count: 36 },
    { id: '2A', name: '2nd Class AC - 2A', count: 43 },
    { id: '3A', name: '3rd Class AC - 3A', count: 47 },
    { id: 'SL', name: 'Sleeper - SL', count: 42 },
    { id: '2S', name: 'Second Sitting - 2S', count: 2 },
  
  ];

  const handleCheckboxChange = (classId) => {
    const newSelectedClasses = selectedClasses.includes(classId)
      ? selectedClasses.filter(id => id !== classId)
      : [...selectedClasses, classId];
    
    setSelectedClasses(newSelectedClasses);
    onFilterChange(newSelectedClasses);
  };

  return (
    <div className="w-full p-4 bg-white border border-gray-200 rounded-lg shadow-sm">
      <h3 className="text-lg font-semibold mb-4">Journey Class Filters</h3>
      <div className="space-y-3">
        {classOptions.map((option) => (
          <div key={option.id} className="flex items-center">
            <label className="flex items-center w-full cursor-pointer">
              <input
                type="checkbox"
                className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                checked={selectedClasses.includes(option.id)}
                onChange={() => handleCheckboxChange(option.id)}
              />
              <span className="ml-2 text-gray-700 flex-grow">{option.name}</span>
              <span className="text-gray-500 text-sm">{option.count}</span>
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ClassFilter;