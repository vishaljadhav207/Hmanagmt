import React, { useEffect, useState } from "react";
import {
  Container,
  TextField,
  Button,
  Typography,
  MenuItem,
  Box,
  Grid,
  Paper,
  Alert,
  CircularProgress,
  Avatar,
  Divider,
  IconButton,
  Card,
  CardContent,
  Chip,
  InputAdornment,
} from "@mui/material";
import {
  Person as PersonIcon,
  DirectionsBus as BusIcon,
  Payment as PaymentIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  LocationOn as LocationOnIcon,
  Event as DateIcon,
  AccessTime as TimeIcon,
} from "@mui/icons-material";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getBusTripById } from "../app/bustripApi";
import Swal from "sweetalert2";
import { format } from "date-fns";

const BusForm = () => {
  const { state } = useLocation();
  const { busTripId, classType, fare } = state || {};
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { selectedBusTrip, status, error } = useSelector(
    (state) => state.bustrip
  );

  const [formData, setFormData] = useState({
    transportType: "BUS_OPERATOR",
    tripId: busTripId,
    classType: classType || "",
    seatPreference: "NO_PREFERENCE",
    boarding: "",
    departure: "",
    journeyDate: "",
    totalFare: fare || 0,
    cancellationFee: 0,
    refundAmount: 0,
    refunded: true,
    passengerList: [{ name: "", age: "", gender: "", seatNumber: "" }],
  });

  useEffect(() => {
    if (busTripId) {
      dispatch(getBusTripById(busTripId));
    }
  }, [dispatch, busTripId]);

  useEffect(() => {
    if (selectedBusTrip) {
      const busClassTypes = selectedBusTrip.bus?.classTypes || [];
      const initialClassType =
        classType ||
        (busClassTypes.length > 0 ? busClassTypes[0].className : "");
      const selectedClass = busClassTypes.find(
        (cls) => cls.className === initialClassType
      );
      const initialFare = selectedClass ? selectedClass.fare : 0;

      setFormData((prev) => ({
        ...prev,
        transportId: selectedBusTrip.bus?.busId,
        journeyDate: selectedBusTrip.departureDate,
        totalFare: initialFare * prev.passengerList.length,
        boarding: selectedBusTrip.origin,
        departure: selectedBusTrip.destination,
        classType: initialClassType,
      }));
    }
  }, [selectedBusTrip, classType]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePassengerChange = (index, e) => {
    const { name, value } = e.target;
    const updatedPassengers = [...formData.passengerList];
    updatedPassengers[index][name] = value;

    setFormData((prev) => ({
      ...prev,
      passengerList: updatedPassengers,
      totalFare:
        updatedPassengers.length * (prev.totalFare / prev.passengerList.length),
    }));
  };

  const handleAddPassenger = () => {
    if (formData.passengerList.length >= 6) {
      Swal.fire({
        title: "Maximum Passengers",
        text: "You can only book for up to 6 passengers at a time",
        icon: "warning",
        confirmButtonColor: "#5A2360",
      });
      return;
    }

    setFormData((prev) => ({
      ...prev,
      passengerList: [
        ...prev.passengerList,
        { name: "", age: "", gender: "", seatNumber: "" },
      ],
      totalFare:
        (prev.totalFare / prev.passengerList.length) *
        (prev.passengerList.length + 1),
    }));
  };

  const handleRemovePassenger = (index) => {
    const updatedList = formData.passengerList.filter((_, i) => i !== index);
    const updatedFare = updatedList.length
      ? (formData.totalFare / formData.passengerList.length) *
        updatedList.length
      : 0;

    setFormData((prev) => ({
      ...prev,
      passengerList: updatedList,
      totalFare: updatedFare,
    }));
  };

  const validatePassengers = () => {
    for (const passenger of formData.passengerList) {
      if (!passenger.name || !passenger.age || !passenger.gender) {
        Swal.fire({
          title: "Incomplete Details",
          text: "Please fill all passenger details before proceeding",
          icon: "error",
          confirmButtonColor: "#5A2360",
        });
        return false;
      }
      if (isNaN(passenger.age)) {
        Swal.fire({
          title: "Invalid Age",
          text: "Please enter a valid age for all passengers",
          icon: "error",
          confirmButtonColor: "#5A2360",
        });
        return false;
      }
    }
    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validatePassengers()) return;

    const bookingData = {
      busTripId: formData.tripId,
      classType: formData.classType,
      fare: formData.totalFare / formData.passengerList.length,
      busData: {
        busId: formData.transportId,
        operatorName: selectedBusTrip?.bus?.operatorName,
        busNo: selectedBusTrip?.bus?.busNo,
        origin: formData.boarding,
        destination: formData.departure,
        departureDate: formData.journeyDate,
        arrivalDate: selectedBusTrip.arrivalDate,
        classId: selectedBusTrip?.bus?.classTypes?.find(
          (cls) => cls.className === formData.classType
        )?.classId,
        stops: [
          { name: selectedBusTrip.origin, time: "00:00" },
          ...(selectedBusTrip.intermediateStops || []).map((stop) => ({
            name: stop.stopName,
            time: stop.arrivalTime,
          })),
          { name: selectedBusTrip.destination, time: "23:59" },
        ],
      },
      passengerDetails: formData.passengerList,
      seatPreference: formData.seatPreference,
    };

    navigate("/book-bus-seat", { state: bookingData });
  };

  if (status === "loading" && !selectedBusTrip) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, textAlign: "center" }}>
        <CircularProgress size={60} />
        <Typography variant="h6" sx={{ mt: 2 }}>
          Loading bus details...
        </Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Card sx={{ mb: 4, borderRadius: 3, boxShadow: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={8}>
              <Box display="flex" alignItems="center" mb={1}>
                <Avatar sx={{ bgcolor: "primary.main", mr: 2 }}>
                  <BusIcon />
                </Avatar>
                <Box>
                  <Typography variant="h6" fontWeight="bold">
                    {selectedBusTrip?.bus?.operatorName} -{" "}
                    {selectedBusTrip?.bus?.busNo}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {selectedBusTrip?.origin} to {selectedBusTrip?.destination}
                  </Typography>
                </Box>
              </Box>
              <Box display="flex" alignItems="center" gap={3}>
                <Box display="flex" alignItems="center">
                  <DateIcon color="primary" fontSize="small" sx={{ mr: 1 }} />
                  <Typography variant="body2">
                    {selectedBusTrip?.departureDate
                      ? format(
                          new Date(selectedBusTrip.departureDate),
                          "dd MMM yyyy"
                        )
                      : ""}
                  </Typography>
                </Box>
                <Box display="flex" alignItems="center">
                  <TimeIcon color="primary" fontSize="small" sx={{ mr: 1 }} />
                  <Typography variant="body2">
                    {selectedBusTrip?.departureDate
                      ? format(
                          new Date(selectedBusTrip.departureDate),
                          "hh:mm a"
                        )
                      : ""}
                  </Typography>
                </Box>
              </Box>
            </Grid>
            <Grid
              item
              xs={12}
              md={4}
              sx={{ textAlign: { xs: "left", md: "right" } }}
            >
              <Typography variant="h5" color="primary">
                ₹{formData.totalFare}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Total for {formData.passengerList.length} passenger(s)
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit}>
        <Box component="form" noValidate sx={{ mt: 2 }}>
          <Typography variant="h6" gutterBottom sx={{ mb: 3 }}>
            Passenger Information
          </Typography>
          {formData.passengerList.map((passenger, index) => (
            <Paper
              key={index}
              elevation={2}
              sx={{
                p: 3,
                mb: 3,
                borderRadius: 2,
                borderLeft: "4px solid #5A2360",
              }}
            >
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                mb={2}
              >
                <Typography variant="subtitle1">
                  Passenger {index + 1}
                </Typography>
                {formData.passengerList.length > 1 && (
                  <IconButton
                    onClick={() => handleRemovePassenger(index)}
                    color="error"
                    size="small"
                  >
                    <DeleteIcon />
                  </IconButton>
                )}
              </Box>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Full Name"
                    name="name"
                    value={passenger.name}
                    onChange={(e) => handlePassengerChange(index, e)}
                    fullWidth
                    required
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <PersonIcon color="action" />
                        </InputAdornment>
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    label="Age"
                    name="age"
                    type="number"
                    value={passenger.age}
                    onChange={(e) => handlePassengerChange(index, e)}
                    fullWidth
                    required
                    inputProps={{ min: 1, max: 100 }}
                  />
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    label="Gender"
                    name="gender"
                    select
                    value={passenger.gender}
                    onChange={(e) => handlePassengerChange(index, e)}
                    fullWidth
                    required
                  >
                    <MenuItem value="Male">Male</MenuItem>
                    <MenuItem value="Female">Female</MenuItem>
                    <MenuItem value="Other">Other</MenuItem>
                  </TextField>
                </Grid>
              </Grid>
            </Paper>
          ))}
          <Box sx={{ mt: 2, textAlign: "center" }}>
            <Button
              onClick={handleAddPassenger}
              startIcon={<AddIcon />}
              variant="outlined"
              color="primary"
              sx={{ borderRadius: 2 }}
            >
              Add Passenger
            </Button>
          </Box>
        </Box>

        <Box sx={{ mt: 3 }}>
          <Typography variant="h6" gutterBottom>
            Seat Preference
          </Typography>
          <TextField
            select
            fullWidth
            label="Preferred Seat Type"
            value={formData.seatPreference}
            onChange={handleChange}
            name="seatPreference"
          >
            <MenuItem value="WINDOW">Window</MenuItem>
            <MenuItem value="AISLE">Aisle</MenuItem>

            <MenuItem value="NO_PREFERENCE">No Preference</MenuItem>
          </TextField>
        </Box>

        <Paper elevation={3} sx={{ p: 3, borderRadius: 2, mt: 4 }}>
          <Typography variant="h6" gutterBottom>
            Fare Summary
          </Typography>
          <Box sx={{ mb: 2 }}>
            <Box display="flex" justifyContent="space-between" mb={1}>
              <Typography variant="body1">Base Fare</Typography>
              <Typography variant="body1">
                ₹
                {(formData.totalFare / formData.passengerList.length).toFixed(
                  2
                )}{" "}
                x {formData.passengerList.length}
              </Typography>
            </Box>
            <Box display="flex" justifyContent="space-between" mb={1}>
              <Typography variant="body1">Taxes & Fees</Typography>
              <Typography variant="body1">₹200.00</Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Box display="flex" justifyContent="space-between">
              <Typography variant="h6">Base Amount</Typography>
              <Typography variant="h6" color="primary">
                ₹{(formData.totalFare + 200).toFixed(2)}
              </Typography>
            </Box>
          </Box>
        </Paper>

        <Box sx={{ mt: 4, textAlign: "right" }}>
          <Button
            type="submit"
            variant="contained"
            startIcon={<PaymentIcon />}
            sx={{
              borderRadius: 2,
              background: "linear-gradient(135deg, #5A2360 0%, #3f51b5 100%)",
              "&:hover": {
                transform: "translateY(-1px)",
                boxShadow: "0 4px 12px rgba(90,35,96,0.3)",
              },
            }}
          >
            Continue to Seat Selection
          </Button>
        </Box>
      </form>

      {status === "failed" && error && (
        <Alert severity="error" sx={{ mt: 3 }}>
          {error}
        </Alert>
      )}
    </Container>
  );
};

export default BusForm;
