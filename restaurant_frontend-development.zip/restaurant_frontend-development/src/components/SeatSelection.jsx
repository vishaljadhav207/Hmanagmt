import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Card,
  CardBody,
  CardHeader,
  Typography,
  Button,
  Chip,
  Tooltip,
  IconButton,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
} from '@material-tailwind/react';
import { FaBus, FaWheelchair, FaInfoCircle } from 'react-icons/fa';

const SeatSelection = () => {
  const [seats, setSeats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const { busId, classId } = useParams();

  useEffect(() => {
    const fetchSeats = async () => {
      try {
        const response = await fetch(
          `http://localhost:8082/api/bus-seats/create-by-id?busId=${busId}&classId=${classId}`
        );
        if (!response.ok) {
          throw new Error('Failed to fetch seats');
        }
        const data = await response.json();
        setSeats(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchSeats();
  }, [busId, classId]);

  const handleSeatSelect = (seat) => {
    if (!seat.isAvailable) return;

    setSelectedSeats((prev) => {
      if (prev.some((s) => s.seatId === seat.seatId)) {
        return prev.filter((s) => s.seatId !== seat.seatId);
      } else {
        return [...prev, seat];
      }
    });
  };

  const handleOpenDialog = () => setOpenDialog(!openDialog);

  if (loading)
    return (
      <div className="flex justify-center items-center h-64">
        <Typography variant="h5" color="blue-gray">
          Loading seat information...
        </Typography>
      </div>
    );

  if (error)
    return (
      <div className="flex justify-center items-center h-64">
        <Typography variant="h5" color="red">
          Error: {error}
        </Typography>
      </div>
    );

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="mb-8">
        <CardHeader
          color="purple"
          floated={false}
          shadow={false}
          className="m-0 p-4"
        >
          <div className="flex items-center justify-between">
            <Typography variant="h4" color="white">
              Select Your Seats
            </Typography>
            <Tooltip content="Seat information">
              <IconButton variant="text" color="white" onClick={handleOpenDialog}>
                <FaInfoCircle className="h-5 w-5" />
              </IconButton>
            </Tooltip>
          </div>
        </CardHeader>
        <CardBody>
          {/* Bus Layout */}
          <div className="bus-layout mb-8">
            {/* Driver Area */}
            <div className="driver-area bg-gray-100 p-4 rounded-lg mb-6 flex items-center justify-center">
              <div className="text-center">
                <FaBus className="h-8 w-8 mx-auto text-gray-600" />
                <Typography variant="small" color="gray">
                  Driver Cabin
                </Typography>
              </div>
            </div>

            {/* Seats Grid */}
            <div className="grid grid-cols-4 md:grid-cols-5 gap-4">
              {seats.map((seat) => (
                <Tooltip key={seat.seatId} content={`Seat ${seat.seatNumber} - ₹${seat.fare}`}>
                  <div
                    onClick={() => handleSeatSelect(seat)}
                    className={`seat p-3 rounded-lg text-center cursor-pointer transition-all duration-300 border
                      ${
                        !seat.isAvailable
                          ? 'bg-red-50 border-red-200 cursor-not-allowed'
                          : selectedSeats.some((s) => s.seatId === seat.seatId)
                          ? 'bg-green-500 border-green-600 text-white'
                          : 'bg-blue-gray-50 border-blue-gray-200 hover:bg-blue-gray-100'
                      }
                      ${seat.isWheelchairAccessible ? 'ring-2 ring-purple-500' : ''}
                    `}
                  >
                    <div className="flex flex-col items-center">
                      <Typography variant="small" className="font-bold">
                        {seat.seatNumber}
                      </Typography>
                      {seat.isWheelchairAccessible && (
                        <FaWheelchair className="h-4 w-4 mt-1 text-purple-600" />
                      )}
                    </div>
                  </div>
                </Tooltip>
              ))}
            </div>

            {/* Aisle */}
            <div className="aisle h-2 my-6 bg-gradient-to-r from-transparent via-blue-gray-200 to-transparent"></div>
          </div>

          {/* Selected Seats Summary */}
          {selectedSeats.length > 0 && (
            <Card className="mb-6 border border-green-500">
              <CardBody>
                <Typography variant="h6" color="blue-gray" className="mb-2">
                  Selected Seats
                </Typography>
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedSeats.map((seat) => (
                    <Chip
                      key={seat.seatId}
                      value={`${seat.seatNumber} (₹${seat.fare})`}
                      color="green"
                      className="rounded-full"
                    />
                  ))}
                </div>
                <Typography variant="lead">
                  Total: ₹{selectedSeats.reduce((sum, seat) => sum + seat.fare, 0)}
                </Typography>
              </CardBody>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-4">
            <Button variant="outlined" color="blue-gray">
              Cancel
            </Button>
            <Button
              color="purple"
              disabled={selectedSeats.length === 0}
              onClick={() => {
                // Handle booking logic
              }}
            >
              Proceed to Payment
            </Button>
          </div>
        </CardBody>
      </Card>

      {/* Seat Information Dialog */}
      <Dialog open={openDialog} handler={handleOpenDialog}>
        <DialogHeader>Seat Information</DialogHeader>
        <DialogBody divider>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-green-500 rounded"></div>
              <Typography>Selected Seat</Typography>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-gray-50 border border-blue-gray-200 rounded"></div>
              <Typography>Available Seat</Typography>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-red-50 border border-red-200 rounded"></div>
              <Typography>Booked Seat</Typography>
            </div>
            <div className="flex items-center gap-2">
              <FaWheelchair className="h-5 w-5 text-purple-600" />
              <Typography>Wheelchair Accessible</Typography>
            </div>
          </div>
        </DialogBody>
        <DialogFooter>
          <Button variant="gradient" color="purple" onClick={handleOpenDialog}>
            <span>Got it</span>
          </Button>
        </DialogFooter>
      </Dialog>
    </div>
  );
};

export default SeatSelection;