import React from "react";

// Modal for showing the full summary
const SummaryModal = ({ summary, closeModal }) => (
  <div
    className="fixed inset-0 backdrop-blur-xs flex justify-center items-center z-50 transition-opacity"
    onClick={closeModal} // Close the modal when clicking outside
  >
    <div
      className="bg-white p-6 rounded-lg shadow-sm max-w-3xl w-full relative" // Added shadow-sm for light shadow
      onClick={(e) => e.stopPropagation()} // Prevent closing the modal when clicking inside
    >
      <button
        onClick={closeModal}
        className="absolute top-4 right-4 text-xl font-bold text-gray-600"
      >
        ×
      </button>
      {/* Heading "About The Hotel" */}
      <h1 className="text-2xl font-bold text-gray-800 mb-4">About The Hotel</h1>

      {/* Horizontal Line */}
      <hr className="border-t-2 border-gray-300 mb-4" />

      {/* Summary Content */}
      <div className="mt-4 text-gray-700 text-lg">{summary}</div>
    </div>
  </div>
);

export default SummaryModal;
