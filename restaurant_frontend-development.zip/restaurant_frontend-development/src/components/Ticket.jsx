import React from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import {
  Typography,
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  Avatar,
  Button,
  Tooltip,
  IconButton,
} from "@material-tailwind/react";
import {
  BanknotesIcon,
  ClockIcon,
  UserIcon,
  MapPinIcon,
  CalendarIcon,
  TicketIcon,
  PhoneIcon,
  EnvelopeIcon,
  ArrowRightIcon,
} from "@heroicons/react/24/solid";

const Ticket = () => {
  const { state } = useLocation();
  const ticketData = state?.ticket?.data || state?.ticket;
  const { selectedFlightTrip } = useSelector((state) => state.flighttrip); // Fixed variable name
  const { selectedTrainTrip } = useSelector((state) => state.traintrip);
  const { userInfo } = useSelector((state) => state.user);

  if (!ticketData) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Typography variant="h5" color="red">
          No ticket data found.
        </Typography>
      </div>
    );
  }

  const {
    transportType,
    passengerList = [],
    seatNumber = [],
    pnrNumber,
    journeyDate,
    boarding,
    departure,
    classType,
    totalFare,
    status,
    departureTime, // Added departureTime from ticketData
  } = ticketData;

  const mobileNumber = userInfo?.mobile || "N/A";
  const email = userInfo?.email || "N/A";

  const transportDetails = {
    RAILWAY: {
      title: "Train E-Ticket",
      color: "bg-gradient-to-r from-blue-600 to-purple-600",
      icon: "🚆",
      details: `Train: ${selectedTrainTrip?.train?.trainName || "N/A"} (${selectedTrainTrip?.train?.trainNo || "N/A"})`,
      timeInfo: `Departure: ${new Date(selectedTrainTrip?.departureDate || departureTime || journeyDate).toLocaleTimeString() || "N/A"}`,
    },
    AIRLINE: {
      title: "Flight E-Ticket",
      color: "bg-gradient-to-r from-green-600 to-teal-600",
      icon: "✈️",
      details: `Airline: ${selectedFlightTrip?.flight?.airline || "N/A"} (${selectedFlightTrip?.flight?.flight_no || "N/A"})`, // Fixed flight_no to flightNo
      timeInfo: `Departure: ${new Date(selectedFlightTrip?.departureDate || departureTime || journeyDate).toLocaleTimeString() || "N/A"}`, // Added fallbacks
    },
  };

  const { title, color, icon, details, timeInfo } = transportDetails[transportType] || {};

  const getStatusColor = () => {
    switch (status) {
      case 'CONFIRMED': return 'text-green-600';
      case 'WAITING': return 'text-yellow-600';
      case 'CANCELLED': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  // Function to display seat numbers properly
  const displaySeatNumber = (index) => {
    if (seatNumber && seatNumber[index]) {
      return seatNumber[index];
    }
    if (status === 'WAITING' && ticketData.waitingNumber) {
      return `WL${ticketData.waitingNumber}`;
    }
    return 'To be assigned';
  };

  return (
    <div className="flex justify-center p-4">
      <Card className="w-full max-w-2xl">
        {/* Header */}
        <CardHeader floated={false} shadow={false} className={`rounded-none rounded-t-lg ${color} p-6`}>
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="text-center">
              <Typography variant="h3" color="white" className="mb-1">
                Booking Confirmed
              </Typography>
              <Typography variant="h5" color="white">
                {title}
              </Typography>
            </div>
          </div>
        </CardHeader>

        <CardBody className="p-4">
          {/* Summary */}
          <div className="flex flex-col md:flex-row justify-between items-center mb-8 bg-blue-gray-50/50 p-4 rounded-lg">
            <div className="flex items-center gap-2">
              <TicketIcon className="h-5 w-5 text-blue-gray-500" />
              <div>
                <Typography variant="small" color="blue-gray">
                  PNR Number
                </Typography>
                <Typography variant="h6" color="blue-gray">
                  {pnrNumber}
                </Typography>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <BanknotesIcon className="h-5 w-5 text-blue-gray-500" />
              <div>
                <Typography variant="small" color="blue-gray">
                  Total Fare
                </Typography>
                <Typography variant="h6" color="green">
                  ₹{totalFare}
                </Typography>
              </div>
            </div>
          </div>

          {/* Journey Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-8">
            <Card className="col-span-2 p-4">
              <div className="flex justify-between items-center">
                <div className="text-center">
                  <Typography variant="small" color="blue-gray">
                    From
                  </Typography>
                  <Typography variant="h4" color="blue-gray">
                    {boarding}
                  </Typography>
                </div>
                <div className="flex-1 px-4">
                  <div className="relative">
                    <div className="border-t-2 border-dashed border-blue-gray-200"></div>
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-white px-2">
                      <ArrowRightIcon className="h-5 w-5 text-blue-gray-300" />
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <Typography variant="small" color="blue-gray">
                    To
                  </Typography>
                  <Typography variant="h4" color="blue-gray">
                    {departure}
                  </Typography>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <CalendarIcon className="h-5 w-5 text-blue-gray-500" />
                <Typography variant="h6" color="blue-gray">
                  Journey Date
                </Typography>
              </div>
              <Typography>
                {new Date(journeyDate).toLocaleDateString("en-US", {
                  weekday: "short",
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })}
              </Typography>
              {timeInfo && (
                <Typography variant="small" className="mt-1">
                  {timeInfo}
                </Typography>
              )}
            </Card>
          </div>

          {/* Transport Details */}
          <Card className="mb-5 p-4">
            <Typography variant="h5" color="blue-gray" className="mb-4">
              Journey Details
            </Typography>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Typography variant="small" color="blue-gray">
                  {details}
                </Typography>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Typography variant="small" color="blue-gray">
                    Class
                  </Typography>
                  <Typography variant="h6">{classType}</Typography>
                </div>
                <div>
                  <Typography variant="small" color="blue-gray">
                    Seat Preference
                  </Typography>
                  <Typography variant="h6">{ticketData.seatPreference || "Standard"}</Typography>
                </div>
              </div>
            </div>
          </Card>

          {/* Contact Info */}
          <Card className="mb-8 p-4">
            <Typography variant="h5" color="blue-gray" className="mb-4">
              Contact Information
            </Typography>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <PhoneIcon className="h-5 w-5 text-blue-gray-500" />
                <div>
                  <Typography variant="small" color="blue-gray">
                    Mobile Number
                  </Typography>
                  <Typography variant="h6">{mobileNumber}</Typography>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <EnvelopeIcon className="h-5 w-5 text-blue-gray-500" />
                <div>
                  <Typography variant="small" color="blue-gray">
                    Email Address
                  </Typography>
                  <Typography variant="h6">{email}</Typography>
                </div>
              </div>
            </div>
          </Card>

          {/* Passengers */}
          <Card className="mb-8 p-4">
            <Typography variant="h5" color="blue-gray" className="mb-4">
              Passenger Details ({passengerList.length})
            </Typography>
            <div className="space-y-4">
              {passengerList.map((passenger, index) => (
                <Card key={index} className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div>
                      <Typography variant="small" color="blue-gray">
                        Passenger {index + 1}
                      </Typography>
                      <Typography variant="h5" className="mt-1">
                        {passenger.name}
                      </Typography>
                      <div className="flex gap-4 mt-2">
                        <div>
                          <Typography variant="small" color="blue-gray">
                            Age
                          </Typography>
                          <Typography>{passenger.age}</Typography>
                        </div>
                        <div>
                          <Typography variant="small" color="blue-gray">
                            Gender
                          </Typography>
                          <Typography>{passenger.gender}</Typography>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      
                      <Typography variant="small" color="blue-gray">
                        Seat Number
                      </Typography>
                      <Typography variant="h4" className="mt-1">
                        {displaySeatNumber(index)}
                      </Typography>
                      <Typography variant="small" className="mt-1">
                        {passenger.seatPreference || ticketData.seatPreference || "Standard"}
                      </Typography>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </Card>

          {/* Additional Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4">
              <div className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5 text-blue-gray-500" />
                <div>
                  <Typography variant="small" color="blue-gray">
                    Booking Date
                  </Typography>
                  <Typography>
                    {new Date(ticketData.bookingDate).toLocaleDateString()}
                  </Typography>
                </div>
              </div>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2">
                <BanknotesIcon className="h-5 w-5 text-blue-gray-500" />
                <div>
                  <Typography variant="small" color="blue-gray">
                    Payment Status
                  </Typography>
                  <Typography color="green">Paid</Typography>
                </div>
              </div>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2">
                <ClockIcon className="h-5 w-5 text-blue-gray-500" />
                <div>
                  <Typography variant="small" color="blue-gray">
                    Cancellation Policy
                  </Typography>
                  <Typography>As per terms</Typography>
                </div>
              </div>
            </Card>
          </div>
        </CardBody>

       <CardFooter className="flex items-center justify-center gap-4 pt-2 border-t border-blue-gray-50">
  <Typography variant="small" className="text-center">
    Terms & Conditions: Non-transferable | Carry valid ID proof
  </Typography>
  <div className="flex gap-2">
    <Tooltip content="Download Ticket">
      <IconButton
        variant="text"
        onClick={() => window.print()}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 16v-8m0 8l-4-4m4 4l4-4M4 20h16" />
        </svg>
      </IconButton>
    </Tooltip>
    <Tooltip content="Call Customer Care">
      <IconButton variant="text">
        <PhoneIcon className="h-5 w-5" />
      </IconButton>
    </Tooltip>
    <Tooltip content="Email Support">
      <IconButton variant="text">
        <EnvelopeIcon className="h-5 w-5" />
      </IconButton>
    </Tooltip>
  </div>
</CardFooter>
      </Card>
    </div>
  );
};

export default Ticket;