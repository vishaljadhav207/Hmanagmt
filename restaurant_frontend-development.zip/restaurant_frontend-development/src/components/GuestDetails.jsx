import React from "react";
import InputField from "./InputField";

const GuestDetails = ({
  guestDetails,
  handleGuestDetailsChange,
  paymentMethod,
  handlePaymentMethodChange,
}) => (
  <div className="guest-details mb-8 p-6 bg-white rounded-xl shadow-md border border-gray-100">
    <h3 className="text-2xl font-semibold mb-6 text-gray-800 border-b pb-2">
      Guest Details
    </h3>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Title
        </label>
        <select
          name="title"
          value={guestDetails.title}
          onChange={handleGuestDetailsChange}
          className="block w-full p-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="Mr">Mr</option>
          <option value="Ms">Ms</option>
          <option value="Mrs">Mrs</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          First Name
        </label>
        <InputField
          type="text"
          placeholder="First Name"
          name="firstName"
          value={guestDetails.firstName}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Last Name
        </label>
        <InputField
          type="text"
          placeholder="Last Name"
          name="lastName"
          value={guestDetails.lastName}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Gender
        </label>
        <select
          name="gender"
          value={guestDetails.gender}
          onChange={handleGuestDetailsChange}
          className="block w-full p-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
          <option value="Prefer not to say">Prefer not to say</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Age
        </label>
        <InputField
          type="number"
          placeholder="Age"
          name="age"
          value={guestDetails.age}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Nationality
        </label>
        <select
          name="nationality"
          value={guestDetails.nationality}
          onChange={handleGuestDetailsChange}
          className="block w-full p-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="Indian">Indian</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Government ID Type
        </label>
        <select
          name="govIdType"
          value={guestDetails.govIdType}
          onChange={handleGuestDetailsChange}
          className="block w-full p-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="Aadhar">Aadhar</option>
          <option value="Passport">Passport</option>
          <option value="Driving License">Driving License</option>
          <option value="Voter ID">Voter ID</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Government ID Number
        </label>
        <InputField
          type="text"
          placeholder="ID Number"
          name="govIdNumber"
          value={guestDetails.govIdNumber}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Email Address
        </label>
        <InputField
          type="email"
          placeholder="Email ID"
          name="email"
          value={guestDetails.email}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Mobile Number
        </label>
        <InputField
          type="tel"
          placeholder="Enter Mobile Number"
          name="mobile"
          value={guestDetails.mobile}
          onChange={handleGuestDetailsChange}
          className="w-full p-3 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Payment Method
        </label>
        <select
          name="paymentMethod"
          value={paymentMethod}
          onChange={handlePaymentMethodChange}
          required
          className="w-full p-2 rounded-lg focus:ring-blue-500 focus:border-blue-500 border border-gray-300"
        >
          <option value="" disabled>
            Select Payment Method
          </option>
          <option value="UPI">UPI</option>
          <option value="Cash">Cash</option>
        </select>
      </div>
    </div>
  </div>
);

export default GuestDetails;
