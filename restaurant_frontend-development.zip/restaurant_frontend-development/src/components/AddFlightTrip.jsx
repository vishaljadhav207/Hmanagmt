import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Box,
  Chip,
  Card,
  CardContent,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Snackbar,
  Alert,
  CircularProgress,
  IconButton,
  Tooltip,
  Autocomplete,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import FlightTakeoffIcon from "@mui/icons-material/FlightTakeoff";
import FlightLandIcon from "@mui/icons-material/FlightLand";
import PlaceIcon from "@mui/icons-material/Place";
import { createFlightTrip } from "../app/flighttripApi";
import { fetchFlightsByUserId } from "../app/flightApi";
import { selectAllFlights, selectCurrentFlight } from "../redux/flightSlice";

// Helper function to get today's date in YYYY-MM-DD format
const getTodayDateString = () => {
  const today = new Date();
  return today.toISOString().split("T")[0];
};

// Helper function to get current datetime in local format
const getCurrentDateTimeString = () => {
  const now = new Date();
  // Format as YYYY-MM-DDTHH:MM
  return new Date(now.getTime() - now.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 16);
};
import Swal from 'sweetalert2';

const CreateFlightTripForm = ({ onClose, onSuccess }) => {
  const dispatch = useDispatch();
  const flights = useSelector(selectAllFlights);
  const currentFlight = useSelector(selectCurrentFlight);
  const status = useSelector((state) => state.flighttrip.status);
  const error = useSelector((state) => state.flighttrip.error);

  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [expanded, setExpanded] = useState("flightDetails");

  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;

  const [formData, setFormData] = useState({
    flightTripId: Math.floor(Math.random() * 1000) + 1,
    origin: "",
    destination: "",
    departureDate: getTodayDateString(),
    arrivalDate: "",
    selectedFlight: null,
    intermediateStops: [
      {
        stopName: "",
        arrivalTime: getCurrentDateTimeString(),
        distanceFromPrevious: 0,
        departureTime: "",
        sequence: 0,
      },
    ],
  });

  useEffect(() => {
    dispatch(fetchFlightsByUserId(userId));
  }, [dispatch, userId]);

  useEffect(() => {
    if (currentFlight) {
      const flightData = currentFlight.flight || currentFlight;

      setFormData((prev) => ({
        ...prev,
        origin: flightData.departFrom,
        destination: flightData.destination,
        selectedFlight: flightData,
        departureDate: flightData.departureDate
          ? flightData.departureDate.slice(0, 10)
          : getTodayDateString(),
        arrivalDate: flightData.arrivalDate
          ? flightData.arrivalDate.slice(0, 10)
          : "",
      }));
    }
  }, [currentFlight]);

  const handleAccordionChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFlightChange = (event, value) => {
    if (value) {
      const flightData = value.flight || value;

      setFormData((prev) => ({
        ...prev,
        selectedFlight: flightData,
        origin: flightData.departFrom,
        destination: flightData.destination,
        departureDate:
          flightData.departureDate?.slice(0, 10) || getTodayDateString(),
        arrivalDate: flightData.arrivalDate?.slice(0, 10) || "",
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        selectedFlight: null,
        origin: "",
        destination: "",
        departureDate: getTodayDateString(),
        arrivalDate: "",
      }));
    }
  };

  const getFlightsForDropdown = () => {
    return flights.map((flight) => {
      return flight.flight
        ? { ...flight.flight, flight_id: flight.flight.flight_id }
        : flight;
    });
  };

  const getSelectedFlightForDropdown = () => {
    if (!formData.selectedFlight) return null;

    return getFlightsForDropdown().find(
      (flight) => flight.flight_id === formData.selectedFlight.flight_id
    );
  };

  const handleStopChange = (index, field, value) => {
    const updatedStops = [...formData.intermediateStops];
    updatedStops[index][field] = value;
    setFormData((prev) => ({ ...prev, intermediateStops: updatedStops }));
  };

  const handleAddStop = () => {
    setFormData((prev) => ({
      ...prev,
      intermediateStops: [
        ...prev.intermediateStops,
        {
          stopName: "",
          arrivalTime: getCurrentDateTimeString(),
          distanceFromPrevious: 0,
          departureTime: "",
          sequence: prev.intermediateStops.length,
        },
      ],
    }));
  };

  const handleRemoveStop = (index) => {
    if (formData.intermediateStops.length > 1) {
      const updatedStops = formData.intermediateStops.filter(
        (_, i) => i !== index
      );
      setFormData((prev) => ({ ...prev, intermediateStops: updatedStops }));
    }
  };

  const validateDates = () => {
    const today = new Date(getTodayDateString());
    const departureDate = new Date(formData.departureDate);

    if (departureDate < today) {
      alert("Departure date cannot be in the past");
      return false;
    }

    if (
      formData.arrivalDate &&
      new Date(formData.arrivalDate) < departureDate
    ) {
      alert("Arrival date cannot be before departure date");
      return false;
    }

    for (const stop of formData.intermediateStops) {
      if (new Date(stop.arrivalTime) < new Date()) {
        alert(
          `Stop ${
            stop.stopName || formData.intermediateStops.indexOf(stop) + 1
          } arrival time cannot be in the past`
        );
        return false;
      }

      if (
        stop.departureTime &&
        new Date(stop.departureTime) < new Date(stop.arrivalTime)
      ) {
        alert(
          `Stop ${
            stop.stopName || formData.intermediateStops.indexOf(stop) + 1
          } departure time cannot be before arrival time`
        );
        return false;
      }
    }

    return true;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateDates()) {
      return;
    }

    const payload = {
      origin: formData.origin,
      destination: formData.destination,
      departureDate: formData.departureDate,
      arrivalDate: formData.arrivalDate,
      flight: {
        flight_id: formData.selectedFlight?.flight_id,
      },
      intermediateStops: formData.intermediateStops.map((stop, idx) => ({
        stopName: stop.stopName,
        arrivalTime: stop.arrivalTime,
        distanceFromPrevious: Number(stop.distanceFromPrevious),
        departureTime: stop.departureTime,
        sequence: idx + 1,
      })),
    };

    dispatch(createFlightTrip(payload))
      .unwrap()
      .then(() => {
         Swal.fire({
        icon: 'success',
        title: 'Added!',
        text: 'Flight trip created successfully.',
        timer: 2000,
        showConfirmButton: false
      });
        setSnackbarOpen(true);
        if (onSuccess) onSuccess();
        if (onClose) onClose();
      })
      .catch((error) => {
        setSnackbarOpen(true);
      });
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
    if (status === "succeeded") {
      if (!onClose) {
        setFormData({
          flightTripId: Math.floor(Math.random() * 1000) + 1,
          origin: "",
          destination: "",
          departureDate: getTodayDateString(),
          arrivalDate: "",
          selectedFlight: null,
          intermediateStops: [
            {
              stopName: "",
              arrivalTime: getCurrentDateTimeString(),
              distanceFromPrevious: 0,
              departureTime: "",
              sequence: 0,
            },
          ],
        });
        setExpanded(false);
      }
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography
          variant="h4"
          component="h1"
          gutterBottom
          align="center"
          sx={{ mb: 4 }}
        >
          Create New Flight Trip
        </Typography>

        <Box component="form" onSubmit={handleSubmit}>
          <Accordion
            expanded={expanded === "flightDetails"}
            onChange={handleAccordionChange("flightDetails")}
          >
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                Flight Details
              </Typography>
              {formData.origin && formData.destination && (
                <Chip
                  label={`${formData.origin} → ${formData.destination}`}
                  color="primary"
                  size="small"
                  sx={{ ml: 2 }}
                />
              )}
            </AccordionSummary>
            <AccordionDetails>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Autocomplete
                    options={getFlightsForDropdown()}
                    getOptionLabel={(option) =>
                      `${option.airline} - ${option.flight_no} (${option.departFrom} → ${option.destination})`
                    }
                    value={getSelectedFlightForDropdown()}
                    onChange={handleFlightChange}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Flight"
                        required
                        placeholder="Search flights..."
                      />
                    )}
                    isOptionEqualToValue={(option, value) =>
                      option.flight_id === value?.flight_id
                    }
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Origin"
                    name="origin"
                    value={formData.origin}
                    onChange={handleInputChange}
                    required
                    InputProps={{
                      startAdornment: (
                        <FlightTakeoffIcon color="action" sx={{ mr: 1 }} />
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Destination"
                    name="destination"
                    value={formData.destination}
                    onChange={handleInputChange}
                    required
                    InputProps={{
                      startAdornment: (
                        <FlightLandIcon color="action" sx={{ mr: 1 }} />
                      ),
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Departure Date"
                    type="date"
                    name="departureDate"
                    value={formData.departureDate}
                    onChange={handleInputChange}
                    required
                    InputLabelProps={{
                      shrink: true,
                    }}
                    inputProps={{
                      min: getTodayDateString(),
                    }}
                    error={
                      new Date(formData.departureDate) <
                      new Date(getTodayDateString())
                    }
                    helperText={
                      new Date(formData.departureDate) <
                      new Date(getTodayDateString())
                        ? "Departure date cannot be in the past"
                        : ""
                    }
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Arrival Date"
                    type="date"
                    name="arrivalDate"
                    value={formData.arrivalDate}
                    onChange={handleInputChange}
                    required
                    InputLabelProps={{
                      shrink: true,
                    }}
                    inputProps={{
                      min: formData.departureDate || getTodayDateString(),
                    }}
                    error={
                      formData.arrivalDate &&
                      new Date(formData.arrivalDate) <
                        new Date(formData.departureDate)
                    }
                    helperText={
                      formData.arrivalDate &&
                      new Date(formData.arrivalDate) <
                        new Date(formData.departureDate)
                        ? "Arrival date cannot be before departure date"
                        : ""
                    }
                  />
                </Grid>
              </Grid>
            </AccordionDetails>
          </Accordion>

          <Accordion
            expanded={expanded === "routeStops"}
            onChange={handleAccordionChange("routeStops")}
            sx={{ mt: 2 }}
          >
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                Route Stops
              </Typography>
              {formData.intermediateStops.length > 0 && (
                <Chip
                  label={`${formData.intermediateStops.length} stops`}
                  color="secondary"
                  size="small"
                  sx={{ ml: 2 }}
                />
              )}
            </AccordionSummary>
            <AccordionDetails>
              <Typography variant="body2" color="text.secondary" paragraph>
                Add all intermediate stops between origin and destination
              </Typography>

              {formData.intermediateStops.map((stop, index) => (
                <Card key={index} sx={{ mb: 2 }}>
                  <CardContent>
                    <Grid container spacing={2} alignItems="center">
                      <Grid item xs={12} sm={4}>
                        <TextField
                          fullWidth
                          label="Stop Name"
                          value={stop.stopName}
                          onChange={(e) =>
                            handleStopChange(index, "stopName", e.target.value)
                          }
                          required
                          InputProps={{
                            startAdornment: (
                              <PlaceIcon color="action" sx={{ mr: 1 }} />
                            ),
                          }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <TextField
                          fullWidth
                          label="Arrival Time"
                          type="datetime-local"
                          value={stop.arrivalTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "arrivalTime",
                              e.target.value
                            )
                          }
                          required
                          InputLabelProps={{
                            shrink: true,
                          }}
                          inputProps={{
                            min: getCurrentDateTimeString(),
                          }}
                          error={new Date(stop.arrivalTime) < new Date()}
                          helperText={
                            new Date(stop.arrivalTime) < new Date()
                              ? "Arrival time cannot be in the past"
                              : ""
                          }
                        />
                      </Grid>
                      <Grid item xs={12} sm={3}>
                        <TextField
                          fullWidth
                          label="Departure Time"
                          type="datetime-local"
                          value={stop.departureTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "departureTime",
                              e.target.value
                            )
                          }
                          required
                          InputLabelProps={{
                            shrink: true,
                          }}
                          inputProps={{
                            min: stop.arrivalTime || getCurrentDateTimeString(),
                          }}
                          error={
                            stop.departureTime &&
                            new Date(stop.departureTime) <
                              new Date(stop.arrivalTime)
                          }
                          helperText={
                            stop.departureTime &&
                            new Date(stop.departureTime) <
                              new Date(stop.arrivalTime)
                              ? "Departure time cannot be before arrival time"
                              : ""
                          }
                        />
                      </Grid>
                      <Grid item xs={12} sm={1}>
                        <Tooltip title="Distance from previous stop (km)">
                          <TextField
                            fullWidth
                            label="Distance"
                            type="number"
                            value={stop.distanceFromPrevious}
                            onChange={(e) =>
                              handleStopChange(
                                index,
                                "distanceFromPrevious",
                                parseInt(e.target.value)
                              )
                            }
                            required
                          />
                        </Tooltip>
                      </Grid>
                      <Grid item xs={12} sm={1} sx={{ textAlign: "center" }}>
                        {index > 0 && (
                          <IconButton
                            color="error"
                            onClick={() => handleRemoveStop(index)}
                          >
                            <RemoveIcon />
                          </IconButton>
                        )}
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              ))}

              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={handleAddStop}
                sx={{ mt: 1 }}
              >
                Add Stop
              </Button>
            </AccordionDetails>
          </Accordion>

          <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 4 }}>
            <Button
              type="submit"
              variant="contained"
              color="success"
              size="large"
              disabled={status === "loading"}
              startIcon={
                status === "loading" ? (
                  <CircularProgress size={20} color="inherit" />
                ) : null
              }
            >
              {status === "loading"
                ? "Creating Flight Trip..."
                : "Create Flight Trip"}
            </Button>
          </Box>
        </Box>
      </Paper>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={status === "succeeded" ? "success" : "error"}
          sx={{ width: "100%" }}
        >
          {status === "succeeded"
            ? "Flight trip created successfully!"
            : `Error: ${error}`}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default CreateFlightTripForm;
