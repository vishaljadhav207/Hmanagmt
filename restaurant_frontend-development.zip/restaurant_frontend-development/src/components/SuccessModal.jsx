import React, { useEffect } from 'react';
import { CheckCircleIcon } from '@heroicons/react/24/solid';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const SuccessModal = ({ isOpen, onClose }) => {
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleOkClick = () => {
    onClose(); // Close the modal
    navigate('/user-history'); // Navigate to the UserHistory page
  };

  return (
    <div
      className="fixed inset-0 bg-opacity-30 backdrop-blur-sm flex justify-center items-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white p-8 rounded-xl shadow-2xl w-96 transform transition-all duration-300 animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col items-center">
          {/* Animated checkmark circle */}
          <div className="relative mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center animate-pulse">
              <CheckCircleIcon className="w-16 h-16 text-green-500 animate-scale-in" />
            </div>
            {/* Floating dots animation */}
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-300 rounded-full animate-bounce"></div>
            <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-green-300 rounded-full animate-bounce delay-100"></div>
          </div>

          <h2 className="text-2xl font-bold text-green-600 mb-2">
            Booking Confirmed!
          </h2>
          <p className="text-gray-600 mb-6 text-center">
            Your reservation has been successfully processed. A confirmation has been sent to your email.
          </p>

          <button
            onClick={handleOkClick} // Use the handleOkClick function
            className="px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition-all duration-300 hover:from-green-600 hover:to-green-700 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-50"
          >
            Ok
          </button>

          {/* Additional decorative elements */}
          <div className="mt-6 text-xs text-gray-400">
            <p>Thank you for choosing our service!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuccessModal;