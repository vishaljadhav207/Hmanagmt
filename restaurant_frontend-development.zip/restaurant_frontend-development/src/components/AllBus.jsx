import React, { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Chip,
  Grid,
  Stack,
  Divider,
  Avatar,
  Paper,
  Pagination,
  CircularProgress,
  Alert,
  Collapse,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Tooltip,
  Button,
} from "@mui/material";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import UpdateIcon from "@mui/icons-material/Update";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import StopIcon from "@mui/icons-material/Stop";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAllBusTrips } from "../app/bustripApi";
import { setCurrentPage } from "../redux/busTripSlice";
import seatAxios from "../app/seatAxios";

const AllBus = ({ searchResults }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { bustrip, status, error, currentPage, totalPages, pageSize } =
    useSelector((state) => state.bustrip);

  const [seatsData, setSeatsData] = useState([]);
  const [loadingSeats, setLoadingSeats] = useState(false);
  const [expandedStops, setExpandedStops] = useState({});
  const [seatAvailability, setSeatAvailability] = useState({});

  const filterCurrentAndFutureTrips = (trips) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return trips
      .filter((trip) => {
        const departureDate = new Date(trip.departureDate);
        return departureDate >= today;
      })
      .sort((a, b) => new Date(a.departureDate) - new Date(b.departureDate));
  };

  const isToday = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  useEffect(() => {
    if (!searchResults) {
      const today = new Date().toISOString().split("T")[0];
      dispatch(
        getAllBusTrips({
          page: currentPage,
          size: pageSize,
          departureAfter: today,
        })
      );
    }
  }, [dispatch, currentPage, pageSize, searchResults]);

  useEffect(() => {
    const fetchSeatsData = async () => {
      setLoadingSeats(true);
      try {
        const response = await seatAxios.get("/bus-seats/getAllBusSeat");
        setSeatsData(response.data);

        const availabilityMap = {};
        response.data.forEach((seat) => {
          const key = `${seat.busId}-${seat.classId}`;
          availabilityMap[key] = {
            total: seat.layout.seatMap.length,
            available: seat.layout.seatMap.filter((s) => s.available).length,
          };
        });
        setSeatAvailability(availabilityMap);
      } catch (err) {
        console.error("Error fetching seats data:", err);
      } finally {
        setLoadingSeats(false);
      }
    };

    fetchSeatsData();
  }, []);

  const getSeatStatus = (busId, classId) => {
    if (loadingSeats) return { status: "loading", available: 0, total: 0 };

    const key = `${busId}-${classId}`;
    const seatInfo = seatAvailability[key];

    if (!seatInfo) return { status: "not-available", available: 0, total: 0 };

    if (seatInfo.available === 0) {
      return { status: "sold-out", available: 0, total: seatInfo.total };
    }

    return {
      status: "available",
      available: seatInfo.available,
      total: seatInfo.total,
    };
  };

  const handlePageChange = (event, newPage) => {
    dispatch(setCurrentPage(newPage - 1));
  };

  const handleCardClick = (busTripId, classType, fare) => {
    navigate("/bus-booking", { state: { busTripId, classType, fare } });
  };

  const formatDate = (dateString) => {
    const options = { day: "2-digit", month: "short", year: "numeric" };
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", options).toUpperCase();
  };

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const toggleStopsExpansion = (busTripId) => {
    setExpandedStops((prev) => ({
      ...prev,
      [busTripId]: !prev[busTripId],
    }));
  };

  if (status === "loading") {
    return (
      <Container
        maxWidth="xl"
        sx={{ py: 4, display: "flex", justifyContent: "center" }}
      >
        <CircularProgress />
      </Container>
    );
  }

  if (status === "failed") {
    return (
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  const busesToShow =
    searchResults && Array.isArray(searchResults)
      ? filterCurrentAndFutureTrips(searchResults)
      : filterCurrentAndFutureTrips(bustrip);

  return (
    <Container maxWidth="xl" sx={{ py: 4 }}>
      <Typography variant="h4" fontWeight="bold" align="center" gutterBottom>
        🚌 Available Buses
      </Typography>

      {busesToShow.length === 0 ? (
        <Alert severity="info" sx={{ mt: 2 }}>
          No buses available for today or future dates. Please try a different
          search.
        </Alert>
      ) : (
        <>
          <Stack spacing={4}>
            {busesToShow.map((bus, index) => (
              <Card
                key={index}
                variant="outlined"
                sx={{ borderRadius: 2, boxShadow: 3 }}
              >
                <CardContent>
                  {/* Header */}
                  <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                    mb={2}
                  >
                    <Box display="flex" alignItems="center" gap={1}>
                      <Avatar sx={{ bgcolor: "primary.main" }}>
                        <DirectionsBusIcon />
                      </Avatar>
                      <Typography variant="h6" fontWeight="bold">
                        {bus.bus?.operatorName || "Unknown Operator"}
                      </Typography>
                      {isToday(bus.departureDate) && (
                        <Chip label="Today" color="primary" size="small" />
                      )}
                    </Box>
                    <Chip
                      label={`#${bus.bus?.busNo || "N/A"}`}
                      color="secondary"
                      variant="outlined"
                    />
                  </Box>

                  {/* Departure Info */}
                  <Box
                    display="flex"
                    justifyContent="space-between"
                    flexWrap="wrap"
                    mb={2}
                  >
                    <Typography variant="body2">
                      Departure:{" "}
                      <strong>{formatDate(bus.departureDate)}</strong>
                    </Typography>
                    <Typography variant="body2">
                      Type: <strong>{bus.bus?.busType || "Standard"}</strong>
                    </Typography>
                  </Box>

                  {/* Grid Info */}
                  <Grid container spacing={2} alignItems="center">
                    <Grid item xs={12} md={4}>
                      <Box display="flex" alignItems="center" gap={1}>
                        <AccessTimeIcon color="action" />
                        <Typography variant="subtitle1">
                          {formatTime(bus.departureDate)}
                        </Typography>
                      </Box>
                      <Typography variant="caption" color="text.secondary">
                        <LocationOnIcon fontSize="small" /> {bus.origin}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={4} textAlign="center">
                      <Typography variant="body2" color="text.secondary">
                        {bus.intermediateStops?.length > 0
                          ? `${bus.intermediateStops.length} stops`
                          : "Direct route"}
                      </Typography>
                      <Divider sx={{ my: 1 }} />
                      <Typography variant="caption" color="text.secondary">
                        {bus.classTypes?.length || 0} class options
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={4} textAlign="right">
                      <Box display="flex" justifyContent="flex-end" gap={1}>
                        <AccessTimeIcon color="action" />
                        <Typography variant="subtitle1">
                          {formatTime(bus.arrivalDate)}
                        </Typography>
                      </Box>
                      <Typography variant="caption" color="text.secondary">
                        <LocationOnIcon fontSize="small" /> {bus.destination}
                      </Typography>
                    </Grid>
                  </Grid>

                  {/* Intermediate Stops */}
                  {bus.intermediateStops?.length > 0 && (
                    <Box mt={2}>
                      <Box
                        display="flex"
                        alignItems="center"
                        sx={{ cursor: "pointer" }}
                        onClick={() => toggleStopsExpansion(bus.busTripId)}
                      >
                        <Typography variant="subtitle2" fontWeight="bold">
                          View Intermediate Stops
                        </Typography>
                        <IconButton size="small">
                          {expandedStops[bus.busTripId] ? (
                            <ExpandLessIcon />
                          ) : (
                            <ExpandMoreIcon />
                          )}
                        </IconButton>
                      </Box>
                      <Collapse in={expandedStops[bus.busTripId]}>
                        <List dense sx={{ mt: 1 }}>
                          {bus.intermediateStops.map((stop, stopIdx) => (
                            <ListItem key={stopIdx} sx={{ py: 0 }}>
                              <ListItemIcon sx={{ minWidth: 32 }}>
                                <StopIcon fontSize="small" color="primary" />
                              </ListItemIcon>
                              <ListItemText
                                primary={stop.stopName}
                                secondary={
                                  <>
                                    Arr: {formatTime(stop.arrivalTime)}, Dep:{" "}
                                    {formatTime(stop.departureTime)}
                                  </>
                                }
                              />
                            </ListItem>
                          ))}
                        </List>
                      </Collapse>
                    </Box>
                  )}

                  {/* Class Types */}
                  <Box
                    sx={{
                      display: "flex",
                      overflowX: "auto",
                      gap: 2,
                      py: 2,
                      scrollSnapType: "x mandatory",
                      "& > *": { scrollSnapAlign: "start" },
                    }}
                  >
                    {bus.classTypes?.map((cls, clsIndex) => {
                      const seatStatus = getSeatStatus(
                        bus.bus?.busId,
                        cls.classId
                      );

                      return (
                        <Tooltip
                          key={clsIndex}
                          title={`Click to book ${cls.className} class`}
                          arrow
                        >
                          <Paper
                            elevation={3}
                            sx={{
                              minWidth: 250,
                              p: 2,
                              borderRadius: 2,
                              cursor: "pointer",
                              transition: "0.3s",
                              ":hover": {
                                boxShadow: 6,
                                transform: "translateY(-2px)",
                              },
                              border:
                                seatStatus.status === "sold-out" ||
                                seatStatus.status === "not-available"
                                  ? "1px solid #ff6b6b"
                                  : "1px solid #e0e0e0",
                            }}
                            onClick={() =>
                              handleCardClick(
                                bus.busTripId,
                                cls.className,
                                cls.fare
                              )
                            }
                          >
                            <Box
                              display="flex"
                              justifyContent="space-between"
                              mb={1}
                            >
                              <Typography
                                variant="subtitle1"
                                fontWeight="medium"
                              >
                                {cls.className}
                              </Typography>
                              <Chip
                                label={
                                  cls.status === "pending"
                                    ? "REGULAR"
                                    : "TATKAL"
                                }
                                size="small"
                                color={
                                  cls.status === "pending" ? "success" : "error"
                                }
                                variant="outlined"
                              />
                            </Box>

                            <Typography variant="h6" color="primary">
                              ₹{cls.fare}
                            </Typography>

                            <Box mt={1}>
                              <Typography variant="body2">
                                <strong>Seats:</strong>{" "}
                                {(() => {
                                  switch (seatStatus.status) {
                                    case "loading":
                                      return "Loading...";
                                    case "not-available":
                                      return (
                                        <span style={{ color: "red" }}>
                                          Not available
                                        </span>
                                      );
                                    case "sold-out":
                                      return (
                                        <span style={{ color: "red" }}>
                                          Sold out
                                        </span>
                                      );
                                    case "available":
                                      return (
                                        <>
                                          <span style={{ color: "green" }}>
                                            {seatStatus.available} available
                                          </span>
                                          <br />
                                          <small>
                                            Total seats: {seatStatus.total}
                                          </small>
                                        </>
                                      );
                                    default:
                                      return "N/A";
                                  }
                                })()}
                              </Typography>

                              <Box
                                display="flex"
                                alignItems="center"
                                mt={1}
                                color="success.main"
                              >
                                <CheckCircleIcon
                                  fontSize="small"
                                  sx={{ mr: 0.5 }}
                                />
                                <Typography variant="caption">
                                  {cls.className === "General"
                                    ? "No Refund"
                                    : "Free Cancellation"}
                                </Typography>
                              </Box>

                              <Box
                                display="flex"
                                alignItems="center"
                                mt={1}
                                color="text.secondary"
                              >
                                <UpdateIcon fontSize="small" sx={{ mr: 0.5 }} />
                                <Typography variant="caption">
                                  Updated just now
                                </Typography>
                              </Box>
                            </Box>
                          </Paper>
                        </Tooltip>
                      );
                    })}
                  </Box>

                  {/* View Details Button at Bottom Right */}
                  <Box display="flex" justifyContent="flex-end" mt={2}>
                    <Button
                      variant="contained"
                      onClick={() => handleCardClick(bus.busTripId, null, null)}
                    >
                      Book Now
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </Stack>

          {!searchResults && totalPages > 1 && (
            <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
              <Pagination
                count={totalPages}
                page={currentPage + 1}
                onChange={handlePageChange}
                color="primary"
                showFirstButton
                showLastButton
              />
            </Box>
          )}
        </>
      )}
    </Container>
  );
};

export default AllBus;
