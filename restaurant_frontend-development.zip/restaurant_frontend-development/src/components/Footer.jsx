import React from "react";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaLinkedinIn,
  FaEnvelope,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import sam from "../assets/stars.png"; // Placeholder logo/image
import { useTranslation } from "react-i18next";

const Footer = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  // Navigate to specific page
  const handleNavigation = (page) => {
    navigate(`/${page}`);
  };

  return (
    <footer className="bg-gradient-to-r from-[#081123] to-[#2a3a61] text-white p-6 mt-10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
        {/* Left Section: Logo & Description */}
        <div className="text-center md:text-left flex flex-col items-center md:items-start space-y-2">
          <p className="text-base font-semibold text-fuchsia-100 uppercase tracking-wide">
            {t("footer.travelPlatform")}
          </p>

          {/* PrakritiStay with hover effect */}
          <h2
            onClick={() => handleNavigation("")}
            className="text-3xl font-bold font-serif text-fuchsia-100 cursor-pointer transition-all duration-500 hover:text-fuchsia-300 transform hover:scale-105"
          >
            PrakritiStay
          </h2>

          {/* Star Rating */}
          <div className="mt-1 flex items-center justify-center md:justify-start">
            <img
              src={sam}
              alt="star rating"
              className="w-[35px] mr-2 transform transition-all duration-500 hover:scale-110"
            />
          </div>

          <p className="text-sm mt-1 text-gray-300">{t("footer.description")}</p>
          <p className="text-sm mt-1 text-gray-300">{t("footer.rightsReserved")}</p>
        </div>

        {/* Middle Section: Navigation Links */}
        <div className="text-center space-y-4 md:text-left">
          <ul className="flex flex-wrap justify-center md:justify-start space-x-6 text-lg font-medium text-gray-300 hover:scale-105 transition-all duration-300">
          <li>
              <a
                href="#home"
                className="hover:text-fuchsia-300 transition-all duration-300"
                onClick={() => handleNavigation("home")}
              >
                {t("footer.home")}
              </a>
            </li>
            <li>
              <a
                href="#about"
                className="hover:text-fuchsia-300 transition-all duration-300"
                onClick={() => handleNavigation("about-us")}
              >
                {t("footer.aboutUs")}
              </a>
            </li>
            <li>
              <a
                href="#services"
                className="hover:text-fuchsia-300 transition-all duration-300"
                onClick={() => handleNavigation("hotel")}
              >
                {t("footer.hotels")}
              </a>
            </li>
            <li>
              <a
                href="#contact"
                className="hover:text-fuchsia-300 transition-all duration-300"
                onClick={() => handleNavigation("contact")}
              >
                {t("footer.contact")}
              </a>
            </li>
          </ul>
          <div className="mt-2 text-center md:text-left text-gray-200 text-sm">
            <p>{t("footer.subscribe")}</p>
          </div>
        </div>

        {/* Right Section: Contact, Social Media & Subscription */}
        <div className="text-center md:text-left space-y-4">
          <p className="text-base text-gray-200">{t("footer.address")}</p>
          <p className="text-base text-gray-200">{t("footer.email")}</p>
          <p className="text-base text-gray-200">{t("footer.phone")}</p>

          {/* Social Media Links */}
          <div className="mt-4 flex justify-center md:justify-start space-x-6">
            <a
              href="https://www.facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-fuchsia-300 transition-all duration-300 transform hover:scale-125"
              title="Facebook"
            >
              <FaFacebookF size={26} />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-fuchsia-300 transition-all duration-300 transform hover:scale-125"
              title="Twitter"
            >
              <FaTwitter size={26} />
            </a>
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-fuchsia-300 transition-all duration-300 transform hover:scale-125"
              title="Instagram"
            >
              <FaInstagram size={26} />
            </a>
            <a
              href="https://www.linkedin.com/company/PrakritiStay"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white hover:text-fuchsia-300 transition-all duration-300 transform hover:scale-125"
              title="LinkedIn"
            >
              <FaLinkedinIn size={26} />
            </a>
          </div>

          {/* Subscription Form */}
          <div className="mt-4">
            <p className="text-sm text-gray-200">{t("footer.subscribe")}</p>
            <form className="flex items-center mt-3">
              <input
                type="email"
                placeholder="Enter your email"
                className="p-2 rounded-l-md border border-gray-300 w-64 md:w-80 focus:outline-none"
              />
              <button
                type="submit"
                className="p-2 bg-fuchsia-950 text-white rounded-r-md hover:bg-fuchsia-700 transition duration-300"
              >
                <FaEnvelope />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer Divider */}
      <div className="mt-6 border-t-2 border-fuchsia-950 w-full"></div>

      {/* Fade-in Animation on Scroll */}
      <div className="mt-6 text-center fade-in">
        <p className="text-sm text-gray-300">{t("footer.poweredBy")}</p>
      </div>
    </footer>
  );
};

export default Footer;