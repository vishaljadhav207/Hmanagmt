import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Login from "../pages/Login";
import Home from "../pages/Home";
import SignUp from "../pages/SignUp";
import ProtectedRoutes from "./ProtectedRoutes";
import Dashboard from "../dashboard/Dashboard";
import HotelList from "../dashboard/HotelList";
import UserList from "../dashboard/UserList";
import AdminLayout from "../layout/AdminLayout";
import AppLayout from "../applayout/AppLayout";
import Adminprofile from "../dashboard/Adminprofile";
import Contact from "../pages/Contact";
import AboutUs from "../pages/AboutUs";
import Profile from "../pages/Profile";
import News from "../pages/News";
import { useSelector } from "react-redux";
import NoPage from "../pages/NoPage";
import ForgotPassword from "../pages/ForgotPassword";
import VerifyEmailOtp from "../pages/VerifyEmailOtp";
import ResetPassword from "../pages/ResetPassword";
import Hotel from "../pages/Hotel";
import { ReviewBooking } from "../components/ReviewBooking";
import RoomDetails from "../components/RoomDetails";
import OwnerProperties from "../dashboard/OwnerProperties";
import Bookings from "../dashboard/Bookings";
import FlightBookingTab from "../components/flightBookingTab";

import Queries from "../dashboard/Queries";
import AllBus from "../components/AllBus";
import Train from "../pages/train_booking/Train";
import Flight from "../pages/Flight";
import Bus from "../pages/Bus";
import SupervisorList from "../dashboard/SupervisorList";
import TrainList from "../dashboard/TrainList";
import FlightList from "../dashboard/FlightList";
import FlightSupervisorList from "../dashboard/FlightSupervisorList";
import BusList from "../dashboard/BusList";
import BusSupervisorList from "../dashboard/BusSupervisorList";
import OrgDashboard from "../components/OrgDashboard";
import OrgList from "../dashboard/OrgList";

import BusBooking from "../components/BusBooking";

import Ticket from "../components/Ticket";
import SuperVisorLayout from "../layout/SuperVisorLayout";
import Form from "../components/Form";
import FlightForm from "../components/FlightForm";
import TrainTrip from "../components/TrainTripList";
import FlightTripsList from "../dashboard/flight_supervisor_dashboard/FlightTripsList";
import FlightMgmt from "../dashboard/flight_supervisor_dashboard/FlightMgmt";

import BusForm from "../components/BusForm";
import BusTrip from "../dashboard/bus_supervisor_dashboard/BusTrip";
// import FlightSeatMgmt from "../components/FlightSeatMgmt";
import SupervisorBusSeat from "../dashboard/bus_supervisor_dashboard/SupervisorBusSeat";
// import BusManagement from "../dashboard/bus_supervisor_dashboard/BusMangemnt";
// import BusManagement from "../dashboard/bus_supervisor_dashboard/BusMangemnt";
import TrainManagement from "../dashboard/train_supervisor_dashboard/TrainManagement";
import TrainSeatLayout from "../dashboard/train_supervisor_dashboard/TrainSeatLayout";
import FlightSeatLayout from "../dashboard/flight_supervisor_dashboard/FlightSeatsLayout";
import BusDashboard from "../dashboard/component/BusDashboard";
import TrainDashboard from "../dashboard/component/TrainDashboard";
import FlightDashboard from "../dashboard/component/FlightDashboard";
import BusAdminDashboard from "../dashboard/component/BusAdminDashboard";
import FlightAdminDashboard from "../dashboard/flight_supervisor_dashboard/FlightAdminDashboard";
import TrainAdminDashboard from "../dashboard/TrainAdminDashboard";
import BookBusSeat from "../dashboard/bus_supervisor_dashboard/BookBusSeat";
import BusTicket from "../components/BusTicket";
import OwnerDashboard from "../dashboard/OwnerDashboard";
import BusManagement from "../dashboard/bus_supervisor_dashboard/BusMangemnt";


import History from "../pages/History";
import UserHistory from "../pages/UserHistory";


function Router() {
  const { userInfo } = useSelector((state) => state.user) || {};

  const roleId = userInfo?.role?.roleId;
  return (
    <Routes>
      {userInfo === null && (
        <Route path="/">
          <Route index element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/verify-emailOtp" element={<VerifyEmailOtp />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/bus-booking" element={<BusBooking />} />
          <Route path="/bus-booking" element={<AllBus />} />
          <Route path="/flightbooking" element={<FlightBookingTab />}></Route>
          ...............................
          <Route path="*" element={<NoPage />} />
        </Route>
      )}

      {roleId === 1000 && (
        <Route path="/" element={<AppLayout />}>
          <Route
            index
            element={
              <ProtectedRoutes>
                <Home />
              </ProtectedRoutes>
            }
          />
          <Route
            path="contact"
            element={
              <ProtectedRoutes>
                <Contact />
              </ProtectedRoutes>
            }
          />
          <Route
            path="room-details/:hotelId"
            element={
              <ProtectedRoutes>
                <RoomDetails />
              </ProtectedRoutes>
            }
          />
          <Route
            path="about-us"
            element={
              <ProtectedRoutes>
                <AboutUs />
              </ProtectedRoutes>
            }
          />
          <Route
            path="profile"
            element={
              <ProtectedRoutes>
                <Profile />
              </ProtectedRoutes>
            }
          />
          <Route
            path="news"
            element={
              <ProtectedRoutes>
                <News />
              </ProtectedRoutes>
            }
          />
          <Route
            index
            element={
              <ProtectedRoutes>
                <Home />
              </ProtectedRoutes>
            }
          />
          <Route
            path="contact"
            element={
              <ProtectedRoutes>
                <Contact />
              </ProtectedRoutes>
            }
          />
          <Route
            path="hotel"
            element={
              <ProtectedRoutes>
                <Hotel />
              </ProtectedRoutes>
            }
          />
          <Route
            path="flight"
            element={
              <ProtectedRoutes>
                <Flight />
              </ProtectedRoutes>
            }
          />
          <Route
            path="bus"
            element={
              <ProtectedRoutes>
                <Bus />
              </ProtectedRoutes>
            }
          />
          <Route
            path="about-us"
            element={
              <ProtectedRoutes>
                <AboutUs />
              </ProtectedRoutes>
            }
          />
          <Route
            path="profile"
            element={
              <ProtectedRoutes>
                <Profile />
              </ProtectedRoutes>
            }
          />
          <Route
            path="news"
            element={
              <ProtectedRoutes>
                <News />
              </ProtectedRoutes>
            }
          />
          <Route
            path="review-booking"
            element={
              <ProtectedRoutes>
                <ReviewBooking />
              </ProtectedRoutes>
            }
          />
          <Route
            path="history"
            element={
              <ProtectedRoutes>
                <History />
              </ProtectedRoutes>
            }
          />
          <Route
            path="train"
            element={
              <ProtectedRoutes>
                <Train />
              </ProtectedRoutes>
            }
          />
          <Route
            path="train-booking"
            element={
              <ProtectedRoutes>
                <Form />
              </ProtectedRoutes>
            }
          />
          <Route
            path="ticket"
            element={
              <ProtectedRoutes>
                <Ticket />
              </ProtectedRoutes>
            }
          />
          <Route
            path="bus-ticket"
            element={
              <ProtectedRoutes>
                <BusTicket />
              </ProtectedRoutes>
            }
          />
          <Route
            path="bus-booking"
            element={
              <ProtectedRoutes>
                <BusForm />
              </ProtectedRoutes>
            }
          />
          <Route
            path="flight-booking"
            element={
              <ProtectedRoutes>
                <FlightForm />
              </ProtectedRoutes>
            }
          />
          <Route
            path="book-bus-seat"
            element={
              <ProtectedRoutes>
                <BookBusSeat />
              </ProtectedRoutes>
            }
          />
          <Route
            path="ticket"
            element={
              <ProtectedRoutes>
                <Ticket />
              </ProtectedRoutes>
            }
          />
          {/* <Route element={<HistoryTabs />}>
            <Route path="user-history" element={<UserHistory />} />
            <Route path="train-history" element={<TrainHistory />} />
            <Route path="bus-history" element={<BusHistory />} />
            <Route path="flight-history" element={<FlightHistory />} />
          </Route> */}

          <Route path="*" element={<NoPage />} />
        </Route>
      )}

      {roleId === 1001 && (
        <Route path="/" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="/org-dashboard" element={<OrgDashboard />} />
          <Route path="org-list" element={<OrgList />} />
          <Route path="hotel-list" element={<HotelList />} />
          <Route path="user-list" element={<UserList />} />
          <Route path="admin-profile" element={<Adminprofile />} />
          <Route path="queries" element={<Queries />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}

      {roleId === 1002 && (
        <Route path="/" element={<AdminLayout />}>
          <Route index element={<OwnerDashboard />} />
          <Route path="properties" element={<OwnerProperties />} />
          <Route path="bookings" element={<Bookings />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}
      {roleId === 2001 && (
        <Route path="/" element={<AdminLayout />}>
          <Route index element={<TrainAdminDashboard />} />
          <Route path="manage-train" element={<TrainList />} />
          <Route path="supervisor-list" element={<SupervisorList />} />
          {/* <Route path="queries" element={<Queries />} /> */}
          <Route path="org-owner-profile" element={<Adminprofile />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}
      {roleId === 3001 && (
        <Route path="/" element={<AdminLayout />}>
          <Route index element={<FlightAdminDashboard />} />
          <Route path="manage-flight" element={<FlightList />} />
          <Route path="supervisor-list" element={<FlightSupervisorList />} />
          {/* <Route path="queries" element={<Queries />} /> */}
          <Route path="org-owner-profile" element={<Adminprofile />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}
      {roleId === 4001 && (
        <Route path="/" element={<AdminLayout />}>
          <Route index element={<BusAdminDashboard />} />
          <Route path="manage-bus" element={<BusList />} />
          <Route path="supervisor-list" element={<BusSupervisorList />} />
          {/* <Route path="queries" element={<Queries />} /> */}
          <Route path="org-owner-profile" element={<Adminprofile />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}
      {roleId === 2002 && (
        <>
          <Route path="/" element={<SuperVisorLayout />}>
            <Route index element={<TrainDashboard />} />
            <Route path="/train-management" element={<TrainManagement />} />
            <Route path="/train-trips" element={<TrainTrip />} />
            <Route path="/seat-management" element={<TrainSeatLayout />} />
            <Route path="*" element={<NoPage />} />
          </Route>
          <Route />
        </>
      )}
      {roleId === 4002 && (
        <>
          <Route path="/" element={<SuperVisorLayout />}>
            <Route index element={<BusDashboard />} />
            <Route path="/bus-management" element={<BusManagement />} />
            <Route path="/bus-trips" element={<BusTrip />} />
            <Route
              path="/bus-seat-management"
              element={<SupervisorBusSeat />}
            />
            <Route path="*" element={<NoPage />} />
          </Route>
          <Route />
        </>
      )}

      {roleId === 3002 && (
        <Route path="/" element={<SuperVisorLayout />}>
          <Route index element={<FlightDashboard />} />
          <Route path="/flight-management" element={<FlightMgmt />} />
          <Route path="/flight-trips" element={<FlightTripsList />} />
          <Route path="/seat-layout" element={<FlightSeatLayout />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      )}
    </Routes>
  );
}

export default Router;
