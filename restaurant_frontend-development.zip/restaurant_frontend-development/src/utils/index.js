export const validateEmail = (email) => {
  const emailPattern = /^[a-zA-Z0-9.]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return !emailPattern.test(email);
};

export const domainValidate = (email) => {
  const validDomains = [
    "ampcus.com",
    "ampcustech.com",
    "maildrop.cc",
    "yopmail.com",
  ];
  if (!validDomains.includes(email.split("@")[1])) {
    return "Invalid email domain";
  }
};
