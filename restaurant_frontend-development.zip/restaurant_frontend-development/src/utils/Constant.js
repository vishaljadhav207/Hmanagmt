export const KEY={
    TOKEN:"TOKEN",
    USER_INFO:"USER_INFO"
}

