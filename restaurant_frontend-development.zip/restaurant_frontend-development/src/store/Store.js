import { configureStore } from "@reduxjs/toolkit";
import userSlice from "../redux/userSlice";
import hotelSlice from "../redux/hotelSlice";
import roomSlice from "../redux/roomSlice";
import bookingsReducer from "../redux/bookingSlice";
import historyReducer from "../redux/userHistorySlice";
import trainReducer from "../redux/trainSlice";
import flightReducer from "../redux/flightSlice";
import busReducer from "../redux/busSlice";
import organizationReducer from "../redux/organizationSlice";
import traintripReducer from "../redux/traintripSlice";
import flighttripReducer from "../redux/flightTripsSlice";
import bustripReducer from "../redux/busTripSlice";


const store = configureStore({
  reducer: {
    user: userSlice,
    hotels: hotelSlice,
    rooms: roomSlice,
    history: historyReducer,
    bookings: bookingsReducer,
    trains: trainReducer,
    flights: flightReducer,
    buses: busReducer,
    organization: organizationReducer,
    traintrip: traintripReducer,
    flighttrip: flighttripReducer,
    bustrip : bustripReducer,
   
    
  },
});

export default store;
