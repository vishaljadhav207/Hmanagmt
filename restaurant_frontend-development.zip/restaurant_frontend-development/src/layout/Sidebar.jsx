import { Link, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChartPie,
  faUsers,
  faBuilding,
  faUser,
  faQuestionCircle,
  faCity,
  faPlane,
  faTrain,
  faBus,
} from "@fortawesome/free-solid-svg-icons";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";

const SidebarItem = ({ href, label, isCollapsed, icon, isActive }) => {
  return (
    <li className="group">
      <Link
        to={href}
        className={`flex items-center py-3 px-4 hover:bg-fuchsia-50 transition-all duration-300 ${isActive
          ? "bg-fuchsia-50 border-l-4 border-fuchsia-900 text-fuchsia-900"
          : "text-gray-600"
          }`}
      >
        <FontAwesomeIcon
          icon={icon}
          className={`w-5 h-5 ${isActive ? "text-fuchsia-900" : "text-gray-500"
            }`}
        />
        <span
          className={`text-base font-medium ml-4 ${isCollapsed ? "hidden" : "block"
            }`}
        >
          {label}
        </span>
      </Link>
    </li>
  );
};

const Sidebar = ({ isCollapsed, toggleSidebar }) => {
  const { userInfo } = useSelector((state) => state.user);
  const [menuList, setMenuList] = useState([]);
  const location = useLocation();
  console.log(userInfo);

  useEffect(() => {
    let sidebarItems = [];
    if (userInfo?.role?.roleId === 1001) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/org-list", label: "Org-List", icon: faCity },
        { href: "/hotel-list", label: "Hotel List", icon: faBuilding },
        { href: "/user-list", label: "User List", icon: faUsers },
        { href: "/queries", label: "Queries", icon: faQuestionCircle },
        { href: "/admin-profile", label: "Profile", icon: faUser },
      ];
    } else if (userInfo?.role?.roleId === 1002) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/properties", label: "My Properties", icon: faBuilding },
        { href: "/bookings", label: "Bookings", icon: faUsers },
      ];
    } else if (userInfo?.role?.roleId === 2001) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/manage-train", label: "Manage Train", icon: faBuilding },
        { href: "/supervisor-list", label: "Supervisor List", icon: faUsers },
        // { href: "/queries", label: "Queries", icon: faQuestionCircle },
        { href: "/org-owner-profile", label: "Profile", icon: faUser },
      ];
    } else if (userInfo?.role?.roleId === 3001) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/manage-flight", label: "Manage Flight", icon: faBuilding },
        { href: "/supervisor-list", label: "Supervisor List", icon: faUsers },
        // { href: "/queries", label: "Queries", icon: faQuestionCircle },
        { href: "/org-owner-profile", label: "Profile", icon: faUser },
      ];
    } else if (userInfo?.role?.roleId === 4001) {
      sidebarItems = [
        { href: "/", label: "Dashboard", icon: faChartPie },
        { href: "/manage-bus", label: "Manage Bus", icon: faBuilding },
        { href: "/supervisor-list", label: "Supervisor List", icon: faUsers },
        // { href: "/queries", label: "Queries", icon: faQuestionCircle },
        { href: "/org-owner-profile", label: "Profile", icon: faUser },
      ];
    } else if (userInfo?.role?.roleId === 2002) {
      sidebarItems = [
        { href: "/", label: "Supervisor Dashboard", icon: faChartPie },
        { href: "/train-management", label: "Train-Managements", icon: faBuilding },
          { href: "/train-trips", label: "Train Trips", icon: faUser },
        { href: "/seat-management", label: "Seat-Managements", icon: faBuilding },
        
      


        // { href: "/bookings", label: "Bookings", icon: faUsers },
      ];
    } else if (userInfo?.role?.roleId === 3002) {
      sidebarItems = [
        { href: "/", label: " Supervisor Dashboard", icon: faChartPie },

        { href: "/flight-management", label: "Flight Supervisor", icon: faPlane },
        { href: "/flight-trips", label: "Flight trips", icon: faBuilding },
        { href: "/seat-layout", label: "Flight Seats Layout", icon: faUsers },
      ];
    } else if (userInfo?.role?.roleId === 4002) {
      sidebarItems = [
        { href: "/", label: " Supervisor Dashboard", icon: faChartPie },
        { href: "/bus-management", label: "Bus-Supervisor", icon: faBus },
          { href: "/bus-trips", label: "Bus Trips", icon: faBuilding },
        { href: "/bus-seat-management", label: "Bus Seat Management", icon: faUsers },

        // { href: "/bookings", label: "Bookings", icon: faUsers },
      ];
    }

    setMenuList(sidebarItems);
  }, [userInfo]);

  return (
    <aside
      className={`${isCollapsed ? "w-16" : "w-64"
        } h-full bg-white shadow-md transition-all duration-300 ease-in-out fixed z-20`}
    >
      <div className="flex items-center justify-between p-4 border-b">
        {!isCollapsed && (
          <h2 className="text-xl font-bold text-fuchsia-950">
            {userInfo?.role?.roleId === 1002
              ? "Owner Panel"
              : userInfo?.role?.roleId === 1001
                ? "Super Admin Panel"
                : userInfo?.role?.roleId === 2001
                  ? "Train Admin Panel"
                  : userInfo?.role?.roleId === 3001
                    ? "Flight Admin Panel"
                    : userInfo?.role?.roleId === 4001
                      ? "Bus Admin Panel"
                      : userInfo?.role?.roleId === 2002
                        ? "Train Supervisor Panel"
                        : userInfo?.role?.roleId === 3002
                          ? "Flight Supervisor"
                          : userInfo?.role?.roleId === 4002
                            ? "Bus Supervisor"
                            : " "}
          </h2>
        )}
      </div>

      <nav className="mt-4">
        <ul>
          {menuList.map((item) => (
            <SidebarItem
              key={item.href}
              href={item.href}
              label={item.label}
              isCollapsed={isCollapsed}
              icon={item.icon}
              isActive={location.pathname === item.href}
            />
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
