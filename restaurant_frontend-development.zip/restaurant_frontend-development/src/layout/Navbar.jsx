import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { KEY } from "../utils/Constant";
import { logout } from "../redux/userSlice";
import { FaUserCircle } from "react-icons/fa";
import Swal from "sweetalert2";

const Navbar = ({ title }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const buttonRef = useRef(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogout = (e) => {
  e.preventDefault();
  Swal.fire({
    title: "Are you sure?",
    text: "You will be logged out of your account.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Yes, log out!",
  }).then((result) => {
    if (result.isConfirmed) {
      localStorage.removeItem(KEY.USER_INFO);
      localStorage.removeItem(KEY.TOKEN);
      dispatch(logout());
      navigate("/", { replace: true });
      Swal.fire({
        icon: "success",
        title: "Logged out!",
        showConfirmButton: false,
        timer: 1200,
      });
    }
  });
};
  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target)
      ) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  const { userInfo } = useSelector((state) => state.user);

  return (
    <header className=" ">
      <nav className="flex justify-end items-center">
        <div className="flex items-center space-x-4">
          <div className="relative" ref={buttonRef}>
            <button
              onClick={toggleDropdown}
              className="flex items-center space-x-2 focus:outline-none"
            >
              <FaUserCircle className="text-3xl text-fuchsia-950" />
            </button>

            {isDropdownOpen && (
              <div
                ref={dropdownRef}
                className="absolute right-0 mt-2 w-48 bg-fuchsia-950 rounded-md shadow-lg py-1 z-20"
              >
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-white"
                >
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
