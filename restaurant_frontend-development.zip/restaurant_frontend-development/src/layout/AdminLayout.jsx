import React, { useState, useEffect } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

const AdminLayout = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();
  const [currentPath, setCurrentPath] = useState("");

  useEffect(() => {
    setCurrentPath(location.pathname);
  }, [location]);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const getPageTitle = () => {
    switch (currentPath) {
      case "/":
        return "Dashboard";
      case "/hotel-list":
        return "Hotel Management";
      case "/user-list":
        return "User Management";
      case "/admin-profile":
        return "My Profile";
      case "/properties":
        return "My Properties";
      case "/bookings":
        return "Bookings";
      case "/manage-train":
        return "Manage Train";
      case "/manage-flight":
        return "Manage Flight";
      case "/manage-bus":
        return "Manage Bus";
      case "/supervisor-list":
        return "Supervisor List";
      case "/org-owner-profile":
        return "My Profile";

      default:
        return "Dashboard";
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar isCollapsed={isCollapsed} toggleSidebar={toggleSidebar} />

      <div
        className={`flex-1 flex flex-col overflow-hidden ${
          isCollapsed ? "ml-14" : "ml-64"
        }`}
      >
        <Navbar title={getPageTitle()} />

        <main className="flex-1 overflow-y-auto bg-gray-100 p-6">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6 flex justify-between items-center">
              <h1 className="text-2xl font-bold text-fuchsia-950">
                {getPageTitle()}
              </h1>
              <nav className="flex" aria-label="Breadcrumb">
                <ol className="inline-flex items-center space-x-1 md:space-x-2">
                  <li className="inline-flex items-center">
                    <Link
                      to="/"
                      className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-fuchsia-950"
                    >
                      <svg
                        className="w-3 h-3 mr-2.5"
                        aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                      </svg>
                      Home
                    </Link>
                  </li>
                  {currentPath !== "/" && (
                    <li>
                      <div className="flex items-center">
                        <svg
                          className="w-3 h-3 text-gray-400 mx-1"
                          aria-hidden="true"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 6 10"
                        >
                          <path
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="m1 9 4-4-4-4"
                          />
                        </svg>
                        <span className="ml-1 text-sm font-medium text-gray-700 md:ml-2 capitalize">
                          {getPageTitle()}
                        </span>
                      </div>
                    </li>
                  )}
                </ol>
              </nav>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
