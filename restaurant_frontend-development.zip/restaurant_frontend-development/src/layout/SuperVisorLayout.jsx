import React, { useState, useEffect } from "react";
import {  Outlet, useLocation, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

const SuperVisorLayout = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();
  const [currentPath, setCurrentPath] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    setCurrentPath(location.pathname);
  }, [location]);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const getPageTitle = () => {
    switch (currentPath) {
      case "/train-management":
        return "Train Management Dashboard";

        case "/train-trips":
        return "Train Management Dashboard";

        case "/seat-management":
        return "Train Management Dashboard";

      case "/flight-seat-management":
        return "Flight Management Dashboard";

      case "/flight-management":
        return "Flight Management Dashboard";

      case "/flight-trips":
        return "Flight Management Dashboard";
      
      case "/bus-seat-management":
          return "Bus Management Dashboard";
      
      case "/bus-trips":
          return "Bus Trip Management";

      case "/bus-management":
        return "Bus Supervisor";

        

        default :
        return "Dashboard";

    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar isCollapsed={isCollapsed} toggleSidebar={toggleSidebar} />

      <div
        className={`flex-1 flex flex-col overflow-hidden ${
          isCollapsed ? "ml-14" : "ml-64"
        }`}
      >
        <div className="bg-white shadow-md p-2">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-fuchsia-950">
            {getPageTitle()}
            </h1>
            <Navbar />
          </div>
        </div>

        <main className=" justify-center overflow-y-auto bg-gray-100">
          <div className="max-w-7xl mx-auto p-4">
            <div className="bg-white rounded-lg shadow-md p-2">
              <Outlet />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default SuperVisorLayout;
