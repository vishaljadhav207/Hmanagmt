
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { getTrainByUserId, deleteTrain } from "../../app/trainApi";
import { selectTrainData, selectTrainLoading, selectTrainError } from "../../redux/trainSlice";
import { FaEye, FaTrash, FaEdit, FaTrain } from 'react-icons/fa';
import { toast } from 'react-toastify';



const TrainManagement = () => {
  const dispatch = useDispatch();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrain, setSelectedTrain] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [trainToDelete, setTrainToDelete] = useState(null);
  
  const userDetails = JSON.parse(localStorage.getItem("USER_INFO"));
  const userId = userDetails?.id;
  const trainResponse = useSelector(selectTrainData);
  const trains = trainResponse?.data || []; 
  const loading = useSelector(selectTrainLoading);
  const error = useSelector(selectTrainError);

  useEffect(() => {
    if (userId) {
      dispatch(getTrainByUserId(userId));
    }
  }, [dispatch, userId]);

  const handleView = (train) => {
    setSelectedTrain(train);
    setIsModalOpen(true);
  };

  const handleDeleteClick = (trainId) => {
    setTrainToDelete(trainId);
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    try {
      await dispatch(deleteTrain(trainToDelete));
      toast.success('Train deleted successfully');
     
      dispatch(getTrainByUserId(userId));
    } catch (error) {
      const errorMsg = error.payload?.message || error.message || 'Failed to delete train';
      toast.error(errorMsg);
    } finally {
      setDeleteConfirmOpen(false);
      setTrainToDelete(null);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedTrain(null);
  };

  const closeDeleteConfirm = () => {
    setDeleteConfirmOpen(false);
    setTrainToDelete(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-fuchsia-950"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-4">
        Error loading trains: {error?.message || error?.error || error?.toString() || 'Unknown error'}
      </div>
    );
  }

  if (!trains || trains.length === 0) {
    return (
      <div className="text-center py-4">
        <p>No trains found</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold flex items-center">
          <FaTrain className="mr-2" /> Your Train List
        </h2>
      </div>

      {/* Trains Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Train No</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Train Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Railway Zone</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Coaches</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Organization</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
            
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {trains.map((train) => ( 
              <tr key={train.trainId} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-medium">{train.trainNo}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800">{train.trainName}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800">{train.railwayZone}</div>
                </td>
               
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800">{train.numberOfCoaches}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800">{train.organization?.orgName || 'N/A'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    train.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                    train.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {train.status || 'Active'}
                  </span>
                </td>
              
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* View Modal */}
      {isModalOpen && selectedTrain && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-gray-800">
                  <FaTrain className="inline mr-2" />
                  {selectedTrain.trainName} Details
                </h3>
                <button
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  &times;
                </button>
              </div>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-700 mb-2">Train Information</h4>
                  <p><span className="font-medium">Train No:</span> {selectedTrain.trainNo}</p>
                  <p><span className="font-medium">Railway Zone:</span> {selectedTrain.railwayZone}</p>
                  <p><span className="font-medium">Coaches:</span> {selectedTrain.numberOfCoaches}</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-700 mb-2">Route Information</h4>
                  <p><span className="font-medium">Departure:</span> {selectedTrain.departFrom}</p>
                  <p><span className="font-medium">Destination:</span> {selectedTrain.destination}</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg md:col-span-2">
                  <h4 className="font-semibold text-gray-700 mb-2">Organization Details</h4>
                  <p><span className="font-medium">Name:</span> {selectedTrain.organization?.orgName || 'N/A'}</p>
                  <p><span className="font-medium">Type:</span> {selectedTrain.organization?.type || 'N/A'}</p>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button
                  onClick={closeModal}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <h3 className="text-lg font-bold text-gray-800">Confirm Deletion</h3>
                <button
                  onClick={closeDeleteConfirm}
                  className="text-gray-500 hover:text-gray-700"
                >
                  &times;
                </button>
              </div>
              
              <div className="mt-4">
                <p className="text-gray-600">Are you sure you want to delete this train? This action cannot be undone.</p>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={closeDeleteConfirm}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrainManagement;