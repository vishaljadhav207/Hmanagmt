import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Card,
  CardContent,
  Container,
  Grid,
  Typography,
  MenuItem,
  Button,
} from "@mui/material";
import SeatLayoutPreview from "../component/SeatLayoutPreview";
import CustomButton from "../component/CustomButton";
import CustomSelect from "../component/CustomSelect";
import CustomTextField from "../component/CustomTextField";
import CustomSnackbar from "../component/CustomSnackbar";
import { getTrainByUserId } from "../../app/trainApi";
import seatAxios from "../../app/seatAxios";

const TrainSeatLayout = () => {
  const dispatch = useDispatch();
  const trainResponse = useSelector((state) => state.trains.trainByUserId);
  const loading = useSelector((state) => state.trains.loading);
  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id || "";
  
  const [totalSeats, setTotalSeats] = useState(48);
  const [seatType, setSeatType] = useState("2x2");
  const [layoutType, setLayoutType] = useState("Sleeper");
  const [layout, setLayout] = useState([]);
  const [selectedTrain, setSelectedTrain] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [classOptions, setClassOptions] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [hasExistingLayout, setHasExistingLayout] = useState(false);
  const [currentLayoutId, setCurrentLayoutId] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success"
  });


  const trainData = trainResponse?.data || [];

const selectedTrainObj = trainData.find(
  (train) => String(train.train_id) === String(selectedTrain)
);
const selectedTrainNo = selectedTrainObj ? selectedTrainObj.trainNo : "";

  useEffect(() => {
    if (userId) {
      dispatch(getTrainByUserId(userId));
    }
  }, [dispatch, userId]);

  // Update class options when selected train changes
  useEffect(() => {
    if (selectedTrain && trainData.length > 0) {
      const train = trainData.find((train) => train.train_id === Number(selectedTrain));
      
      if (train && train.classTypes) {
        const options = train.classTypes.map((cls) => ({
          value: cls.classId,
          label: cls.className,
        }));
        setClassOptions(options);
        if (options.length > 0) {
          setSelectedClass(options[0].value.toString());
        } else {
          setSelectedClass("");
        }
      }
    }
  }, [selectedTrain, trainData]);

  // Fetch existing seat layout when train or class changes
  useEffect(() => {
    if (selectedTrainNo && selectedClass) {
      fetchSeatLayout(selectedTrainNo, selectedClass);
    }
  }, [selectedTrainNo, selectedClass]);

  const fetchSeatLayout = async (selectedTrainNo, selectedClass) => {
    try {
      setIsSaving(true);
      const response = await seatAxios.get(
        `train-seats?trainId=${selectedTrainNo}&classId=${selectedClass}`
      );
      const seatData = response.data;

      if (!seatData || !seatData.layout) {
        setHasExistingLayout(false);
        setLayout([]);
        setSnackbar({
          open: true,
          message: "No existing seat layout found",
          severity: "info"
        });
        return;
      }

      setCurrentLayoutId(seatData.id);
      const { totalRows, seatsPerRow, seatMap } = seatData.layout;
      const newLayout = [];

      // Add entry point row
      newLayout.push([
        { number: "Entry", type: "entry" },
        ...Array(seatsPerRow).fill(null)
      ]);

      // Reconstruct layout from seatMap
      for (let row = 0; row < totalRows; row++) {
        const rowSeats = [];
        const [left, right] = seatType.split("x").map(Number);
        
        // Left seats
        for (let i = 0; i < left; i++) {
          const seatIndex = row * seatsPerRow + i;
          if (seatIndex < seatMap.length) {
            const seat = seatMap[seatIndex];
            rowSeats.push({
              number: parseInt(seat.seatNumber.substring(1)),
              seatNumber: seat.seatNumber,
              type: seat.type,
              layout: layoutType,
              available: seat.available
            });
          } else {
            rowSeats.push(null);
          }
        }

        rowSeats.push("aisle");

        // Right seats
        for (let i = 0; i < right; i++) {
          const seatIndex = row * seatsPerRow + left + i;
          if (seatIndex < seatMap.length) {
            const seat = seatMap[seatIndex];
            rowSeats.push({
              number: parseInt(seat.seatNumber.substring(1)),
              seatNumber: seat.seatNumber,
              type: seat.type,
              layout: layoutType,
              available: seat.available
            });
          } else {
            rowSeats.push(null);
          }
        }

        newLayout.push(rowSeats);
      }

      // Add toilet row
      const toiletRow = Array(seatsPerRow + 1).fill(null);
      toiletRow[0] = { type: "toilet", label: "Toilet - Left" };
      toiletRow[seatsPerRow] = { type: "toilet", label: "Toilet - Right" };
      newLayout.push(toiletRow);

      setLayout(newLayout);
      setHasExistingLayout(true);
    } catch (error) {
      console.error("Failed to fetch seat layout:", error);
      setHasExistingLayout(false);
      setLayout([]);
    } finally {
      setIsSaving(false);
    }
  };

  const generateLayout = () => {
    const [left, right] = seatType.split("x").map(Number);
    const seatsPerRow = left + right;
    const totalRows = Math.ceil(totalSeats / seatsPerRow);
    const newLayout = [];

    // Add entry point row
    newLayout.push([
      { number: "Entry", type: "entry" },
      ...Array(seatsPerRow).fill(null)
    ]);

    let seatNumber = 1;
    for (let row = 0; row < totalRows; row++) {
      const rowSeats = [];
      const deck = layoutType === "Sleeper" ? (row % 2 === 0 ? "L" : "U") : "S";

      // Left seats
      for (let i = 0; i < left; i++) {
        const seatPosition = i === 0 ? "window" : left >= 3 && i === 1 ? "middle" : "aisle";
        rowSeats.push(seatNumber <= totalSeats ? {
          number: seatNumber,
          seatNumber: `${deck}${seatNumber}`,
          type: seatPosition,
          layout: layoutType,
          available: true
        } : null);
        seatNumber++;
      }

      rowSeats.push("aisle");

      // Right seats
      for (let i = 0; i < right; i++) {
        const seatPosition = i === right - 1 ? "window" : right >= 3 && i === 1 ? "middle" : "aisle";
        rowSeats.push(seatNumber <= totalSeats ? {
          number: seatNumber,
          seatNumber: `${deck}${seatNumber}`,
          type: seatPosition,
          layout: layoutType,
          available: true
        } : null);
        seatNumber++;
      }

      newLayout.push(rowSeats);
    }

    // Add toilet row
    const toiletRow = Array(seatsPerRow + 1).fill(null);
    toiletRow[0] = { type: "toilet", label: "Toilet - Left" };
    toiletRow[seatsPerRow] = { type: "toilet", label: "Toilet - Right" };
    newLayout.push(toiletRow);

    setLayout(newLayout);
    setHasExistingLayout(false);
  };

  const toggleSeatAvailability = async (seatNumber) => {
    try {
      const updatedLayout = layout.map((row) =>
        row.map((seat) =>
          seat && seat.seatNumber === seatNumber
            ? { ...seat, available: !seat.available }
            : seat
        )
      );
      setLayout(updatedLayout);

      if (hasExistingLayout) {
        const seat = layout
          .flat()
          .find(s => s && typeof s === "object" && s.seatNumber === seatNumber);
        
        await seatAxios.patch(
          `/train-seats/update-seat?trainId=${selectedTrainNo}&classId=${selectedClass}&seatNumber=${seatNumber}&isAvailable=${!seat.available}`
        );

        setSnackbar({
          open: true,
          message: `Seat ${seatNumber} availability updated`,
          severity: "success"
        });
      }
    } catch (error) {
      console.error("Error updating seat availability:", error);
      setSnackbar({
        open: true,
        message: "Failed to update seat availability",
        severity: "error"
      });
    }
  };

const saveSeatLayout = async () => {
  if (!selectedTrain || !selectedClass || layout.length === 0) return;

  setIsSaving(true);
  try {
    const payload = {
      totalRows: layout.length - 2, // minus entry and toilet rows
      seatsPerRow: seatType.split("x").reduce((a, b) => parseInt(a) + parseInt(b)),
      seatMap: layout.flatMap((row, rowIndex) =>
        rowIndex === 0 || rowIndex === layout.length - 1
          ? []
          : row
              .filter(seat => seat && typeof seat === "object")
              .map(seat => ({
                seatNumber: seat.seatNumber,
                type: seat.type,
                available: seat.available
              }))
      ),
    };

    await seatAxios.post(
      `/train-seats/create-by-id?trainId=${selectedTrain}&classId=${selectedClass}`,
      payload
    );

    setSnackbar({
      open: true,
      message: "Seat layout saved successfully!",
      severity: "success"
    });
    setHasExistingLayout(true);
  } catch (error) {
    console.error("Error saving seat layout:", error);
    setSnackbar({
      open: true,
      message: "Failed to save seat layout",
      severity: "error"
    });
  } finally {
    setIsSaving(false);
  }
};
  const deleteSeatLayout = async () => {
    if (!currentLayoutId) return;

    try {
      setIsSaving(true);
      await seatAxios.delete(`/train-seats/delete?id=${currentLayoutId}`);

      setLayout([]);
      setHasExistingLayout(false);
      setCurrentLayoutId(null);
      setSnackbar({
        open: true,
        message: "Seat layout deleted successfully!",
        severity: "success"
      });
    } catch (error) {
      console.error("Error deleting seat layout:", error);
      setSnackbar({
        open: true,
        message: "Failed to delete seat layout",
        severity: "error"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const seatPatternOptions = [
    { value: "2x2", label: "2x2 (Standard Berth)" },
    { value: "3x2", label: "3x2 (Economy)" },
    { value: "1x1", label: "1x1 (AC Coach)" },
  ];

  const layoutTypeOptions = [
    { value: "Sleeper", label: "Sleeper" },
    { value: "Seater", label: "Seater" },
  ];

  const trainOptions = trainData.map((train) => ({
    value: train.train_id.toString(),
    label: `${train.trainName} (${train.trainNo})`,
  }));

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, textAlign: "center" }}>
        <Typography variant="h4">Train Seat Layout Manager</Typography>
        <Typography variant="subtitle1" color="text.secondary">
          (Total seats:{" "}
          {
            layout
              .flat()
              .filter(
                (seat) =>
                  seat && typeof seat === "object" && seat.type === "berth"
              ).length
          }
          )
        </Typography>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <CustomSelect
                label="Select Train"
                value={selectedTrain}
                onChange={(e) => setSelectedTrain(e.target.value)}
                options={trainOptions}
                disabled={loading || trainData.length === 0}
              >
                {loading && (
                  <MenuItem disabled value="">
                    Loading trains...
                  </MenuItem>
                )}
                {!loading && trainData.length === 0 && (
                  <MenuItem disabled value="">
                    No trains available
                  </MenuItem>
                )}
              </CustomSelect>
            </Grid>
            <Grid item xs={12} md={6}>
              <CustomSelect
                label="Class Type"
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                options={classOptions}
                disabled={!selectedTrain || classOptions.length === 0}
              >
                {!selectedTrain && (
                  <MenuItem disabled value="">
                    Select a train first
                  </MenuItem>
                )}
                {selectedTrain && classOptions.length === 0 && (
                  <MenuItem disabled value="">
                    No classes available for this train
                  </MenuItem>
                )}
              </CustomSelect>
            </Grid>
            <Grid item xs={12} md={4}>
              <CustomTextField
                label="Total Seats"
                type="number"
                value={totalSeats}
                onChange={(e) =>
                  setTotalSeats(Math.max(1, Number(e.target.value)))
                }
                disabled={hasExistingLayout}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Seat Pattern"
                value={seatType}
                onChange={(e) => setSeatType(e.target.value)}
                options={seatPatternOptions}
                disabled={hasExistingLayout}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Layout Type"
                value={layoutType}
                onChange={(e) => setLayoutType(e.target.value)}
                options={layoutTypeOptions}
                disabled={hasExistingLayout}
              />
            </Grid>
          </Grid>

          {!hasExistingLayout && (
            <CustomButton
              onClick={generateLayout}
              sx={{ mt: 2 }}
              fullWidth
              disabled={!selectedTrain || !selectedClass}
            >
              Generate Layout
            </CustomButton>
          )}
        </CardContent>
      </Card>

      {layout.length > 0 && (
        <>
          <SeatLayoutPreview
            layout={layout}
            onSeatClick={toggleSeatAvailability}
          />

          <Box sx={{ mt: 2, display: "flex", justifyContent: "flex-end", gap: 2 }}>
            {hasExistingLayout && (
              <Button
                variant="contained"
                color="error"
                onClick={deleteSeatLayout}
                disabled={isSaving}
              >
                {isSaving ? "Processing..." : "Delete Layout"}
              </Button>
            )}
            <Button
              variant="contained"
              color="primary"
              onClick={saveSeatLayout}
              disabled={isSaving || !selectedTrain || !selectedClass}
            >
              {isSaving ? "Saving..." : "Save Layout"}
            </Button>
          </Box>
        </>
      )}

      <CustomSnackbar
        open={snackbar.open}
        onClose={handleCloseSnackbar}
        message={snackbar.message}
        severity={snackbar.severity}
      />
    </Container>
  );
};

export default TrainSeatLayout;