import React from 'react';

const PropertyList = ({ properties }) => {
  return (
    <div className="mt-8">
      <h2 className="text-xl font-bold">Property List</h2>
      {properties.length === 0 ? (
        <p>No properties to display.</p>
      ) : (
        <table className="table-auto w-full mt-4">
          <thead>
            <tr>
              <th className="px-4 py-2">Number of Rooms</th>
              <th className="px-4 py-2">Room Type</th>
              <th className="px-4 py-2">Price (INR)</th>
              <th className="px-4 py-2">Location</th>
              <th className="px-4 py-2">Available From</th>
            </tr>
          </thead>
          <tbody>
            {properties.map((property, index) => (
              <tr key={index}>
                <td className="px-4 py-2">{property.number_of_rooms}</td>
                <td className="px-4 py-2">{property.room_type}</td>
                <td className="px-4 py-2">{property.price}</td>
                <td className="px-4 py-2">{property.location}</td>
                <td className="px-4 py-2">{property.available_from}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default PropertyList;
