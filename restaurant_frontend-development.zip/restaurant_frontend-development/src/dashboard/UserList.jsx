import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsers, registerOwner } from "../app/userApi.js";
import { setPage, setPageSize } from "../redux/userSlice.jsx";
import GridTable from "../components/GridTable.jsx";
import { registerOrgOwner } from "../app/userApi.js";
import { getOrganizationsByType } from "../app/organizationApis.js";
import { organizationState } from "../redux/organizationSlice.jsx";
import Swal from "sweetalert2";

const Table = () => {
  const dispatch = useDispatch();
  const {
    data: users,
    totalPages,
    totalUsersCount,
    currentPage,
    pageSize,
    loading,
  } = useSelector((state) => state.user);

  const [modalOpen, setModalOpen] = useState(false);
  const [selectedOrganization, setSelectedOrganization] = useState("");
  const [orgModal, setOrgModal] = useState(false);
  const [roleId, setRoleId] = useState(null);
  const [roleName, setRoleName] = useState("");
  const [orgDropdownOpen, setOrgDropdownOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    mobile: "",
    role: {},
  });

  const { organizationsByType } = useSelector(organizationState) || [];

  console.log(organizationsByType, "organizationsByType");

  useEffect(() => {
    dispatch(fetchUsers({ page: currentPage, size: pageSize }));
  }, [dispatch, currentPage, pageSize]);

 const handleSubmit = (e) => {
  e.preventDefault();

  if (newUser.role.roleId === 1002) {
    dispatch(registerOwner(newUser))
      .unwrap()
      .then(() => {
        dispatch(fetchUsers({ page: currentPage, size: pageSize })).unwrap();
        setNewUser({
          firstName: "",
          lastName: "",
          email: "",
          password: "",
          mobile: "",
          role: { roleId: roleId, roleName: roleName },
        });
        setModalOpen(false);
        Swal.fire({
          icon: "success",
          title: "Hotel Owner added successfully!",
          showConfirmButton: false,
          timer: 1500,
        });
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Failed to add Hotel Owner",
          text: error?.message || "Please try again.",
        });
      });
  } else {
    dispatch(registerOrgOwner(newUser))
      .unwrap()
      .then(() => {
        setNewUser({
          firstName: "",
          lastName: "",
          email: "",
          password: "",
          mobile: "",
          orgId: "",
          role: { roleId: roleId, roleName: roleName },
        });
        setSelectedOrganization("");
        setOrgModal(false);
        Swal.fire({
          icon: "success",
          title: "Organization Owner added successfully!",
          showConfirmButton: false,
          timer: 1500,
        });
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Failed to add Organization Owner",
          text: error?.message || "Please try again.",
        });
      });
  }
};
  const modifiedUsers = users.map((user) => ({
    ...user,
    id: user.userId,
    role: user.role?.roleName || "N/A",
    orgId: user.orgId || "N/A",
  }));

  const columns = [
    { field: "id", headerName: "ID", width: 150 },
    { field: "firstName", headerName: "First Name", width: 250 },
    { field: "lastName", headerName: "Last Name", width: 250 },
    { field: "email", headerName: "Email", width: 250 },
    { field: "mobile", headerName: "Phone No", width: 250 },
    { field: "role", headerName: "Role", width: 250 },
    { field: "orgId", headerName: "Organization ID", width: 250 },
  ];

  const handlePageSizeChange = (newPageSize) => {
    dispatch(setPageSize(newPageSize));
  };

  const handlePageChange = (page) => {
    dispatch(setPage(page));
  };

  const handleRoleChange = (roleId, roleName, type) => {
    setNewUser((prev) => ({
      ...prev,
      role: { roleId, roleName },
    }));
    setRoleId(roleId);
    setRoleName(roleName);
    // Open modal after role selection
    dispatch(getOrganizationsByType(type));
    setOrgDropdownOpen(false); // Close dropdown after selection
  };

  return (
    <>
      <div className="p-4">
        <div className="flex justify-end items-center mb-4">
          <div className="flex gap-4 relative">
            <button
              onClick={() => {
                setNewUser({
                  firstName: "",
                  lastName: "",
                  email: "",
                  password: "",
                  mobile: "",
                  role: { roleId: 1002, roleName: "Hotel Owner" },
                });
                setModalOpen(true);
              }}
              className="px-4 py-2 bg-fuchsia-800 text-white rounded hover:bg-fuchsia-900"
            >
              Add Hotel Owner
            </button>

            <div className="relative">
              <button
                onClick={() => setOrgDropdownOpen(true)}
                className="px-4 py-2 bg-fuchsia-800 text-white rounded hover:bg-fuchsia-900"
              >
                Add Organization Owner
              </button>

              {orgDropdownOpen && (
                <div className="absolute right-0 mt-2 bg-white border border-gray-300 rounded shadow-md w-48 z-50">
                  <button
                    className="block w-full text-left px-4 py-2 hover:bg-gray-200"
                    onClick={() => {
                      handleRoleChange(2001, "Train Admin", "RAILWAY");
                      setOrgModal(true);
                    }}
                  >
                    Train Admin
                  </button>
                  <button
                    className="block w-full text-left px-4 py-2 hover:bg-gray-200"
                    onClick={() => {
                      handleRoleChange(3001, "Airline Admin", "AIRLINE");
                      setOrgModal(true);
                    }}
                  >
                    Airline Admin
                  </button>
                  <button
                    className="block w-full text-left px-4 py-2 hover:bg-gray-200"
                    onClick={() => {
                      handleRoleChange(4001, "Bus Admin", "BUS_OPERATOR");
                      setOrgModal(true);
                    }}
                  >
                    Bus Admin
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center space-x-2">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-fuchsia-950"></div>
            <span className="text-fuchsia-950 font-medium">
              Loading users...
            </span>
          </div>
        ) : (
          <GridTable
            rowData={modifiedUsers}
            columnData={columns}
            hideAddButton={true}
            currentPage={currentPage}
            totalPages={totalPages}
            pageSize={pageSize}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            getRowId={(row) => row.userId}
          />
        )}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 bg-gray-500/75 flex justify-center items-center z-70">
          <div className="bg-white p-6 rounded-lg w-1/3">
            <h2 className="text-2xl font-semibold mb-4">
              Add New{" "}
              {newUser.role.roleName === "Hotel Owner"
                ? "Hotel"
                : "Organization"}{" "}
              Owner
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label
                  htmlFor="firstName"
                  className="block text-sm text-gray-700"
                >
                  First Name
                </label>
                <input
                  id="firstName"
                  type="text"
                  value={newUser.firstName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, firstName: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="lastName"
                  className="block text-sm text-gray-700"
                >
                  Last Name
                </label>
                <input
                  id="lastName"
                  type="text"
                  value={newUser.lastName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, lastName: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm text-gray-700">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) =>
                    setNewUser({ ...newUser, email: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="mobile" className="block text-sm text-gray-700">
                  Mobile
                </label>
                <input
                  id="mobile"
                  type="text"
                  value={newUser.mobile}
                  onChange={(e) =>
                    setNewUser({ ...newUser, mobile: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="password"
                  className="block text-sm text-gray-700"
                >
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) =>
                    setNewUser({ ...newUser, password: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  Add User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {orgModal && (
        <div className="fixed inset-0 bg-gray-500/75 flex justify-center items-center z-70">
          <div className="bg-white p-6 rounded-lg w-1/3">
            <h2 className="text-2xl font-semibold mb-4">
              Add New{" "}
              {newUser.role.roleName === "Hotel Owner"
                ? "Hotel"
                : "Organization"}{" "}
              Owner
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label
                  htmlFor="firstName"
                  className="block text-sm text-gray-700"
                >
                  First Name
                </label>
                <input
                  id="firstName"
                  type="text"
                  value={newUser.firstName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, firstName: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="lastName"
                  className="block text-sm text-gray-700"
                >
                  Last Name
                </label>
                <input
                  id="lastName"
                  type="text"
                  value={newUser.lastName}
                  onChange={(e) =>
                    setNewUser({ ...newUser, lastName: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm text-gray-700">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) =>
                    setNewUser({ ...newUser, email: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="mobile" className="block text-sm text-gray-700">
                  Mobile
                </label>
                <input
                  id="mobile"
                  type="text"
                  value={newUser.mobile}
                  onChange={(e) =>
                    setNewUser({ ...newUser, mobile: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="password"
                  className="block text-sm text-gray-700"
                >
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) =>
                    setNewUser({ ...newUser, password: e.target.value })
                  }
                  className="w-full p-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium mb-1">
                  Organization
                </label>
                <select
                  value={selectedOrganization}
                  onChange={(e) => {
                    setSelectedOrganization(e.target.value);
                    setNewUser({ ...newUser, orgId: e.target.value });
                  }}
                  className="w-full border px-3 py-2 rounded"
                >
                  <option value="">Select an Organization</option>
                  {organizationsByType?.map((org) => (
                    <option key={org.orgId} value={org.orgId}>
                      {org.orgName}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setOrgModal(false)}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  Add User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default Table;
