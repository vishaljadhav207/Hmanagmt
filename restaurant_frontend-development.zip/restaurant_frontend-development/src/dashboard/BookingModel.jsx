import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Divider from '@mui/material/Divider';
import Alert from '@mui/material/Alert';
import axios from 'axios';
import { useSelector } from 'react-redux';
import axiosInstance from '../app/axiosInstance';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '70%',
  maxWidth: 900,
  bgcolor: 'background.paper',
  border: 'none',
  borderRadius: '12px',
  boxShadow: 24,
  p: 3,
  maxHeight: '90vh',
  overflowY: 'auto',
};

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  padding: theme.spacing(2),
  borderRadius: '8px',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
}));

const statusColors = {
  PENDING: 'orange',
  BOOKED: 'green',
  REJECTED: 'red',
  CANCELLED: 'red',
  CHECKED_IN: 'blue',
  CHECKED_OUT: 'purple',
};

export default function BookingModel({ open, handleClose, bookingData, onStatusUpdate }) {
  const [status, setStatus] = React.useState(bookingData?.status || 'PENDING');
  const [notes, setNotes] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [success, setSuccess] = React.useState(null);
  const { userInfo } = useSelector((state) => state.user);
  const token = userInfo?.token;
  const baseURL=axiosInstance.defaults.baseURL;

  React.useEffect(() => {
    if (bookingData) {
      setStatus(bookingData.status);
      setNotes('');
      setError(null);
      setSuccess(null);
    }
  }, [bookingData]);

  if (!bookingData) return null;

  const handleStatusChange = (event) => {
    setStatus(event.target.value);
  };

  const handleSaveStatus = async () => {
    setIsLoading(true);
    setError(null);
    setSuccess(null);
  
    try {
      if ((status === 'REJECTED' || status === 'CANCELLED') && !notes.trim()) {
        throw new Error('Remark is required for reject or cancel actions');
      }
  
      const actionMap = {
        'REJECTED': 'reject',
        'CHECKED_IN': 'checkin',
        'CHECKED_OUT': 'checkout',
        'CANCELLED': 'cancel'
      };
  
      const action = actionMap[status];
      if (!action) {
        throw new Error('Invalid status selected');
      }
  
      const payload = {
        bookingId: bookingData.bookingId,
        action: action,
        remark: notes || 'Status updated by owner'
      };
  
      const response = await axios.put(
        `${baseURL}booking/updateBookingStatus`,
        payload,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );
  
      // Updated response handling
      if (response.data?.statusCode === 200) {
        setSuccess('Status updated successfully!');
        setTimeout(() => {
          handleClose();
          if (onStatusUpdate) onStatusUpdate();
        }, 1500);
      } else {
        // Handle error responses that still return HTTP 200
        const errorMsg = response.data?.message || 'Failed to update status';
        throw new Error(errorMsg);
      }
    } catch (error) {
      
      console.error('Error updating booking status:', error);
      
      // Improved error message extraction
      let errorMessage = error.message;
      
      if (error.response) {
        errorMessage = error.response.data?.message || 
                      error.response.data?.error || 
                      error.message;
      
        if (error.response.data?.errors) {
          errorMessage += ': ' + Object.values(error.response.data.errors).join(', ');
        }
      } else if (error.request) {
        errorMessage = 'No response received from server';
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusOptions = () => {
    // Owner can perform these actions regardless of current status
    const baseOptions = [
      { value: 'REJECTED', label: 'Reject Booking' },
      { value: 'CHECKED_IN', label: 'Check In Guest' },
      { value: 'CHECKED_OUT', label: 'Check Out Guest' },
      // { value: 'CANCELLED', label: 'Cancel Booking' }
    ];

    return baseOptions;
  };

  return (
    <Modal open={open} onClose={handleClose}>
      <Box sx={style}>
        <Typography variant="h5" component="h2" sx={{ mb: 2, fontWeight: 'bold' }}>
          Booking Details
        </Typography>
        
        <Divider sx={{ mb: 3 }} />
        
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 3 }}>{success}</Alert>}
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Item sx={{ mb: 3 }}>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Booking Information</Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Booking ID:</Typography>
                  <Typography>{bookingData.bookingId}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Current Status:</Typography>
                  <Typography sx={{ 
                    color: statusColors[bookingData.status], 
                    fontWeight: 'bold',
                    textTransform: 'capitalize'
                  }}>
                    {bookingData.status.toLowerCase().replace('_', ' ')}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Name:</Typography>
                  <Typography>{bookingData.firstName} {bookingData.lastName}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Contact:</Typography>
                  <Typography>{bookingData.mobile} / {bookingData.email}</Typography>
                </Grid>
              </Grid>
            </Item>

            <Item sx={{ mb: 3 }}>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Stay Details</Typography>
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Hotel:</Typography>
                  <Typography>{bookingData.hotelName}, {bookingData.hotelAddress}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Room Type:</Typography>
                  <Typography>{bookingData.roomType}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Check-in:</Typography>
                  <Typography>{new Date(bookingData.checkInDate).toLocaleDateString()}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Check-out:</Typography>
                  <Typography>{new Date(bookingData.checkOutDate).toLocaleDateString()}</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Guests:</Typography>
                  <Typography>{bookingData.numberOfAdults} adults</Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="subtitle2">Payment:</Typography>
                  <Typography>{bookingData.paymentMethod} ({bookingData.paymentStatus})</Typography>
                </Grid>
              </Grid>
            </Item>

            {bookingData.guest && bookingData.guest.length > 0 && (
              <Item>
                <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Guest Details</Typography>
                {bookingData.guest.map((guest, index) => (
                  <Box key={index} sx={{ mb: 2 }}>
                    <Typography><strong>Name:</strong> {guest.firstName} {guest.lastName}</Typography>
                    <Typography><strong>Phone:</strong> {guest.phoneNumber}</Typography>
                    <Typography><strong>ID:</strong> {guest.govIdType} - {guest.govIdNumber}</Typography>
                    {index < bookingData.guest.length - 1 && <Divider sx={{ my: 1 }} />}
                  </Box>
                ))}
              </Item>
            )}
          </Grid>

          <Grid item xs={12} md={4}>
            <Item>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Update Status</Typography>
              
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>Select Action</InputLabel>
                <Select
                  value={status}
                  onChange={handleStatusChange}
                  label="Select Action"
                  sx={{
                    '& .MuiSelect-select': {
                      color: statusColors[status],
                      fontWeight: 'bold',
                    },
                  }}
                >
                  {getStatusOptions().map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                fullWidth
                label="Notes"
                multiline
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                sx={{ mb: 2 }}
                required={(status === 'REJECTED' || status === 'CANCELLED')}
                error={(status === 'REJECTED' || status === 'CANCELLED') && !notes}
                helperText={(status === 'REJECTED' || status === 'CANCELLED') && !notes ? 
                  'Remarks are required for this action' : ''}
              />

              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button 
                  variant="outlined" 
                  onClick={handleClose}
                  disabled={isLoading}
                  sx={{ 
                    color: '#5A2360', 
                    borderColor: '#5A2360',
                    '&:hover': { borderColor: '#3A1640' }
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  variant="contained" 
                  onClick={handleSaveStatus}
                  disabled={isLoading || ((status === 'REJECTED' || status === 'CANCELLED') && !notes)}
                  sx={{ 
                    backgroundColor: '#5A2360',
                    '&:hover': { backgroundColor: '#3A1640' },
                    fontWeight: 'bold'
                  }}
                >
                  {isLoading ? 'Processing...' : 'Update Status'}
                </Button>
              </Box>
            </Item>

            <Item sx={{ mt: 2 }}>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Payment Details</Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography>Room Price:</Typography>
                <Typography>₹{bookingData.totalPrice}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography>Taxes & Fees:</Typography>
                <Typography>+₹{Math.round(bookingData.totalPrice * 0.18)}</Typography>
              </Box>
              <Divider sx={{ my: 1 }} />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
                <Typography>Total Amount:</Typography>
                <Typography>₹{Math.round(bookingData.totalPrice * 1.18)}</Typography>
              </Box>
            </Item>
          </Grid>
        </Grid>
      </Box>
    </Modal>
  );
}
