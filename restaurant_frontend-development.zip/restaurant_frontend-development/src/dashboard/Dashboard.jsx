import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllHotels } from "../app/hotelApi";
import { fetchUsers } from "../app/userApi";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Avatar,
  CircularProgress,
  Divider,
  Button,
  Stack,
  Chip,
  LinearProgress
} from "@mui/material";
import {
  Hotel,
  People,
  CheckCircle,
  Cancel,
  ArrowForward
} from "@mui/icons-material";
import { BarChart, PieChart } from "@mui/x-charts";
import { useNavigate } from "react-router-dom"; 


const PRIMARY_COLOR = "#5A2360";
const PRIMARY_LIGHT = "#8B5F8F";
const PRIMARY_DARK = "#3D1642";
const SECONDARY_COLOR = "#D6BAA0";
const BACKGROUND_LIGHT = "#F9F5FA";
const BACKGROUND_DARK = "#EDE5EF";
const TEXT_PRIMARY = "#2E2E2E";
const TEXT_SECONDARY = "#5D5D5D";

const Dashboard = () => {
  const dispatch = useDispatch();
    const navigate = useNavigate(); 
  const hotels = useSelector((state) => state.hotels.hotels || []);
  const users = useSelector((state) => state.user.data || []);
  const [activeUsers, setActiveUsers] = useState(0);

  useEffect(() => {
    dispatch(getAllHotels({ page: 0, size: 100 }));
    dispatch(fetchUsers({ page: 0, size: 100 }));
  }, [dispatch]);

  useEffect(() => {
    const activeCount = Math.round(users.length * 0.75);
    setActiveUsers(activeCount);
  }, [users]);

  if (!hotels || !users) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: BACKGROUND_LIGHT
        }}
      >
        <CircularProgress size={60} />
      </Box>
    );
  }

  const activePercentage = Math.round((activeUsers / Math.max(users.length, 1)) * 100);

  return (
    <Box sx={{ 
      p: 4,
      backgroundColor: BACKGROUND_LIGHT,
      minHeight: '100'
    }}>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Hotel fontSize="large" />}
            label="Total Hotels"
            value={hotels.length}
            color={PRIMARY_COLOR}
            actionText="Manage Hotels"
            actionIcon={<ArrowForward />}
             onClick={() => navigate("/hotel-list")}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<People fontSize="large" />}
            label="Total Users"
            value={users.length}
            color={SECONDARY_COLOR}
            actionText="Manage Users"
            actionIcon={<ArrowForward />}
             onClick={() => navigate("/user-list")}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<CheckCircle fontSize="large" />}
            label="Active Users"
            value={activeUsers}
            percentage={activePercentage}
            color="#388e3c"
            chipColor="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Cancel fontSize="large" />}
            label="Inactive Users"
            value={users.length - activeUsers}
            percentage={100 - activePercentage}
            color="#d32f2f"
            chipColor="error"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card sx={{ 
            boxShadow: 4,
            height: '100%',
            transition: 'all 0.3s ease',
            '&:hover': {
              boxShadow: 6
            }
          }}>
            <CardContent>
              <Typography variant="h5" fontWeight="bold" sx={{ color: PRIMARY_COLOR, mb: 2 }}>
                Hotels and Users Overview
              </Typography>
              <Divider sx={{ mb: 3 }} />
              <Box sx={{ height: 300 }}>
                <BarChart
                  series={[
                    {
                      data: [hotels.length, users.length],
                      label: 'Count',
                      color: PRIMARY_COLOR,
                    }
                  ]}
                  xAxis={[{ scaleType: 'band', data: ['Hotels', 'Users'] }]}
                  height={300}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card sx={{ 
            boxShadow: 4,
            height: '100%',
            transition: 'all 0.3s ease',
            '&:hover': {
              boxShadow: 6
            }
          }}>
            <CardContent>
              <Typography variant="h5" fontWeight="bold" sx={{ color: PRIMARY_COLOR, mb: 2 }}>
                User Status Distribution
              </Typography>
              <Divider sx={{ mb: 3 }} />
              <Box sx={{ height: 300 }}>
                <PieChart
                  series={[
                    {
                      data: [
                        { value: activeUsers, label: 'Active Users', color: PRIMARY_COLOR },
                        { value: users.length - activeUsers, label: 'Inactive Users', color: SECONDARY_COLOR },
                      ],
                      innerRadius: 30,
                      outerRadius: 100,
                      paddingAngle: 5,
                      cornerRadius: 5,
                    }
                  ]}
                  height={300}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

const SummaryCard = ({
  icon,
  label,
  value,
  percentage,
  chipColor = "default",
  color,
  onClick,
  actionText,
  actionIcon
}) => {
  return (
    <Card
      sx={{
        height: "100%",
        backgroundColor: `${color}08`,
        borderLeft: `4px solid ${color}`,
        boxShadow: 3,
        transition: "all 0.3s ease",
        "&:hover": {
          transform: onClick ? "translateY(-5px)" : "none",
          boxShadow: 6,
          cursor: onClick ? "pointer" : "default",
        },
      }}
      onClick={onClick}
    >
      <CardContent>
        <Stack direction="row" alignItems="center" spacing={2}>
          <Avatar sx={{ 
            bgcolor: `${color}20`,
            color: color,
            width: 56, 
            height: 56 
          }}>
            {icon}
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="subtitle1" sx={{ color: TEXT_SECONDARY }}>
              {label}
            </Typography>
            <Typography variant="h3" fontWeight="bold" sx={{ color: TEXT_PRIMARY }}>
              {value}
            </Typography>
          </Box>
        </Stack>
        
        {percentage !== undefined && (
          <Box sx={{ mt: 2 }}>
            <LinearProgress 
              variant="determinate" 
              value={percentage} 
              sx={{ 
                height: 8, 
                borderRadius: 4,
                mb: 1,
                backgroundColor: BACKGROUND_DARK,
                '& .MuiLinearProgress-bar': {
                  backgroundColor: color
                }
              }} 
            />
            <Typography variant="caption" sx={{ color: TEXT_SECONDARY }}>
              {percentage}% of total
            </Typography>
          </Box>
        )}
        
        {actionText && (
          <Button
            fullWidth
            variant="text"
            endIcon={actionIcon}
            sx={{
              mt: 2,
              color: color,
              fontWeight: 'bold',
              justifyContent: 'flex-end',
              '&:hover': {
                backgroundColor: `${color}10`
              }
            }}
          >
            {actionText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default Dashboard;