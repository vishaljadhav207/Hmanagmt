import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getTrainsByOrgId, fetchTrainSupervisors } from "../app/trainApi";
import {
  selectAllTrains,
  selectTrainStatus,
  selectTrainSupervisors,
} from "../redux/trainSlice";
import {
  Box,
  Typography,
  Grid,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  CircularProgress,
  Card,
  CardContent,
  Stack,
  Chip,
  LinearProgress,
  Divider,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import {
  Train as TrainIcon,
  Engineering,
  ArrowForward,
  ArrowRightAlt,
  DirectionsRailway,
  People,
  Schedule,
} from "@mui/icons-material";

const PRIMARY_COLOR = "#5A2360";
const PRIMARY_LIGHT = "#8B5F8F";
const PRIMARY_DARK = "#3D1642";
const SECONDARY_COLOR = "#FFA000";
const BACKGROUND_LIGHT = "#F9F5FA";
const BACKGROUND_DARK = "#EDE5EF";
const TEXT_PRIMARY = "#2E2E2E";
const TEXT_SECONDARY = "#5D5D5D";

const TrainAdminDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { userInfo: user } = useSelector((state) => state.user);

  const trains = useSelector(selectAllTrains) || [];
  console.log("Trains in Dashboard:", trains);
  const status = useSelector(selectTrainStatus);
  const supervisors = useSelector(selectTrainSupervisors) || [];
  console.log("Supervisors in Dashboard:", supervisors);

  const activeTrains = trains.filter(
    (train) => (train.status || "ACTIVE") === "ACTIVE"
  ).length;
  const totalSupervisors =
    supervisors.length > 0
      ? supervisors.length
      : new Set(trains.map((t) => t.userId)).size;

  const activePercentage = Math.round(
    (activeTrains / Math.max(trains.length, 1)) * 100
  );

  useEffect(() => {
    if (user?.orgId) {
      dispatch(getTrainsByOrgId({ orgId: user.orgId, page: 0, size: 5 }));
      dispatch(fetchTrainSupervisors());
    }
  }, [dispatch, user?.orgId]);

  if (status === "loading") {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: BACKGROUND_LIGHT,
        }}
      >
        <CircularProgress size={60} sx={{ color: PRIMARY_COLOR }} />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: 4,
        backgroundColor: BACKGROUND_LIGHT,
        minHeight: "100",
      }}
    >
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<TrainIcon fontSize="large" />}
            label="Total Trains"
            value={trains.length}
            color={PRIMARY_COLOR}
            onClick={() => navigate("/manage-train")}
            actionText="Manage Trains"
            actionIcon={<ArrowForward />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<DirectionsRailway fontSize="large" />}
            label="Active Trains"
            value={activeTrains}
            percentage={activePercentage}
            color="#388e3c"
            chipColor="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Engineering fontSize="large" />}
            label="Supervisors"
            value={totalSupervisors}
            color={SECONDARY_COLOR}
            onClick={() => navigate("/supervisor-list")}
            actionText="View All"
            actionIcon={<People />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Schedule fontSize="large" />}
            label="Avg Coaches"
            value={
              trains.length > 0
                ? Math.round(
                    trains.reduce(
                      (sum, train) =>
                        sum + parseInt(train.numberOfCoaches || 0),
                      0
                    ) / trains.length
                  )
                : 0
            }
            color={PRIMARY_LIGHT}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card
            sx={{
              boxShadow: 4,
              transition: "all 0.3s ease",
              backgroundColor: "white",
              "&:hover": {
                boxShadow: 6,
              },
            }}
          >
            <CardContent>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 3,
                }}
              >
                <Typography
                  variant="h5"
                  fontWeight="bold"
                  sx={{ color: PRIMARY_DARK }}
                >
                  Recent Trains
                </Typography>
                <Button
                  variant="outlined"
                  sx={{
                    color: PRIMARY_COLOR,
                    borderColor: PRIMARY_COLOR,
                    textTransform: "none",
                    fontWeight: "bold",
                    "&:hover": {
                      borderColor: PRIMARY_DARK,
                      color: PRIMARY_DARK,
                      backgroundColor: `${PRIMARY_COLOR}10`,
                    },
                  }}
                  onClick={() => navigate("/manage-train")}
                  endIcon={<ArrowForward />}
                >
                  View All Trains
                </Button>
              </Box>

              <Divider sx={{ mb: 3 }} />

              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow
                      sx={{
                        backgroundColor: BACKGROUND_DARK,
                        "& th": {
                          fontWeight: "bold",
                          color: TEXT_SECONDARY,
                        },
                      }}
                    >
                      <TableCell>Train No</TableCell>
                      <TableCell>Train Name</TableCell>
                      <TableCell>Railway Zone</TableCell>
                      <TableCell>Route</TableCell>
                      <TableCell>Coaches</TableCell>
                      <TableCell align="center">Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {trains.slice(0, 5).map((train, idx) => (
                      <TableRow
                        key={train.trainNo || train.train_id || idx}
                        sx={{
                          transition: "background-color 0.2s",
                          "&:hover": {
                            backgroundColor: BACKGROUND_DARK,
                          },
                        }}
                      >
                        <TableCell sx={{ color: TEXT_PRIMARY }}>
                          
                            {train.trainNo || train.train_no}
                         
                        </TableCell>
                        <TableCell sx={{ color: TEXT_PRIMARY }}>
                          {train.trainName || train.train_name}
                        </TableCell>
                        <TableCell sx={{ color: TEXT_SECONDARY }}>
                          <Chip
                            label={train.railwayZone}
                            size="small"
                            variant="outlined"
                            sx={{
                              color: PRIMARY_DARK,
                              borderColor: PRIMARY_DARK,
                              fontWeight: "medium",
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              gap: 1,
                            }}
                          >
                            <Chip
                              label={train.departFrom}
                              size="small"
                              variant="outlined"
                              sx={{
                                color: PRIMARY_COLOR,
                                borderColor: PRIMARY_COLOR,
                                fontWeight: "bold",
                              }}
                            />
                            <ArrowRightAlt sx={{ color: PRIMARY_COLOR }} />
                            <Chip
                              label={train.destination}
                              size="small"
                              variant="outlined"
                              sx={{
                                color: PRIMARY_COLOR,
                                borderColor: PRIMARY_COLOR,
                                fontWeight: "bold",
                              }}
                            />
                          </Box>
                        </TableCell>
                        <TableCell sx={{ color: TEXT_SECONDARY }}>
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              gap: 1,
                            }}
                          >
                            <Chip
                              label={`${train.numberOfCoaches} coaches`}
                              size="small"
                              sx={{
                                backgroundColor: `${PRIMARY_COLOR}10`,
                                color: PRIMARY_DARK,
                                fontWeight: "bold",
                              }}
                            />
                          </Box>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={train.status || "ACTIVE"}
                            color={
                              train.status === "ACTIVE"
                                ? "success"
                                : train.status === "MAINTENANCE"
                                ? "warning"
                                : "error"
                            }
                            size="small"
                            sx={{
                              fontWeight: "bold",
                              minWidth: 80,
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

const SummaryCard = ({
  icon,
  label,
  value,
  percentage,
  chipColor = "default",
  color,
  onClick,
  actionText,
  actionIcon,
}) => {
  return (
    <Card
      sx={{
        height: "100%",
        backgroundColor: "white",
        borderLeft: `4px solid ${color}`,
        boxShadow: 3,
        transition: "all 0.3s ease",
        "&:hover": {
          transform: onClick ? "translateY(-5px)" : "none",
          boxShadow: 6,
          cursor: onClick ? "pointer" : "default",
        },
      }}
      onClick={onClick}
    >
      <CardContent>
        <Stack direction="row" alignItems="center" spacing={2}>
          <Avatar
            sx={{
              bgcolor: `${color}10`,
              color: color,
              width: 56,
              height: 56,
            }}
          >
            {icon}
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="subtitle1" sx={{ color: TEXT_SECONDARY }}>
              {label}
            </Typography>
            <Typography
              variant="h4"
              fontWeight="bold"
              sx={{ color: TEXT_PRIMARY }}
            >
              {value}
            </Typography>
          </Box>
        </Stack>

        {percentage ? (
          <Box sx={{ mt: 2 }}>
            <LinearProgress
              variant="determinate"
              value={percentage}
              sx={{
                height: 8,
                borderRadius: 4,
                mb: 1,
                backgroundColor: BACKGROUND_DARK,
                "& .MuiLinearProgress-bar": {
                  backgroundColor: color,
                },
              }}
            />
            <Typography variant="caption" sx={{ color: TEXT_SECONDARY }}>
              {percentage}% of total
            </Typography>
          </Box>
        ) : null}

        {actionText && (
          <Button
            fullWidth
            variant="text"
            endIcon={actionIcon}
            sx={{
              mt: 2,
              color: color,
              fontWeight: "bold",
              justifyContent: "flex-end",
              "&:hover": {
                backgroundColor: `${color}10`,
              },
            }}
          >
            {actionText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default TrainAdminDashboard;
