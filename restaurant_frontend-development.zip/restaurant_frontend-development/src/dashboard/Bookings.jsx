import * as React from 'react';
import { useEffect, useState } from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import VisibilityIcon from '@mui/icons-material/Visibility';
import Stack from '@mui/material/Stack';
import TablePagination from '@mui/material/TablePagination';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import ArrowUpward from '@mui/icons-material/ArrowUpward';
import ArrowDownward from '@mui/icons-material/ArrowDownward';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import BookingModel from './BookingModel';
import axiosInstance from '../app/axiosInstance';
import InputBase from '@mui/material/InputBase';
import SearchIcon from '@mui/icons-material/Search';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { fetchHotelById } from '../app/hotelApi';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: '#5A2360',
    color: theme.palette.common.white,
    textAlign: 'center',
    cursor: 'pointer',
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    textAlign: 'center',
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: '#f5f5f5',
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '20ch',
      '&:focus': {
        width: '30ch',
      },
    },
  },
}));

export default function Bookings() {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [sortBy, setSortBy] = useState('');
  const [sortDirection, setSortDirection] = useState('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const { userInfo } = useSelector((state) => state.user);
  const token = userInfo?.token;
  const baseURL = axiosInstance.defaults.baseURL;
  const user = useSelector((state) => state.user.userInfo);
  const userId = user?.id;

  const { selectedHotel } = useSelector((state) => state.hotels);
  const hotelId = selectedHotel?.data?.[0]?.hotelId;

  const dispatch = useDispatch();
  useEffect(() => {
    if (userId) {
      dispatch(fetchHotelById(userId));
    }
  }, [dispatch, userId]);


  const fetchBookings = async (page, size, sortBy, sortDirection, searchTerm = '') => {
    try {
      let url = `${baseURL}booking/bookingsByHotelId?page=${page}&size=${size}&hotelId=${hotelId}`;

      if (sortBy) {
        url += `&sortBy=${sortBy}&sortDirection=${sortDirection}`;
      }

      if (searchTerm) {
        url += `&firstName=${searchTerm}`;
      }

      const response = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.statusCode === 200) {
        setRows(response.data.data.data);
        setTotal(response.data.data.total);
      }
    } catch (error) {
      console.error("Error fetching bookings:", error);
    }
  };

  useEffect(() => {
    if (hotelId) {
      fetchBookings(page, rowsPerPage, sortBy, sortDirection, searchTerm);
    }
  }, [page, rowsPerPage, sortBy, sortDirection, searchTerm, hotelId]);

  const handleView = (rowData) => {
    setSelectedBooking(rowData);
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
    setSelectedBooking(null);
  };

  const handleStatusUpdate = () => {
    fetchBookings(page, rowsPerPage, sortBy, sortDirection, searchTerm);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSort = (field) => {
    console.log(`Sorting by ${field}, current direction: ${sortDirection}`);
    const newSortDirection = sortBy === field && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortBy(field);
    setSortDirection(newSortDirection);
  };

  const handleSearch = (e) => {
    if (e.key === 'Enter' || e.type === 'click') {
      setPage(0);
      fetchBookings(0, rowsPerPage, sortBy, sortDirection, searchTerm);
    }
  };

  const emptyRows = rowsPerPage - Math.min(rowsPerPage, total - page * rowsPerPage);

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2, gap: 2 }}>
        <Search sx={{ display: 'flex', alignItems: 'center', position: 'relative', width: '100%' }}>
          <StyledInputBase
            placeholder="Search by name..."
            inputProps={{ 'aria-label': 'search' }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={handleSearch}
          />
          <IconButton
            onClick={handleSearch}
            sx={{ position: 'absolute', right: 0, top: 0, height: '100%' }}
          >
            <SearchIcon />
          </IconButton>
        </Search>
      </Box>

      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell onClick={() => handleSort('bookingId')}>Booking ID</StyledTableCell>
                <StyledTableCell onClick={() => handleSort('firstName')}>
                  Name
                  {sortBy === 'firstName' && (sortDirection === 'asc' ? <ArrowUpward fontSize="small" /> : <ArrowDownward fontSize="small" />)}
                </StyledTableCell>
                <StyledTableCell>Email</StyledTableCell>
                <StyledTableCell>Phone</StyledTableCell>
                <StyledTableCell onClick={() => handleSort('roomType')}>Room Type</StyledTableCell>
                <StyledTableCell onClick={() => handleSort('checkInDate')}>
                  Check-in/Check-out
                  {sortBy === 'checkInDate' && (sortDirection === 'asc' ? <ArrowUpward fontSize="small" /> : <ArrowDownward fontSize="small" />)}
                </StyledTableCell>
                <StyledTableCell onClick={() => handleSort('status')}>
                  Status
                  {sortBy === 'status' && (sortDirection === 'asc' ? <ArrowUpward fontSize="small" /> : <ArrowDownward fontSize="small" />)}
                </StyledTableCell>
                <StyledTableCell>View</StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>

              {rows.map((row) => (
                <StyledTableRow key={row.bookingId}>
                  <StyledTableCell>{row.bookingId}</StyledTableCell>
                  <StyledTableCell>{row.firstName} {row.lastName}</StyledTableCell>
                  <StyledTableCell>{row.email}</StyledTableCell>
                  <StyledTableCell>{row.mobile}</StyledTableCell>
                  <StyledTableCell>{row.roomType}</StyledTableCell>
                  <StyledTableCell>
                    {new Date(row.checkInDate).toLocaleDateString()} - {new Date(row.checkOutDate).toLocaleDateString()}
                  </StyledTableCell>
                  <StyledTableCell>{row.status}</StyledTableCell>
                  <StyledTableCell>
                    <Stack direction="row" spacing={1} justifyContent="center">
                      <Tooltip title="View">
                        <IconButton color="primary" onClick={() => handleView(row)}>
                          <VisibilityIcon />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </StyledTableCell>
                </StyledTableRow>
              ))}
              {emptyRows > 0 && (
                <StyledTableRow style={{ height: 53 * emptyRows }}>
                  <StyledTableCell colSpan={8} />
                </StyledTableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={total}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
      <BookingModel
        open={modalOpen}
        handleClose={handleCloseModal}
        bookingData={selectedBooking}
        onStatusUpdate={handleStatusUpdate}
      />
    </>
  );
}