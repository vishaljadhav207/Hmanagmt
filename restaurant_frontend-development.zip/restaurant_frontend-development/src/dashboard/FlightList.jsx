import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import {
  getFlightByOrgId,
  fetchFlightSupervisors,
  saveFlight,
  updateFlight,
  deleteFlight,
} from "../app/flightApi";
import {
  setFlightCurrentPage,
  setFlightPageSize,
  clearError,
  setSortBy,
  setSortDir,
} from "../redux/flightSlice";
import AppButton from "../components/AppButton";
import {
  FaEdit,
  FaTrash,
  FaEye,
  FaPlus,
  FaPlane,
  FaSearch,
  FaCalendarAlt,
  FaClock,
  FaUserTie,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import AddModelFlight from "./AddModelFlight";
import Swal from "sweetalert2";

// MUI Components
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TablePagination,
  IconButton,
  LinearProgress,
  Typography,
  Box,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Avatar,
  TextField,
  InputAdornment,
  Chip,
  Divider,
  Tooltip,
} from "@mui/material";
import { styled } from "@mui/material/styles";

// Custom styled components
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontWeight: 500,
  padding: theme.spacing(1.5),
  borderBottom: `1px solid ${theme.palette.divider}`,
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td": {
    borderBottom: 0,
  },
}));

const DetailCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[1],
  height: "100%",
  display: "flex",
  flexDirection: "column",
  backgroundColor: theme.palette.background.paper,
}));

const FlightList = () => {
  const dispatch = useDispatch();
  const { userInfo: user } = useSelector((state) => state.user);
  const {
    flights,
    status: flightStatus,
    supervisors,
    error,
    currentPage,
    totalPages,
    totalItems,
    pageSize,
    sortBy,
    sortDir,
  } = useSelector((state) => state.flights);

  const safeFlights = Array.isArray(flights) ? flights : [];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredFlights = safeFlights.filter(
    (flight) =>
      flight.flight_no?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      flight.airline?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      flight.departFrom?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      flight.destination?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const refreshFlights = () => {
    if (user?.orgId) {
      dispatch(
        getFlightByOrgId({
          orgId: user.orgId,
          pageNumber: currentPage,
          pageSize,
          sortBy,
          sortDir,
        })
      );
    }
  };

  useEffect(() => {
    refreshFlights();
    dispatch(fetchFlightSupervisors());
  }, [dispatch, user?.orgId, currentPage, pageSize, sortBy, sortDir]);

  const handleSort = (column) => {
    if (sortBy === column) {
      const newDir = sortDir === "asc" ? "desc" : "asc";
      dispatch(setSortDir(newDir));
    } else {
      dispatch(setSortBy(column));
      dispatch(setSortDir("asc"));
    }

    dispatch(setFlightCurrentPage(0));
  };

  const renderSortIcon = (column) => {
    if (sortBy !== column)
      return <FaSort style={{ marginLeft: 5, opacity: 0.3 }} />;
    return sortDir === "asc" ? (
      <FaSortUp style={{ marginLeft: 5 }} />
    ) : (
      <FaSortDown style={{ marginLeft: 5 }} />
    );
  };

  const handleAddFlight = () => {
    setSelectedFlight(null);
    setIsModalOpen(true);
  };

  const handleSaveFlight = async (flightData) => {
    try {
      await dispatch(saveFlight(flightData)).unwrap();
      refreshFlights();
      setIsModalOpen(false);
      dispatch(clearError());
      Swal.fire({
        title: "Success!",
        text: "Flight added successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to add flight",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleUpdateFlight = async (flightData) => {
    if (!selectedFlight?.flight_id) return;

    try {
      await dispatch(
        updateFlight({
          flightId: selectedFlight.flight_id,
          ...flightData,
        })
      ).unwrap();
      refreshFlights();
      setIsModalOpen(false);
      dispatch(clearError());
      Swal.fire({
        title: "Success!",
        text: "Flight updated successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to update flight",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleViewDetails = (flight) => {
    setSelectedFlight(flight);
    setIsViewModalOpen(true);
  };

  const handleDeleteClick = (flightId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#5A2360",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        handleConfirmDelete(flightId);
      }
    });
  };

  const handleConfirmDelete = async (flightId) => {
    try {
      await dispatch(deleteFlight(flightId)).unwrap();
      refreshFlights();
      Swal.fire({
        title: "Deleted!",
        text: "Flight has been deleted successfully.",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to delete flight",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleCloseViewModal = () => setIsViewModalOpen(false);
  const handlePageChange = (event, newPage) => {
    dispatch(setFlightCurrentPage(newPage));
  };

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    dispatch(setFlightPageSize(newSize));
    dispatch(setFlightCurrentPage(0));
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <Box sx={{ p: { xs: 1, md: 3 } }}>
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
          gap: 2,
        }}
      >
        <TextField
          placeholder="Search flights..."
          variant="outlined"
          size="small"
          sx={{
            width: { xs: "100%", md: "400px" },
            backgroundColor: "background.paper",
            borderRadius: 1,
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <FaSearch color="action" />
              </InputAdornment>
            ),
          }}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <AppButton
          title="Add Flight"
          onClick={handleAddFlight}
          icon={<FaPlus style={{ marginRight: 8 }} />}
          className="bg-[#5A2360] text-white hover:bg-[#6B2D72] px-6 py-3 text-base"
          sx={{
            minWidth: 220,
            height: 50,
            borderRadius: 1,
            fontSize: "1.05rem",
            padding: "0 24px",
          }}
        />
      </Box>

      <Paper
        sx={{
          width: "100%",
          overflow: "hidden",
          mb: 2,
          borderRadius: 2,
          boxShadow: 1,
        }}
      >
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: "primary.main" }}>
                <StyledTableCell
                  onClick={() => handleSort("flight_no")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Flight No
                    </Typography>
                    {renderSortIcon("flight_no")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("airline")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Airline
                    </Typography>
                    {renderSortIcon("airline")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("departFrom")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Departure
                    </Typography>
                    {renderSortIcon("departFrom")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("destination")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Destination
                    </Typography>
                    {renderSortIcon("destination")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell>
                  <Typography color="common.white" fontWeight="bold">
                    Organization
                  </Typography>
                </StyledTableCell>
                <StyledTableCell>
                  <Typography color="common.white" fontWeight="bold">
                    Organization Type
                  </Typography>
                </StyledTableCell>
                <StyledTableCell align="right">
                  <Typography color="common.white" fontWeight="bold">
                    Actions
                  </Typography>
                </StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {flightStatus === "loading" ? (
                <TableRow>
                  <TableCell colSpan={7}>
                    <LinearProgress />
                    <Typography align="center" sx={{ py: 2 }}>
                      Loading flights...
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : filteredFlights.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                    <Box textAlign="center" py={4}>
                      <FaPlane
                        size={48}
                        color="#5A2360"
                        style={{ opacity: 0.5 }}
                      />
                      <Typography variant="h6" color="textSecondary" mt={2}>
                        {searchTerm
                          ? "No matching flights found"
                          : "No flights available"}
                      </Typography>
                      {!searchTerm && (
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={handleAddFlight}
                          sx={{ mt: 4 }}
                        >
                          Add Your First Flight
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                filteredFlights.map((flight) => (
                  <StyledTableRow key={flight.flight_id} hover>
                    <StyledTableCell>
                      <Tooltip title={`Flight ID: ${flight.flight_id}`}>
                        <Chip
                          label={flight.flight_no || "N/A"}
                          color="primary"
                          size="small"
                          sx={{ fontWeight: 600 }}
                        />
                      </Tooltip>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography fontWeight="medium">
                        {flight.airline || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {flight.departFrom || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {flight.destination || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {flight.organization?.orgName || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {flight.organization?.type || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell align="right">
                      <Box display="flex" justifyContent="flex-end" gap={1}>
                        <Tooltip title="View details">
                          <IconButton
                            onClick={() => handleViewDetails(flight)}
                            color="info"
                            size="small"
                          >
                            <FaEye />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit flight">
                          <IconButton
                            onClick={() => {
                              setSelectedFlight({
                                ...flight,
                                flightId: flight.flight_id,
                              });
                              setIsModalOpen(true);
                            }}
                            color="warning"
                            size="small"
                          >
                            <FaEdit />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete flight">
                          <IconButton
                            onClick={() => handleDeleteClick(flight.flight_id)}
                            color="error"
                            size="small"
                          >
                            <FaTrash />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </StyledTableCell>
                  </StyledTableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Divider />

        <Box
          sx={{
            p: 2,
            display: "flex",
            flexDirection: { xs: "column", sm: "row" },
            justifyContent: "space-between",
            alignItems: "center",
            gap: 2,
          }}
        >
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Rows per page</InputLabel>
            <Select
              value={pageSize}
              onChange={handlePageSizeChange}
              label="Rows per page"
            >
              {[5, 10, 25, 50].map((size) => (
                <MenuItem key={size} value={size}>
                  {size}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TablePagination
            component="div"
            count={totalItems}
            page={currentPage}
            onPageChange={handlePageChange}
            rowsPerPage={pageSize}
            rowsPerPageOptions={[]}
            labelDisplayedRows={({ from, to, count }) =>
              `${from}-${to} of ${count}`
            }
          />
        </Box>
      </Paper>

      {/* Add/Edit Flight Modal */}
      {isModalOpen && (
        <AddModelFlight
          open={isModalOpen} // Add this
          flight={selectedFlight}
          onSave={selectedFlight ? handleUpdateFlight : handleSaveFlight}
          onCancel={() => setIsModalOpen(false)}
          onSuccess={() => {
            refreshFlights();
            setIsModalOpen(false);
          }}
        />
      )}

      {/* View Flight Details Modal */}
      <Dialog
        open={isViewModalOpen}
        onClose={handleCloseViewModal}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            overflow: "hidden",
          },
        }}
      >
        <DialogTitle
          sx={{
            backgroundColor: "primary.main",
            color: "white",
            display: "flex",
            alignItems: "center",
            gap: 2,
            py: 2,
          }}
        >
          <FaPlane />
          <Typography variant="h6" fontWeight="bold">
            Flight Details: {selectedFlight?.flight_no}
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ p: 3 }}>
          {selectedFlight && (
            <Box
              sx={{
                display: "flex",
                flexWrap: "nowrap",
                overflowX: "auto",
                gap: 3,
                mt: 2,
                pb: 2,
              }}
            >
              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  FLIGHT INFORMATION
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Flight ID"
                  value={selectedFlight.flight_id}
                />
                <DetailItem
                  label="Flight Number"
                  value={selectedFlight.flight_no}
                />
                <DetailItem label="Airline" value={selectedFlight.airline} />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  ROUTE DETAILS
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Departure"
                  value={selectedFlight.departFrom || "N/A"}
                />
                <DetailItem
                  label="Destination"
                  value={selectedFlight.destination || "N/A"}
                />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  ORGANIZATION
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Organization Name"
                  value={selectedFlight.organization?.orgName || "N/A"}
                />
                <DetailItem
                  label="Organization Type"
                  value={selectedFlight.organization?.type || "N/A"}
                />
              </DetailCard>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={handleCloseViewModal}
            variant="outlined"
            color="primary"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

const DetailItem = ({ label, value }) => (
  <Box sx={{ mb: 2 }}>
    <Typography variant="subtitle2" color="textSecondary">
      {label}
    </Typography>
    <Typography variant="body1" sx={{ mt: 0.5, wordBreak: "break-word" }}>
      {value || (
        <Typography component="span" color="text.disabled">
          Not available
        </Typography>
      )}
    </Typography>
  </Box>
);

export default FlightList;
