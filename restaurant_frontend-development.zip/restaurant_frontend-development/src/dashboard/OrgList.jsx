import React, { useState, useEffect } from "react";
import { FaEye, FaTrash, FaPlus, FaEdit } from "react-icons/fa";
import { getUserbyRole, saveOrganization } from "../app/userApi";
import { fetchOrganizations } from "../app/organizationApis";
import { useDispatch, useSelector } from "react-redux";
import { userState } from "../redux/userSlice";
import { organizationState } from "../redux/organizationSlice";
import axios from "axios";
import Swal from "sweetalert2";

function OrgList() {
  const [orgType, setOrgType] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [type, setType] = useState(null);
  const [orgName, setOrgName] = useState("");
  const [selectedAdmin, setSelectedAdmin] = useState("");
  const [editingOrgId, setEditingOrgId] = useState(null);
  const [saveError, setSaveError] = useState("");

  const { organizations } = useSelector(organizationState);
  const { userByRole } = useSelector(userState);
  const dispatch = useDispatch();
  const token = localStorage.getItem("TOKEN");

  useEffect(() => {
    dispatch(fetchOrganizations());
  }, [dispatch]);

  useEffect(() => {
    if (type) {
      dispatch(getUserbyRole(type));
    }
  }, [dispatch, type]);

  const adminList = userByRole.map((item) => ({
    value: item.userId,
    label: `${item.firstName} ${item.lastName}`,
  }));

  const showSuccessAlert = (message) => {
    Swal.fire({
      title: "Success!",
      text: message,
      icon: "success",
      confirmButtonColor: "#4a044e",
      timer: 3000,
    });
  };

  const showErrorAlert = (message) => {
    Swal.fire({
      title: "Error!",
      text: message,
      icon: "error",
      confirmButtonColor: "#4a044e",
    });
  };

  const handleSelectType = (type) => {
    setType(
      type === "Railway"
        ? "RAILWAY"
        : type === "Bus"
        ? "BUS_OPERATOR"
        : type === "Airline"
        ? "AIRLINE"
        : ""
    );
    setOrgType(false);
    setModalOpen(true);
  };

  const handleSave = async () => {
    const userId = selectedAdmin ? Number(selectedAdmin) : null;

    if (!orgName || !type || !userId) {
      showErrorAlert("Please fill in all fields.");
      return;
    }
    try {
      if (editingOrgId) {
        await axios.put(
          `http://localhost:8081/api/organizations/updateById/${editingOrgId}`,
          { orgName, type, userId },
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        showSuccessAlert("Organization updated successfully");
      } else {
        await dispatch(saveOrganization({ orgName, type, userId })).unwrap();
        showSuccessAlert("Organization created successfully");
      }
      await dispatch(fetchOrganizations());
      resetForm();
    } catch (error) {
      const errorMsg = error.payload?.message || error.message || "Failed to save organization";
      setSaveError(errorMsg);
      showErrorAlert(errorMsg);
    }
  };

  const resetForm = () => {
    setModalOpen(false);
    setOrgName("");
    setSelectedAdmin("");
    setType(null);
    setEditingOrgId(null);
    setSaveError("");
  };

// ...existing code...
const handleDelete = async (orgId) => {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#4a044e",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        const response = await fetch(
          `http://localhost:8081/api/organizations/deleteById/${orgId}`,
          {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        // Only parse JSON if there is content
        let data = {};
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          data = await response.json();
        }

        if (!response.ok) {
          throw new Error(data.message || "Deletion failed");
        }

        await dispatch(fetchOrganizations());
        showSuccessAlert("Organization deleted successfully");
      } catch (error) {
        showErrorAlert(error.message || "Failed to delete organization");
      }
    }
  });
};
// ...existing code...

  const handleEdit = async (orgId) => {
    try {
      const response = await axios.get(
        `http://localhost:8081/api/organizations/getById/${orgId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const org = response.data;
      setOrgName(org.orgName);
      setType(org.type);
      setSelectedAdmin(org.userId);
      setEditingOrgId(orgId);
      setModalOpen(true);
    } catch (error) {
      showErrorAlert("Failed to fetch organization details.");
    }
  };

  const handleView = async (orgId) => {
    try {
      const response = await axios.get(
        `http://localhost:8081/api/organizations/getById/${orgId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const org = response.data;
      
      Swal.fire({
        title: "Organization Details",
        html: `
          <div class="text-left">
            <p><strong>Name:</strong> ${org.orgName}</p>
            <p><strong>Type:</strong> ${org.type}</p>
            <p><strong>Owner ID:</strong> ${org.userId}</p>
          </div>
        `,
        confirmButtonColor: "#4a044e",
      });
    } catch (error) {
      showErrorAlert("Failed to fetch organization details.");
    }
  };

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header and Add Organization Button */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Organizations</h2>
        <div className="relative">
          <button
            onClick={() => {
              setOrgType((prev) => !prev);
              setType("");
            }}
            className="flex items-center px-4 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
          >
            <FaPlus className="mr-2" />
            Add Organization
          </button>

          {orgType && (
            <div className="absolute top-full right-0 mt-2 bg-white border border-gray-200 rounded shadow-md z-50 w-38">
              <button
                onClick={() => handleSelectType("Railway")}
                className="block w-full text-left px-4 py-2 hover:bg-gray-100"
              >
                Railway
              </button>
              <button
                onClick={() => handleSelectType("Bus")}
                className="block w-full text-left px-4 py-2 hover:bg-gray-100"
              >
                Bus
              </button>
              <button
                onClick={() => handleSelectType("Airline")}
                className="block w-full text-left px-4 py-2 hover:bg-gray-100"
              >
                Airline
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Organizations Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Owner ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {organizations.map((org) => (
              <tr key={org.orgId} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">{org.orgId}</td>
                <td className="px-6 py-4 whitespace-nowrap">{org.orgName}</td>
                <td className="px-6 py-4 whitespace-nowrap">{org.type}</td>
                <td className="px-6 py-4 whitespace-nowrap">{org.userId}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleView(org.orgId)}
                      className="text-blue-600 hover:text-blue-800 p-1 rounded hover:bg-blue-100"
                      title="View Details"
                    >
                      <FaEye />
                    </button>
                    <button
                      onClick={() => handleDelete(org.orgId)}
                      className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-100"
                      title="Delete"
                    >
                      <FaTrash />
                    </button>
                    <button
                      onClick={() => handleEdit(org.orgId)}
                      className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-100"
                      title="Edit"
                    >
                      <FaEdit />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Organization Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            onClick={resetForm}
          />
          <div className="relative w-full max-w-md max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-y-auto">
            <div className="sticky top-0 z-10 bg-fuchsia-950 p-6 text-white">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold">
                  {editingOrgId ? "Edit Organization" : "Add Organization"}
                </h3>
                <button
                  onClick={resetForm}
                  className="p-1 rounded-full hover:bg-white/20"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {saveError && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {saveError}
                </div>
              )}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Organization Name*
                  </label>
                  <input
                    type="text"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Enter organization name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Organization Type*
                  </label>
                  <input
                    type="text"
                    value={type}
                    readOnly
                    className="w-full bg-gray-100 border px-3 py-2 rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Organization Admin*
                  </label>
                  <select
                    value={selectedAdmin}
                    onChange={(e) => setSelectedAdmin(e.target.value)}
                    className="w-full border px-3 py-2 rounded-md"
                  >
                    <option value="">Select an admin</option>
                    {adminList.map((admin) => (
                      <option key={admin.value} value={admin.value}>
                        {admin.label}
                      </option>
                    ))}
                  </select>
                </div>
                
              </div>
            </div>
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex justify-end space-x-3">
              <button
                onClick={resetForm}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
              >
                {editingOrgId ? "Update" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default OrgList;