import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchHotelOwners,
  fetchAmenities,
  updateHotel,
  saveHotel,
} from "../app/hotelApi";
import InputField from "../components/InputField";

const AddModal = ({ hotel, amenities, onSave, onCancel }) => {
  const dispatch = useDispatch();
  const { owners, loading, error } = useSelector((state) => state.hotels);

  const [formData, setFormData] = useState({
    ownerId: hotel?.hotelOwner?.userId || "",
    name: hotel?.hotelName || "",
    address: hotel?.hotelAdd || "",
    amenities: Array.isArray(hotel?.amenities)
      ? hotel.amenities.map((a) => a.id)
      : [],
    rooms: hotel?.hotelRooms || "",
    description: hotel?.hotelDes || "",
    city: hotel?.city || "",
    latitude: hotel?.latitude || "",
    longitude: hotel?.longitude || "",
  });
  const [formError, setFormError] = useState(null);

  useEffect(() => {
    dispatch(fetchHotelOwners());
    dispatch(fetchAmenities());
  }, [dispatch]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (e) => {
    const { value, checked } = e.target;
    setFormData((prevState) => {
      const amenities = checked
        ? [...prevState.amenities, parseInt(value)]
        : prevState.amenities.filter((amenity) => amenity !== parseInt(value));
      return { ...prevState, amenities };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (
      !formData.ownerId ||
      !formData.name ||
      !formData.address ||
      !formData.rooms ||
      !formData.city ||
      !formData.latitude ||
      !formData.longitude
    ) {
      setFormError("Please fill in all required fields.");
      return;
    }

    const rooms = Number(formData.rooms);
    if (isNaN(rooms)) {
      setFormError("Rooms must be a valid number");
      return;
    }

    const hotelData = {
      hotelName: formData.name.trim(),
      hotelAdd: formData.address.trim(),
      hotelRooms: rooms,
      amenityIds: formData.amenities.map((id) => Number(id)),
      hotelDes: formData.description?.trim() || "",
      hotelOwner: {
        userId: Number(formData.ownerId),
      },
      city: formData.city.trim(),
      latitude: parseFloat(formData.latitude),
      longitude: parseFloat(formData.longitude),
    };


    try {
      await dispatch(saveHotel(hotelData));
      onSave(hotelData); 
    } catch (error) {
      setFormError("Failed to save hotel. Please try again.");
      console.error("Error saving hotel:", error);
    }
  };
  const isEditMode = hotel && hotel.hotelId;

  return (
    <div className="relative z-10" role="dialog" aria-modal="true">
      <div
        className="fixed inset-0 bg-gray-500/75 transition-opacity"
        aria-hidden="true"
      ></div>
      <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
        <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
          <div className="relative transform overflow-hidden rounded-lg bg-[#5A2360] text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg">
              <div className="bg-[#5A2360] px-4 pt-5 pb-4 sm:p-6 sm:pb-4 rounded-t-lg">
                <h3 className="text-base font-semibold text-white text-center">
                  {isEditMode ? "Edit Hotel" : "Add Hotel"}
                </h3>
              </div>
              <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                {formError && <p className="text-red-500">{formError}</p>}
                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="ownerId"
                  >
                    Owner Name
                  </label>
                  <select
                    name="ownerId"
                    value={formData.ownerId}
                    onChange={handleChange}
                    className="border border-gray-300 p-2 w-full bg-white text-gray-700 shadow-lg shadow-gray-900/5 ring-4 ring-transparent mt-1 rounded"
                  >
                    <option value="" disabled>
                      Select an Owner
                    </option>
                    {owners.map((owner) => (
                      <option key={owner.userId} value={owner.userId}>
                        {owner.firstName} {owner.lastName}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="name"
                  >
                    Hotel Name
                  </label>
                  <InputField
                    type="text"
                    name="name"
                    placeholder="Hotel Name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>
                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="city"
                  >
                    City
                  </label>
                  <InputField
                    type="text"
                    name="city"
                    placeholder="City"
                    value={formData.city}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>
                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="address"
                  >
                    Address
                  </label>
                  <InputField
                    type="text"
                    name="address"
                    placeholder="Address"
                    value={formData.address}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>

                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="rooms"
                  >
                    Rooms
                  </label>
                  <InputField
                    type="number"
                    name="rooms"
                    placeholder="Number of rooms"
                    value={formData.rooms}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>

                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="description"
                  >
                    Description
                  </label>
                  <InputField
                    type="text"
                    name="description"
                    placeholder="Description"
                    value={formData.description}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>
                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="latitude"
                  >
                    Latitude
                  </label>
                  <InputField
                    type="number"
                    name="latitude"
                    placeholder="Latitude"
                    value={formData.latitude}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>

                <div className="mb-4">
                  <label
                    className="block text-gray-700 text-sm font-bold mb-2"
                    htmlFor="longitude"
                  >
                    Longitude
                  </label>
                  <InputField
                    type="number"
                    name="longitude"
                    placeholder="Longitude"
                    value={formData.longitude}
                    onChange={handleChange}
                    className="w-full p-2 !border !border-gray-300 rounded mt-1 bg-white text-gray-700 placeholder-gray-500"
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Amenities
                  </label>
                  {amenities.map((amenity) => (
                    <label key={amenity.id} className="block">
                      <input
                        type="checkbox"
                        value={amenity.id}
                        checked={formData.amenities.includes(amenity.id)}
                        onChange={handleCheckboxChange}
                      />{" "}
                      {amenity.amenityName}
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                <button
                  type="submit"
                  className="inline-flex w-full justify-center rounded-md bg-[#5A2360] px-3 py-2 text-sm font-semibold text-white shadow-xs hover:bg-purple-600 sm:ml-3 sm:w-auto"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={onCancel}
                  className="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 ring-1 shadow-xs ring-gray-300 ring-inset hover:bg-gray-50 sm:mt-0 sm:w-auto"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddModal;
