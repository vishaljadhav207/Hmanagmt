
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  CircularProgress,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Chip,
} from "@mui/material";
import { FaBus } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { getSupervisorByOrgId } from "../app/userApi";
import { getClassTypesByTransportType } from "../app/busApi";

const AddModelBus = ({ open, bus, onSave, onSuccess, onCancel }) => {
  const { userInfo } = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const {
    supervisorByOrg: supervisors = [],
    loading: supervisorLoading,
    error: supervisorError,
  } = useSelector((state) => state.user);

  const {
    classTypes = [],
    classTypesLoading,
    classTypesError,
  } = useSelector((state) => state.buses);

  const [formData, setFormData] = useState({
    busNo: "",
    busType: "",
    operatorName: "",
    destination: "",
    departFrom: "",
    supervisorId: "",
    orgId: userInfo?.orgId || "",
    classTypes: [],
  });

  const [formError, setFormError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize form data when bus prop changes
  useEffect(() => {
    if (bus) {
      setFormData({
        busNo: bus.busNo || "",
        busType: bus.busType || "",
        operatorName: bus.operatorName || "",
        departFrom: bus.departFrom || "",
        destination: bus.destination || "",
        supervisorId: bus.supervisorId || bus.userId || "",
        orgId: bus.orgId || userInfo?.orgId || "",
        classTypes: bus.classTypes || [],
      });
    } else {
      // Reset form for new bus
      setFormData({
        busNo: "",
        busType: "",
        operatorName: "",
        departFrom: "",
        destination: "",
        supervisorId: "",
        orgId: userInfo?.orgId || "",
        classTypes: [],
      });
    }
  }, [bus, userInfo]);

  // Load supervisors and class types when orgId is available
  useEffect(() => {
    if (userInfo?.orgId) {
      dispatch(getSupervisorByOrgId({ orgId: userInfo.orgId, roleId: 4002 }));
      dispatch(getClassTypesByTransportType("BUS")); 
    }
  }, [dispatch, userInfo?.orgId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleClassTypeChange = (classId) => (e) => {
    const { checked } = e.target;
    setFormData((prev) => {
      if (checked) {
        return {
          ...prev,
          classTypes: [...prev.classTypes, { classId }],
        };
      } else {
        return {
          ...prev,
          classTypes: prev.classTypes.filter((ct) => ct.classId !== classId),
        };
      }
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);
    setIsSubmitting(true);

    // Validate required fields
    if (
      !formData.busNo ||
      !formData.busType ||
      !formData.operatorName ||
      !formData.supervisorId ||
      !formData.orgId
    ) {
      setFormError("Please fill in all required fields");
      setIsSubmitting(false);
      return;
    }

    const { supervisorId, ...rest } = formData;

    const busData = {
      ...rest,
      busNo: rest.busNo.trim(),
      busType: rest.busType.trim(),
      operatorName: rest.operatorName.trim(),
      destination: rest.destination.trim(),
      departFrom: rest.departFrom.trim(),
      userId: Number(supervisorId),
      organization: {
        orgId: Number(rest.orgId),
      },
      classTypes: rest.classTypes.map((ct) => ({ classId: ct.classId })),
      ...(bus?.busId && { busId: bus.busId }),
    };

    try {
      await onSave(busData);
      onSuccess();
    } catch (err) {
      setFormError(err.message || "An error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  const isClassTypeSelected = (classId) => {
    return formData.classTypes.some((ct) => ct.classId === classId);
  };

  return (
    <Dialog
      open={open}
      onClose={onCancel}
      maxWidth="md"
      fullWidth
      PaperProps={{ sx: { borderRadius: 3 } }}
    >
      <DialogTitle
        sx={{
          backgroundColor: "primary.main",
          color: "white",
          display: "flex",
          alignItems: "center",
          gap: 2,
          py: 2,
        }}
      >
        <FaBus />
        <Typography variant="h6" fontWeight="bold">
          {bus?.busId ? "Edit Bus" : "Add New Bus"}
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ p: 3 }}>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          {/* Error messages */}
          {(formError || supervisorError || classTypesError) && (
            <Typography color="error" mb={2}>
              {formError || supervisorError || classTypesError}
            </Typography>
          )}

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
              mt: 2,
            }}
          >
            {/* Bus Number */}
            <TextField
              label="Bus Number *"
              name="busNo"
              value={formData.busNo}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            {/* Bus Type */}
            <TextField
              label="Bus Type *"
              name="busType"
              value={formData.busType}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            {/* Operator Name */}
            <TextField
              label="Operator Name *"
              name="operatorName"
              value={formData.operatorName}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            {/* Destination */}
            <TextField
              label="Destination"
              name="destination"
              value={formData.destination}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            {/* Depart From */}
            <TextField
              label="Depart From"
              name="departFrom"
              value={formData.departFrom}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            {/* Supervisor */}
            <FormControl fullWidth size="small" required>
              <InputLabel>Supervisor *</InputLabel>
              <Select
                name="supervisorId"
                value={formData.supervisorId}
                onChange={handleChange}
                label="Supervisor *"
                disabled={supervisorLoading}
              >
                <MenuItem value="">
                  {supervisorLoading ? "Loading..." : "Select Supervisor"}
                </MenuItem>
                {supervisors.map((supervisor) => (
                  <MenuItem key={supervisor.userId} value={supervisor.userId}>
                    {supervisor.firstName} {supervisor.lastName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* Organization ID (read-only) */}
            <TextField
              label="Organization ID *"
              name="orgId"
              value={formData.orgId}
              onChange={handleChange}
              fullWidth
              size="small"
              required
              InputProps={{
                readOnly: true,
              }}
            />
          </Box>

          {/* Class Types Section */}
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Available Classes
            </Typography>

            {classTypesLoading ? (
              <CircularProgress size={24} />
            ) : (
              <FormGroup row>
                {classTypes.map((classType) => (
                  <FormControlLabel
                    key={classType.classId}
                    control={
                      <Checkbox
                        checked={isClassTypeSelected(classType.classId)}
                        onChange={handleClassTypeChange(classType.classId)}
                        name={`class-${classType.classId}`}
                      />
                    }
                    label={classType.className}
                  />
                ))}
              </FormGroup>
            )}

            {formData.classTypes.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Selected Classes:
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {formData.classTypes.map((classType) => {
                    const classInfo = classTypes.find(
                      (ct) => ct.classId === classType.classId
                    );
                    return (
                      <Chip
                        key={classType.classId}
                        label={
                          classInfo?.className || `Class ${classType.classId}`
                        }
                        onDelete={() =>
                          handleClassTypeChange(classType.classId)({
                            target: { checked: false },
                          })
                        }
                      />
                    );
                  })}
                </Box>
              </Box>
            )}
          </Box>

          <Divider sx={{ my: 3 }} />

          <DialogActions>
            <Button
              onClick={onCancel}
              variant="outlined"
              color="primary"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={isSubmitting}
              sx={{
                backgroundColor: "#5A2360",
                "&:hover": { backgroundColor: "#6B2D72" },
                minWidth: 120,
              }}
            >
              {isSubmitting ? (
                <CircularProgress size={24} color="inherit" />
              ) : bus?.busId ? (
                "Update Bus"
              ) : (
                "Add Bus"
              )}
            </Button>
          </DialogActions>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AddModelBus;
