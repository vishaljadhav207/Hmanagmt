import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllContacts,
  updateContactReply,
  deleteContact,
} from "../app/userApi";
import Swal from "sweetalert2";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box,
} from "@mui/material";

const Queries = () => {
  const dispatch = useDispatch();
  const {
    contacts = [],
    contactsLoading,
    contactsError,
  } = useSelector((state) => ({
    contacts: state.user.contacts || [],
    contactsLoading: state.user.contactsLoading,
    contactsError: state.user.contactsError,
  }));

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [adminReply, setAdminReply] = useState("");

  useEffect(() => {
    dispatch(getAllContacts());
  }, [dispatch]);

  const openModal = (contact) => {
    setSelectedContact(contact);

    if (typeof contact.adminReply === "object") {
      setAdminReply(JSON.stringify(contact.adminReply));
    } else {
      setAdminReply(contact.adminReply || "");
    }

    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedContact(null);
    setAdminReply("");
  };

  const handleReplySubmit = async () => {
    try {
      await dispatch(
        updateContactReply({
          email: selectedContact.email,
          adminReply,
        })
      ).unwrap();

      dispatch(getAllContacts());
      Swal.fire({
        title: "Success!",
        text: "Reply submitted successfully",
        icon: "success",
        customClass: {
          popup: "small-icon-popup",
        },
      });
      closeModal();
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to submit reply",
        icon: "error",
        customClass: {
          popup: "small-icon-popup",
        },
      });
    }
  };

  const handleDelete = async (contactId) => {
    const result = await Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });

    if (result.isConfirmed) {
      try {
        await dispatch(deleteContact(contactId)).unwrap();
        dispatch(getAllContacts());
        Swal.fire("Deleted!", "The contact has been deleted.", "success");
      } catch (error) {
        Swal.fire({
          title: "Error!",
          text: error.message || "Failed to delete contact",
          icon: "error",
        });
      }
    }
  };

  const safeContacts = Array.isArray(contacts) ? contacts : [];

  return (
    <Box sx={{ py: 4 }}>
      <TableContainer component={Paper} elevation={3}>
        <Table>
          <TableHead sx={{ bgcolor: "background.paper" }}>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Subject</TableCell>
              <TableCell>Message</TableCell>
              <TableCell>Admin Reply</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {contactsLoading ? (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  <Box display="flex" alignItems="center" gap={2}>
                    <CircularProgress size={24} />
                    <Typography>Loading data...</Typography>
                  </Box>
                </TableCell>
              </TableRow>
            ) : contactsError ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  align="center"
                  sx={{ color: "error.main" }}
                >
                  {contactsError.message || "Error loading contacts"}
                </TableCell>
              </TableRow>
            ) : safeContacts.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  align="center"
                  sx={{ color: "text.secondary" }}
                >
                  No contact records found
                </TableCell>
              </TableRow>
            ) : (
              safeContacts.map((contact) => (
                <TableRow key={contact.id || contact._id} hover>
                  <TableCell>{contact.id || contact._id}</TableCell>
                  <TableCell>{contact.name}</TableCell>
                  <TableCell>{contact.email}</TableCell>
                  <TableCell>{contact.subject}</TableCell>
                  <TableCell>{contact.message}</TableCell>
                  <TableCell>
                    <Button onClick={() => openModal(contact)} color="primary">
                      {contact.adminReply ? "Edit Reply" : "Add Reply"}
                    </Button>
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() => handleDelete(contact.id || contact._id)}
                      color="error"
                    >
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={isModalOpen} onClose={closeModal} fullWidth maxWidth="sm">
        <DialogTitle>Admin Reply</DialogTitle>
        <DialogContent>
          <TextField
            multiline
            rows={5}
            fullWidth
            variant="outlined"
            value={adminReply}
            onChange={(e) => setAdminReply(e.target.value)}
            placeholder="Enter your reply here..."
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={closeModal} color="secondary">
            Cancel
          </Button>
          <Button
            onClick={handleReplySubmit}
            color="primary"
            variant="contained"
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Queries;
