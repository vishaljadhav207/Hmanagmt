import React, { useEffect, useState } from "react";
import seatAxios from "../../app/seatAxios";
import { useDispatch, useSelector } from "react-redux";
import { fetchFlightsByUserId } from "../../app/flightApi";
import { selectCurrentFlight } from "../../redux/flightSlice";

function FlightSeatLayout() {
  const [totalSeats, setTotalSeats] = useState(60);
  const [seatType, setSeatType] = useState("3-3-3");
  const [layout, setLayout] = useState([]);
  const [flightId, setFlightId] = useState(null);
  const [classId, setClassId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [hasExistingLayout, setHasExistingLayout] = useState(false);
  const [savedLayouts, setSavedLayouts] = useState([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [seatToToggle, setSeatToToggle] = useState(null);
  const dispatch = useDispatch();

  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;
  const flights = useSelector(selectCurrentFlight) || [];

  useEffect(() => {
    if (userId) {
      dispatch(fetchFlightsByUserId(userId));
    }
  }, [dispatch, userId]);

  useEffect(() => {
    if (flights.length > 0 && !selectedFlight) {
      const flight = flights[0];
      setSelectedFlight(flight);
      setFlightId(flight?.flight_id || "");
      if (flight?.classTypes?.length > 0) {
        setClassId(flight.classTypes[0].classId);
      }
    }
  }, [flights, selectedFlight]);

  useEffect(() => {
    if (flightId && classId) {
      fetchSeatLayout(flightId, classId);
    }
  }, [flightId, classId]);

  const isLayoutSaved = () => {
    return savedLayouts.some(
      (item) => item.flightId === flightId && item.classId === classId
    );
  };

  const generateLayout = () => {
    const [left, middle, right] = seatType.split("-").map(Number);
    const seatsPerRow = left + middle + right;
    const totalRows = Math.ceil(totalSeats / seatsPerRow);
    const newLayout = [];

    let seatNumber = 1;

    for (let row = 1; row <= totalRows; row++) {
      const rowSeats = [];

      // Left section
      for (let i = 0; i < left; i++) {
        const seatLetter = String.fromCharCode(65 + i);
        const seatPosition = i === 0 ? "Window" : "Aisle";
        rowSeats.push({
          number: seatNumber,
          seatNumber: `${row}${seatLetter}`,
          type: seatPosition,
          available: true
        });
        seatNumber++;
      }

      // Middle section (if any)
      if (middle > 0) {
        rowSeats.push("aisle");

        for (let i = 0; i < middle; i++) {
          const seatLetter = String.fromCharCode(65 + left + i);
          const seatPosition = "Middle";
          rowSeats.push({
            number: seatNumber,
            seatNumber: `${row}${seatLetter}`,
            type: seatPosition,
            available: true
          });
          seatNumber++;
        }
      }

      // Right section
      if (right > 0) {
        rowSeats.push("aisle");

        for (let i = 0; i < right; i++) {
          const seatLetter = String.fromCharCode(65 + left + middle + i);
          const seatPosition = i === right - 1 ? "Window" : "Aisle";
          rowSeats.push({
            number: seatNumber,
            seatNumber: `${row}${seatLetter}`,
            type: seatPosition,
            available: true
          });
          seatNumber++;
        }
      }

      newLayout.push(rowSeats);
    }

    setLayout(newLayout);
    setHasExistingLayout(false);
  };

  const fetchSeatLayout = async (flightId, classId) => {
    try {
      setLoading(true);
      const response = await seatAxios.get(
        `flight-seats?flightId=${flightId}&classId=${classId}`
      );
      const seatData = response.data;

      if (!seatData || !seatData.layout) {
        setHasExistingLayout(false);
        return;
      }

      const { totalRows, seatsPerRow, seatMap } = seatData.layout;
      const newLayout = [];

      // Process seat map into rows with aisles
      for (let row = 0; row < totalRows; row++) {
        const rowSeats = [];
        const leftSeats = seatMap.slice(row * seatsPerRow, row * seatsPerRow + seatsPerRow / 2);
        const rightSeats = seatMap.slice(row * seatsPerRow + seatsPerRow / 2, (row + 1) * seatsPerRow);

        // Add left seats
        leftSeats.forEach(seat => {
          rowSeats.push({
            ...seat,
            number: parseInt(seat.seatNumber.match(/\d+/)[0])
          });
        });

        // Add aisle
        rowSeats.push("aisle");

        // Add right seats
        rightSeats.forEach(seat => {
          rowSeats.push({
            ...seat,
            number: parseInt(seat.seatNumber.match(/\d+/)[0])
          });
        });

        newLayout.push(rowSeats);
      }

      setLayout(newLayout);
      setHasExistingLayout(true);
      // Mark this layout as saved
      setSavedLayouts(prev => [
        ...prev.filter(item => !(item.flightId === flightId && item.classId === classId)),
        { flightId, classId }
      ]);
    } catch (error) {
      console.error("Failed to fetch seat layout:", error);
      setHasExistingLayout(false);
    } finally {
      setLoading(false);
    }
  };

  const saveSeatLayout = async () => {
    if (!flightId || !classId) {
      alert("Please select a flight and class type first");
      return;
    }

    try {
      setLoading(true);
      const payload = {
        totalRows: layout.length,
        seatsPerRow: seatType.split("-").reduce((a, b) => parseInt(a) + parseInt(b), 0),
        seatMap: layout.flatMap((row) =>
          row.filter((seat) => seat && typeof seat === "object")
            .map((seat) => ({
              seatNumber: seat.seatNumber,
              type: seat.type,
              available: seat.available
            }))
        ),
      };

      await seatAxios.post(
        `http://localhost:8082/api/flight-seats/create-by-id?flightId=${flightId}&classId=${classId}`,
        payload
      );
     
      setHasExistingLayout(true);
      // Mark this layout as saved
      setSavedLayouts(prev => [
        ...prev.filter(item => !(item.flightId === flightId && item.classId === classId)),
        { flightId, classId }
      ]);
    } catch (error) {
      console.error("Error saving seat layout:", error);
    } finally {
      setLoading(false);
    }
  };

  // Remove confirmation modal logic, make toggle immediate
  const confirmToggleSeat = (seatNumber) => {
    toggleSeatAvailability(seatNumber);
  };

  const toggleSeatAvailability = async (seatNumber) => {
    try {
      const currentSeat = layout
        .flat()
        .find(seat => seat && typeof seat === "object" && seat.seatNumber === seatNumber);

      if (!currentSeat) return;

      const newAvailability = !currentSeat.available;

      // Optimistic UI update
      const updatedLayout = layout.map((row) =>
        row.map((seat) =>
          seat && seat.seatNumber === seatNumber
            ? { ...seat, available: newAvailability }
            : seat
        )
      );
      setLayout(updatedLayout);

      // Call API to update seat availability
      await seatAxios.patch(
        `http://localhost:8082/api/flight-seats/update-seat?flightId=${flightId}&classId=${classId}&seatNumber=${seatNumber}&isAvailable=${newAvailability}`
      );

    } catch (error) {
      console.error("Error updating seat availability:", error);
      // Revert on error
      const revertedLayout = layout.map((row) =>
        row.map((seat) =>
          seat && seat.seatNumber === seatNumber
            ? { ...seat, available: !newAvailability }
            : seat
        )
      );
      setLayout(revertedLayout);
    } finally {
      setSeatToToggle(null);
      setShowConfirmModal(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Flight Seat Administration
          </h1>
          <p className="text-gray-600">Manage seat layouts for your flights</p>
        </header>

        {/* Flight/Class/Seat Config */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Select Flight
              </label>
              <select
                value={selectedFlight?.flight_id || ""}
                onChange={(e) => {
                  if (!e.target.value) {
                    setSelectedFlight(null);
                    setFlightId(null);
                    setClassId(null);
                    setLayout([]);
                    setHasExistingLayout(false);
                    return;
                  }
                  const flight = flights.find(f => f.flight_id === parseInt(e.target.value));
                  setSelectedFlight(flight);
                  setFlightId(flight?.flight_id || "");
                  setClassId(flight?.classTypes?.[0]?.classId || "");
                  setHasExistingLayout(false);
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              >
                <option value="">Select Flight</option>
                {flights.map(flight => (
                  <option key={flight.flight_id} value={flight.flight_id}>
                    {flight.flight_no} - {flight.departFrom} to {flight.destination}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Class Type
              </label>
              <select
                value={classId || ""}
                onChange={(e) => {
                  if (!e.target.value) {
                    setClassId(null);
                    setLayout([]);
                    setHasExistingLayout(false);
                    return;
                  }
                  setClassId(e.target.value);
                  setHasExistingLayout(false);
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              >
                <option value="">Select Class</option>
                {selectedFlight?.classTypes?.map(cls => (
                  <option key={cls.classId} value={cls.classId}>
                    {cls.className}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Total Seats
              </label>
              <input
                type="number"
                value={totalSeats}
                onChange={(e) => setTotalSeats(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                disabled={hasExistingLayout}
              />
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Seat Configuration
              </label>
              <select
                value={seatType}
                onChange={(e) => setSeatType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                disabled={hasExistingLayout}
              >
                <option value="1-2-1">1-2-1</option>
                <option value="2-4-2">2-4-2</option>
                <option value="3-3-3">3-3-3</option>
              </select>
            </div>
          </div>

          {!hasExistingLayout && (
            <button
              onClick={generateLayout}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2.5 px-6 rounded-md transition-colors"
            >
              Generate Layout
            </button>
          )}
        </div>

        {layout.length > 0 && (
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Layout Preview</h2>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4 text-sm">
              <div className="text-green-600 font-medium">
                Available Seats: {
                  layout.flat().filter(seat => seat && typeof seat === "object" && seat.available).length
                }
              </div>
              <div className="text-red-500 font-medium">
                Unavailable Seats: {
                  layout.flat().filter(seat => seat && typeof seat === "object" && !seat.available).length
                }
              </div>
            </div>
            <div className="flex flex-col items-center gap-3 mb-8">
              {layout.map((row, rowIndex) => (
                <div key={rowIndex} className="flex gap-2">
                  {row.map((seat, seatIndex) => {
                    if (seat === "aisle") {
                      return (
                        <div key={seatIndex} className="w-12 bg-gray-50 rounded-sm relative">
                          <div className="absolute inset-0 border-l-2 border-r-2 border-dashed border-gray-300" />
                        </div>
                      );
                    }

                    if (!seat) {
                      return <div key={seatIndex} className="w-8 h-8 opacity-0" />;
                    }

                    const seatClasses = [
                      "flex items-center justify-center text-xs font-medium rounded-sm",
                      "shadow-sm transition-all",
                      !seat.available && "bg-gray-400 text-white cursor-not-allowed",
                      seat.available && seat.type === "Window" && "bg-blue-200 text-blue-800",
                      seat.available && seat.type === "Aisle" && "bg-green-200 text-green-800",
                      seat.available && seat.type === "Middle" && "bg-yellow-200 text-yellow-800",
                      "w-8 h-8",
                      "cursor-pointer hover:opacity-80"
                    ]
                      .filter(Boolean)
                      .join(" ");

                    return (
                      <div
                        key={seatIndex}
                        className={seatClasses}
                        title={`Seat: ${seat.seatNumber} | Type: ${seat.type} | ${seat.available ? 'Available' : 'Unavailable'}`}
                        onClick={() => confirmToggleSeat(seat.seatNumber)}
                      >
                        {seat.seatNumber}
                        {!seat.available && (
                          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                            This seat is unavailable
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

            <button
              onClick={saveSeatLayout}
              disabled={loading || !flightId || !classId || isLayoutSaved()}
              className={`w-full bg-green-500 hover:bg-green-600 text-white font-medium py-2.5 px-6 rounded-md transition-colors ${
                loading || !flightId || !classId || isLayoutSaved() ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              {loading ? "Saving..." : isLayoutSaved() ? "Layout Saved" : "Save Seat Layout"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default FlightSeatLayout;