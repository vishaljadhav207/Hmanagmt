import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { fetchFlightsByUserId } from "../../app/flightApi";
import { selectCurrentFlight, selectFlightError, selectFlightStatus } from "../../redux/flightSlice";

const FlightManagement = () => {
  const dispatch = useDispatch();
  const flightData = useSelector(selectCurrentFlight);
  const status = useSelector(selectFlightStatus);
  const error = useSelector(selectFlightError);
  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;

  // Convert single flight to array for consistent rendering
  const flights = Array.isArray(flightData) ? flightData : (flightData ? [flightData] : []);

  useEffect(() => {
    if (userId) {
      dispatch(fetchFlightsByUserId(userId));
    }
  }, [dispatch, userId]);

  if (status === "loading") {
    return (
      <div className="p-9 flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (status === "failed") {
    return (
      <div className="p-9 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
        <p className="font-bold">Error</p>
        <p>{error}</p>
      </div>
    );
  }

  if (flights.length === 0) {
    return (
      <div className="p-9 bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4">
        <p>No flights found for this user.</p>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-9">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">
          {flights.length > 1 ? "My Flights" : "My Flights"}
        </h1>
        <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
          {flights.length} {flights.length === 1 ? "Flight" : "Flights"}
        </span>
      </div>

      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Flight Details
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Route
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Organization
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Classes & Pricing
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {flights.map((flight) => (
                <tr key={flight.flight_id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">
                          {flight.airline}
                        </div>
                        <div className="text-sm text-gray-500">
                          #{flight.flight_no}
                        </div>
                        {/* <div className="text-xs text-gray-400 mt-1">
                          ID: {flight.flight_id}
                        </div> */}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 font-medium">
                      {flight.departFrom} → {flight.destination}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{flight.organization.orgName}</div>
                    <div className="text-sm text-gray-500">{flight.organization.type}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-2">
                      {flight.classTypes?.map((classType) => (
                        <div 
                          key={classType.classId} 
                          className="border rounded-lg p-2 min-w-[120px]"
                        >
                          <div className="font-medium text-sm text-gray-900">
                            {classType.className}
                          </div>
                          {/* <div className="text-xs text-gray-500">
                            Available: {classType.availability}
                          </div> */}
                          <div className="text-sm font-semibold text-blue-600">
                            ₹{classType.fare.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Optional: Summary at bottom
      <div className="mt-4 text-sm text-gray-500">
        Showing {flights.length} {flights.length === 1 ? "flight" : "flights"}
      </div> */}
    </div>
  );
};

export default FlightManagement;