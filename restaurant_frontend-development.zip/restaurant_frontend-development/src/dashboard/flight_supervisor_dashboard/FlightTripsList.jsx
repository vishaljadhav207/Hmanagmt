import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { deleteFlightTrip, getFlightTripsByUserId, updateFlightTrip } from "../../app/flighttripApi";
import { flightTripState } from "../../redux/flightTripsSlice";
import Swal from 'sweetalert2';

// Material UI Components
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TableSortLabel,
  Button,
  IconButton,
  Tooltip,
  Typography,
  Box,
  Stack,
  Chip,
  Modal,
  Grid,
  Divider,
  List,
  ListItem,
  ListItemText,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Snackbar,
  Alert,
  TextField
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  AirplanemodeActive as FlightIcon,
  Close as CloseIcon,
  Save as SaveIcon,
  AddCircleOutline as AddStopIcon,
  RemoveCircleOutline as RemoveStopIcon
} from '@mui/icons-material';
import AddFlightTrip from '../../components/AddFlightTrip';
import ViewFlightTrip from '../../components/ViewFlightTrip';

const editModalStyle = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '70%',
  maxWidth: 800,
  maxHeight: '90vh',
  overflowY: 'auto',
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
  borderRadius: 2
};

const FlightTripsList = () => {
  const [addModalOpen, setAddModalOpen] = useState(false);
  const dispatch = useDispatch();
  const { userFlightTrip, status, error } = useSelector(flightTripState);
  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('departureDate');
  const [openModal, setOpenModal] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [flightTripToDelete, setFlightTripToDelete] = useState(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingFlight, setEditingFlight] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  useEffect(() => {
    if (userId) {
      dispatch(getFlightTripsByUserId(userId));
    }
  }, [dispatch, userId]);

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleViewClick = (trip) => {
    setSelectedFlight(trip);
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setSelectedFlight(null);
  };

  const handleEditClick = (trip) => {
    const tripWithStops = {
      ...trip,
      intermediateStops: trip.intermediateStops || []
    };
    setEditingFlight(tripWithStops);
    setEditModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setEditModalOpen(false);
    setEditingFlight(null);
  };

  const handleDeleteClick = (flightTripId) => {
    setFlightTripToDelete(flightTripId);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    try {
      await dispatch(deleteFlightTrip(flightTripToDelete)).unwrap();
      setSnackbar({
        open: true,
        message: 'Flight trip deleted successfully',
        severity: 'success'
      });
      Swal.fire({
      icon: 'success',
      title: 'Deleted!',
      text: 'Flight trip deleted successfully.',
      timer: 2000,
      showConfirmButton: false
    });
    } catch (error) {
      setSnackbar({
        open: true,
        message: error.message || 'Failed to delete flight trip',
        severity: 'error'
      });
    } finally {
      setDeleteDialogOpen(false);
      setFlightTripToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setDeleteDialogOpen(false);
    setFlightTripToDelete(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditingFlight(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFlightInputChange = (e) => {
    const { name, value } = e.target;
    setEditingFlight(prev => ({
      ...prev,
      flight: {
        ...prev.flight,
        [name]: value
      }
    }));
  };

  const handleAddIntermediateStop = () => {
    setEditingFlight(prev => ({
      ...prev,
      intermediateStops: [
        ...(prev.intermediateStops || []),
        {
          stopName: '',
          arrivalTime: new Date().toISOString().slice(0, 16),
          departureTime: new Date().toISOString().slice(0, 16),
          sequence: (prev.intermediateStops?.length || 0) + 1
        }
      ]
    }));
  };

  const handleRemoveIntermediateStop = (index) => {
    setEditingFlight(prev => {
      const newStops = [...prev.intermediateStops];
      newStops.splice(index, 1);

      const updatedStops = newStops.map((stop, idx) => ({
        ...stop,
        sequence: idx + 1
      }));

      return {
        ...prev,
        intermediateStops: updatedStops
      };
    });
  };

  const handleIntermediateStopChange = (index, field, value) => {
    setEditingFlight(prev => {
      const newStops = [...prev.intermediateStops];
      newStops[index] = {
        ...newStops[index],
        [field]: value
      };
      return {
        ...prev,
        intermediateStops: newStops
      };
    });
  };

  const handleSubmitUpdate = async () => {
    try {
      const { flightTripId } = editingFlight; 

      const updatedData = {
        origin: editingFlight.origin,
        destination: editingFlight.destination,
        departureDate: editingFlight.departureDate,
        arrivalDate: editingFlight.arrivalDate,
        flight: {
          flight_id: editingFlight.flight?.flight_id,
          flight_no: editingFlight.flight?.flight_no,
          airline: editingFlight.flight?.airline,
          departFrom: editingFlight.origin,
          destination: editingFlight.destination,
          userId: editingFlight.flight?.userId,
          organization: editingFlight.flight?.organization
        },
        intermediateStops: editingFlight.intermediateStops?.map(stop => ({
          stopName: stop.stopName,
          arrivalTime: stop.arrivalTime,
          departureTime: stop.departureTime,
          sequence: stop.sequence
        })) || []
      };

      await dispatch(updateFlightTrip({ flightTripId, updatedData })).unwrap();
      dispatch(getFlightTripsByUserId(userId));
      setSnackbar({
        open: true,
        message: 'Flight trip updated successfully',
        severity: 'success'
      });
      setEditModalOpen(false);
       Swal.fire({
      icon: 'success',
      title: 'Updated!',
      text: 'Flight trip updated successfully.',
      timer: 2000,
      showConfirmButton: false
    });
    } catch (error) {
      setSnackbar({
        open: true,
        message: error.message || 'Failed to update flight trip',
        severity: 'error'
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const sortedFlights = [...(userFlightTrip || [])].sort((a, b) => {
    if (a[orderBy] < b[orderBy]) {
      return order === 'asc' ? -1 : 1;
    }
    if (a[orderBy] > b[orderBy]) {
      return order === 'asc' ? 1 : -1;
    }
    return 0;
  });

  const paginatedFlights = sortedFlights.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  if (status === "loading") {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <Typography>Loading flight information...</Typography>
      </Box>
    );
  }

  if (status === "failed") {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <Typography color="error">Error: {error}</Typography>
      </Box>
    );
  }

  if (!userFlightTrip || userFlightTrip.length === 0) {
    return (
      <Box display="flex" justifyContent="center" p={3}>
        <Typography>No flight trips found for this user.</Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => setAddModalOpen(true)}
          sx={{ ml: 2 }}
        >
          Add New Trip
        </Button>
        
        <Modal
          open={addModalOpen}
          onClose={() => setAddModalOpen(false)}
          aria-labelledby="add-flight-modal"
        >
          <div>
            <AddFlightTrip onClose={() => setAddModalOpen(false)} />
          </div>
        </Modal>
      </Box>
    );
  }

  return (
    <Box p={3}>
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity}>
          {snackbar.message}
        </Alert>
      </Snackbar>

      <Dialog
        open={deleteDialogOpen}
        onClose={handleCancelDelete}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete this flight trip? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancelDelete}>Cancel</Button>
          <Button onClick={handleConfirmDelete} color="error" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Modal
        open={editModalOpen}
        onClose={handleCloseEditModal}
        aria-labelledby="edit-flight-modal"
        aria-describedby="edit-flight-description"
      >
        <Box sx={editModalStyle}>
          {editingFlight && (
            <Grid container spacing={3} className='p-8'>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Origin"
                    name="origin"
                    value={editingFlight.origin || ''}
                    onChange={handleInputChange}
                    margin="normal"
                    variant="outlined"
                  />
                  <TextField
                    fullWidth
                    label="Destination"
                    name="destination"
                    value={editingFlight.destination || ''}
                    onChange={handleInputChange}
                    margin="normal"
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    fullWidth
                    label="Departure Date"
                    name="departureDate"
                    type="datetime-local"
                    value={editingFlight.departureDate ? new Date(editingFlight.departureDate).toISOString().slice(0, 16) : ''}
                    onChange={handleInputChange}
                    margin="normal"
                    variant="outlined"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <TextField
                    fullWidth
                    label="Arrival Date"
                    name="arrivalDate"
                    type="datetime-local"
                    value={editingFlight.arrivalDate ? new Date(editingFlight.arrivalDate).toISOString().slice(0, 16) : ''}
                    onChange={handleInputChange}
                    margin="normal"
                    variant="outlined"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <Card variant="outlined" sx={{ mt: 2, p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                    <Typography variant="h6">Intermediate Stops</Typography>
                    <Button
                      variant="outlined"
                      startIcon={<AddStopIcon />}
                      onClick={handleAddIntermediateStop}
                    >
                      Add Stop
                    </Button>
                  </Box>

                  {editingFlight.intermediateStops && editingFlight.intermediateStops.length > 0 ? (
                    editingFlight.intermediateStops.map((stop, index) => (
                      <Box key={index} sx={{ mb: 2, p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12} display="flex" justifyContent="space-between" alignItems="center">
                            <Typography variant="subtitle1">Stop {index + 1}</Typography>
                            <IconButton
                              color="error"
                              size="small"
                              onClick={() => handleRemoveIntermediateStop(index)}
                            >
                              <RemoveStopIcon />
                            </IconButton>
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <TextField
                              fullWidth
                              label="Stop Name"
                              value={stop.stopName || ''}
                              onChange={(e) => handleIntermediateStopChange(index, 'stopName', e.target.value)}
                              variant="outlined"
                              size="small"
                            />
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <TextField
                              fullWidth
                              label="Arrival Time"
                              type="datetime-local"
                              value={stop.arrivalTime ? new Date(stop.arrivalTime).toISOString().slice(0, 16) : ''}
                              onChange={(e) => handleIntermediateStopChange(index, 'arrivalTime', e.target.value)}
                              variant="outlined"
                              size="small"
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </Grid>
                          <Grid item xs={12} md={4}>
                            <TextField
                              fullWidth
                              label="Departure Time"
                              type="datetime-local"
                              value={stop.departureTime ? new Date(stop.departureTime).toISOString().slice(0, 16) : ''}
                              onChange={(e) => handleIntermediateStopChange(index, 'departureTime', e.target.value)}
                              variant="outlined"
                              size="small"
                              InputLabelProps={{
                                shrink: true,
                              }}
                            />
                          </Grid>
                        </Grid>
                      </Box>
                    ))
                  ) : (
                    <Typography color="textSecondary">No intermediate stops added.</Typography>
                  )}
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Box display="flex" justifyContent="flex-end" mt={2}>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<SaveIcon />}
                    onClick={handleSubmitUpdate}
                  >
                    Save Changes
                  </Button>
                </Box>
              </Grid>
            </Grid>
          )}
        </Box>
      </Modal>

      <ViewFlightTrip
        open={openModal}
        onClose={handleCloseModal}
        selectedFlight={selectedFlight}
      />

      <Paper elevation={3} sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h5" component="h2" sx={{ display: 'flex', alignItems: 'center' }}>
            <FlightIcon color="primary" sx={{ mr: 1 }} />
            Flight Trips
          </Typography>
          <div>
            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={() => setAddModalOpen(true)}
            >
              Add New Trip
            </Button>

            <Modal
              open={addModalOpen}
              onClose={() => setAddModalOpen(false)}
              aria-labelledby="add-flight-modal"
            >
              <div>
                <AddFlightTrip onClose={() => setAddModalOpen(false)} />
              </div>
            </Modal>
          </div>
        </Stack>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: 'primary.light' }}>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'flightTripId'}
                    direction={orderBy === 'flightTripId' ? order : 'asc'}
                    onClick={() => handleRequestSort('flightTripId')}
                  >
                    <Typography fontWeight="bold">Trip ID</Typography>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'flight_no'}
                    direction={orderBy === 'flight_no' ? order : 'asc'}
                    onClick={() => handleRequestSort('flight_no')}
                  >
                    <Typography fontWeight="bold">Class</Typography>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'departureDate'}
                    direction={orderBy === 'departureDate' ? order : 'asc'}
                    onClick={() => handleRequestSort('departureDate')}
                  >
                    <Typography fontWeight="bold">Departure</Typography>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'arrivalDate'}
                    direction={orderBy === 'arrivalDate' ? order : 'asc'}
                    onClick={() => handleRequestSort('arrivalDate')}
                  >
                    <Typography fontWeight="bold">Arrival</Typography>
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <Typography fontWeight="bold">Route</Typography>
                </TableCell>
                <TableCell align="center">
                  <Typography fontWeight="bold">Actions</Typography>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedFlights.map((trip) => (
                <TableRow key={trip.flightTripId} hover>
                  <TableCell>{trip.flightTripId}</TableCell>
                  <TableCell>
                    <Stack direction="column" spacing={0.5}>
                      {trip?.flight?.classTypes?.map((classType, index) => (
                        <Chip
                          key={index}
                          label={classType.className}
                          size="small"
                          color={
                            classType.className === 'Business' ? 'primary' :
                              classType.className === 'Economy' ? 'secondary' :
                                'default'
                          }
                          variant="outlined"
                          sx={{ mb: 0.5 }}
                        />
                      ))}
                    </Stack>
                  </TableCell>
                  <TableCell>
                    {new Date(trip.departureDate).toLocaleDateString()}
                    <Typography variant="caption" display="block">
                      {new Date(trip.departureDate).toLocaleTimeString()}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {new Date(trip.arrivalDate).toLocaleDateString()}
                    <Typography variant="caption" display="block">
                      {new Date(trip.arrivalDate).toLocaleTimeString()}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={trip.origin}
                      size="small"
                      color="primary"
                      variant="outlined"
                      sx={{ mr: 1 }}
                    />
                    <Typography variant="caption">→</Typography>
                    <Chip
                      label={trip.destination}
                      size="small"
                      color="secondary"
                      variant="outlined"
                      sx={{ ml: 1 }}
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Tooltip title="View Details">
                      <IconButton color="info" onClick={() => handleViewClick(trip)}>
                        <ViewIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Edit Trip">
                      <IconButton
                        color="primary"
                        onClick={() => handleEditClick(trip)}
                      >
                        <EditIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete Trip">
                      <IconButton
                        color="error"
                        onClick={() => handleDeleteClick(trip.flightTripId)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={userFlightTrip.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
    </Box>
  );
};

export default FlightTripsList;