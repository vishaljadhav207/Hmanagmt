import React from 'react'

function OrganizationOwner() {
  return (
    <div>
      roeighuwrieghui
    </div>
  )
}

export default OrganizationOwner
