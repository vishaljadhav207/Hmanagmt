import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getTrainsByOrgId,
  deleteTrain,
  saveTrain,
  updateTrain,
} from "../app/trainApi";
import {
  setCurrentPage,
  setPageSize,
  setSortBy,
  setSortDir,
} from "../redux/trainSlice";
import {
  Box,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
  TablePagination,
  IconButton,
  Typography,
  LinearProgress,
  Chip,
  Divider,
  Tooltip,
  TextField,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import {
  FaEdit,
  FaTrash,
  FaEye,
  FaPlus,
  FaTrain,
  FaSearch,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import Swal from "sweetalert2";
import AddModelTrain from "./AddModelTrain";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontWeight: 500,
  padding: theme.spacing(1.5),
  borderBottom: `1px solid ${theme.palette.divider}`,
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td": {
    borderBottom: 0,
  },
}));

const DetailCard = ({ children }) => (
  <Paper
    sx={{
      flex: 1,
      minWidth: 250,
      p: 2,
      borderRadius: 2,
      boxShadow: 1,
    }}
  >
    {children}
  </Paper>
);

const DetailItem = ({ label, value }) => (
  <Box sx={{ mb: 2 }}>
    <Typography variant="subtitle2" color="textSecondary">
      {label}
    </Typography>
    <Typography variant="body1" sx={{ mt: 0.5, wordBreak: "break-word" }}>
      {value || (
        <Typography component="span" color="text.disabled">
          Not available
        </Typography>
      )}
    </Typography>
  </Box>
);

const TrainList = () => {
  const dispatch = useDispatch();
  const { userInfo: user } = useSelector((state) => state.user);
  const {
    trains,
    status,
    error,
    currentPage,
    totalPages,
    pageSize,
    totalItems,
    sortBy,
    sortDir,
  } = useSelector((state) => state.trains);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrain, setSelectedTrain] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const safeTrains = Array.isArray(trains) ? trains : [];

  const filteredTrains = useMemo(() => {
    return safeTrains.filter((train) => {
      const trainNo = String(train.trainNo || train.train_no || "");
      const trainName = String(train.trainName || "");
      const railwayZone = String(train.railwayZone || "");
      const destination = String(train.destination || "");

      return (
        trainNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        trainName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        railwayZone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        destination.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [safeTrains, searchTerm]);

  const refreshTrains = () => {
    if (!user?.orgId) {
      console.warn("Missing orgId, cannot fetch trains.");
      return;
    }
    dispatch(
      getTrainsByOrgId({
        orgId: user.orgId,
        pageNumber: currentPage,
        pageSize,
        sortBy,
        sortDir,
      })
    )
      .unwrap()
      .catch((error) => {
        Swal.fire({
          title: "Error!",
          text: error.message || "Failed to load trains",
          icon: "error",
          confirmButtonColor: "#5A2360",
        });
      });
  };

  useEffect(() => {
    if (user?.orgId) {
      refreshTrains();
    }
  }, [dispatch, user?.orgId, currentPage, pageSize, sortBy, sortDir]);

  const handleSort = (column) => {
    if (sortBy === column) {
      const newDir = sortDir === "asc" ? "desc" : "asc";
      dispatch(setSortDir(newDir));
    } else {
      dispatch(setSortBy(column));
      dispatch(setSortDir("asc"));
    }
    dispatch(setCurrentPage(0));
  };

  const renderSortIcon = (column) => {
    if (sortBy !== column)
      return <FaSort style={{ marginLeft: 5, opacity: 0.3 }} />;
    return sortDir === "asc" ? (
      <FaSortUp style={{ marginLeft: 5 }} />
    ) : (
      <FaSortDown style={{ marginLeft: 5 }} />
    );
  };

  const handleAddTrain = () => {
    setSelectedTrain(null);
    setIsModalOpen(true);
  };

  const handleSaveTrain = async (trainData) => {
    try {
      await dispatch(saveTrain(trainData)).unwrap();

      Swal.fire({
        title: "Success!",
        text: "Train added successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });

      setIsModalOpen(false);
      refreshTrains();
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to add train",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleUpdateTrain = async (trainData) => {
    if (!selectedTrain?.train_id) return;

    try {
      await dispatch(
        updateTrain({
          train_id: selectedTrain.train_id,
          ...trainData,
        })
      ).unwrap();

      Swal.fire({
        title: "Success!",
        text: "Train updated successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });

      setIsModalOpen(false);
      refreshTrains();
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to update train",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleViewDetails = (train) => {
    setSelectedTrain(train);
    setIsViewModalOpen(true);
  };

  const handleDeleteClick = (trainId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#5A2360",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        handleConfirmDelete(trainId);
      }
    });
  };

  const handleConfirmDelete = async (trainId) => {
    try {
      await dispatch(deleteTrain(trainId)).unwrap();
      refreshTrains();
      Swal.fire({
        title: "Deleted!",
        text: "Train has been deleted successfully.",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to delete train",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleCloseViewModal = () => setIsViewModalOpen(false);
  const handlePageChange = (event, newPage) => {
    dispatch(setCurrentPage(newPage));
  };

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    dispatch(setPageSize(newSize));
    dispatch(setCurrentPage(0));
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  if (!user?.orgId) {
    return (
      <Typography sx={{ p: 4 }} color="text.secondary">
        Loading user info...
      </Typography>
    );
  }

  return (
    <Box sx={{ p: { xs: 1, md: 3 } }}>
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
          gap: 2,
        }}
      >
        <TextField
          placeholder="Search trains..."
          variant="outlined"
          size="small"
          sx={{
            width: { xs: "100%", md: "400px" },
            backgroundColor: "background.paper",
            borderRadius: 1,
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <FaSearch color="action" />
              </InputAdornment>
            ),
          }}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <Button
          variant="contained"
          startIcon={<FaPlus />}
          onClick={handleAddTrain}
          sx={{
            backgroundColor: "#5A2360",
            color: "white",
            "&:hover": {
              backgroundColor: "#6B2D72",
            },
            minWidth: 220,
            height: 50,
            borderRadius: 1,
            fontSize: "1.05rem",
            padding: "0 24px",
          }}
        >
          Add Train
        </Button>
      </Box>

      <Paper
        sx={{
          width: "100%",
          overflow: "hidden",
          mb: 2,
          borderRadius: 2,
          boxShadow: 1,
        }}
      >
        <TableContainer>
          <Table>
            <TableHead sx={{ backgroundColor: "primary.main" }}>
              <TableRow>
                <StyledTableCell
                  onClick={() => handleSort("trainNo")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Train No
                    </Typography>
                    {renderSortIcon("trainNo")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("trainName")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Train Name
                    </Typography>
                    {renderSortIcon("trainName")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("railwayZone")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Zone
                    </Typography>
                    {renderSortIcon("railwayZone")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("numberOfCoaches")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Coaches
                    </Typography>
                    {renderSortIcon("numberOfCoaches")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("destination")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Destination
                    </Typography>
                    {renderSortIcon("destination")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell>
                  <Typography color="common.white" fontWeight="bold">
                    Organization
                  </Typography>
                </StyledTableCell>
                <StyledTableCell align="right">
                  <Typography color="common.white" fontWeight="bold">
                    Actions
                  </Typography>
                </StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {status === "loading" ? (
                <TableRow>
                  <TableCell colSpan={7}>
                    <LinearProgress />
                    <Typography align="center" sx={{ py: 2 }}>
                      Loading trains...
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : filteredTrains.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                    <Box textAlign="center" py={4}>
                      <FaTrain
                        size={48}
                        color="#5A2360"
                        style={{ opacity: 0.5 }}
                      />
                      <Typography variant="h6" color="textSecondary" mt={2}>
                        {searchTerm
                          ? "No matching trains found"
                          : "No trains available"}
                      </Typography>
                      {!searchTerm && (
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={handleAddTrain}
                          sx={{ mt: 4 }}
                        >
                          Add Your First Train
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                filteredTrains.map((train) => (
                  <StyledTableRow key={train.train_id} hover>
                    <StyledTableCell>
                      <Tooltip title={`Train ID: ${train.train_id}`}>
                        <Chip
                          label={train.trainNo || "N/A"}
                          color="primary"
                          size="small"
                          sx={{ fontWeight: 600 }}
                        />
                      </Tooltip>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography fontWeight="medium">
                        {train.trainName || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {train.railwayZone || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {train.numberOfCoaches || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {train.destination || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {train.organization?.orgName || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell align="right">
                      <Box display="flex" justifyContent="flex-end" gap={1}>
                        <Tooltip title="View details">
                          <IconButton
                            onClick={() => handleViewDetails(train)}
                            color="info"
                            size="small"
                          >
                            <FaEye />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit train">
                          <IconButton
                            onClick={() => {
                              setSelectedTrain({
                                ...train,
                                train_id: train.train_id,
                              });
                              setIsModalOpen(true);
                            }}
                            color="warning"
                            size="small"
                          >
                            <FaEdit />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete train">
                          <IconButton
                            onClick={() => handleDeleteClick(train.train_id)}
                            color="error"
                            size="small"
                          >
                            <FaTrash />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </StyledTableCell>
                  </StyledTableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Divider />

        <Box
          sx={{
            p: 2,
            display: "flex",
            flexDirection: { xs: "column", sm: "row" },
            justifyContent: "space-between",
            alignItems: "center",
            gap: 2,
          }}
        >
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Rows per page</InputLabel>
            <Select
              value={pageSize}
              onChange={handlePageSizeChange}
              label="Rows per page"
            >
              {[5, 10, 25, 50].map((size) => (
                <MenuItem key={size} value={size}>
                  {size}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TablePagination
            component="div"
            count={totalItems}
            page={currentPage}
            onPageChange={handlePageChange}
            rowsPerPage={pageSize}
            rowsPerPageOptions={[]}
            labelDisplayedRows={({ from, to, count }) =>
              `${from}-${to} of ${count}`
            }
          />
        </Box>
      </Paper>

      {/* Add/Edit Train Modal */}
      <AddModelTrain
        open={isModalOpen}
        train={selectedTrain}
        onSave={selectedTrain ? handleUpdateTrain : handleSaveTrain}
        onCancel={handleCancel}
      />

      <Dialog
        open={isViewModalOpen}
        onClose={handleCloseViewModal}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            overflow: "hidden",
          },
        }}
      >
        <DialogTitle
          sx={{
            backgroundColor: "primary.main",
            color: "white",
            display: "flex",
            alignItems: "center",
            gap: 2,
            py: 2,
          }}
        >
          <FaTrain />
          <Typography variant="h6" fontWeight="bold">
            Train Details: {selectedTrain?.trainNo}
          </Typography>
        </DialogTitle>

        <DialogContent sx={{ p: 3 }}>
          {selectedTrain && (
            <Box
              sx={{
                display: "flex",
                flexWrap: "wrap",
                gap: 3,
                mt: 2,
                pb: 2,
              }}
            >
              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  TRAIN INFORMATION
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem label="Train ID" value={selectedTrain.train_id} />
                <DetailItem
                  label="Train Number"
                  value={selectedTrain.trainNo}
                />
                <DetailItem
                  label="Train Name"
                  value={selectedTrain.trainName}
                />
                <DetailItem
                  label="Railway Zone"
                  value={selectedTrain.railwayZone}
                />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  CAPACITY DETAILS
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Number of Coaches"
                  value={selectedTrain.numberOfCoaches || "N/A"}
                />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  ROUTE DETAILS
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Departure Station"
                  value={selectedTrain.departFrom || "N/A"}
                />
                <DetailItem
                  label="Destination"
                  value={selectedTrain.destination || "N/A"}
                />
                <DetailItem
                  label="Organization"
                  value={selectedTrain.organization?.orgName || "N/A"}
                />
              </DetailCard>
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={handleCloseViewModal}
            variant="outlined"
            color="primary"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default TrainList;
