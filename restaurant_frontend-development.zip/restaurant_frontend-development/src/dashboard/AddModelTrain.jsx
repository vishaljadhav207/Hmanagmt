import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getSupervisorByOrgId } from "../app/userApi";
import { getClassTypesByTransportType } from "../app/busApi";
import {
  Box,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Typography,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Chip,
} from "@mui/material";
import { FaTrain } from "react-icons/fa";

const AddModelTrain = ({ open, train, onSave, onCancel }) => {
  const { userInfo: user } = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const {
    supervisorByOrg: supervisors = [],
    loading: supervisorLoading,
    error: supervisorError,
  } = useSelector((state) => state.user);

  const {
    classTypes = [],
    classTypesLoading,
    classTypesError,
  } = useSelector((state) => state.buses);

  // Initialize form data state
  const [formData, setFormData] = useState({
    trainNo: "",
    trainName: "",
    railwayZone: "",
    numberOfCoaches: "",
    departFrom: "",
    destination: "",
    userId: "",
    orgId: user?.orgId || "",
    classTypes: [],
    train_id: null,
  });

  const [formError, setFormError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when opening/closing or when train prop changes
  useEffect(() => {
    if (open) {
      if (train) {
        // For edit mode, normalize the train data
        setFormData({
          trainNo: train.trainNo || train.train_no || "",
          trainName: train.trainName || "",
          railwayZone: train.railwayZone || "",
          numberOfCoaches: train.numberOfCoaches || "",
          departFrom: train.departFrom || "",
          destination: train.destination || "",
          userId: train.userId || "",
          orgId: user?.orgId || train.orgId || train.organization?.orgId || "",
          classTypes: train.classTypes || [],
          train_id: train.train_id || null,
        });
      } else {
        // For add mode, reset to defaults but keep orgId
        setFormData({
          trainNo: "",
          trainName: "",
          railwayZone: "",
          numberOfCoaches: "",
          departFrom: "",
          destination: "",
          userId: "",
          orgId: user?.orgId || "",
          classTypes: [],
          train_id: null,
        });
      }
      setFormError(null);
    }
  }, [open, train, user?.orgId]);

  useEffect(() => {
    if (open && user?.orgId) {
      dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 2002 }));
      dispatch(getClassTypesByTransportType("TRAIN")); // Assuming "train" is the transport type
    }
  }, [dispatch, open, user?.orgId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleClassTypeChange = (classId) => (e) => {
    const { checked } = e.target;
    setFormData((prev) => {
      if (checked) {
        return {
          ...prev,
          classTypes: [...prev.classTypes, { classId }],
        };
      } else {
        return {
          ...prev,
          classTypes: prev.classTypes.filter((ct) => ct.classId !== classId),
        };
      }
    });
  };

  const isClassTypeSelected = (classId) => {
    return formData.classTypes.some((ct) => ct.classId === classId);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);
    setIsSubmitting(true);

    const { trainNo, trainName, userId, numberOfCoaches } = formData;
    if (!trainNo || !trainName || !userId || !numberOfCoaches) {
      setFormError("Please fill in all required fields (marked with *)");
      setIsSubmitting(false);
      return;
    }

    try {
      const trainData = {
        trainNo: String(formData.trainNo).trim(),
        trainName: String(formData.trainName).trim(),
        railwayZone: String(formData.railwayZone).trim(),
        numberOfCoaches: Number(formData.numberOfCoaches) || 0,
        departFrom: String(formData.departFrom).trim(),
        destination: String(formData.destination).trim(),
        userId: Number(formData.userId),
        organization: {
          orgId: Number(formData.orgId),
        },
        classTypes: formData.classTypes,
      };

      // Include train_id only in edit mode
      if (formData.train_id) {
        trainData.train_id = formData.train_id;
      }

      await onSave(trainData);
    } catch (err) {
      setFormError(err.message || "Failed to save train");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onCancel}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 3,
        },
      }}
    >
      <DialogTitle
        sx={{
          backgroundColor: "primary.main",
          color: "white",
          display: "flex",
          alignItems: "center",
          gap: 2,
          py: 2,
        }}
      >
        <FaTrain />
        <Typography variant="h6" fontWeight="bold">
          {formData.train_id ? "Edit Train" : "Add New Train"}
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ p: 3 }}>
        <Box component="form" onSubmit={handleSubmit}>
          {(formError || supervisorError || classTypesError) && (
            <Typography color="error" mb={2}>
              {formError || supervisorError || classTypesError}
            </Typography>
          )}

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
              mt: 2,
            }}
          >
            <TextField
              label="Train Number *"
              name="trainNo"
              value={formData.trainNo}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            <TextField
              label="Train Name *"
              name="trainName"
              value={formData.trainName}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            <TextField
              label="Railway Zone"
              name="railwayZone"
              value={formData.railwayZone}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            <TextField
              label="Number of Coaches *"
              name="numberOfCoaches"
              type="number"
              value={formData.numberOfCoaches}
              onChange={handleChange}
              fullWidth
              size="small"
              required
              inputProps={{ min: 1 }}
            />

            <TextField
              label="Departure Station"
              name="departFrom"
              value={formData.departFrom}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            <TextField
              label="Destination Station"
              name="destination"
              value={formData.destination}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            <FormControl fullWidth size="small" required>
              <InputLabel>Supervisor *</InputLabel>
              <Select
                name="userId"
                value={formData.userId}
                onChange={handleChange}
                label="Supervisor *"
                disabled={supervisorLoading}
              >
                <MenuItem value="">
                  {supervisorLoading ? "Loading..." : "Select Supervisor"}
                </MenuItem>
                {supervisors.map((s) => (
                  <MenuItem key={s.userId} value={s.userId}>
                    {s.firstName} {s.lastName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              label="Organization ID"
              name="orgId"
              value={formData.orgId}
              InputProps={{
                readOnly: true,
              }}
              fullWidth
              size="small"
              disabled
            />
          </Box>

          {/* Class Types Section */}
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Available Classes
            </Typography>

            {classTypesLoading ? (
              <CircularProgress size={24} />
            ) : (
              <FormGroup row>
                {classTypes.map((classType) => (
                  <FormControlLabel
                    key={classType.classId}
                    control={
                      <Checkbox
                        checked={isClassTypeSelected(classType.classId)}
                        onChange={handleClassTypeChange(classType.classId)}
                        name={`class-${classType.classId}`}
                      />
                    }
                    label={classType.className}
                  />
                ))}
              </FormGroup>
            )}

            {formData.classTypes.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Selected Classes:
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {formData.classTypes.map((classType) => {
                    const classInfo = classTypes.find(
                      (ct) => ct.classId === classType.classId
                    );
                    return (
                      <Chip
                        key={classType.classId}
                        label={
                          classInfo?.className || `Class ${classType.classId}`
                        }
                        onDelete={() =>
                          handleClassTypeChange(classType.classId)({
                            target: { checked: false },
                          })
                        }
                      />
                    );
                  })}
                </Box>
              </Box>
            )}
          </Box>

          <Divider sx={{ my: 3 }} />

          <DialogActions>
            <Button
              onClick={onCancel}
              variant="outlined"
              color="primary"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={isSubmitting}
              sx={{
                backgroundColor: "#5A2360",
                "&:hover": { backgroundColor: "#6B2D72" },
              }}
            >
              {isSubmitting
                ? "Processing..."
                : formData.train_id
                ? "Update Train"
                : "Add Train"}
            </Button>
          </DialogActions>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AddModelTrain;
