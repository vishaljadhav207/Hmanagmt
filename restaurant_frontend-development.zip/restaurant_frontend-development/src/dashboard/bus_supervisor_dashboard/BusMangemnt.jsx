import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { getBusByUserId, deleteBus } from "../../app/busApi";
import { selectBusTrips, selectBusTripStatus } from "../../redux/busSlice";
import { FaEye, FaTrash, FaEdit } from 'react-icons/fa';
import { toast } from 'react-toastify';

const BusManagement = () => {
  const dispatch = useDispatch();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedBus, setSelectedBus] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [busToDelete, setBusToDelete] = useState(null);
  
  const userDetails = JSON.parse(localStorage.getItem("USER_INFO"));
  const userId = userDetails?.id;
  const busTrips = useSelector(selectBusTrips) || [];
  const status = useSelector(selectBusTripStatus);

  useEffect(() => {
    if (userId) {
      dispatch(getBusByUserId(userId));
    }
  }, [dispatch, userId]);

  const handleView = (bus) => {
    setSelectedBus(bus);
    setIsModalOpen(true);
  };

  const handleDeleteClick = (busId) => {
    setBusToDelete(busId);
    setDeleteConfirmOpen(true);
  };

  const confirmDelete = async () => {
    try {
      await dispatch(deleteBus(busToDelete));
      toast.success('Bus deleted successfully');
    } catch (error) {
      const errorMsg = error.payload?.message || error.message || 'Failed to delete bus';
      toast.error(errorMsg);
    } finally {
      setDeleteConfirmOpen(false);
      setBusToDelete(null);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedBus(null);
  };

  const closeDeleteConfirm = () => {
    setDeleteConfirmOpen(false);
    setBusToDelete(null);
  };

  if (status === "loading") {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-fuchsia-950"></div>
      </div>
    );
  }

  if (status === "failed") {
    return (
      <div className="text-red-500 text-center py-4">
        Error loading buses: {error?.message || error?.error || error?.toString() || 'Unknown error'}
      </div>
    );
  }

  if (!busTrips || busTrips.length === 0) {
    return (
      <div className="text-center py-4">
        <p>No buses found</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Your Bus List</h2>
      </div>

      {/* Buses Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bus No</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bus Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Organization</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Seats</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fare</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
           
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {busTrips.map((bus) => (
              <tr key={bus.busId} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="font-medium">{bus.busNo}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800 capitalize">{bus.busType}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-800">{bus.organization?.orgName || 'N/A'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {bus.classTypes?.length > 0 ? (
                    bus.classTypes.map((classType) => (
                      <div key={classType.classId} className="text-sm text-gray-800 capitalize">
                        {classType.className}
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-gray-400">N/A</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {bus.classTypes?.length > 0 ? (
                    bus.classTypes.map((classType) => (
                      <div key={classType.classId} className="text-sm text-gray-800">
                        {classType.availability}
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-gray-400">N/A</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {bus.classTypes?.length > 0 ? (
                    bus.classTypes.map((classType) => (
                      <div key={classType.classId} className="text-sm font-medium text-blue-600">
                        ₹{classType.fare}
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-gray-400">N/A</div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    bus.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                    bus.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {bus.status || 'Active'}
                  </span>
                </td>
               
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    
  
    </div>
  );
};

export default BusManagement;