import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getBusTripsByUserId,
  deleteBusTrip,
  createBusTrip,
  updateBusTrip,
  getBusByUserId,
} from "../../app/busApi";
import { FaEye, FaTrash, FaPlus, FaEdit } from "react-icons/fa";
import Swal from "sweetalert2";

const BusTrip = ({ busId }) => {
  const userDetails = JSON.parse(localStorage.getItem("USER_INFO"));
  const userId = userDetails?.id;
  const dispatch = useDispatch();
  const { busTrips, buses, status, error } = useSelector((state) => ({
    busTrips: state.buses.busTrips,
    buses: state.buses.buses,
    status: state.buses.status,
    error: state.buses.error,
  }));

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [tripToDelete, setTripToDelete] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [tripToEdit, setTripToEdit] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTrip, setNewTrip] = useState({
    origin: "",
    destination: "",
    departureDate: "",
    arrivalDate: "",
    busId: "",
    totalRouteDistance: "",
    intermediateStops: [
      {
        stopName: "",
        arrivalTime: "",
        departureTime: "",
        sequence: 1,
        distanceFromPrevious: 0,
      },
    ],
    classTypes: [{ classId: "" }],
  });
  const [saveError, setSaveError] = useState("");

  useEffect(() => {
    if (userId) {
      dispatch(getBusByUserId(userId));
      dispatch(getBusTripsByUserId(userId));
    }
  }, [userId, dispatch]);

  const showSuccessAlert = (message) => {
    Swal.fire({
      title: "Success!",
      text: message,
      icon: "success",
      confirmButtonColor: "#4a044e",
      timer: 3000,
    });
  };

  const showErrorAlert = (message) => {
    Swal.fire({
      title: "Error!",
      text: message,
      icon: "error",
      confirmButtonColor: "#4a044e",
    });
  };

  const handleView = (trip) => {
    setSelectedTrip(trip);
    setIsModalOpen(true);
  };

  const handleDeleteClick = (tripId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#4a044e",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        confirmDelete(tripId);
      }
    });
  };

  const confirmDelete = async (tripId) => {
    try {
      await dispatch(deleteBusTrip(tripId));
      showSuccessAlert("Trip deleted successfully");
      dispatch(getBusTripsByUserId(userId));
    } catch (error) {
      const errorMsg =
        error.payload?.message || error.message || "Failed to delete trip";
      showErrorAlert(errorMsg);
    }
  };

  const handleAddClick = () => {
    setNewTrip((prev) => ({
      ...prev,
      busId: busId || "",
    }));
    setIsAddModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedTrip(null);
  };

  const closeAddModal = () => {
    setIsAddModalOpen(false);
    setNewTrip({
      origin: "",
      destination: "",
      departureDate: "",
      arrivalDate: "",
      busId: "",
      intermediateStops: [
        { stopName: "", arrivalTime: "", departureTime: "", sequence: 1 },
      ],
      classTypes: [{ classId: "" }],
    });
    setSaveError("");
  };

  const addIntermediateStop = () => {
    setNewTrip((prev) => ({
      ...prev,
      intermediateStops: [
        ...prev.intermediateStops,
        {
          stopName: "",
          arrivalTime: "",
          departureTime: "",
          sequence: prev.intermediateStops.length + 1,
          distanceFromPrevious: 0,
        },
      ],
    }));
  };

  const removeIntermediateStop = (index) => {
    const updatedStops = [...newTrip.intermediateStops];
    updatedStops.splice(index, 1);
    setNewTrip((prev) => ({ ...prev, intermediateStops: updatedStops }));
  };

  const addClassType = () => {
    setNewTrip((prev) => ({
      ...prev,
      classTypes: [...prev.classTypes, { classId: "" }],
    }));
  };

  const removeClassType = (index) => {
    const updated = [...newTrip.classTypes];
    updated.splice(index, 1);
    setNewTrip((prev) => ({ ...prev, classTypes: updated }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTrip((prev) => ({ ...prev, [name]: value }));
  };

  const handleStopChange = (index, field, value) => {
    const updatedStops = [...newTrip.intermediateStops];
    updatedStops[index][field] = value;
    setNewTrip((prev) => ({ ...prev, intermediateStops: updatedStops }));
  };

  const handleClassChange = (index, value) => {
    const updated = [...newTrip.classTypes];
    updated[index].classId = value;
    setNewTrip((prev) => ({ ...prev, classTypes: updated }));
  };

  const handleSaveTrip = async () => {
    try {
      if (
        !newTrip.origin ||
        !newTrip.destination ||
        !newTrip.departureDate ||
        !newTrip.arrivalDate ||
        !newTrip.busId ||
        !newTrip.totalRouteDistance
      ) {
        throw new Error("Please fill all required fields including bus ID");
      }

      const tripData = {
        origin: newTrip.origin,
        destination: newTrip.destination,
        departureDate: newTrip.departureDate,
        arrivalDate: newTrip.arrivalDate,
        bus: {
          busId: parseInt(newTrip.busId),
        },
        totalRouteDistance: parseInt(newTrip.totalRouteDistance),
        intermediateStops: newTrip.intermediateStops
          .filter((stop) => stop.stopName)
          .map((stop) => ({
            ...stop,
            sequence: parseInt(stop.sequence),
          })),
        classTypes: newTrip.classTypes
          .filter((cls) => cls.classId)
          .map((cls) => ({
            classId: parseInt(cls.classId),
          })),
      };

      let response;
      if (tripToEdit) {
        response = await dispatch(
          updateBusTrip({
            tripId: tripToEdit.busTripId,
            tripData,
          })
        );
        showSuccessAlert("Trip updated successfully");
      } else {
        response = await dispatch(createBusTrip(tripData));
        showSuccessAlert("Trip created successfully");
      }

      if (response.error) {
        throw new Error(response.error.message || "Failed to save trip");
      }

      dispatch(getBusTripsByUserId(userId));

      if (tripToEdit) {
        closeEditModal();
      } else {
        closeAddModal();
      }
    } catch (error) {
      setSaveError(error.message || "Failed to save trip. Please try again.");
      showErrorAlert(error.message || "Failed to save trip");
    }
  };

  if (status === "loading" && !busTrips) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-fuchsia-950"></div>
      </div>
    );
  }

  if (status === "failed") {
    return (
      <div className="text-red-500 text-center py-4">
        Error loading bus trips:{" "}
        {error?.message || error?.error || error?.toString() || "Unknown error"}
      </div>
    );
  }

  const handleEditClick = (trip) => {
    setTripToEdit(trip);
    setIsEditModalOpen(true);

    setNewTrip({
      origin: trip.origin,
      destination: trip.destination,
      departureDate: trip.departureDate,
      arrivalDate: trip.arrivalDate,
      busId: trip.bus?.busId || busId,
      totalRouteDistance: trip.totalRouteDistance || "",

      intermediateStops:
        trip.intermediateStops?.length > 0
          ? trip.intermediateStops.map((stop) => ({
              ...stop,
              distanceFromPrevious: stop.distanceFromPrevious || 0,
            }))
          : [
              {
                stopName: "",
                arrivalTime: "",
                departureTime: "",
                sequence: 1,
                distanceFromPrevious: 0,
              },
            ],
      classTypes:
        trip.classTypes?.length > 0 ? trip.classTypes : [{ classId: "" }],
    });
  };

  const closeEditModal = () => {
    setIsEditModalOpen(false);
    setTripToEdit(null);
    setNewTrip({
      origin: "",
      destination: "",
      departureDate: "",
      arrivalDate: "",
      busId: "",
      totalRouteDistance: "",
      intermediateStops: [
        { stopName: "", arrivalTime: "", departureTime: "", sequence: 1 },
      ],
      classTypes: [{ classId: "" }],
    });
  };

  const getMinDateTime = () => {
    const now = new Date();
    const pad = (n) => n.toString().padStart(2, "0");
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(
      now.getDate()
    )}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
  };

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header and Add Trip Button */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Bus Trips for Bus ID: {busId}</h2>
        <button
          onClick={handleAddClick}
          className="flex items-center px-4 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
        >
          <FaPlus className="mr-2" />
          Add Bus Trip
        </button>
      </div>

      {/* Trips Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Trip ID
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Departure
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Arrival
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Departure Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Arrival Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bus No
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total Distance (km)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {busTrips.map((trip) => (
              <tr key={trip.busTripId} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  {trip.busTripId}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{trip.origin}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {trip.destination}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(trip.departureDate).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {new Date(trip.arrivalDate).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {trip.bus?.busNo || "N/A"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {trip.totalRouteDistance || "N/A"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleView(trip)}
                      className="text-blue-600 hover:text-blue-800 p-1 rounded hover:bg-blue-100"
                      title="View Details"
                    >
                      <FaEye />
                    </button>
                    <button
                      onClick={() => handleDeleteClick(trip.busTripId)}
                      className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-100"
                      title="Delete"
                    >
                      <FaTrash />
                    </button>
                    <button
                      onClick={() => handleEditClick(trip)}
                      className="text-blue-500 hover:text-blue-700 p-1 rounded hover:bg-blue-100"
                      title="Edit"
                    >
                      <FaEdit />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit Trip Modal */}
      {isEditModalOpen && tripToEdit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            onClick={closeEditModal}
          />
          <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-y-auto">
            <div className="sticky top-0 z-10 bg-fuchsia-950 p-6 text-white">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold">Edit Trip</h3>
                <button
                  onClick={closeEditModal}
                  className="p-1 rounded-full hover:bg-white/20"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {saveError && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {saveError}
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bus*
                  </label>
                  <select
                    name="busId"
                    value={newTrip.busId}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100"
                    required
                    disabled={!!tripToEdit}
                  >
                    <option value="">Select a bus</option>
                    {buses.map((bus) => (
                      <option key={bus.busId} value={bus.busId}>
                        {bus.busNo} - {bus.busType}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Origin*
                  </label>
                  <input
                    type="text"
                    name="origin"
                    value={newTrip.origin}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Departure location"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Destination*
                  </label>
                  <input
                    type="text"
                    name="destination"
                    value={newTrip.destination}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Arrival location"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Departure Date*
                  </label>
                  <input
                    type="date"
                    name="departureDate"
                    value={newTrip.departureDate}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                    min={getMinDateTime()}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Arrival Date*
                  </label>
                  <input
                    type="date"
                    name="arrivalDate"
                    value={newTrip.arrivalDate}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                    min={getMinDateTime()}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Total Route Distance (km)*
                  </label>
                  <input
                    type="number"
                    name="totalRouteDistance"
                    value={newTrip.totalRouteDistance}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Total distance in km"
                    required
                    min={1}
                  />
                </div>
              </div>

              {/* Intermediate Stops */}
              <div className="space-y-4">
                <h4 className="text-lg font-medium"> Stops</h4>
                {newTrip.intermediateStops.map((stop, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Stop Name
                        </label>
                        <input
                          type="text"
                          value={stop.stopName}
                          onChange={(e) =>
                            handleStopChange(index, "stopName", e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Stop name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Arrival Time
                        </label>
                        <input
                          type="datetime-local"
                          value={stop.arrivalTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "arrivalTime",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          min={getMinDateTime()}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Departure Time
                        </label>
                        <input
                          type="datetime-local"
                          value={stop.departureTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "departureTime",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          min={getMinDateTime()}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Distance From Previous (km)
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.1"
                          value={stop.distanceFromPrevious}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "distanceFromPrevious",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Distance in km"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeIntermediateStop(index)}
                      className="mt-3 text-red-500 text-sm flex items-center"
                    >
                      <FaTrash className="mr-1" />
                      Remove Stop
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={addIntermediateStop}
                  className="flex items-center text-sm text-fuchsia-950"
                >
                  <FaPlus className="mr-1" />
                  Add Another Stop
                </button>
              </div>
            </div>
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex justify-end space-x-3">
              <button
                type="button"
                onClick={closeEditModal}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveTrip}
                className="px-6 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
              >
                Update Trip
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Trip Modal */}
      {isModalOpen && selectedTrip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            onClick={closeModal}
          />
          <div className="relative w-full max-w-3xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-hidden">
            <div className="sticky top-0 z-10 bg-fuchsia-950 p-6 text-white">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold">Trip Details</h3>
                <button
                  onClick={closeModal}
                  className="p-1 rounded-full hover:bg-white/20"
                  aria-label="Close modal"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-2 overflow-y-auto max-h-[60vh]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Trip Information
                  </h4>
                  <div className="space-y-2">
                    <p>
                      <span className="font-medium">Route:</span>{" "}
                      {selectedTrip.origin} → {selectedTrip.destination}
                    </p>
                    <p>
                      <span className="font-medium">Departure:</span>{" "}
                      {new Date(selectedTrip.departureDate).toLocaleString()}
                    </p>
                    <p>
                      <span className="font-medium">Arrival:</span>{" "}
                      {new Date(selectedTrip.arrivalDate).toLocaleString()}
                    </p>
                    <p>
                      <span className="font-medium">Total Distance:</span>{" "}
                      {selectedTrip.totalRouteDistance} km
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Bus Information
                  </h4>
                  <div className="space-y-2">
                    <p>
                      <span className="font-medium">Bus Number:</span>{" "}
                      {selectedTrip.bus?.busNo ?? "N/A"}
                    </p>
                    <p>
                      <span className="font-medium">Bus Type:</span>{" "}
                      {selectedTrip.bus?.busType ?? "N/A"}
                    </p>
                    <p>
                      <span className="font-medium">Operator:</span>{" "}
                      {selectedTrip.bus?.operatorName ?? "N/A"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">
                  Route Stops
                </h4>
                {selectedTrip.intermediateStops?.length > 0 ? (
                  <div className="space-y-3">
                    {selectedTrip.intermediateStops.map((stop, index) => (
                      <div key={index} className="flex items-start">
                        <div className="flex flex-col items-center mr-4">
                          <div className="w-px h-6 bg-gray-300"></div>
                          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                          <div className="w-px h-6 bg-gray-300"></div>
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{stop.stopName}</p>
                          {stop.arrivalTime && (
                            <p className="text-sm text-gray-500">
                              Arrival:{" "}
                              {new Date(stop.arrivalTime).toLocaleTimeString()}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No intermediate stops</p>
                )}
              </div>
            </div>

            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex justify-end">
              <button
                onClick={closeModal}
                className="px-6 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Trip Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            onClick={closeAddModal}
          />
          <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-y-auto">
            <div className="sticky top-0 z-10 bg-fuchsia-950 p-6 text-white">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold">Add Bus Trip</h3>
                <button
                  onClick={closeAddModal}
                  className="p-1 rounded-full hover:bg-white/20"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {saveError && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                  {saveError}
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bus*
                  </label>
                  <select
                    name="busId"
                    value={newTrip.busId}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="">Select a bus</option>
                    {buses.map((bus) => (
                      <option key={bus.busId} value={bus.busId}>
                        {bus.busNo} - {bus.busType}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Origin*
                  </label>
                  <input
                    type="text"
                    name="origin"
                    value={newTrip.origin}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Departure location"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Destination*
                  </label>
                  <input
                    type="text"
                    name="destination"
                    value={newTrip.destination}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Arrival location"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Departure Date*
                  </label>
                  <input
                    type="date"
                    name="departureDate"
                    value={newTrip.departureDate}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                    min={getMinDateTime()}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Arrival Date*
                  </label>
                  <input
                    type="date"
                    name="arrivalDate"
                    value={newTrip.arrivalDate}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                    min={getMinDateTime()}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Total Route Distance (km)*
                  </label>
                  <input
                    type="number"
                    name="totalRouteDistance"
                    value={newTrip.totalRouteDistance}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Total distance in km"
                    required
                    min={1}
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-lg font-medium"> Stops</h4>
                {newTrip.intermediateStops.map((stop, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-4"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Stop Name
                        </label>
                        <input
                          type="text"
                          value={stop.stopName}
                          onChange={(e) =>
                            handleStopChange(index, "stopName", e.target.value)
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Stop name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Arrival Time
                        </label>
                        <input
                          type="datetime-local"
                          value={stop.arrivalTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "arrivalTime",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          min={getMinDateTime()}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Departure Time
                        </label>
                        <input
                          type="datetime-local"
                          value={stop.departureTime}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "departureTime",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          min={getMinDateTime()}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Distance From Previous (km)
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.1"
                          value={stop.distanceFromPrevious}
                          onChange={(e) =>
                            handleStopChange(
                              index,
                              "distanceFromPrevious",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Distance in km"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeIntermediateStop(index)}
                      className="mt-3 text-red-500 text-sm flex items-center"
                    >
                      <FaTrash className="mr-1" />
                      Remove Stop
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={addIntermediateStop}
                  className="flex items-center text-sm text-fuchsia-950"
                >
                  <FaPlus className="mr-1" />
                  Add Another Stop
                </button>
              </div>
            </div>
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex justify-end space-x-3">
              <button
                type="button"
                onClick={closeAddModal}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveTrip}
                className="px-6 py-2 bg-fuchsia-950 text-white rounded-lg hover:bg-fuchsia-700 transition-colors"
              >
                Save Trip
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BusTrip;
