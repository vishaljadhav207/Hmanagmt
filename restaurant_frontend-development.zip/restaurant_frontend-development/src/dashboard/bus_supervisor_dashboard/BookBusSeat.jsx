import React, { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Box,
  Card,
  CardContent,
  Grid,
  Button,
  Chip,
  Divider,
  CircularProgress,
  Alert,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tooltip,
  Stepper,
  Step,
  StepLabel,
  Badge,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  TextField,
  MenuItem,
  InputAdornment,
} from "@mui/material";
import {
  ArrowBack as ArrowBackIcon,
  EventSeat as SeatIcon,
  DirectionsBus as BusIcon,
  Person as PersonIcon,
  Payment as PaymentIcon,
  LocationOn as LocationIcon,
  CheckCircle as CheckIcon,
  Person as DriverIcon,
  SupervisorAccount as ConductorIcon,
} from "@mui/icons-material";
import { useNavigate, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { saveTicket } from "../../app/busApi";
import seatAxios from "../../app/seatAxios";
import { format } from "date-fns";
import Swal from "sweetalert2";

const steps = ["Select Seats", "Review Details", "Payment"];

const BookBusSeat = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { userInfo } = useSelector((state) => state.user);
  const {
    busTripId,
    classType,
    fare,
    busData,
    seatPreference,
    passengerDetails,
  } = location.state || {};

  const [activeStep, setActiveStep] = useState(0);
  const [layout, setLayout] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [boardingPoint, setBoardingPoint] = useState(busData?.origin || "");
  const [dropPoint, setDropPoint] = useState(busData?.destination || "");
  const [openConfirmDialog, setOpenConfirmDialog] = useState(false);
  const [ticketStatus, setTicketStatus] = useState("idle");

  useEffect(() => {
    if (!busTripId || !busData) {
      navigate("/bus");
      return;
    }

    const fetchSeatLayout = async () => {
      try {
        setLoading(true);
        const response = await seatAxios.get(
          `/bus-seats/getBusSeatByBusId?busId=${busData.busId}`
        );

        if (!response.data || response.data.length === 0) {
          throw new Error("No seat layout found for this bus");
        }

        const seatData =
          response.data.find((sd) => sd.classId === busData.classId) ||
          response.data[0];

        const { totalRows, seatsPerRow, seatMap } = seatData.layout;
        const newLayout = [];

        // Add driver row (only one seat for driver)
        newLayout.push([
          { number: "Driver", type: "driver", available: false },
          ...Array(seatsPerRow - 1).fill(null),
          { number: "Conductor", type: "conductor", available: false },
        ]);

        // Process each row
        for (let row = 0; row < totalRows; row++) {
          const rowSeats = [];
          const rowStart = row * seatsPerRow;
          const leftSeats = seatMap.slice(
            rowStart,
            rowStart + Math.floor(seatsPerRow / 2)
          );
          const rightSeats = seatMap.slice(
            rowStart + Math.floor(seatsPerRow / 2),
            rowStart + seatsPerRow
          );

          // Left seats (window side)
          leftSeats.forEach((seat) => {
            rowSeats.push({
              ...seat,
              number: parseInt(seat.seatNumber.substring(1)),
              layout: seatData.layoutType || "Seater",
              seatType: "window",
            });
          });

          // Aisle (empty space)
          rowSeats.push(null);

          // Right seats (aisle side)
          rightSeats.forEach((seat) => {
            rowSeats.push({
              ...seat,
              number: parseInt(seat.seatNumber.substring(1)),
              layout: seatData.layoutType || "Seater",
              seatType: "aisle",
            });
          });

          newLayout.push(rowSeats);
        }

        setLayout(newLayout);
      } catch (err) {
        console.error("Failed to fetch seat layout:", err);
        setError(err.message || "Failed to load seat layout");
        Swal.fire({
          title: "Error",
          text: err.message || "Failed to load seat layout",
          icon: "error",
          confirmButtonColor: "#5A2360",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSeatLayout();
  }, [busTripId, busData, navigate]);

  const handleSeatClick = (seat) => {
    if (!seat || !seat.available) return;

    const isSelected = selectedSeats.some(
      (s) => s.seatNumber === seat.seatNumber
    );

    if (isSelected) {
      setSelectedSeats((prev) =>
        prev.filter((s) => s.seatNumber !== seat.seatNumber)
      );
    } else {
      if (selectedSeats.length >= passengerDetails.length) {
        Swal.fire({
          title: "Maximum Seats Reached",
          text: `You can only select ${passengerDetails.length} seat(s) for ${passengerDetails.length} passenger(s)`,
          icon: "warning",
          confirmButtonColor: "#5A2360",
        });
        return;
      }
      setSelectedSeats((prev) => [...prev, seat]);
    }
  };

  const handleNext = () => {
    if (activeStep === 0) {
      if (selectedSeats.length > passengerDetails.length) {
        Swal.fire({
          title: "Too Many Seats Selected",
          text: `Please select only ${passengerDetails.length} seat(s) for ${passengerDetails.length} passenger(s)`,
          icon: "warning",
          confirmButtonColor: "#5A2360",
        });
        return;
      }

      if (selectedSeats.length === 0) {
        Swal.fire({
          title: "No Seats Selected",
          text: "You can proceed without selecting seats, but passengers will be on waiting list",
          icon: "info",
          showCancelButton: true,
          confirmButtonColor: "#5A2360",
          cancelButtonColor: "#6c757d",
          confirmButtonText: "Proceed Anyway",
          cancelButtonText: "Select Seats",
        }).then((result) => {
          if (result.isConfirmed) {
            setActiveStep((prev) => prev + 1);
          }
        });
        return;
      }
    }

    setActiveStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const handleConfirmBooking = () => {
    setOpenConfirmDialog(true);
  };

  const handleCloseConfirmDialog = () => {
    setOpenConfirmDialog(false);
  };

  const handleProceedToPayment = async () => {
    try {
      setTicketStatus("loading");

      const ticketData = {
        transportType: "BUS_OPERATOR",
        transportId: busData.busId,
        tripId: busTripId,
        classType: classType,
        seatPreference: seatPreference || "Window",
        seatNumber: selectedSeats.map((seat) => seat.seatNumber),
        boarding: boardingPoint,
        departure: dropPoint,
        journeyDate: busData.departureDate,
        passengerList: passengerDetails.map((passenger, index) => ({
          name: passenger.name,
          age: parseInt(passenger.age),
          gender: passenger.gender,
          seatNumber: selectedSeats[index]?.seatNumber || null,
        })),
        busData,
      };

      const resultAction = await dispatch(saveTicket(ticketData));

      if (saveTicket.fulfilled.match(resultAction)) {
        setTicketStatus("succeeded");
        Swal.fire({
          title: "Booking Confirmed!",
          text: "Your bus tickets have been successfully booked",
          icon: "success",
          confirmButtonColor: "#5A2360",
        }).then(() => {
          navigate("/bus-ticket", {
            state: { ticket: { ...resultAction.payload, busData } },
          });
        });
      } else {
        throw new Error(resultAction.error.message || "Failed to save ticket");
      }
    } catch (error) {
      console.error("Failed to save ticket:", error);
      setError(error.message);
      setTicketStatus("failed");
      Swal.fire({
        title: "Booking Failed",
        text: error.message || "Failed to complete booking",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    } finally {
      setOpenConfirmDialog(false);
    }
  };

  const getSeatColor = (seat) => {
    if (!seat) return "transparent";
    if (!seat.available) return "#e0e0e0";
    if (selectedSeats.some((s) => s.seatNumber === seat.seatNumber))
      return "#4caf50";
    return seat.seatType === "window" ? "#1976d2" : "#9c27b0";
  };

  const renderBusInfo = () => (
    <Card variant="outlined" sx={{ mb: 3 }}>
      <CardContent>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={8}>
            <Typography variant="h6" component="div">
              {busData.operatorName} - {busData.busNo}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {busData.origin} to {busData.destination}
            </Typography>
            <Typography variant="body2">
              Departure: {format(new Date(busData.departureDate), "PPPp")}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box
              display="flex"
              justifyContent="flex-end"
              alignItems="center"
              gap={2}
            >
              <Chip
                icon={<BusIcon />}
                label={`Class: ${classType}`}
                variant="outlined"
              />
              <Chip
                label={`Fare: ₹${fare}/seat`}
                color="primary"
                variant="outlined"
              />
            </Box>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );

  const renderSeatLayout = () => (
    <Paper elevation={2} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        Select Your Seats ({selectedSeats.length}/{passengerDetails.length}{" "}
        selected)
      </Typography>

      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          bgcolor: "#f5f5f5",
          p: 3,
          borderRadius: 2,
          border: "1px dashed #e0e0e0",
        }}
      >
        <Box
          sx={{
            position: "relative",
            width: "100%",
            maxWidth: 600,
            bgcolor: "white",
            p: 2,
            borderRadius: 2,
            boxShadow: 1,
          }}
        >
          {/* Driver Area */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              mb: 2,
              p: 1,
              bgcolor: "#f0f0f0",
              borderRadius: 1,
            }}
          >
            <Typography variant="caption">Driver</Typography>
          </Box>

          {/* Seats */}
          {layout.map((row, rowIndex) => (
            <Box
              key={rowIndex}
              sx={{
                display: "flex",
                justifyContent: "center",
                mb: 1,
              }}
            >
              {row.map((seat, seatIndex) => (
                <Tooltip
                  key={seatIndex}
                  title={
                    seat
                      ? `Seat ${seat.seatNumber} - ${
                          seat.seatType === "window" ? "Window" : "Aisle"
                        }${!seat.available ? " (Booked)" : ""}`
                      : "Aisle"
                  }
                  placement="top"
                >
                  <Box
                    onClick={() => handleSeatClick(seat)}
                    sx={{
                      width: 40,
                      height: 40,
                      m: 0.5,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      borderRadius: 1,
                      cursor: seat?.available ? "pointer" : "not-allowed",
                      bgcolor: getSeatColor(seat),
                      color: seat?.available ? "white" : "text.disabled",
                      position: "relative",
                      border: seat ? "1px solid #ccc" : "none",
                      "&:hover": {
                        opacity: seat?.available ? 0.9 : 1,
                      },
                    }}
                  >
                    {seat ? (
                      seat.type === "driver" ? (
                        <DriverIcon fontSize="small" />
                      ) : seat.type === "conductor" ? (
                        <ConductorIcon fontSize="small" />
                      ) : (
                        <>
                          <SeatIcon fontSize="small" />
                          <Typography
                            variant="caption"
                            sx={{
                              position: "absolute",
                              bottom: 2,
                              fontSize: 10,
                            }}
                          >
                            {seat.number}
                          </Typography>
                          {selectedSeats.some(
                            (s) => s.seatNumber === seat.seatNumber
                          ) && (
                            <Badge
                              badgeContent={
                                selectedSeats.findIndex(
                                  (s) => s.seatNumber === seat.seatNumber
                                ) + 1
                              }
                              color="secondary"
                              sx={{
                                position: "absolute",
                                top: -8,
                                right: -8,
                              }}
                            />
                          )}
                        </>
                      )
                    ) : null}
                  </Box>
                </Tooltip>
              ))}
            </Box>
          ))}

          {/* Conductor Area */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              mt: 2,
              p: 1,
              bgcolor: "#f0f0f0",
              borderRadius: 1,
            }}
          >
            <Typography variant="caption">Conductor</Typography>
          </Box>
        </Box>
      </Box>

      <Box
        sx={{
          display: "flex",
          gap: 2,
          mt: 3,
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            sx={{ width: 20, height: 20, bgcolor: "#1976d2", borderRadius: 1 }}
          />
          <Typography variant="caption">Window Seats</Typography>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            sx={{ width: 20, height: 20, bgcolor: "#9c27b0", borderRadius: 1 }}
          />
          <Typography variant="caption">Aisle Seats</Typography>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            sx={{ width: 20, height: 20, bgcolor: "#4caf50", borderRadius: 1 }}
          />
          <Typography variant="caption">Selected</Typography>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            sx={{ width: 20, height: 20, bgcolor: "#e0e0e0", borderRadius: 1 }}
          />
          <Typography variant="caption">Booked</Typography>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Box
            sx={{
              width: 20,
              height: 20,
              bgcolor: "transparent",
              border: "1px solid #ccc",
              borderRadius: 1,
            }}
          />
          <Typography variant="caption">Aisle</Typography>
        </Box>
      </Box>
    </Paper>
  );

  const renderPassengerDetails = () => (
    <Paper elevation={2} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        Passenger Details
      </Typography>

      <List>
        {passengerDetails.map((passenger, index) => (
          <ListItem
            key={index}
            divider
            sx={{
              bgcolor: "#f9f9f9",
              borderRadius: 1,
              mb: 1,
            }}
          >
            <ListItemAvatar>
              <Avatar sx={{ bgcolor: "#5A2360" }}>
                <PersonIcon />
              </Avatar>
            </ListItemAvatar>
            <ListItemText
              primary={passenger.name}
              secondary={`${passenger.gender}, ${passenger.age} years`}
            />
            <Chip
              label={
                selectedSeats[index]
                  ? `Seat: ${selectedSeats[index].seatNumber}`
                  : "No seat selected"
              }
              color={selectedSeats[index] ? "primary" : "default"}
              variant="outlined"
            />
          </ListItem>
        ))}
      </List>

      <Grid container spacing={2} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <TextField
            select
            fullWidth
            label="Boarding Point"
            value={boardingPoint}
            onChange={(e) => setBoardingPoint(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LocationIcon color="action" />
                </InputAdornment>
              ),
            }}
          >
            {busData?.stops?.map((stop, index) => (
              <MenuItem key={index} value={stop.name}>
                {stop.name} ({stop.time})
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            select
            fullWidth
            label="Drop Point"
            value={dropPoint}
            onChange={(e) => setDropPoint(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LocationIcon color="action" />
                </InputAdornment>
              ),
            }}
          >
            {busData?.stops?.map((stop, index) => (
              <MenuItem
                key={index}
                value={stop.name}
                disabled={
                  busData.stops.findIndex((s) => s.name === boardingPoint) >=
                  index
                }
              >
                {stop.name} ({stop.time})
              </MenuItem>
            ))}
          </TextField>
        </Grid>
      </Grid>
    </Paper>
  );

  const renderPaymentSummary = () => (
    <Paper elevation={2} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom>
        Fare Summary
      </Typography>

      <Box sx={{ mb: 2 }}>
        <Box display="flex" justifyContent="space-between" mb={1}>
          <Typography variant="body1">Base Fare</Typography>
          <Typography variant="body1">
            ₹{fare} x {passengerDetails.length}
          </Typography>
        </Box>
        <Box display="flex" justifyContent="space-between" mb={1}>
          <Typography variant="body1">Seat Selection</Typography>
          <Typography variant="body1">
            {selectedSeats.length > 0 ? "Selected" : "Not Selected"}
          </Typography>
        </Box>
        <Box display="flex" justifyContent="space-between" mb={1}>
          <Typography variant="body1">Taxes & Fees</Typography>
          <Typography variant="body1">₹200.00</Typography>
        </Box>
        <Divider sx={{ my: 2 }} />
        <Box display="flex" justifyContent="space-between">
          <Typography variant="h6">Base Amount</Typography>
          <Typography variant="h6" color="primary">
            ₹{(fare * passengerDetails.length + 200).toFixed(2)}
          </Typography>
        </Box>
      </Box>

      {selectedSeats.length < passengerDetails.length && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          {passengerDetails.length - selectedSeats.length} passenger(s) will be
          on waiting list as no seats are selected for them.
        </Alert>
      )}

      <Button
        variant="contained"
        color="primary"
        fullWidth
        size="large"
        onClick={handleConfirmBooking}
        disabled={ticketStatus === "loading"}
        sx={{ mt: 2 }}
      >
        {ticketStatus === "loading" ? (
          <CircularProgress size={24} color="inherit" />
        ) : (
          "Confirm & Pay"
        )}
      </Button>
    </Paper>
  );

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <>
            {renderBusInfo()}
            {renderSeatLayout()}
          </>
        );
      case 1:
        return (
          <>
            {renderBusInfo()}
            {renderPassengerDetails()}
          </>
        );
      case 2:
        return renderPaymentSummary();
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <Container maxWidth="md" sx={{ py: 4, textAlign: "center" }}>
        <CircularProgress />
        <Typography variant="body1" sx={{ mt: 2 }}>
          Loading seat layout...
        </Typography>
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ py: 4 }}>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Button
          variant="contained"
          onClick={() => navigate("/bus")}
          startIcon={<ArrowBackIcon />}
        >
          Back to Bus Search
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate(-1)}
        sx={{ mb: 3 }}
      >
        Back
      </Button>

      <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {renderStepContent()}

      <Box sx={{ display: "flex", justifyContent: "space-between", mt: 3 }}>
        <Button
          onClick={handleBack}
          disabled={activeStep === 0}
          variant="outlined"
          sx={{ borderRadius: 2 }}
        >
          Back
        </Button>
        <Button
          variant="contained"
          onClick={
            activeStep === steps.length - 1 ? handleConfirmBooking : handleNext
          }
          disabled={
            activeStep === steps.length - 1 &&
            selectedSeats.length > passengerDetails.length
          }
          sx={{ borderRadius: 2 }}
        >
          {activeStep === steps.length - 1 ? "Finish" : "Next"}
        </Button>
      </Box>

      <Dialog
        open={openConfirmDialog}
        onClose={handleCloseConfirmDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Confirm Your Booking</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            You are booking {passengerDetails.length} ticket(s):
          </Typography>

          <List dense>
            {passengerDetails.map((passenger, index) => (
              <ListItem key={index}>
                <ListItemText
                  primary={passenger.name}
                  secondary={`Seat: ${
                    selectedSeats[index]?.seatNumber || "Waiting"
                  }`}
                />
              </ListItem>
            ))}
          </List>

          <Typography gutterBottom sx={{ mt: 2 }}>
            <strong>Boarding:</strong> {boardingPoint}
          </Typography>
          <Typography gutterBottom>
            <strong>Drop Point:</strong> {dropPoint}
          </Typography>

          <Typography gutterBottom sx={{ mt: 2 }}>
            <strong>Base Amount:</strong> ₹
            {fare * passengerDetails.length + 200}
          </Typography>
          <Typography
            variant="caption"
            color="warning.main"
            sx={{ display: "block", mt: 1 }}
          >
            * Final amount will be confirmed after booking by the backend.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={handleCloseConfirmDialog}
            variant="outlined"
            color="inherit"
          >
            Cancel
          </Button>
          <Button
            onClick={handleProceedToPayment}
            variant="contained"
            color="primary"
            disabled={ticketStatus === "loading"}
          >
            {ticketStatus === "loading" ? (
              <CircularProgress size={24} />
            ) : (
              "Confirm Payment"
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default BookBusSeat;
