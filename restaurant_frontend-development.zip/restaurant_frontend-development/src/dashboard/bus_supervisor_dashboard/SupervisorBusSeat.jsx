import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getBusByUserId } from "../../app/busApi";
import { selectBusTrips } from "../../redux/busSlice";
import seatAxios from "../../app/seatAxios";
import {
  Box,
  Card,
  CardContent,
  Container,
  Grid,
  Typography,
} from "@mui/material";

//custom components
import SeatLayoutPreview from "../component/SeatLayoutPreview";
import CustomButton from "../component/CustomButton";
import CustomSnackbar from "../component/CustomSnackbar";
import CustomSelect from "../component/CustomSelect";
import CustomTextField from "../component/CustomTextField";

function SupervisorBusSeat() {
  const [totalSeats, setTotalSeats] = useState(40);
  const [seatType, setSeatType] = useState("1x2");
  const [layoutType, setLayoutType] = useState("Seater");
  const [layout, setLayout] = useState([]);
  const [busId, setBusId] = useState("");
  const [classId, setClassId] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedBus, setSelectedBus] = useState(null);
  const [selectedClass, setSelectedClass] = useState(null);
  const [hasExistingLayout, setHasExistingLayout] = useState(false);
  const [currentLayoutId, setCurrentLayoutId] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success"
  });
  const dispatch = useDispatch();

  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;
  const buses = useSelector(selectBusTrips) || [];

  useEffect(() => {
    if (userId) {
      dispatch(getBusByUserId(userId));
    }
  }, [dispatch, userId]);

  useEffect(() => {
    if (buses.length > 0) {
      const firstBus = buses[0];
      setSelectedBus(firstBus);
      setBusId(firstBus?.busId || "");
      if (firstBus?.classTypes?.length > 0) {
        setClassId(firstBus.classTypes[0].classId);
        setSelectedClass(firstBus.classTypes[0]);
      }
    }
  }, [buses]);

  useEffect(() => {
    if (busId && classId) {
      fetchSeatLayout(busId, classId);
    }
  }, [busId, classId]);

  const generateLayout = () => {
    const [left, right] = seatType.split("x").map(Number);
    const seatsPerRow = left + right;
    const usableSeats = totalSeats - 2;
    const totalRows = Math.ceil(usableSeats / seatsPerRow);
    const newLayout = [];

    newLayout.push([
      { number: "Driver", type: "driver" },
      ...Array(seatsPerRow).fill(null),
      { number: "Conductor", type: "conductor" }
    ]);

    let seatNumber = 1;

    for (let row = 0; row < totalRows; row++) {
      const rowSeats = [];
      const deck = row < totalRows / 2 ? "L" : "U";

      for (let i = 0; i < left; i++) {
        const seatPosition = i === 0 ? "window" : left >= 3 && i === 1 ? "middle" : "aisle";
        rowSeats.push(seatNumber <= usableSeats
          ? {
            number: seatNumber,
            seatNumber: `${deck}${seatNumber}`,
            type: seatPosition,
            layout: layoutType,
            available: true
          }
          : null);
        seatNumber++;
      }

      rowSeats.push("aisle");

      for (let i = 0; i < right; i++) {
        const seatPosition = i === right - 1 ? "window" : right >= 3 && i === 1 ? "middle" : "aisle";
        rowSeats.push(seatNumber <= usableSeats
          ? {
            number: seatNumber,
            seatNumber: `${deck}${seatNumber}`,
            type: seatPosition,
            layout: layoutType,
            available: true
          }
          : null);
        seatNumber++;
      }

      newLayout.push(rowSeats);
    }

    setLayout(newLayout);
    setHasExistingLayout(false);
  };

  const deleteSeatLayout = async (id) => {
    try {
      setLoading(true);
      await seatAxios.delete(`/bus-seats/delete?id=${id}`);

      setSnackbar({
        open: true,
        message: "Seat layout deleted successfully!",
        severity: "success"
      });

      setLayout([]);
      setHasExistingLayout(false);
    } catch (error) {
      console.error("Error deleting seat layout:", error);
      setSnackbar({
        open: true,
        message: "Failed to delete seat layout",
        severity: "error"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSeatLayout = async (busId, classId) => {
    try {
      setLoading(true);
      const response = await seatAxios.get(
        `bus-seats?busId=${busId}&classId=${classId}`
        


      );
      const seatData = response.data;

      if (!seatData || !seatData.layout) {
        setHasExistingLayout(false);
        setLayout([]);
        setSnackbar({
          open: true,
          message: "Seat layout is not available.",
          severity: "warning"
        });
        return;
      }

      setCurrentLayoutId(seatData.id);

      const { totalRows, seatsPerRow, seatMap } = seatData.layout;
      const newLayout = [];

      newLayout.push([
        { number: "Driver", type: "driver" },
        ...Array(seatsPerRow).fill(null),
        { number: "Conductor", type: "conductor" }
      ]);

      for (let row = 0; row < totalRows; row++) {
        const rowSeats = [];
        const leftSeats = seatMap.slice(row * seatsPerRow, row * seatsPerRow + seatsPerRow / 2);
        const rightSeats = seatMap.slice(row * seatsPerRow + seatsPerRow / 2, (row + 1) * seatsPerRow);

        leftSeats.forEach(seat => {
          rowSeats.push({
            ...seat,
            number: parseInt(seat.seatNumber.substring(1)),
            layout: layoutType
          });
        });

        rowSeats.push("aisle");

        rightSeats.forEach(seat => {
          rowSeats.push({
            ...seat,
            number: parseInt(seat.seatNumber.substring(1)),
            layout: layoutType
          });
        });

        newLayout.push(rowSeats);
      }

      setLayout(newLayout);
      setHasExistingLayout(true);
    } catch (error) {
      console.error("Failed to fetch seat layout:", error);
      setHasExistingLayout(false);
      setLayout([]);
    
    } finally {
      setLoading(false);
    }
  };

  const toggleSeatAvailability = async (seatNumber) => {
    try {
      const currentSeat = layout
        .flat()
        .find(seat => seat && typeof seat === "object" && seat.seatNumber === seatNumber);

      if (!currentSeat) return;

      const newAvailability = !currentSeat.available;

      const updatedLayout = layout.map((row) =>
        row.map((seat) =>
          seat && seat.seatNumber === seatNumber
            ? { ...seat, available: newAvailability }
            : seat
        )
      );
      setLayout(updatedLayout);

      await seatAxios.patch(
        `/bus-seats/update-seat?busId=${busId}&classId=${classId}&seatNumber=${seatNumber}&isAvailable=${newAvailability}`
      );

      setSnackbar({
        open: true,
        message: `Seat ${seatNumber} marked as ${newAvailability ? 'available' : 'unavailable'}`,
        severity: "success"
      });
    } catch (error) {
      console.error("Error updating seat availability:", error);
      const revertedLayout = layout.map((row) =>
        row.map((seat) =>
          seat && seat.seatNumber === seatNumber
            ? { ...seat, available: !newAvailability }
            : seat
        )
      );
      setLayout(revertedLayout);
      setSnackbar({
        open: true,
        message: "Failed to update seat availability",
        severity: "error"
      });
    }
  };

  const saveSeatLayout = async () => {
    try {
      setLoading(true);
      const payload = {
        totalRows: layout.length - 1,
        seatsPerRow: seatType.split("x").reduce((a, b) => parseInt(a) + parseInt(b)),
        seatMap: layout.flatMap((row, rowIndex) =>
          rowIndex === 0
            ? []
            : row
              .filter(seat => seat && typeof seat === "object")
              .map(seat => ({
                seatNumber: seat.seatNumber,
                type: seat.type,
                available: seat.available
              }))
        ),
      };

      await seatAxios.post(
        `/bus-seats/create-by-id?busId=${busId}&classId=${classId}`,
        payload
      );

      setSnackbar({
        open: true,
        message: "Seat layout saved successfully!",
        severity: "success"
      });
      setHasExistingLayout(true);
    } catch (error) {
      console.error("Error saving seat layout:", error);
      setSnackbar({
        open: true,
        message: "Failed to save seat layout",
        severity: "error"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const busOptions = buses.map(bus => ({
    value: bus.busId,
    label: `${bus.busNo} - ${bus.busType}`
  }));

  const classOptions = selectedBus?.classTypes?.map(cls => ({
    value: cls.classId,
    label: cls.className
  })) || [];

  const seatPatternOptions = [
    { value: '1x2', label: '1x2 (Single Aisle)' },
    { value: '2x2', label: '2x2 (Dual Aisle)' },
    { value: '2x3', label: '2x3 (Wide Aisle)' }
  ];

  const layoutTypeOptions = [
    { value: 'Seater', label: 'Seater' },
    { value: 'Sleeper', label: 'Sleeper' }
  ];

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, textAlign: "center" }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Bus Seat Administration
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Manage seat layouts for your buses
        </Typography>
      </Box>

      <Card sx={{ mb: 4 }}>
        <CardContent>
          <Grid container spacing={3}>
            {/* Bus Dropdown */}
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Select Bus"
                value={busId}
                onChange={(e) => {
                  const bus = buses.find(b => b.busId === parseInt(e.target.value));
                  setSelectedBus(bus);
                  setBusId(e.target.value);
                  if (bus?.classTypes?.length > 0) {
                    setClassId(bus.classTypes[0].classId);
                    setSelectedClass(bus.classTypes[0]);
                  }
                }}
                options={busOptions}
              />
            </Grid>

            {/* Class Type */}
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Class Type"
                value={classId}
                onChange={(e) => {
                  const selectedClass = selectedBus?.classTypes?.find(cls => cls.classId === parseInt(e.target.value));
                  setClassId(e.target.value);
                  setSelectedClass(selectedClass);
                }}
                options={classOptions}
              />
            </Grid>

            {/* Total Seats */}
            <Grid item xs={12} md={4}>
              <CustomTextField
                label="Total Seats"
                type="number"
                value={totalSeats}
                onChange={(e) => setTotalSeats(Math.max(2, Number(e.target.value)))}
                disabled={hasExistingLayout}
                min={2}
              />
            </Grid>

            {/* Seat Pattern */}
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Seat Pattern"
                value={seatType}
                onChange={(e) => setSeatType(e.target.value)}
                options={seatPatternOptions}
                disabled={hasExistingLayout}
              />
            </Grid>

            {/* Layout Type */}
            <Grid item xs={12} md={4}>
              <CustomSelect
                label="Layout Type"
                value={layoutType}
                onChange={(e) => setLayoutType(e.target.value)}
                options={layoutTypeOptions}
                disabled={hasExistingLayout}
              />
            </Grid>
          </Grid>

          {!hasExistingLayout && (
            <CustomButton
              onClick={generateLayout}
              sx={{ mt: 2 }}
            >
              Generate Layout
            </CustomButton>
          )}
        </CardContent>
      </Card>

      {layout.length > 0 && (
        <>
          <SeatLayoutPreview
            layout={layout}
            onSeatClick={toggleSeatAvailability}
          />

          <CustomButton
            color="success"
            fullWidth
            onClick={saveSeatLayout}
            disabled={loading || !busId || !classId}
            loading={loading}
            sx={{ mt: 2 }}
          >
            Save Seat Layout
          </CustomButton>

          {hasExistingLayout && currentLayoutId && (
            <CustomButton
              color="error"
              fullWidth
              onClick={() => deleteSeatLayout(currentLayoutId)}
              disabled={loading}
              loading={loading}
              sx={{ mt: 2 }}
            >
              Delete Layout
            </CustomButton>
          )}
        </>
      )}

      <CustomSnackbar
        open={snackbar.open}
        onClose={handleCloseSnackbar}
        message={snackbar.message}
        severity={snackbar.severity}
      />
    </Container>
  );
}

export default SupervisorBusSeat;