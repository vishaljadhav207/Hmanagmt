import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getAllHotels,
  fetchAmenities,
  saveHotel,
  updateHotel,
  deleteHotel,
} from "../app/hotelApi";
import { setCurrentPage, setPageSize } from "../redux/hotelSlice";
import AddModal from "./AddModal";
import AppButton from "../components/AppButton";
import ViewDetailsModal from "./ViewDetailsModal";
import Swal from "sweetalert2";
import { FaEdit, FaTrash, FaEye, FaPlus } from "react-icons/fa";

const HotelList = () => {
  const dispatch = useDispatch();
  const hotels = useSelector((state) => state.hotels.hotels || []);
  const hotelStatus = useSelector((state) => state.hotels.status);
  const amenities = useSelector((state) => state.hotels.amenities || []);
  const error = useSelector((state) => state.hotels.error);
  const currentPage = useSelector((state) => state.hotels.currentPage);
  const totalPages = useSelector((state) => state.hotels.totalPages);
  const pageSize = useSelector((state) => state.hotels.pageSize);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [saveError, setSaveError] = useState(null);

  useEffect(() => {
    dispatch(getAllHotels({ page: currentPage, size: pageSize }));
    dispatch(fetchAmenities());
  }, [dispatch, currentPage, pageSize]);

  const handleAddHotel = () => {
    setSelectedHotel(null);
    setIsModalOpen(true);
  };

  const handleSaveHotel = async (hotelData) => {
  try {
    await dispatch(saveHotel(hotelData));
    setIsModalOpen(false);
    setSaveError(null);
    dispatch(getAllHotels({ page: currentPage, size: pageSize }));
    Swal.fire({
      icon: "success",
      title: "Hotel saved successfully!",
      showConfirmButton: false,
      timer: 1500,
    });
  } catch (error) {
    setSaveError("Failed to save hotel. Please try again.");
    Swal.fire({
      icon: "error",
      title: "Save failed",
      text: "Failed to save hotel. Please try again.",
    });
  }
};

const handleUpdateHotel = async (hotelData) => {
  if (selectedHotel && selectedHotel.hotelId) {
    hotelData.hotelId = selectedHotel.hotelId;
    try {
      await dispatch(updateHotel(hotelData));
      setIsModalOpen(false);
      setSaveError(null);
      dispatch(getAllHotels({ page: currentPage, size: pageSize }));
      Swal.fire({
        icon: "success",
        title: "Hotel updated successfully!",
        showConfirmButton: false,
        timer: 1500,
      });
    } catch (error) {
      setSaveError("Failed to update hotel. Please try again.");
      Swal.fire({
        icon: "error",
        title: "Update failed",
        text: "Failed to update hotel. Please try again.",
      });
    }
  }
};            

  const handleDeleteHotel = (hotelId) => {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      dispatch(deleteHotel(hotelId)).then(() => {
        dispatch(getAllHotels({ page: currentPage, size: pageSize }));
        Swal.fire("Deleted!", "Hotel has been deleted.", "success");
      });
    }
  });
};

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const handleViewDetails = (hotel) => {
    setSelectedHotel(hotel);
    setIsViewModalOpen(true);
  };

  const handleCloseViewModal = () => {
    setIsViewModalOpen(false);
  };

  const handlePageChange = (newPage) => {
    if (newPage < 0 || newPage >= totalPages) return;
    if (newPage < 0 || newPage >= totalPages) return;
    dispatch(setCurrentPage(newPage));
  };

  const handlePageSizeChange = (newSize) => {
    dispatch(setPageSize(newSize));
    dispatch(setCurrentPage(0));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-800">Hotel List</h2>
        <AppButton
          title="Add Hotel"
          onClick={handleAddHotel}
          icon={<FaPlus className="mr-2" />}
          className="bg-[#5A2360] text-white w-35"
        />
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          Error: {error}
        </div>
      )}

      {saveError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {saveError}
        </div>
      )}

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Owner
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hotel Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Address
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rooms
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {hotelStatus === "loading" ? (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center">
                    <div className="flex justify-center items-center space-x-2">
                      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-fuchsia-950"></div>
                      <span>Loading hotels...</span>
                    </div>
                  </td>
                </tr>
              ) : hotels.length === 0 ? (
                <tr>
                  <td
                    colSpan="6"
                    className="px-6 py-4 text-center text-gray-500"
                  >
                    No hotels found
                  </td>
                </tr>
              ) : (
                hotels.map((hotel) => (
                  <tr key={hotel.hotelId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {hotel.hotelId}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {hotel.hotelOwner.firstName} {hotel.hotelOwner.lastName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {hotel.hotelName}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {hotel.hotelAdd.length > 30
                        ? `${hotel.hotelAdd.substring(0, 30)}...`
                        : hotel.hotelAdd}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {hotel.hotelRooms}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleViewDetails(hotel)}
                          className="text-[#5A2360] hover:text-fuchsia-700"
                          title="View"
                        >
                          <FaEye />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedHotel(hotel);
                            setIsModalOpen(true);
                          }}
                          className="text-blue-600 hover:text-blue-900"
                          title="Edit"
                        >
                          <FaEdit />
                        </button>
                        <button
                          onClick={() => handleDeleteHotel(hotel.hotelId)}
                          className="text-red-600 hover:text-red-900"
                          title="Delete"
                        >
                          <FaTrash />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="bg-gray-50 px-6 py-3 flex items-center justify-between border-t border-gray-200">
          <div className="flex-1 flex justify-between items-center sm:hidden">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 0}
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Previous
            </button>
            <span className="text-sm text-gray-700">
              Page {currentPage + 1} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage >= totalPages - 1}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Next
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing{" "}
                <span className="font-medium">
                  {currentPage * pageSize + 1}
                </span>{" "}
                to{" "}
                <span className="font-medium">
                  {Math.min((currentPage + 1) * pageSize, hotels.length)}
                </span>{" "}
                of <span className="font-medium">{hotels.length}</span> results
              </p>
            </div>
            <div className="flex space-x-2">
              <select
                value={pageSize}
                onChange={(e) => handlePageSizeChange(Number(e.target.value))}
                className="border-gray-300 rounded-md shadow-sm focus:border-fuchsia-900 focus:ring-fuchsia-900 text-sm"
              >
                {[5, 10, 20, 50].map((size) => (
                  <option key={size} value={size}>
                    Show {size}
                  </option>
                ))}
              </select>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 0}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  <span className="sr-only">Previous</span>
                  &larr;
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => handlePageChange(i)}
                    className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                      currentPage === i
                        ? "z-10 bg-[#5A2360] border-fuchsia-900 text-white"
                        : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages - 1}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  <span className="sr-only">Next</span>
                  &rarr;
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <AddModal
          hotel={selectedHotel}
          amenities={amenities || []}
          onSave={selectedHotel ? handleUpdateHotel : handleSaveHotel}
          onCancel={handleCancel}
        />
      )}

      {isViewModalOpen && (
        <ViewDetailsModal
          hotel={selectedHotel}
          onClose={handleCloseViewModal}
        />
      )}
    </div>
  );
};

export default HotelList;
