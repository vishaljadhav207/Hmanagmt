import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getSupervisorByOrgId,
  registerbusSupervisor,
  deleteUser,
  updateUser,
} from "../app/userApi";
import GridTable from "../components/GridTable.jsx";
import Swal from "sweetalert2";

const BusSupervisorList = () => {
  const dispatch = useDispatch();
  const { userInfo: user } = useSelector((state) => state.user);
  const {
    supervisorByOrg: supervisors,
    loading,
    error,
  } = useSelector((state) => state.user);

  const [modalMode, setModalMode] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedSupervisor, setSelectedSupervisor] = useState(null);

  const [newUser, setNewUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    mobile: "",
    role: "",
    orgId: user?.orgId || "",
  });

  useEffect(() => {
    if (user?.orgId) {
      dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 4002 }));
    }
  }, [dispatch, user?.orgId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const userToSubmit = {
      ...newUser,
      role: { roleId: 4002 }, // Bus supervisor role ID
    };

    dispatch(registerbusSupervisor(userToSubmit))
      .unwrap()
      .then(() => {
        dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 4002 }));
        Swal.fire(
          "Success",
          "Bus supervisor registered successfully",
          "success"
        );
        resetForm();
        setModalMode(null);
      })
      .catch((error) => {
        Swal.fire("Error", "Failed to register bus supervisor", "error");
        console.error("Registration error:", error);
      });
  };

  const handleUpdate = (e) => {
    e.preventDefault();

    const updatedUser = {
      id: selectedSupervisor.userId,
      firstName: selectedSupervisor.firstName,
      lastName: selectedSupervisor.lastName,
      email: selectedSupervisor.email,
      mobile: selectedSupervisor.mobile,
    };

    dispatch(updateUser(updatedUser))
      .unwrap()
      .then(() => {
        dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 4002 }));
        Swal.fire(
          "Updated!",
          "Bus supervisor updated successfully.",
          "success"
        );
        setModalMode(null);
        resetForm();
      })
      .catch((error) => {
        Swal.fire("Error!", "Failed to update bus supervisor.", "error");
        console.error("Update error:", error);
      });
  };

  const handleDelete = (userId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        dispatch(deleteUser(userId))
          .unwrap()
          .then(() => {
            dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 4002 }));
            Swal.fire(
              "Deleted!",
              "The bus supervisor has been deleted.",
              "success"
            );
          })
          .catch(() => {
            Swal.fire("Error!", "Failed to delete bus supervisor.", "error");
          });
      }
    });
  };

  const handleView = (supervisor) => {
    setSelectedSupervisor(supervisor);
    setModalMode("VIEW");
  };

  const resetForm = () => {
    setNewUser({
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      mobile: "",
      role: "supervisor",
      orgId: user?.orgId || "",
    });
    setSelectedSupervisor(null);
    setIsEditMode(false);
  };

  const modifiedSupervisors =
    supervisors?.map((supervisor) => ({
      ...supervisor,
      id: supervisor.userId,
      role: supervisor.role?.roleName || "Bus Supervisor",
    })) || [];

  const columns = [
    { field: "id", headerName: "ID", flex: 1 },
    { field: "firstName", headerName: "First Name", flex: 1 },
    { field: "lastName", headerName: "Last Name", flex: 1 },
    { field: "email", headerName: "Email", flex: 2 },
    { field: "mobile", headerName: "Phone No", flex: 1 },
    { field: "role", headerName: "Role", flex: 1 },
  ];

  const handleAction = (type, row) => {
    switch (type) {
      case "DELETE":
        handleDelete(row.userId);
        break;
      case "EDIT":
        setSelectedSupervisor(row);
        setIsEditMode(true);
        setModalMode("EDIT");
        break;
      case "VIEW":
        handleView(row);
        break;
      default:
        break;
    }
  };

  return (
    <>
      <div className="p-4">
        {loading ? (
          <div className="flex justify-center items-center space-x-2">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-fuchsia-950"></div>
            <span className="text-fuchsia-950 font-medium">
              Loading bus supervisors...
            </span>
          </div>
        ) : error ? (
          <div className="text-red-500 font-medium">
            <p>Error fetching supervisors: {error}</p>
          </div>
        ) : (
          <GridTable
            rowData={modifiedSupervisors}
            columnData={columns}
            actions={["DELETE", "EDIT", "VIEW"]}
            onClickAdd={() => {
              resetForm();
              setModalMode("ADD");
            }}
            onClickAction={handleAction}
            hideAddButton={false}
            toolTipName={"Add Bus Supervisor"}
            topActionButtonTitle="Add Bus Supervisor"
            getRowId={(row) => row.userId}
          />
        )}
      </div>

      {(modalMode === "ADD" || modalMode === "EDIT") && (
        <div className="fixed inset-0 bg-gray-500/75 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg w-1/3">
            <h2 className="text-2xl font-semibold mb-4">
              {modalMode === "EDIT"
                ? "Edit Bus Supervisor"
                : "Add New Bus Supervisor"}
            </h2>
            <form onSubmit={modalMode === "EDIT" ? handleUpdate : handleSubmit}>
              {["firstName", "lastName", "email", "mobile"].map(
                (field, index) => (
                  <div className="mb-4" key={index}>
                    <label
                      htmlFor={field}
                      className="block text-sm text-gray-700 capitalize"
                    >
                      {field === "mobile"
                        ? "Mobile"
                        : field.replace(/([A-Z])/g, " $1").trim()}
                    </label>
                    <input
                      id={field}
                      type="text"
                      value={
                        modalMode === "EDIT"
                          ? selectedSupervisor[field]
                          : newUser[field]
                      }
                      onChange={(e) => {
                        modalMode === "EDIT"
                          ? setSelectedSupervisor({
                              ...selectedSupervisor,
                              [field]: e.target.value,
                            })
                          : setNewUser({ ...newUser, [field]: e.target.value });
                      }}
                      className="w-full p-2 border border-gray-300 rounded-md"
                      required
                    />
                  </div>
                )
              )}

              {modalMode === "ADD" && (
                <div className="mb-4">
                  <label
                    htmlFor="password"
                    className="block text-sm text-gray-700"
                  >
                    Password
                  </label>
                  <input
                    id="password"
                    type="password"
                    value={newUser.password}
                    onChange={(e) =>
                      setNewUser({ ...newUser, password: e.target.value })
                    }
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
              )}

              <div className="mb-4">
                <label htmlFor="orgId" className="block text-sm text-gray-700">
                  Organization ID
                </label>
                <input
                  id="orgId"
                  type="text"
                  value={user?.orgId || ""}
                  readOnly
                  className="w-full p-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600 cursor-not-allowed"
                />
              </div>

              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setModalMode(null);
                    resetForm();
                  }}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  {modalMode === "EDIT" ? "Update" : "Add"} Bus Supervisor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {modalMode === "VIEW" && selectedSupervisor && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl overflow-hidden border border-gray-100 animate-scaleIn">
            {/* Header */}
            <div className="bg-gradient-to-r from-fuchsia-700 to-fuchsia-950 px-6 py-5">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Bus Supervisor Profile
                  </h2>
                  <p className="text-blue-100 text-sm mt-1">
                    View detailed information
                  </p>
                </div>
                <button
                  onClick={() => {
                    setModalMode(null);
                    setSelectedSupervisor(null);
                  }}
                  className="text-white/80 hover:text-white transition-colors p-1 rounded-full hover:bg-white/10"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-5">
              {/* Avatar */}
              <div className="flex justify-center -mt-16 mb-6">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 border-4 border-white shadow-md flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-10 w-10 text-indigo-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                    />
                  </svg>
                </div>
              </div>

              {/* Details Grid in Horizontal Layout */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Personal Info */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">
                    Personal Information
                  </h3>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <div>
                      <p className="text-xs font-medium text-gray-400">
                        Full Name
                      </p>
                      <p className="text-base font-semibold text-gray-800 mt-0.5">
                        {selectedSupervisor.firstName}{" "}
                        {selectedSupervisor.lastName}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-400">Role</p>
                      <p className="text-base font-semibold text-indigo-600 mt-0.5">
                        {selectedSupervisor.role?.roleName || "Bus Supervisor"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">
                    Contact Details
                  </h3>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <div>
                      <p className="text-xs font-medium text-gray-400">Email</p>
                      <p className="text-base font-medium text-gray-800 mt-0.5 break-all">
                        {selectedSupervisor.email}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-400">Phone</p>
                      <p className="text-base font-medium text-gray-800 mt-0.5">
                        {selectedSupervisor.mobile || "Not provided"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Organization Info */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">
                    Organization
                  </h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-xs font-medium text-gray-400">
                      Organization ID
                    </p>
                    <p className="text-base font-medium text-gray-800 mt-0.5 font-mono">
                      {user?.orgId || "N/A"}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer with Close Button */}
            <div className="px-6 py-4 border-t border-gray-100 flex justify-end">
              <button
                onClick={() => {
                  setModalMode(null);
                  setSelectedSupervisor(null);
                }}
                className="px-5 py-2.5 text-sm font-medium rounded-lg bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 shadow-sm transition-colors hover:shadow-md flex items-center space-x-2"
              >
                <span>Close</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BusSupervisorList;
