import { Box, Typography, Card, CardContent } from "@mui/material";
import SeatRow from "./SeatRow";

const SeatLayoutPreview = ({ layout, onSeatClick }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Layout Preview
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography color="success.main" fontWeight="medium">
            Available Seats: {
              layout.flat().filter(seat => seat && typeof seat === "object" && seat.available).length
            }
          </Typography>
          <Typography color="error.main" fontWeight="medium">
            Unavailable Seats: {
              layout.flat().filter(seat => seat && typeof seat === "object" && !seat.available).length
            }
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, mb: 4 }}>
          {layout.map((row, rowIndex) => (
            <SeatRow 
              key={rowIndex} 
              row={row} 
              onSeatClick={onSeatClick}
            />
          ))}
        </Box>
      </CardContent>
    </Card>
  );
};

export default SeatLayoutPreview;