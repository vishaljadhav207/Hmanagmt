import { Box } from "@mui/material";
import SeatTooltip from "./SeatTooltip";

const SeatRow = ({ row, onSeatClick }) => {
  return (
    <Box sx={{ display: 'flex', gap: 1 }}>
      {row.map((seat, seatIndex) => (
        <SeatTooltip 
          key={seatIndex} 
          seat={seat} 
          onClick={onSeatClick}
        />
      ))}
    </Box>
  );
};

export default SeatRow;