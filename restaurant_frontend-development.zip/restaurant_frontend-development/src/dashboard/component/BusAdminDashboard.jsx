import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getBusByOrgId } from "../../app/busApi";
import { selectAllBuses, selectBusStatus } from "../../redux/busSlice";
import {
  Box,
  Typography,
  Grid,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  CircularProgress,
  Card,
  CardContent,
  Divider,
  Stack,
  Chip,
  LinearProgress,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import {
  DirectionsBus,
  TrendingUp,
  WarningAmber,
  Engineering,
  ArrowForward,
} from "@mui/icons-material";

const PRIMARY_COLOR = "#5A2360";
const PRIMARY_LIGHT = "#8B5F8F";
const PRIMARY_DARK = "#3D1642";
const SECONDARY_COLOR = "#FFA000";
const BACKGROUND_LIGHT = "#F9F5FA";
const BACKGROUND_DARK = "#EDE5EF";
const TEXT_PRIMARY = "#2E2E2E";
const TEXT_SECONDARY = "#5D5D5D";

const BusAdminDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { userInfo: user } = useSelector((state) => state.user);

  const buses = useSelector(selectAllBuses) || [];
  const status = useSelector(selectBusStatus);

  const activeBuses = buses.filter(
    (bus) => (bus.status || "ACTIVE") === "ACTIVE"
  ).length;
  const totalOperators = new Set(
    buses
      .map((bus) => bus.operatorName)
      .filter((name) => !!name && name.trim() !== "")
  ).size;
  const activePercentage = Math.round(
    (activeBuses / Math.max(buses.length, 1)) * 100
  );

  useEffect(() => {
    if (user?.orgId) {
      dispatch(
        getBusByOrgId({ orgId: user.orgId, pageNumber: 0, pageSize: 5 })
      );
    }
  }, [dispatch, user?.orgId]);

  if (status === "loading") {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: BACKGROUND_LIGHT,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: 4,
        backgroundColor: BACKGROUND_LIGHT,
        minHeight: "100",
      }}
    >
      <Box sx={{ mb: 4 }}></Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={4}>
          <SummaryCard
            icon={<DirectionsBus fontSize="large" />}
            label="Total Buses"
            value={buses.length}
            color={PRIMARY_COLOR}
            onClick={() => navigate("/manage-bus")}
            actionText="Manage Buses"
            actionIcon={<ArrowForward />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SummaryCard
            icon={<DirectionsBus fontSize="large" />}
            label="Active Buses"
            value={activeBuses}
            percentage={activePercentage}
            color="#388e3c"
            chipColor="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <SummaryCard
            icon={<Engineering fontSize="large" />}
            label="Operators"
            value={totalOperators}
            color={SECONDARY_COLOR}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Card
            sx={{
              boxShadow: 4,
              transition: "all 0.3s ease",
              "&:hover": {
                boxShadow: 6,
              },
            }}
          >
            <CardContent>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mb: 3,
                }}
              >
                <Typography
                  variant="h5"
                  fontWeight="bold"
                  sx={{ color: PRIMARY_COLOR }}
                >
                  Recent Buses
                </Typography>
                <Button
                  variant="outlined"
                  sx={{
                    color: PRIMARY_COLOR,
                    borderColor: PRIMARY_COLOR,
                    textTransform: "none",
                    fontWeight: "bold",
                    "&:hover": {
                      borderColor: PRIMARY_DARK,
                      color: PRIMARY_DARK,
                    },
                  }}
                  onClick={() => navigate("manage-bus")}
                  endIcon={<ArrowForward />}
                >
                  View All Buses
                </Button>
              </Box>

              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow
                      sx={{
                        backgroundColor: BACKGROUND_DARK,
                        "& th": {
                          fontWeight: "bold",
                          color: TEXT_SECONDARY,
                        },
                      }}
                    >
                      <TableCell>Bus No</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Operator</TableCell>
                      <TableCell>Destination</TableCell>
                      <TableCell align="center">Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {buses.slice(0, 5).map((bus, idx) => (
                      <TableRow
                        key={bus.busNo || idx}
                        sx={{
                          transition: "background-color 0.2s",
                          "&:hover": {
                            backgroundColor: BACKGROUND_DARK,
                          },
                        }}
                      >
                        <TableCell>
                          <Typography
                            fontWeight="medium"
                            sx={{ color: TEXT_PRIMARY }}
                          >
                            {bus.busNo}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={bus.busType}
                            size="small"
                            variant="outlined"
                            sx={{
                              color: PRIMARY_COLOR,
                              borderColor: PRIMARY_COLOR,
                              fontWeight: "bold",
                            }}
                          />
                        </TableCell>
                        <TableCell sx={{ color: TEXT_SECONDARY }}>
                          {bus.operatorName}
                        </TableCell>
                        <TableCell sx={{ color: TEXT_SECONDARY }}>
                          {bus.destination}
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={bus.status || "ACTIVE"}
                            color={
                              bus.status === "ACTIVE"
                                ? "success"
                                : bus.status === "MAINTENANCE"
                                ? "warning"
                                : "error"
                            }
                            size="small"
                            sx={{
                              fontWeight: "bold",
                              minWidth: 80,
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

const SummaryCard = ({
  icon,
  label,
  value,
  percentage,
  chipColor = "default",
  color,
  onClick,
  actionText,
  actionIcon,
}) => {
  return (
    <Card
      sx={{
        height: "100%",
        backgroundColor: `${color}08`,
        borderLeft: `4px solid ${color}`,
        boxShadow: 3,
        transition: "all 0.3s ease",
        "&:hover": {
          transform: onClick ? "translateY(-5px)" : "none",
          boxShadow: 6,
          cursor: onClick ? "pointer" : "default",
        },
      }}
      onClick={onClick}
    >
      <CardContent>
        <Stack direction="row" alignItems="center" spacing={2}>
          <Avatar
            sx={{
              bgcolor: `${color}20`,
              color: color,
              width: 56,
              height: 56,
            }}
          >
            {icon}
          </Avatar>
          <Box sx={{ flex: 1 }}>
            <Typography variant="subtitle1" sx={{ color: TEXT_SECONDARY }}>
              {label}
            </Typography>
            <Typography
              variant="h3"
              fontWeight="bold"
              sx={{ color: TEXT_PRIMARY }}
            >
              {value}
            </Typography>
          </Box>
        </Stack>

        {percentage && (
          <Box sx={{ mt: 2 }}>
            <LinearProgress
              variant="determinate"
              value={percentage}
              sx={{
                height: 8,
                borderRadius: 4,
                mb: 1,
                backgroundColor: BACKGROUND_DARK,
                "& .MuiLinearProgress-bar": {
                  backgroundColor: color,
                },
              }}
            />
            <Typography variant="caption" sx={{ color: TEXT_SECONDARY }}>
              {percentage}% of total
            </Typography>
          </Box>
        )}

        {actionText && (
          <Button
            fullWidth
            variant="text"
            endIcon={actionIcon}
            sx={{
              mt: 2,
              color: color,
              fontWeight: "bold",
              justifyContent: "flex-end",
              "&:hover": {
                backgroundColor: `${color}10`,
              },
            }}
          >
            {actionText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default BusAdminDashboard;
