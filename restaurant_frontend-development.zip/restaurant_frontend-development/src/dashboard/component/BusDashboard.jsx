import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getBusTripsByUserId } from "../../app/busApi";
import { selectBusTrips } from "../../redux/busSlice";
import {
  Card,
  CardContent,
  Typography,
  Grid,
  Box,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Button,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { Pie } from "react-chartjs-2";
import DateRangeIcon from "@mui/icons-material/DateRange";
import DirectionsBusIcon from "@mui/icons-material/DirectionsBus";
import UpcomingIcon from "@mui/icons-material/Upcoming";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import VisibilityIcon from "@mui/icons-material/Visibility";
import ConfirmationNumberIcon from "@mui/icons-material/ConfirmationNumber";
import BusinessIcon from "@mui/icons-material/Business";
import ClassIcon from "@mui/icons-material/Class";
import RouteIcon from "@mui/icons-material/AltRoute";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import DepartureBoardIcon from "@mui/icons-material/DepartureBoard";
import ArrivalBoardIcon from "@mui/icons-material/EmojiFlags";
import TimelineIcon from "@mui/icons-material/Timeline";
import PlaceIcon from "@mui/icons-material/Place";
import CloseIcon from "@mui/icons-material/Close";

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend);

// Color theme constants
const PRIMARY_COLOR = "#5A2360";
const PRIMARY_LIGHT = "#8B5F8F";
const PRIMARY_DARK = "#3D1642";
const SECONDARY_COLOR = "#FFA000";
const BACKGROUND_LIGHT = "#F9F5FA";
const BACKGROUND_DARK = "#EDE5EF";
const TEXT_PRIMARY = "#2E2E2E";
const TEXT_SECONDARY = "#5D5D5D";

const BusDashboard = () => {
  const dispatch = useDispatch();
  const userDetails = JSON.parse(localStorage.getItem("USER_INFO"));
  const userId = userDetails?.id;
  const busTrips = useSelector(selectBusTrips) || [];
  const [openModal, setOpenModal] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState(null);

  useEffect(() => {
    if (userId) {
      dispatch(getBusTripsByUserId(userId));
    }
  }, [dispatch, userId]);

  const handleView = (trip) => {
    setSelectedTrip(trip);
    setOpenModal(true);
  };
  const handleClose = () => {
    setOpenModal(false);
    setSelectedTrip(null);
  };

  // Summary stats
  const totalTrips = busTrips.length;

  const isUpcoming = (dateStr) => {
    if (!dateStr) return false;
    const todayStr = new Date().toISOString().slice(0, 10);
    return dateStr >= todayStr;
  };

  const upcomingTrips = busTrips.filter((trip) =>
    isUpcoming(trip.departureDate)
  );
  const pastTrips = busTrips.filter((trip) => !isUpcoming(trip.departureDate));


  const totalBuses = new Set(busTrips.map((trip) => trip.bus?.busId)).size;

 
  const tripStatusData = {
    labels: ["Upcoming", "Completed"],
    datasets: [
      {
        label: "Number of Trips",
        data: [upcomingTrips.length, pastTrips.length],
        backgroundColor: [PRIMARY_LIGHT, BACKGROUND_DARK],
        borderColor: [PRIMARY_COLOR, PRIMARY_DARK],
        borderWidth: 1,
      },
    ],
  };

  
  const destinationCounts = busTrips.reduce((acc, trip) => {
    acc[trip.destination] = (acc[trip.destination] || 0) + 1;
    return acc;
  }, {});

  const topDestinations = Object.entries(destinationCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const destinationsData = {
    labels: topDestinations.map(([name]) => name),
    datasets: [
      {
        label: "Number of Trips",
        data: topDestinations.map(([_, value]) => value),
        backgroundColor: [
          PRIMARY_COLOR,
          PRIMARY_LIGHT,
          "#B388B3",
          "#D9C2D9",
          BACKGROUND_DARK,
        ],
        borderColor: [
          PRIMARY_DARK,
          PRIMARY_COLOR,
          PRIMARY_LIGHT,
          "#B388B3",
          "#D9C2D9",
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <Box sx={{ p: 4, backgroundColor: BACKGROUND_LIGHT }}>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Card
            sx={{
              background: `linear-gradient(135deg, ${BACKGROUND_LIGHT} 0%, ${BACKGROUND_DARK} 100%)`,
              boxShadow: 3,
              borderRadius: 2,
              height: "100%",
              borderLeft: `4px solid ${PRIMARY_COLOR}`,
            }}
          >
            <CardContent sx={{ display: "flex", alignItems: "center" }}>
              <DirectionsBusIcon
                sx={{ fontSize: 40, color: PRIMARY_COLOR, mr: 2 }}
              />
              <Box>
                <Typography variant="h6" color={TEXT_SECONDARY}>
                  Total Buses
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
                  {totalBuses}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card
            sx={{
              background: `linear-gradient(135deg, ${BACKGROUND_LIGHT} 0%, ${BACKGROUND_DARK} 100%)`,
              boxShadow: 3,
              borderRadius: 2,
              height: "100%",
              borderLeft: `4px solid ${PRIMARY_COLOR}`,
            }}
          >
            <CardContent sx={{ display: "flex", alignItems: "center" }}>
              <DateRangeIcon sx={{ fontSize: 40, color: PRIMARY_COLOR, mr: 2 }} />
              <Box>
                <Typography variant="h6" color={TEXT_SECONDARY}>
                  Total Trips
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
                  {totalTrips}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card
            sx={{
              background: `linear-gradient(135deg, ${BACKGROUND_LIGHT} 0%, ${BACKGROUND_DARK} 100%)`,
              boxShadow: 3,
              borderRadius: 2,
              height: "100%",
              borderLeft: `4px solid ${PRIMARY_COLOR}`,
            }}
          >
            <CardContent sx={{ display: "flex", alignItems: "center" }}>
              <UpcomingIcon sx={{ fontSize: 40, color: PRIMARY_COLOR, mr: 2 }} />
              <Box>
                <Typography variant="h6" color={TEXT_SECONDARY}>
                  Upcoming Trips
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
                  {upcomingTrips.length}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ 
            p: 2, 
            borderRadius: 2, 
            height: "100%",
            backgroundColor: "white",
            border: `1px solid ${BACKGROUND_DARK}`
          }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
              Trip Status Distribution
            </Typography>
            <Box sx={{ height: "300px", position: "relative" }}>
              <Pie
                data={tripStatusData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: "bottom",
                      labels: {
                        color: TEXT_PRIMARY,
                        font: {
                          weight: "bold"
                        }
                      }
                    },
                    tooltip: {
                      callbacks: {
                        label: function (context) {
                          const label = context.label || "";
                          const value = context.raw || 0;
                          const total = context.dataset.data.reduce(
                            (a, b) => a + b,
                            0
                          );
                          const percentage = Math.round((value / total) * 100);
                          return `${label}: ${value} (${percentage}%)`;
                        },
                      },
                      backgroundColor: PRIMARY_COLOR,
                      titleColor: "white",
                      bodyColor: "white"
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} sx={{ 
            p: 2, 
            borderRadius: 2, 
            height: "100%",
            backgroundColor: "white",
            border: `1px solid ${BACKGROUND_DARK}`
          }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
              Top Destinations
            </Typography>
            <Box sx={{ height: "300px", position: "relative" }}>
              <Pie
                data={destinationsData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: "bottom",
                      labels: {
                        color: TEXT_PRIMARY,
                        font: {
                          weight: "bold"
                        }
                      }
                    },
                    tooltip: {
                      callbacks: {
                        label: function (context) {
                          const label = context.label || "";
                          const value = context.raw || 0;
                          const total = context.dataset.data.reduce(
                            (a, b) => a + b,
                            0
                          );
                          const percentage = Math.round((value / total) * 100);
                          return `${label}: ${value} (${percentage}%)`;
                        },
                      },
                      backgroundColor: PRIMARY_COLOR,
                      titleColor: "white",
                      bodyColor: "white"
                    },
                  },
                }}
              />
            </Box>
          </Paper>
        </Grid>
      </Grid>

      
      <Paper elevation={3} sx={{ 
        p: 3, 
        borderRadius: 2, 
        mb: 4,
        backgroundColor: "white",
        border: `1px solid ${BACKGROUND_DARK}`
      }}>
        <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
          <AccessTimeIcon sx={{ color: PRIMARY_COLOR, mr: 1 }} />
          <Typography variant="h6" sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>
            Upcoming Trips
          </Typography>
        </Box>
        <Table sx={{ minWidth: 650 }}>
          <TableHead>
            <TableRow sx={{ backgroundColor: BACKGROUND_DARK }}>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Bus No</TableCell>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Origin</TableCell>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Destination</TableCell>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Departure</TableCell>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Arrival</TableCell>
              <TableCell sx={{ fontWeight: "bold", color: PRIMARY_DARK }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {upcomingTrips.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center">
                  No upcoming trips
                </TableCell>
              </TableRow>
            ) : (
              upcomingTrips.map((trip) => (
                <TableRow
                  key={trip.busTripId}
                  hover
                  sx={{ 
                    "&:last-child td, &:last-child th": { border: 0 },
                    "&:nth-of-type(odd)": { backgroundColor: BACKGROUND_LIGHT }
                  }}
                >
                  <TableCell>{trip.bus?.busNo || "N/A"}</TableCell>
                  <TableCell>{trip.origin}</TableCell>
                  <TableCell>{trip.destination}</TableCell>
                  <TableCell>
                    {new Date(trip.departureDate).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    {new Date(trip.arrivalDate).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() => handleView(trip)}
                      sx={{
                        backgroundColor: PRIMARY_COLOR,
                        "&:hover": {
                          backgroundColor: PRIMARY_DARK,
                          transform: "scale(1.05)",
                          boxShadow: `0 4px 8px ${PRIMARY_LIGHT}`,
                        },
                        transition: "all 0.3s ease",
                        boxShadow: `0 2px 4px ${PRIMARY_LIGHT}`,
                        textTransform: "none",
                        borderRadius: "8px",
                        padding: "6px 16px",
                        fontSize: "0.875rem",
                        fontWeight: "500",
                        minWidth: "80px",
                        color: "white",
                      }}
                      startIcon={<VisibilityIcon fontSize="small" sx={{ color: "white" }} />}
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Paper>

      
      <Dialog 
        open={openModal} 
        onClose={handleClose} 
        maxWidth="md" 
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: "12px",
            overflow: "hidden",
            boxShadow: `0 10px 30px ${PRIMARY_LIGHT}`,
            border: `1px solid ${PRIMARY_COLOR}`
          }
        }}
      >
        <DialogTitle
          sx={{
            background: `linear-gradient(135deg, ${PRIMARY_COLOR} 0%, ${PRIMARY_DARK} 100%)`,
            color: "white",
            fontWeight: "bold",
            padding: "16px 24px",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
        >
          <DirectionsBusIcon sx={{ fontSize: "1.5rem", color: "white" }} />
          <span>Trip Details</span>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 0, backgroundColor: BACKGROUND_LIGHT }}>
          {selectedTrip && (
            <Box>
             
              <Box sx={{ 
                p: 3,
                background: `linear-gradient(135deg, ${BACKGROUND_LIGHT} 0%, ${BACKGROUND_DARK} 100%)`,
                borderBottom: `1px solid ${PRIMARY_LIGHT}`
              }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6} md={4}>
                    <InfoItem 
                      label="Bus No" 
                      value={selectedTrip.bus?.busNo || "N/A"}
                      icon={<ConfirmationNumberIcon sx={{ color: PRIMARY_COLOR }} />}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <InfoItem 
                      label="Operator" 
                      value={selectedTrip.bus?.operatorName || "N/A"}
                      icon={<BusinessIcon sx={{ color: PRIMARY_COLOR }} />}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <InfoItem 
                      label="Class Types" 
                      value={selectedTrip.classTypes?.map((c) => c.className).join(", ")}
                      icon={<ClassIcon sx={{ color: PRIMARY_COLOR }} />}
                    />
                  </Grid>
                </Grid>
              </Box>

              
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ 
                  mb: 2, 
                  fontWeight: "bold",
                  color: PRIMARY_DARK,
                  display: "flex",
                  alignItems: "center",
                  gap: "8px"
                }}>
                  <RouteIcon sx={{ color: PRIMARY_COLOR }} />
                  Route Information
                </Typography>
                
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <InfoCard 
                      title="Origin"
                      value={selectedTrip.origin}
                      icon={<LocationOnIcon sx={{ color: PRIMARY_COLOR }} />}
                      color={PRIMARY_COLOR}
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <InfoCard 
                      title="Destination"
                      value={selectedTrip.destination}
                      icon={<LocationOnIcon sx={{ color: PRIMARY_COLOR }} />}
                      color={PRIMARY_LIGHT}
                    />
                  </Grid>
                </Grid>
                
                <Grid container spacing={2} sx={{ mt: 1 }}>
                  <Grid item xs={12} md={6}>
                    <InfoCard 
                      title="Departure"
                      value={new Date(selectedTrip.departureDate).toLocaleString()}
                      icon={<DepartureBoardIcon sx={{ color: PRIMARY_COLOR }} />}
                      color={PRIMARY_DARK}
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <InfoCard 
                      title="Arrival"
                      value={new Date(selectedTrip.arrivalDate).toLocaleString()}
                      icon={<ArrivalBoardIcon sx={{ color: PRIMARY_COLOR }} />}
                      color="#8B5F8F"
                    />
                  </Grid>
                </Grid>
              </Box>

              
              {selectedTrip.intermediateStops?.length > 0 && (
                <Box sx={{ p: 3, borderTop: `1px solid ${PRIMARY_LIGHT}` }}>
                  <Typography variant="h6" sx={{ 
                    mb: 2, 
                    fontWeight: "bold",
                    color: PRIMARY_DARK,
                    display: "flex",
                    alignItems: "center",
                    gap: "8px"
                  }}>
                    <TimelineIcon sx={{ color: PRIMARY_COLOR }} />
                    Intermediate Stops
                  </Typography>
                  
                  <Paper elevation={0} sx={{ 
                    border: `1px solid ${PRIMARY_LIGHT}`,
                    borderRadius: "8px",
                    overflow: "hidden"
                  }}>
                    <Table size="small">
                      <TableHead sx={{ backgroundColor: BACKGROUND_DARK }}>
                        <TableRow>
                          <TableCell sx={{ fontWeight: "bold", width: "40%", color: PRIMARY_DARK }}>Stop Name</TableCell>
                          <TableCell sx={{ fontWeight: "bold", width: "30%", color: PRIMARY_DARK }}>Arrival Time</TableCell>
                          <TableCell sx={{ fontWeight: "bold", width: "30%", color: PRIMARY_DARK }}>Departure Time</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {selectedTrip.intermediateStops.map((stop, idx) => (
                          <TableRow 
                            key={idx} 
                            hover
                            sx={{ 
                              '&:nth-of-type(even)': { backgroundColor: BACKGROUND_LIGHT },
                              '&:last-child td': { borderBottom: 0 }
                            }}
                          >
                            <TableCell>
                              <Box sx={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                <PlaceIcon fontSize="small" sx={{ color: PRIMARY_COLOR }} />
                                {stop.stopName}
                              </Box>
                            </TableCell>
                            <TableCell>
                              {stop.arrivalTime ? (
                                <Box sx={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                  <AccessTimeIcon fontSize="small" sx={{ color: PRIMARY_COLOR }} />
                                  {stop.arrivalTime.split("T")[1]?.slice(0, 5) || 
                                   stop.arrivalTime.split(" ")[1]?.slice(0, 5)}
                                </Box>
                              ) : "-"}
                            </TableCell>
                            <TableCell>
                              {stop.departureTime ? (
                                <Box sx={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                  <AccessTimeIcon fontSize="small" sx={{ color: PRIMARY_COLOR }} />
                                  {stop.departureTime.split("T")[1]?.slice(0, 5) || 
                                   stop.departureTime.split(" ")[1]?.slice(0, 5)}
                                </Box>
                              ) : "-"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Paper>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ 
          p: 2, 
          borderTop: `1px solid ${PRIMARY_LIGHT}`,
          backgroundColor: BACKGROUND_DARK
        }}>
          <Button
            onClick={handleClose}
            variant="contained"
            sx={{
              background: `linear-gradient(135deg, ${PRIMARY_COLOR} 0%, ${PRIMARY_DARK} 100%)`,
              "&:hover": { 
                background: PRIMARY_DARK,
                transform: "scale(1.02)"
              },
              transition: "all 0.2s ease",
              borderRadius: "8px",
              padding: "8px 20px",
              textTransform: "none",
              fontWeight: "500",
              boxShadow: "none",
              color: "white"
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};


const InfoItem = ({ label, value, icon }) => (
  <Box sx={{ display: "flex", alignItems: "center", gap: "8px" }}>
    <Box>{icon}</Box>
    <Box>
      <Typography variant="subtitle2" color="textSecondary">{label}</Typography>
      <Typography variant="body1" sx={{ fontWeight: 500 }}>{value || "-"}</Typography>
    </Box>
  </Box>
);

const InfoCard = ({ title, value, icon, color }) => (
  <Paper elevation={0} sx={{ 
    p: 2, 
    borderLeft: `4px solid ${color}`,
    borderRadius: "4px",
    backgroundColor: "#f9f9f9"
  }}>
    <Typography variant="subtitle2" color="textSecondary" sx={{ mb: 1 }}>
      {icon && <Box component="span" sx={{ mr: 1 }}>{icon}</Box>}
      {title}
    </Typography>
    <Typography variant="body1" sx={{ fontWeight: 500 }}>{value}</Typography>
  </Paper>
);

export default BusDashboard;