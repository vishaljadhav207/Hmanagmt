import { Button, CircularProgress } from "@mui/material";

const CustomButton = ({
  variant = "contained",
  color = "primary",
  fullWidth = false,
  onClick,
  disabled = false,
  loading = false,
  children,
  sx = {},
}) => {
  return (
    <Button
      variant={variant}
      color={color}
      fullWidth={fullWidth}
      onClick={onClick}
      disabled={disabled || loading}
      sx={sx}
    >
      {loading ? <CircularProgress size={24} /> : children}
    </Button>
  );
};

export default CustomButton;