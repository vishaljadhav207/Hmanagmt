import { FormControl, InputLabel, Select, MenuItem } from '@mui/material';

const CustomSelect = ({
  label,
  value,
  onChange,
  options,
  fullWidth = true,
  disabled = false,
}) => {
  return (
    <FormControl fullWidth={fullWidth}>
      <InputLabel>{label}</InputLabel>
      <Select
        value={value}
        onChange={onChange}
        label={label}
        disabled={disabled}
      >
        {options.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default CustomSelect;