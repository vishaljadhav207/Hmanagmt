import { Tooltip, Paper, Box } from "@mui/material";

const SeatTooltip = ({ seat, onClick }) => {
  if (seat === "aisle") {
    return (
      <Box
        sx={{
          width: 48,
          bgcolor: "grey.50",
          borderRadius: "4px",
          position: "relative",
        }}
      >
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            borderLeft: "2px dashed",
            borderRight: "2px dashed",
            borderColor: "grey.300",
          }}
        />
      </Box>
    );
  }

  if (!seat) {
    return <Box sx={{ width: 32, height: 32, opacity: 0 }} />;
  }

  console.log(seat, "seat");
  const isSleeper = seat.layout === "Sleeper";

  return (
    <Tooltip
      title={`Seat: ${seat.seatNumber} | Type: ${seat.type} | ${
        seat.available ? "Available" : "Unavailable"
      }`}
    >
      <Paper
        elevation={2}
        sx={{
          width: isSleeper ? 64 : 32,
          height: 32,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "0.75rem",
          fontWeight: "medium",
          borderRadius: "4px",
          cursor: ["driver", "conductor"].includes(seat.type)
            ? "default"
            : "pointer",
          transition: "all 0.2s",
          "&:hover": {
            opacity: ["driver", "conductor"].includes(seat.type) ? 1 : 0.8,
          },
          ...(seat.type === "driver" && {
            bgcolor: "grey.800",
            color: "white",
          }),
          ...(seat.type === "conductor" && {
            bgcolor: "warning.main",
            color: "grey.900",
          }),
          ...(!seat.available && {
            bgcolor: "grey.400",
            color: "white",
            cursor: "not-allowed",
          }),
          ...(seat.available &&
            !["driver", "conductor"].includes(seat.type) && {
              bgcolor: isSleeper ? "primary.light" : "grey.200",
              color: isSleeper ? "white" : "grey.800",
            }),
        }}
        onClick={() => {
          if (seat.type === "driver" || seat.type === "conductor") return;
          onClick(seat.seatNumber);
        }}
      >
        {seat?.type === "toilet"
          ? "Toilet"
          : seat?.type === "entry"
          ? "Entry"
          : seat.seatNumber}
      </Paper>
    </Tooltip>
  );
};

export default SeatTooltip;
