import { TextField } from '@mui/material';

const CustomTextField = ({
  label,
  value,
  onChange,
  type = 'text',
  fullWidth = true,
  disabled = false,
  min,
  max,
  sx = {},
}) => {
  return (
    <TextField
      label={label}
      value={value}
      onChange={onChange}
      type={type}
      fullWidth={fullWidth}
      disabled={disabled}
      inputProps={{ min, max }}
      sx={sx}
    />
  );
};

export default CustomTextField;