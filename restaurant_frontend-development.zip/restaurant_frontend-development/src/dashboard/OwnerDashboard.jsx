import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Avatar,
  CircularProgress,
  Divider,
  Button,
  Stack,
  LinearProgress,
  Chip,
} from "@mui/material";
import {
  Hotel,
  Image,
  Star,
  RoomService,
  ArrowForwardIos,
  LocationOn,
} from "@mui/icons-material";
import { BarChart } from "@mui/x-charts";
import { fetchHotelById, fetchHotelImages } from "../app/hotelApi";
import { getRoomsByHotelId } from "../redux/roomSlice";
import { useNavigate } from "react-router-dom";

const PRIMARY_COLOR = "#5A2360";
const PRIMARY_LIGHT = "#8B5F8F";
const PRIMARY_DARK = "#3D1642";
const SECONDARY_COLOR = "#D6BAA0";
const BACKGROUND_LIGHT = "#F9F5FA";
const BACKGROUND_DARK = "#EDE5EF";
const TEXT_PRIMARY = "#2E2E2E";
const TEXT_SECONDARY = "#5D5D5D";

const OwnerDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { selectedHotel, status, hotelImages } = useSelector(
    (state) => state.hotels
  );
  console.log("Selected Hotel:", selectedHotel);
  console.log("Hotel Images:", hotelImages);
  const { rooms } = useSelector((state) => state.rooms);
  const user = useSelector((state) => state.user.userInfo);

  const hotelId = selectedHotel?.data?.[0]?.hotelId;
  const amenities = selectedHotel?.data?.[0]?.amenities || [];
  const hotelName = selectedHotel?.data?.[0]?.hotelName || "Your Hotel";
  const hotelLocation = selectedHotel?.data?.[0]?.city || "Location not set";
  const hotelRating = selectedHotel?.data?.[0]?.rating || "4.5";

  const roomsArray = Array.isArray(rooms) ? rooms : [];

  const roomTypesCount = new Set(roomsArray.map((room) => room.roomType)).size;
  const totalAmenities = amenities.length;

  const getImageUrl = (img) =>
    img?.imageName && hotelId
      ? `http://localhost:8080/api/images/getImages?hotel_id=${hotelId}&imageName=${img.imageName}`
      : "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80";

  const mainImage =
    hotelImages && hotelImages?.length > 0 && getImageUrl(hotelImages[0])
      ? getImageUrl(hotelImages[0])
      : "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80";

  useEffect(() => {
    if (user?.id) {
      dispatch(fetchHotelById(user.id));
    }
  }, [dispatch, user?.id]);

  useEffect(() => {
    if (hotelId) {
      dispatch(getRoomsByHotelId(hotelId));
      dispatch(fetchHotelImages(hotelId));
    }
  }, [dispatch, hotelId]);

  if (status === "loading") {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          backgroundColor: BACKGROUND_LIGHT,
        }}
      >
        <CircularProgress size={60} />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        p: { xs: 2, md: 4 },
        background: `linear-gradient(135deg, #f9f5fa 60%, #e9d6f5 100%)`,
        minHeight: "100vh",
      }}
    >
      <Card
        sx={{
          mb: 4,
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          boxShadow: 6,
          borderRadius: 4,
          p: 2,
          background: "#fff",
        }}
      >
        <Box
          sx={{
            width: 120,
            height: 120,
            mr: { md: 4 },
            mb: { xs: 2, md: 0 },
            borderRadius: 3,
            overflow: "hidden",
            boxShadow: 3,
            border: `4px solid ${PRIMARY_COLOR}22`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "#f3e6f7",
          }}
        >
          <img
            src={mainImage}
            alt={hotelName}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              borderRadius: "12px",
            }}
            onError={(e) => {
              e.target.src =
                "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80";
            }}
          />
        </Box>
        <Box sx={{ flex: 1 }}>
          <Typography
            variant="h5"
            fontWeight="bold"
            sx={{ color: PRIMARY_COLOR }}
          >
            {hotelName}
          </Typography>
          <Stack
            direction="row"
            spacing={1}
            alignItems="center"
            sx={{ mb: 1, mt: 0.5 }}
          >
            <LocationOn sx={{ color: PRIMARY_LIGHT, fontSize: 20 }} />
            <Typography variant="body2" sx={{ color: TEXT_SECONDARY }}>
              {hotelLocation}
            </Typography>
            <Star sx={{ color: "#FFD700", fontSize: 20, ml: 2 }} />
            <Typography variant="body2" sx={{ color: TEXT_PRIMARY }}>
              {hotelRating}
            </Typography>
          </Stack>
          <Stack direction="row" spacing={1}>
            {amenities.slice(0, 4).map((a) => (
              <Chip
                key={a.amenityId}
                label={a.amenityName}
                size="small"
                sx={{
                  bgcolor: SECONDARY_COLOR,
                  color: PRIMARY_DARK,
                  fontWeight: 500,
                }}
              />
            ))}
            {amenities.length > 4 && (
              <Chip label={`+${amenities.length - 4} more`} size="small" />
            )}
          </Stack>
        </Box>
        <Button
          variant="contained"
          endIcon={<ArrowForwardIos />}
          sx={{
            background: PRIMARY_COLOR,
            fontWeight: "bold",
            px: 3,
            ml: { md: 4 },
            mt: { xs: 2, md: 0 },
            boxShadow: 2,
            "&:hover": { background: PRIMARY_DARK },
          }}
          onClick={() => navigate("/properties")}
        >
          Manage Hotel
        </Button>
      </Card>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Hotel fontSize="large" />}
            label="Total Hotels"
            value={selectedHotel ? 1 : 0}
            color={PRIMARY_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<RoomService fontSize="large" />}
            label="Amenities"
            value={totalAmenities}
            color={PRIMARY_DARK}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Image fontSize="large" />}
            label="Images"
            value={hotelImages?.length}
            color={SECONDARY_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <SummaryCard
            icon={<Star fontSize="large" />}
            label="Avg. Rating"
            value={hotelRating}
            color={PRIMARY_LIGHT}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={7}>
          <Card
            sx={{
              boxShadow: 4,
              height: "100%",
              borderRadius: 3,
              transition: "all 0.3s",
              "&:hover": { boxShadow: 8 },
              background: "#fff",
            }}
          >
            <CardContent>
              <Typography
                variant="h6"
                fontWeight="bold"
                sx={{ color: PRIMARY_COLOR, mb: 2 }}
              >
                Property Overview
              </Typography>
              <Divider sx={{ mb: 3 }} />
              <Box sx={{ height: 300 }}>
                <BarChart
                  series={[
                    {
                      data: [1, totalAmenities, hotelImages?.length],
                      label: "Count",
                      color: PRIMARY_COLOR,
                    },
                  ]}
                  xAxis={[
                    {
                      scaleType: "band",
                      data: ["Hotels", "Amenities", "Images"],
                    },
                  ]}
                  height={300}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={5}>
          <Card
            sx={{
              boxShadow: 4,
              borderRadius: 3,
              height: "100%",
              p: 2,
              background: "#fff",
              transition: "all 0.3s ease",
              "&:hover": {
                boxShadow: 6,
                transform: "translateY(-2px)",
              },
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              mb={2}
            >
              <Typography
                variant="h6"
                fontWeight="bold"
                sx={{ color: PRIMARY_COLOR }}
              >
                Hotel Gallery
              </Typography>
              {hotelImages?.length > 6 && (
                <Button
                  size="small"
                  endIcon={<ArrowForwardIos sx={{ fontSize: 14 }} />}
                  onClick={() => navigate("/properties/images")}
                  sx={{
                    color: PRIMARY_LIGHT,
                    textTransform: "none",
                    "&:hover": {
                      color: PRIMARY_DARK,
                    },
                  }}
                >
                  View All
                </Button>
              )}
            </Stack>

            {hotelImages && hotelImages?.length > 0 ? (
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3, 1fr)",
                  gap: 2,
                  pb: 2,
                }}
              >
                {hotelImages?.slice(0, 6).map((img, idx) => (
                  <Box
                    key={idx}
                    sx={{
                      position: "relative",
                      width: "100%",
                      aspectRatio: "6/5",
                      borderRadius: 2,
                      overflow: "hidden",
                      boxShadow: 3,
                      transition: "all 0.3s ease",
                      cursor: "pointer",
                      "&:hover": {
                        transform: "scale(1.05)",
                        boxShadow: 6,
                        "& .image-overlay": {
                          opacity: 1,
                        },
                      },
                    }}
                    onClick={() => {
                      console.log("View image", img);
                    }}
                  >
                    <Box
                      component="img"
                      src={getImageUrl(img)}
                      alt={`Hotel image ${idx + 1}`}
                      sx={{
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                        backgroundColor: "#f3e6f7",
                      }}
                      onError={(e) => {
                        e.target.src =
                          "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80";
                      }}
                    />
                    <Box
                      className="image-overlay"
                      sx={{
                        position: "absolute",
                        bottom: 0,
                        left: 0,
                        right: 0,
                        background:
                          "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 100%)",
                        color: "white",
                        p: 1,
                        opacity: 0,
                        transition: "opacity 0.3s ease",
                      }}
                    >
                      <Typography variant="caption" sx={{ fontSize: 10 }}>
                        Image {idx + 1}
                      </Typography>
                    </Box>
                  </Box>
                ))}
              </Box>
            ) : (
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  p: 4,
                  border: `2px dashed ${PRIMARY_COLOR}20`,
                  borderRadius: 2,
                  backgroundColor: BACKGROUND_LIGHT,
                }}
              >
                <Image sx={{ fontSize: 40, color: PRIMARY_LIGHT, mb: 1 }} />
                <Typography
                  variant="body2"
                  color="text.secondary"
                  align="center"
                >
                  No images uploaded yet.
                  <br />
                  <Button
                    size="small"
                    onClick={() => navigate("/properties/images")}
                    sx={{
                      mt: 1,
                      color: PRIMARY_COLOR,
                      textTransform: "none",
                    }}
                  >
                    Upload Images
                  </Button>
                </Typography>
              </Box>
            )}
          </Card>
        </Grid>
      </Grid>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <StatCard
            icon={<RoomService fontSize="large" />}
            label="Popular Amenity"
            value={amenities[0]?.amenityName || "None"}
            color={PRIMARY_DARK}
          />
        </Grid>
        <Grid item xs={12} md={8}>
          <Card
            sx={{
              boxShadow: 3,
              borderRadius: 3,
              height: "100%",
              background: "#fff",
              p: 2,
            }}
          >
            <Typography
              variant="h6"
              fontWeight="bold"
              sx={{ color: PRIMARY_COLOR, mb: 2 }}
            >
              All Amenities
            </Typography>
            <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
              {amenities.length > 0 ? (
                amenities.map((a) => (
                  <Chip
                    key={a.amenityId}
                    label={a.amenityName}
                    size="small"
                    sx={{
                      bgcolor: SECONDARY_COLOR,
                      color: PRIMARY_DARK,
                      fontWeight: 500,
                    }}
                  />
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No amenities listed.
                </Typography>
              )}
            </Box>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

const SummaryCard = ({ icon, label, value, percentage, color }) => (
  <Card
    sx={{
      height: "100%",
      backgroundColor: `${color}08`,
      borderLeft: `4px solid ${color}`,
      boxShadow: 3,
      borderRadius: 3,
      transition: "all 0.3s",
      "&:hover": {
        transform: "translateY(-4px)",
        boxShadow: 6,
      },
    }}
  >
    <CardContent>
      <Stack direction="row" alignItems="center" spacing={2}>
        <Avatar
          sx={{
            bgcolor: `${color}20`,
            color: color,
            width: 56,
            height: 56,
          }}
        >
          {icon}
        </Avatar>
        <Box sx={{ flex: 1 }}>
          <Typography variant="subtitle1" sx={{ color: TEXT_SECONDARY }}>
            {label}
          </Typography>
          <Typography
            variant="h3"
            fontWeight="bold"
            sx={{ color: TEXT_PRIMARY }}
          >
            {value}
          </Typography>
        </Box>
      </Stack>
      {percentage !== undefined && (
        <Box sx={{ mt: 2 }}>
          <LinearProgress
            variant="determinate"
            value={percentage}
            sx={{
              height: 8,
              borderRadius: 4,
              mb: 1,
              backgroundColor: BACKGROUND_DARK,
              "& .MuiLinearProgress-bar": {
                backgroundColor: color,
              },
            }}
          />
          <Typography variant="caption" sx={{ color: TEXT_SECONDARY }}>
            {percentage}% of total
          </Typography>
        </Box>
      )}
    </CardContent>
  </Card>
);

const StatCard = ({ icon, label, value, color }) => (
  <Card
    sx={{
      boxShadow: 3,
      borderLeft: `4px solid ${color}`,
      backgroundColor: `${color}08`,
      borderRadius: 3,
      height: "100%",
      transition: "all 0.3s",
      "&:hover": { boxShadow: 6 },
    }}
  >
    <CardContent>
      <Stack direction="row" alignItems="center" spacing={2}>
        <Avatar sx={{ bgcolor: `${color}20`, color: color }}>{icon}</Avatar>
        <Box>
          <Typography variant="subtitle1" sx={{ color: TEXT_SECONDARY }}>
            {label}
          </Typography>
          <Typography
            variant="h4"
            fontWeight="bold"
            sx={{ color: TEXT_PRIMARY }}
          >
            {value}
          </Typography>
        </Box>
      </Stack>
    </CardContent>
  </Card>
);

export default OwnerDashboard;
