import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FiEdit, FiTrash2, FiUpload, FiX, FiPlus } from "react-icons/fi";
import {
  updateHotel,
  deleteHotel,
  fetchHotelById,
  uploadHotelImage,
  fetchHotelImages,
  deleteHotelImage,
  createAndAddAmenityToHotel,
  deleteAmenity,

} from "../app/hotelApi";
import { resetImageUploadStatus } from "../redux/hotelSlice";
import { addRoom, deleteRoom, getRoomsByHotelId, updateRoom } from "../redux/roomSlice";
import Swal from "sweetalert2";
import { deleteRoomAPI, updateRoomAPI } from "../app/roomApi";



const OwnerProperties = () => {
  const dispatch = useDispatch();

  // Redux state
  const {
    selectedHotel,
    status,
    imageUploadStatus,
    hotelImages,
    imagesLoading,
    imagesError,
    error,
  } = useSelector((state) => state.hotels);

 
  const { rooms, status: roomsStatus, error: roomsError } = useSelector((state) => ({
  rooms: Array.isArray(state.rooms.rooms) ? state.rooms.rooms : [],
  status: state.rooms.status,
  error: state.rooms.error
}));



  const user = useSelector((state) => state.user.userInfo);
  const userId = user?.id;
  // const baseUrl = axiosInstance.defaults.baseURL;

  // Component state
  const [editedHotelData, setEditedHotelData] = useState({});
  const [isEditing, setIsEditing] = useState(false);
  const [selectedRoomType, setSelectedRoomType] = useState("");
  const [roomBasePrice, setRoomBasePrice] = useState("");
  const [numberOfRooms, setNumberOfRooms] = useState("");
  const [hotelImage, setHotelImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [deletingImageId, setDeletingImageId] = useState(null);
  const hotelId = selectedHotel?.data?.[0]?.hotelId;
  const [newAmenityName, setNewAmenityName] = useState("");
  const [isAddingAmenity, setIsAddingAmenity] = useState(false);

  // Add this useEffect to fetch rooms when hotelId changes
  useEffect(() => {
    if (hotelId) {
      dispatch(getRoomsByHotelId(hotelId));
    }
  }, [dispatch, hotelId]);

  // Initialize hotel data
  useEffect(() => {
    if (selectedHotel?.data?.[0]) {
      setEditedHotelData({
        ...selectedHotel.data[0],
        city: selectedHotel.data[0].city || "",
      });
    }
  }, [selectedHotel]);

  // Fetch hotel data
  useEffect(() => {
    if (status === "idle" && userId) {
      dispatch(fetchHotelById(userId));
    }
  }, [dispatch, status, userId]);



  // Fetch images when hotel is selected
  useEffect(() => {
    if (hotelId) {
      dispatch(fetchHotelImages(hotelId));
    }
  }, [dispatch, hotelId]);

  // Handlers
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedHotelData((prev) => ({ ...prev, [name]: value }));
  };

  const handleEditHotel = () => setIsEditing(true);

  const handleUpdateHotel = () => {
    if (!editedHotelData.hotelId) return;

    const hotelData = {
      hotelId: editedHotelData.hotelId,
      hotelName: editedHotelData.hotelName,
      hotelAdd: editedHotelData.hotelAdd,
      city: editedHotelData.city,
      hotelRooms: editedHotelData.hotelRooms,
      hotelDes: editedHotelData.hotelDes,
      latitude: editedHotelData.latitude,
      longitude: editedHotelData.longitude,
    };

    dispatch(updateHotel(hotelData))
      .then(() => {
        dispatch(fetchHotelById(userId));
        setIsEditing(false);
         Swal.fire({
        icon: "success",
        title: "Hotel updated successfully!",
        showConfirmButton: false,
        timer: 1500,
      });
      })
      .catch(console.error);
  };

  const handleAddNewAmenity = async () => {
    if (!newAmenityName.trim()) {
     Swal.fire({
      icon: "warning",
      title: "Please enter an amenity name",
    });
      return;
    }

    try {
      const result = await dispatch(
        createAndAddAmenityToHotel({
          hotelId: selectedHotel.data[0].hotelId,
          amenityName: newAmenityName
        })
      ).unwrap();

      // Refresh hotel data to ensure sync
      await dispatch(fetchHotelById(userId));

      setNewAmenityName('');
      setIsAddingAmenity(false);
       Swal.fire({
      icon: "success",
      title: "Amenity added successfully!",
      showConfirmButton: false,
      timer: 1200,
    });
    } catch (error) {
      Swal.fire({
      icon: "error",
      title: "Failed to add amenity",
      text: error?.message || "Error occurred while adding amenity.",
    });
    }
  };



 const handleDeleteImage = (imageId) => {
  Swal.fire({
    title: "Delete this image?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      setDeletingImageId(imageId);
      dispatch(deleteHotelImage(imageId))
        .then(() => {
          dispatch(fetchHotelImages(hotelId));
          Swal.fire("Deleted!", "Image has been deleted.", "success");
        })
        .catch((error) => {
          Swal.fire({
            icon: "error",
            title: "Delete failed",
            text: error?.message || "Failed to delete image.",
          });
        })
        .finally(() => setDeletingImageId(null));
    }
  });
};

 const handleAddRoom = async (hotelId) => {
  if (!selectedRoomType || !roomBasePrice || !numberOfRooms) {
    Swal.fire({
      icon: "warning",
      title: "Please fill out all fields.",
    });
    return;
  }

  try {
    const roomData = {
      roomType: selectedRoomType,
      roomBasePrice: parseFloat(roomBasePrice),
      numberOfRooms: parseInt(numberOfRooms, 10),
      hotel: {
        hotelId: hotelId,
      }
    };

    const result = await dispatch(addRoom(roomData)).unwrap();

    setSelectedRoomType("");
    setRoomBasePrice("");
    setNumberOfRooms("");

   

    await dispatch(getRoomsByHotelId(hotelId)).unwrap();

    Swal.fire({
      icon: "success",
      title: "Room added successfully!",
      showConfirmButton: false,
      timer: 1200,
    });
  } catch (addError) {
    Swal.fire({
      icon: "error",
      title: "Failed to add room",
      text: addError?.message || "Failed to add room.",
    });
  }
};

const handleDeleteAmenity = async (amenityId) => {
  Swal.fire({
    title: "Are you sure?",
    text: "This amenity will be deleted.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Yes, delete it!",
  }).then(async (result) => {
    if (!result.isConfirmed) return;

    try {
      await dispatch(deleteAmenity({
        hotelId: selectedHotel.data[0].hotelId,
        amenityId
      })).unwrap();

      await dispatch(fetchHotelById(userId));

      Swal.fire({
        icon: "success",
        title: "Amenity deleted successfully",
        showConfirmButton: false,
        timer: 1200,
      });
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Failed to delete amenity",
        text: error?.message || "Failed to delete amenity.",
      });
    }
  });
};

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setHotelImage(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleUploadImage = () => {
    if (hotelImage && hotelId) {
      dispatch(uploadHotelImage({ image: hotelImage, hotelId }))
        .then(() => {
          dispatch(fetchHotelImages(hotelId));
          setImagePreview(null);
          setHotelImage(null);
          document.getElementById("fileInput").value = "";
          setTimeout(() => dispatch(resetImageUploadStatus()), 3000);
        })
        .catch(console.error);
    }
  };
  const handleEditRoom = (room) => {
  Swal.fire({
    title: 'Edit Room',
    html:
      `<div class="text-left">
        <div class="mb-4">
          <label class="block text-gray-700 text-sm font-bold mb-2">Room Type</label>
          <select id="swal-room-type" class="w-full px-3 py-2 border rounded">
            <option value="Single" ${room.roomType === 'Single' ? 'selected' : ''}>Single</option>
            <option value="Double" ${room.roomType === 'Double' ? 'selected' : ''}>Double</option>
            <option value="Suite" ${room.roomType === 'Suite' ? 'selected' : ''}>Suite</option>
          </select>
        </div>
        <div class="mb-4">
          <label class="block text-gray-700 text-sm font-bold mb-2">Base Price</label>
          <input id="swal-room-price" type="number" value="${room.roomBasePrice}" class="w-full px-3 py-2 border rounded">
        </div>
        <div>
          <label class="block text-gray-700 text-sm font-bold mb-2">Quantity</label>
          <input id="swal-room-quantity" type="number" value="${room.numberOfRooms}" class="w-full px-3 py-2 border rounded">
        </div>
      </div>`,
    focusConfirm: false,
    preConfirm: () => {
      return {
        roomType: document.getElementById('swal-room-type').value,
        roomBasePrice: document.getElementById('swal-room-price').value,
        numberOfRooms: document.getElementById('swal-room-quantity').value
      }
    }
  }).then((result) => {
    if (result.isConfirmed) {
      const updatedData = {
        roomType: result.value.roomType,
        roomBasePrice: parseFloat(result.value.roomBasePrice),
        numberOfRooms: parseInt(result.value.numberOfRooms, 10)
      };
      
      // Fix: Pass parameters separately, not as an object
      dispatch(updateRoom({ roomId: room.roomId, roomData: updatedData }))
        .unwrap()
        .then(() => {
          Swal.fire({
            icon: 'success',
            title: 'Room updated successfully!',
            showConfirmButton: false,
            timer: 1500
          });
          // Refresh rooms after update
          dispatch(getRoomsByHotelId(hotelId));
        })
        .catch(error => {
          Swal.fire({
            icon: 'error',
            title: 'Failed to update room',
            text: error.message || 'Something went wrong'
          });
        });
    }
  });
};

const handleDeleteRoom = (roomId) => {
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      dispatch(deleteRoom(roomId))
        .unwrap()
        .then(() => {
          Swal.fire(
            'Deleted!',
            'Room has been deleted.',
            'success'
          );
          // Refresh rooms after delete
          dispatch(getRoomsByHotelId(hotelId));
        })
        .catch(error => {
          Swal.fire({
            icon: 'error',
            title: 'Failed to delete room',
            text: error.message || 'Something went wrong'
          });
        });
    }
  });
};

  // Clean up image preview
  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
    };
  }, [imagePreview]);

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Error Display */}
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
          <p>Error: {error}</p>
        </div>
      )}

      {/* Hotel Information Section */}
      <section className="mb-10 bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-[#5B2362] mb-6">Hotel Details</h2>

          {selectedHotel?.data?.[0] ? (
            <div>
              {isEditing ? (
                <form onSubmit={(e) => { e.preventDefault(); handleUpdateHotel(); }}>
                  <h3 className="text-xl font-semibold mb-6 text-gray-800">Edit Hotel Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {[
                      { label: "Hotel Name", name: "hotelName", type: "text" },
                      { label: "Address", name: "hotelAdd", type: "text" },
                      { label: "City", name: "city", type: "text" },
                      { label: "Total Rooms", name: "hotelRooms", type: "number" },
                      { label: "Description", name: "hotelDes", type: "text", colSpan: "md:col-span-2" },
                      { label: "Latitude", name: "latitude", type: "number" },
                      { label: "Longitude", name: "longitude", type: "number" },
                    ].map((field) => (
                      <div key={field.name} className={field.colSpan || ""}>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          {field.label}
                        </label>
                        {field.name === "hotelDes" ? (
                          <textarea
                            name={field.name}
                            value={editedHotelData[field.name] || ""}
                            onChange={handleInputChange}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500 h-32"
                            required
                          />
                        ) : (
                          <input
                            type={field.type}
                            name={field.name}
                            value={editedHotelData[field.name] || ""}
                            onChange={handleInputChange}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                            required
                          />
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button
                      type="submit"
                      className="flex items-center justify-center px-4 py-2 bg-[#5B2362] text-white rounded-md hover:bg-purple-800 transition"
                    >
                      Save Changes
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <>
                  <div className="flex flex-col md:flex-row gap-8">
                    {/* Left Column - Hotel Info */}
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">
                        <span className="text-purple-700">{selectedHotel.data[0].hotelName}</span>
                      </h3>
                      <p className="text-gray-600 mb-4">{selectedHotel.data[0].hotelDes}</p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium text-gray-800 mb-2">Location Details</h4>
                          <p className="text-gray-700"><span className="font-medium">Address:</span> {selectedHotel.data[0].hotelAdd}</p>
                          <p className="text-gray-700"><span className="font-medium">City:</span> {selectedHotel.data[0].city}</p>
                          <p className="text-gray-700"><span className="font-medium">Coordinates:</span> {selectedHotel.data[0].latitude}, {selectedHotel.data[0].longitude}</p>
                        </div>

                        <div className="bg-gray-50 p-4 rounded-lg">
                          <h4 className="font-medium text-gray-800 mb-2">Property Info</h4>
                          <p className="text-gray-700"><span className="font-medium">Total Rooms:</span> {selectedHotel.data[0].hotelRooms}</p>
                          <p className="text-gray-700"><span className="font-medium">Owner:</span> {selectedHotel.data[0].hotelOwner?.firstName} {selectedHotel.data[0].hotelOwner?.lastName}</p>
                        </div>
                      </div>
                    </div>

                    {/* Right Column - Quick Stats */}
                    <div className="md:w-1/3 lg:w-1/4">
                      <div className="bg-purple-50 p-4 rounded-lg border border-purple-100">
                        <h4 className="font-medium text-purple-800 mb-3">Quick Stats</h4>

                        <div className="space-y-3">
                          <div>
                            <p className="text-sm text-gray-600">Total Amenities</p>
                            <p className="text-xl font-semibold text-purple-700">
                              {selectedHotel.data[0].amenities?.length || 0}
                            </p>
                          </div>

                          <div>
                            <p className="text-sm text-gray-600">Total Images</p>
                            <p className="text-xl font-semibold text-purple-700">
                              {hotelImages?.length}
                            </p>
                          </div>

                          <div>
                            <p className="text-sm text-gray-600">Room Types</p>
                            <p className="text-xl font-semibold text-purple-700">
                              {new Set(rooms.map(room => room.roomType)).size}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Quick Actions */}
                      <div className="mt-4 space-y-2">
                        <button
                          onClick={handleEditHotel}
                          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#5B2362] text-white rounded-md hover:bg-purple-800 transition"
                        >
                          <FiEdit /> Edit Hotel
                        </button>
                        
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <p className="text-gray-600">No hotel found for this owner.</p>
          )}
        </div>
      </section>

      {/* Amenities Section */}

      <section className="mb-10 bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-[#5B2362]">Hotel Amenities</h2>
            <button
              onClick={() => setIsAddingAmenity(true)}
              className="flex items-center gap-2 px-4 py-2 bg-[#5B2362] text-white rounded-md hover:bg-purple-800 transition"
            >
              <FiPlus /> Add Amenity
            </button>
          </div>

          {/* Add Amenity Form */}
          {isAddingAmenity && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-gray-800">Create New Amenity</h3>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={newAmenityName}
                  onChange={(e) => setNewAmenityName(e.target.value)}
                  placeholder="Enter amenity name"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                />
                <button
                  onClick={handleAddNewAmenity}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setIsAddingAmenity(false);
                    setNewAmenityName("");
                  }}
                  className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Current Amenities */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {selectedHotel?.data?.[0]?.amenities?.length > 0 ? (
              selectedHotel.data[0].amenities.map((amenity) => (
                <div key={amenity.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition flex justify-between items-center">
                  <span className="text-gray-800">{amenity.amenityName}</span>
                  <button
                    onClick={() => handleDeleteAmenity(amenity.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <FiTrash2 size={16} />
                  </button>
                </div>
              ))
            ) : (
              <p className="text-gray-600 col-span-full">No amenities available</p>
            )}
          </div>
        </div>
      </section>

      {/* Add Room Section */}
      {selectedHotel?.data?.[0] && (
        <section className="mb-10 bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-[#5B2362] mb-6">Add Room</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Room Type</label>
                <select
                  value={selectedRoomType}
                  onChange={(e) => setSelectedRoomType(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Select Type</option>
                  <option value="Single">Single</option>
                  <option value="Double">Double</option>
                  <option value="Suite">Suite</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Base Price</label>
                <input
                  type="number"
                  value={roomBasePrice}
                  onChange={(e) => setRoomBasePrice(e.target.value)}
                  placeholder="₹0.00"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                <input
                  type="number"
                  value={numberOfRooms}
                  onChange={(e) => setNumberOfRooms(e.target.value)}
                  placeholder="0"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => handleAddRoom(selectedHotel.data[0].hotelId)}
                  className="flex items-center justify-center gap-2 w-full px-4 py-2 bg-[#5B2362] text-white rounded-md hover:bg-purple-800 transition"
                >
                  <FiPlus /> Add Room
                </button>
              </div>
            </div>
          </div>
        </section>
      )}
      {selectedHotel?.data?.[0] && (
        <section className="mb-10 bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-[#5B2362] mb-6">Current Rooms</h2>
            {roomsStatus === 'failed' && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-4">
                <p>Error: {roomsError}</p>
                <button
                  onClick={() => dispatch(getRoomsByHotelId(hotelId))}
                  className="mt-2 px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                >
                  Retry
                </button>
              </div>
            )}

            {roomsStatus === 'loading' ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
              </div>
            ) : roomsError ? (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">
                Error loading rooms: {roomsError}
              </div>
            ) : rooms.length > 0 ? (
              <div className="overflow-x-auto">
            
<table className="min-w-full divide-y divide-gray-200">
  <thead className="bg-gray-50">
    <tr>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Room Type</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Base Price</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
    </tr>
  </thead>
  <tbody className="bg-white divide-y divide-gray-200">
    {rooms.map((room) => (
      <tr key={room.roomId}>
        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
          {room.roomType}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
          ₹{room.roomBasePrice}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
          {room.numberOfRooms}
        </td>
        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 flex gap-2">
          <button
            onClick={() => handleEditRoom(room)}
            className="text-blue-600 hover:text-blue-900"
          >
            <FiEdit size={16} />
          </button>
          <button
            onClick={() => handleDeleteRoom(room.roomId)}
            className="text-red-600 hover:text-red-900"
          >
            <FiTrash2 size={16} />
          </button>
        </td>
      </tr>
    ))}
  </tbody>
</table>
              </div>
            ) : (
              <div className="bg-gray-100 rounded-lg p-8 text-center">
                <p className="text-gray-600">No rooms available for this hotel.</p>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Hotel Images Section */}
      <section className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-[#5B2362] mb-6">Hotel Images</h2>

          {/* Upload Section */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Upload New Image</h3>
            <div className="space-y-4">
              {imagePreview && (
                <div className="relative w-full max-w-md mx-auto">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full h-64 object-cover rounded-lg border-2 border-dashed border-gray-300"
                  />
                  <button
                    onClick={() => {
                      setImagePreview(null);
                      setHotelImage(null);
                    }}
                    className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition"
                  >
                    <FiX size={18} />
                  </button>
                </div>
              )}
              <div className="flex flex-col sm:flex-row gap-4">
                <label className="flex-1 cursor-pointer">
                  <div className="px-4 py-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-500 transition text-center">
                    <FiUpload className="mx-auto text-gray-400 mb-2" size={24} />
                    <p className="text-gray-600">Click to select an image</p>
                    <input
                      id="fileInput"
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </div>
                </label>
                <button
                  onClick={handleUploadImage}
                  disabled={!hotelImage || imageUploadStatus === "loading"}
                  className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg ${!hotelImage || imageUploadStatus === "loading"
                    ? "bg-gray-300 cursor-not-allowed"
                    : "bg-purple-700 hover:bg-purple-800 text-white"
                    }`}
                >
                  {imageUploadStatus === "loading" ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Uploading...
                    </>
                  ) : (
                    <>
                      <FiUpload /> Upload Image
                    </>
                  )}
                </button>
              </div>
              {imageUploadStatus === "succeeded" && (
                <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded">
                  Image uploaded successfully!
                </div>
              )}
              {imageUploadStatus === "failed" && (
                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">
                  Failed to upload image: {error}
                </div>
              )}
            </div>
          </div>

          {/* Current Images */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Current Images</h3>
            {imagesLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
              </div>
            ) : imagesError ? (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded">
                Error loading images: {imagesError}
              </div>
            ) : hotelImages?.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {hotelImages.map((image) => {
                  const imageUrl = `http://localhost:8080/api/images/getImages?hotel_id=${hotelId}&imageName=${image.imageName}`;
                  return (
                    <div key={image.id} className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-lg transition">
                      <img
                        src={imageUrl}
                        alt={`Hotel ${selectedHotel?.data?.[0]?.hotelName}`}
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          console.error('Failed to load image:', imageUrl);
                          e.target.onerror = null;
                          e.target.src = '/placeholder-image.jpg';
                        }}
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <button
                          onClick={() => handleDeleteImage(image.id)}
                          disabled={deletingImageId === image.id}
                          className={`flex items-center gap-1 px-3 py-2 rounded-md ${deletingImageId === image.id
                            ? "bg-gray-400 cursor-not-allowed"
                            : "bg-red-600 hover:bg-red-700"
                            } text-white`}
                        >
                          {deletingImageId === image.id ? (
                            <>
                              <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Deleting...
                            </>
                          ) : (
                            <>
                              <FiTrash2 size={16} /> Delete
                            </>
                          )}
                        </button>
                      </div>
                      <div className="p-3 bg-white">
                        <p className="text-sm text-gray-600 truncate">{image.imageName}</p>
                        {image.createdAt && (
                          <p className="text-xs text-gray-500">
                            Uploaded: {new Date(image.createdAt).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-gray-100 rounded-lg p-8 text-center">
                <p className="text-gray-600">No images uploaded yet for this hotel.</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default OwnerProperties;