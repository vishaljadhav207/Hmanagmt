import React, { useState, useEffect } from "react";
import profileimage from "../assets/profileimage.png";
import InputField from "../components/InputField";
import AppButton from "../components/AppButton";
import axiosInstance from "../app/axiosInstance";
import { useDispatch, useSelector } from "react-redux";
import { setAdminId } from "../redux/userSlice";
import { fetchUserById } from "../app/userApi";
import { FaUserEdit, FaSave, FaTimes } from "react-icons/fa";

const AdminProfile = () => {
  const dispatch = useDispatch();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [profileImage, setProfileImage] = useState(profileimage);
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
  });
  const [fetchError, setFetchError] = useState(null);
  const [updateError, setUpdateError] = useState(null);
  const { userInfo } = useSelector((state) => state.user);

  useEffect(() => {
    if (userInfo?.id) {
      dispatch(setAdminId(userInfo?.id));
    }
  }, [userInfo, dispatch]);

  useEffect(() => {
    const fetchProfileData = async () => {
      if (userInfo?.id) {
        try {
          const response = await dispatch(fetchUserById(userInfo?.id));
          const { firstName, lastName, email, mobile } = response.payload;
          setFirstName(firstName);
          setLastName(lastName);
          setEmail(email);
          setPhoneNumber(mobile);
        } catch (error) {
          setFetchError("Failed to load user data. Please try again later.");
        }
      }
    };

    fetchProfileData();
  }, [dispatch, userInfo?.id]);

  const handleEditProfile = () => {
    setIsEditing(true);
  };

  const handleProfileImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file));
    }
  };

  const handleUpdateProfile = async () => {
    const newErrors = {
      firstName: firstName ? "" : "First Name is required",
      lastName: lastName ? "" : "Last Name is required",
      phoneNumber: phoneNumber ? "" : "Phone Number is required",
    };

    setErrors(newErrors);

    if (newErrors.firstName || newErrors.lastName || newErrors.phoneNumber) {
      return;
    }

    const updatedProfile = {
      firstName,
      lastName,
      email,
      mobile: phoneNumber,
    };

    try {
      const response = await axiosInstance.put(
        `user/updateUser/${userInfo?.id}`,
        updatedProfile
      );

      if (response.data.status === "NOT_FOUND") {
        setUpdateError("User not found. Please check the user ID.");
        return;
      }

      setIsEditing(false);
    } catch (error) {
      setUpdateError("Failed to update profile. Please try again later.");
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    if (userInfo?.id) {
      dispatch(fetchUserById(userInfo?.id)).then((response) => {
        const { firstName, lastName, email, mobile } = response.payload;
        setFirstName(firstName);
        setLastName(lastName);
        setEmail(email);
        setPhoneNumber(mobile);
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="bg-[#5A2360] py-4 px-6">
          <h1 className="text-2xl font-bold text-white">My Profile</h1>
        </div>

        <div className="p-6">
          {fetchError && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {fetchError}
            </div>
          )}

          {updateError && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {updateError}
            </div>
          )}

          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3 flex flex-col items-center">
              <div className="relative mb-4">
                <img
                  src={profileImage}
                  alt="Profile"
                  className="rounded-full w-40 h-40 object-cover border-4 border-fuchsia-100"
                />
                {isEditing && (
                  <div className="absolute bottom-2 right-2">
                  <label
                    htmlFor="upload_profile"
                    className="bg-[#5A2360] text-white p-2 rounded-full cursor-pointer hover:bg-fuchsia-900 transition-all duration-300 flex items-center justify-center"
                    title="Change photo"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z"
                        clipRule="evenodd"
                      />
                    </svg>
                    <input
                      type="file"
                      name="profile"
                      id="upload_profile"
                      hidden
                      onChange={handleProfileImageChange}
                      accept="image/*"
                    />
                  </label>
                </div>
                )}
              </div>

              <h2 className="text-xl font-bold text-center">
                {firstName} {lastName}
              </h2>
              <p className="text-gray-600 text-center">{email}</p>

              {!isEditing ? (
                <AppButton
                  onClick={handleEditProfile}
                  className="mt-4 bg-[#5A2360] hover:bg-fuchsia-900 text-white w-48"
                  icon={<FaUserEdit className="mr-2" />}
                  title="Edit Profile"
                />
              ) : (
                <div className="flex space-x-2 mt-4">
                  <AppButton
                    onClick={handleUpdateProfile}
                    className="bg-[#5A2360] w-25 text-white"
                    icon={<FaSave className="mr-2" />}
                    title="Save"
                  />
                  <AppButton
                    onClick={handleCancelEdit}
                    className="bg-gray-400 w-25 text-white"
                    icon={<FaTimes className="mr-2" />}
                    title="Cancel"
                  />
                </div>
              )}
            </div>

            <div className="md:w-2/3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="mb-4">
                  <label className="block text-gray-700 font-medium mb-2">
                    First Name
                  </label>
                  {isEditing ? (
                    <>
                      <InputField
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded focus:ring-fuchsia-900 focus:border-fuchsia-900"
                      />
                      {errors.firstName && (
                        <p className="text-red-500 text-sm mt-1">
                          {errors.firstName}
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="p-2 border border-gray-300 rounded bg-gray-50">
                      {firstName}
                    </div>
                  )}
                </div>

                <div className="mb-4">
                  <label className="block text-gray-700 font-medium mb-2">
                    Last Name
                  </label>
                  {isEditing ? (
                    <>
                      <InputField
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded focus:ring-fuchsia-900 focus:border-fuchsia-900"
                      />
                      {errors.lastName && (
                        <p className="text-red-500 text-sm mt-1">
                          {errors.lastName}
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="p-2 border border-gray-300 rounded bg-gray-50">
                      {lastName}
                    </div>
                  )}
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 font-medium mb-2">
                  Email
                </label>
                <div className="p-2 border border-gray-300 rounded bg-gray-50">
                  {email}
                </div>
                {isEditing && (
                  <p className="text-sm text-gray-500 mt-1">
                    Email cannot be changed
                  </p>
                )}
              </div>

              <div className="mb-4">
                <label className="block text-gray-700 font-medium mb-2">
                  Phone Number
                </label>
                {isEditing ? (
                  <>
                    <InputField
                      type="text"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded focus:ring-fuchsia-900 focus:border-fuchsia-900"
                    />
                    {errors.phoneNumber && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.phoneNumber}
                      </p>
                    )}
                  </>
                ) : (
                  <div className="p-2 border border-gray-300 rounded bg-gray-50">
                    {phoneNumber}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminProfile;
