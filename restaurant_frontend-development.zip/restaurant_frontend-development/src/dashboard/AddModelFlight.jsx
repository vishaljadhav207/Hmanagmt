import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  CircularProgress,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Chip,
} from "@mui/material";
import { FaPlane } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import { getSupervisorByOrgId } from "../app/userApi.js";
import { getClassTypesByTransportType } from "../app/busApi";

const AddModelFlight = ({ open, flight, onSave, onCancel, onSuccess }) => {
  const { userInfo: user } = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const {
    supervisorByOrg: supervisors = [],
    loading: supervisorLoading,
    error: supervisorError,
  } = useSelector((state) => state.user);

  const {
    classTypes = [],
    classTypesLoading,
    classTypesError,
  } = useSelector((state) => state.buses);

  const [formData, setFormData] = useState({
    flightNo: flight?.flight_no || "",
    airline: flight?.airline || "",
    departFrom: flight?.departFrom || "",
    destination: flight?.destination || "",
    userId: flight?.userId || "",
    orgId: user?.orgId || flight?.organization?.orgId || "",
    classTypes: flight?.classTypes?.map((ct) => ct.classId) || [],
  });

  const [formError, setFormError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user?.orgId) {
      dispatch(getSupervisorByOrgId({ orgId: user.orgId, roleId: 3002 }));
      dispatch(getClassTypesByTransportType("FLIGHT"));
    }
  }, [dispatch, user?.orgId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const isClassTypeSelected = (classId) => {
    return formData.classTypes.includes(classId);
  };

  const handleClassTypeChange = (classId) => (e) => {
    const { checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      classTypes: checked
        ? [...prev.classTypes, classId]
        : prev.classTypes.filter((id) => id !== classId),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);
    setIsSubmitting(true);

    const { flightNo, airline, userId } = formData;

    if (!flightNo || !airline || !userId) {
      setFormError("Please fill in all required fields");
      setIsSubmitting(false);
      return;
    }

    const flightData = {
      flight_no: formData.flightNo.trim(),
      airline: formData.airline.trim(),
      departFrom: formData.departFrom.trim(),
      destination: formData.destination.trim(),
      userId: Number(formData.userId),
      organization: {
        orgId: Number(formData.orgId),
      },
      classTypes: formData.classTypes.map((id) => ({ classId: id })),
      ...(flight?.flightId && { flight_id: flight.flightId }),
    };

    try {
      await onSave(flightData);
      onSuccess();
    } catch (err) {
      setFormError(err.message || "Failed to save flight");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={onCancel}
      maxWidth="md"
      fullWidth
      PaperProps={{ sx: { borderRadius: 3 } }}
    >
      <DialogTitle
        sx={{
          backgroundColor: "primary.main",
          color: "white",
          display: "flex",
          alignItems: "center",
          gap: 2,
          py: 2,
        }}
      >
        <FaPlane />
        <Typography variant="h6" fontWeight="bold">
          {flight?.flightId ? "Edit Flight" : "Add New Flight"}
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ p: 3 }}>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          {/* Error messages */}
          {(formError || supervisorError || classTypesError) && (
            <Typography color="error" mb={2}>
              {formError || supervisorError || classTypesError}
            </Typography>
          )}

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
              mt: 2,
            }}
          >
            {/* Flight Number */}
            <TextField
              label="Flight Number *"
              name="flightNo"
              value={formData.flightNo}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            {/* Airline */}
            <TextField
              label="Airline *"
              name="airline"
              value={formData.airline}
              onChange={handleChange}
              fullWidth
              size="small"
              required
            />

            {/* Departure Airport */}
            <TextField
              label="Departure Airport"
              name="departFrom"
              value={formData.departFrom}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            {/* Destination Airport */}
            <TextField
              label="Destination Airport"
              name="destination"
              value={formData.destination}
              onChange={handleChange}
              fullWidth
              size="small"
            />

            {/* Supervisor */}
            <FormControl fullWidth size="small" required>
              <InputLabel>Supervisor *</InputLabel>
              <Select
                name="userId"
                value={formData.userId}
                onChange={handleChange}
                label="Supervisor *"
                disabled={supervisorLoading}
              >
                <MenuItem value="">
                  {supervisorLoading ? "Loading..." : "Select Supervisor"}
                </MenuItem>
                {supervisors.map((supervisor) => (
                  <MenuItem key={supervisor.userId} value={supervisor.userId}>
                    {supervisor.firstName} {supervisor.lastName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* Organization ID (read-only) */}
            <TextField
              label="Organization ID *"
              name="orgId"
              value={formData.orgId}
              onChange={handleChange}
              fullWidth
              size="small"
              required
              InputProps={{
                readOnly: true,
              }}
            />
          </Box>

          {/* Class Types Section */}
          <Box sx={{ mt: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Available Classes
            </Typography>

            {classTypesLoading ? (
              <CircularProgress size={24} />
            ) : (
              <FormGroup row>
                {classTypes.map((classType) => (
                  <FormControlLabel
                    key={classType.classId}
                    control={
                      <Checkbox
                        checked={isClassTypeSelected(classType.classId)}
                        onChange={handleClassTypeChange(classType.classId)}
                        name={`class-${classType.classId}`}
                      />
                    }
                    label={classType.className}
                  />
                ))}
              </FormGroup>
            )}

            {formData.classTypes.length > 0 && (
              <Box sx={{ mt: 2 }}>
                <Typography variant="subtitle2" gutterBottom>
                  Selected Classes:
                </Typography>
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1 }}>
                  {formData.classTypes.map((classId) => {
                    const classInfo = classTypes.find(
                      (ct) => ct.classId === classId
                    );
                    return (
                      <Chip
                        key={classId}
                        label={classInfo?.className || `Class ${classId}`}
                        onDelete={() =>
                          handleClassTypeChange(classId)({
                            target: { checked: false },
                          })
                        }
                      />
                    );
                  })}
                </Box>
              </Box>
            )}
          </Box>

          <Divider sx={{ my: 3 }} />

          <DialogActions>
            <Button
              onClick={onCancel}
              variant="outlined"
              color="primary"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={isSubmitting}
              sx={{
                backgroundColor: "#5A2360",
                "&:hover": { backgroundColor: "#6B2D72" },
                minWidth: 120,
              }}
            >
              {isSubmitting ? (
                <CircularProgress size={24} color="inherit" />
              ) : flight?.flightId ? (
                "Update Flight"
              ) : (
                "Add Flight"
              )}
            </Button>
          </DialogActions>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default AddModelFlight;
