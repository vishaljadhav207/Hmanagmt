
import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getBusByOrgId,
  fetchBusSupervisors,
  saveBus,
  updateBus,
  deleteBus,
} from "../app/busApi";
import {
  setBusCurrentPage,
  setBusPageSize,
  clearError,
  setSortBy,
  setSortDir,
} from "../redux/busSlice";
import AppButton from "../components/AppButton";
import {
  FaEdit,
  FaTrash,
  FaEye,
  FaPlus,
  FaBus,
  FaSearch,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import AddModelBus from "./AddModelBus";
import Swal from "sweetalert2";

// MUI Components
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TablePagination,
  IconButton,
  LinearProgress,
  Typography,
  Box,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Chip,
  Divider,
  Tooltip,
  TextField,
  InputAdornment,
} from "@mui/material";
import { styled } from "@mui/material/styles";

// Custom styled components
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontWeight: 500,
  padding: theme.spacing(1.5),
  borderBottom: `1px solid ${theme.palette.divider}`,
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:hover": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:last-child td": {
    borderBottom: 0,
  },
}));

const DetailCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[1],
  height: "100%",
  display: "flex",
  flexDirection: "column",
  backgroundColor: theme.palette.background.paper,
}));

const BusList = () => {
  const dispatch = useDispatch();
  const { userInfo: user } = useSelector((state) => state.user);
  const {
    buses,
    status: busStatus,
    supervisors,
    error,
    currentPage,
    totalPages,
    totalItems,
    pageSize,
    sortBy,
    sortDir,
  } = useSelector((state) => state.buses);

  const safeBuses = Array.isArray(buses) ? buses : [];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedBus, setSelectedBus] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredBuses = useMemo(() => {
    return safeBuses.filter(
      (bus) =>
        bus.busNo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bus.operatorName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bus.departFrom?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bus.destination?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [safeBuses, searchTerm]);

  const refreshBuses = () => {
    if (user?.orgId) {
      dispatch(
        getBusByOrgId({
          orgId: user.orgId,
          pageNumber: currentPage,
          pageSize,
          sortBy,
          sortDir,
        })
      ).catch((error) => {
        Swal.fire({
          title: "Error!",
          text: error.message || "Failed to load buses",
          icon: "error",
          confirmButtonColor: "#5A2360",
        });
      });
    }
  };

  useEffect(() => {
    refreshBuses();
    dispatch(fetchBusSupervisors());
  }, [dispatch, user?.orgId, currentPage, pageSize, sortBy, sortDir]);

  const handleSort = (column) => {
    if (sortBy === column) {
      const newDir = sortDir === "asc" ? "desc" : "asc";
      dispatch(setSortDir(newDir));
    } else {
      dispatch(setSortBy(column));
      dispatch(setSortDir("asc"));
    }
    dispatch(setBusCurrentPage(0));
  };

  const renderSortIcon = (column) => {
    if (sortBy !== column)
      return <FaSort style={{ marginLeft: 5, opacity: 0.3 }} />;
    return sortDir === "asc" ? (
      <FaSortUp style={{ marginLeft: 5 }} />
    ) : (
      <FaSortDown style={{ marginLeft: 5 }} />
    );
  };

  const handleAddBus = () => {
    setSelectedBus(null);
    setIsModalOpen(true);
  };

  const handleSaveBus = async (busData) => {
    try {
      await dispatch(saveBus(busData)).unwrap();

      Swal.fire({
        title: "Success!",
        text: "Bus added successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to add bus",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
      throw error; // Re-throw to be caught by AddModelBus
    }
  };

  const handleUpdateBus = async (busData) => {
    if (!selectedBus?.busId) return;

    try {
      await dispatch(
        updateBus({
          busId: selectedBus.busId,
          ...busData,
        })
      ).unwrap();

      Swal.fire({
        title: "Success!",
        text: "Bus updated successfully!",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to update bus",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
      throw error; // Re-throw to be caught by AddModelBus
    }
  };

  const handleViewDetails = (bus) => {
    setSelectedBus(bus);
    setIsViewModalOpen(true);
  };

  const handleDeleteClick = (busId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#5A2360",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        handleConfirmDelete(busId);
      }
    });
  };

  const handleConfirmDelete = async (busId) => {
    try {
      await dispatch(deleteBus(busId)).unwrap();
      refreshBuses();
      Swal.fire({
        title: "Deleted!",
        text: "Bus has been deleted successfully.",
        icon: "success",
        confirmButtonColor: "#5A2360",
      });
    } catch (error) {
      Swal.fire({
        title: "Error!",
        text: error.message || "Failed to delete bus",
        icon: "error",
        confirmButtonColor: "#5A2360",
      });
    }
  };

  const handleCloseViewModal = () => setIsViewModalOpen(false);
  const handlePageChange = (event, newPage) => {
    dispatch(setBusCurrentPage(newPage));
  };

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    dispatch(setBusPageSize(newSize));
    dispatch(setBusCurrentPage(0));
  };

  return (
    <Box sx={{ p: { xs: 1, md: 3 } }}>
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
          gap: 2,
        }}
      >
        <TextField
          placeholder="Search buses..."
          variant="outlined"
          size="small"
          sx={{
            width: { xs: "100%", md: "400px" },
            backgroundColor: "background.paper",
            borderRadius: 1,
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <FaSearch color="action" />
              </InputAdornment>
            ),
          }}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <AppButton
          title="Add Bus"
          onClick={handleAddBus}
          icon={<FaPlus style={{ marginRight: 8 }} />}
          className="bg-[#5A2360] text-white hover:bg-[#6B2D72] px-6 py-3 text-base"
          sx={{
            minWidth: 220,
            height: 50,
            borderRadius: 1,
            fontSize: "1.05rem",
            padding: "0 24px",
          }}
        />
      </Box>

      <Paper
        sx={{
          width: "100%",
          overflow: "hidden",
          mb: 2,
          borderRadius: 2,
          boxShadow: 1,
        }}
      >
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: "primary.main" }}>
                <StyledTableCell
                  onClick={() => handleSort("busNo")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Bus No
                    </Typography>
                    {renderSortIcon("busNo")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("busType")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Bus Type
                    </Typography>
                    {renderSortIcon("busType")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("operatorName")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Operator
                    </Typography>
                    {renderSortIcon("operatorName")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("departFrom")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Departure
                    </Typography>
                    {renderSortIcon("departFrom")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell
                  onClick={() => handleSort("destination")}
                  sx={{ cursor: "pointer" }}
                >
                  <Box display="flex" alignItems="center">
                    <Typography color="common.white" fontWeight="bold">
                      Destination
                    </Typography>
                    {renderSortIcon("destination")}
                  </Box>
                </StyledTableCell>
                <StyledTableCell>
                  <Typography color="common.white" fontWeight="bold">
                    Organization
                  </Typography>
                </StyledTableCell>
                <StyledTableCell align="right">
                  <Typography color="common.white" fontWeight="bold">
                    Actions
                  </Typography>
                </StyledTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {busStatus === "loading" ? (
                <TableRow>
                  <TableCell colSpan={7}>
                    <LinearProgress />
                    <Typography align="center" sx={{ py: 2 }}>
                      Loading buses...
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : filteredBuses.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                    <Box textAlign="center" py={4}>
                      <FaBus
                        size={48}
                        color="#5A2360"
                        style={{ opacity: 0.5 }}
                      />
                      <Typography variant="h6" color="textSecondary" mt={2}>
                        {searchTerm
                          ? "No matching buses found"
                          : "No buses available"}
                      </Typography>
                      {!searchTerm && (
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={handleAddBus}
                          sx={{ mt: 4 }}
                        >
                          Add Your First Bus
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                filteredBuses.map((bus) => (
                  <StyledTableRow key={bus.busId} hover>
                    <StyledTableCell>
                      <Tooltip title={`Bus ID: ${bus.busId}`}>
                        <Chip
                          label={bus.busNo || "N/A"}
                          color="primary"
                          size="small"
                          sx={{ fontWeight: 600 }}
                        />
                      </Tooltip>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography fontWeight="medium">
                        {bus.busType || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {bus.operatorName || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {bus.departFrom || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {bus.destination || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Typography variant="body2">
                        {bus.organization?.orgName || "N/A"}
                      </Typography>
                    </StyledTableCell>
                    <StyledTableCell align="right">
                      <Box display="flex" justifyContent="flex-end" gap={1}>
                        <Tooltip title="View details">
                          <IconButton
                            onClick={() => handleViewDetails(bus)}
                            color="info"
                            size="small"
                          >
                            <FaEye />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit bus">
                          <IconButton
                            onClick={() => {
                              setSelectedBus({
                                ...bus,
                                busId: bus.busId,
                              });
                              setIsModalOpen(true);
                            }}
                            color="warning"
                            size="small"
                          >
                            <FaEdit />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete bus">
                          <IconButton
                            onClick={() => handleDeleteClick(bus.busId)}
                            color="error"
                            size="small"
                          >
                            <FaTrash />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </StyledTableCell>
                  </StyledTableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <Divider />

        <Box
          sx={{
            p: 2,
            display: "flex",
            flexDirection: { xs: "column", sm: "row" },
            justifyContent: "space-between",
            alignItems: "center",
            gap: 2,
          }}
        >
          <FormControl size="small" sx={{ minWidth: 120 }}>
            <InputLabel>Rows per page</InputLabel>
            <Select
              value={pageSize}
              onChange={handlePageSizeChange}
              label="Rows per page"
            >
              {[5, 10, 25, 50].map((size) => (
                <MenuItem key={size} value={size}>
                  {size}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TablePagination
            component="div"
            count={totalItems}
            page={currentPage}
            onPageChange={handlePageChange}
            rowsPerPage={pageSize}
            rowsPerPageOptions={[]}
            labelDisplayedRows={({ from, to, count }) =>
              `${from}-${to} of ${count}`
            }
          />
        </Box>
      </Paper>

      {/* Add/Edit Bus Modal */}
      {isModalOpen && (
        <AddModelBus
          open={isModalOpen} // Add this prop
          bus={selectedBus}
          onSave={selectedBus ? handleUpdateBus : handleSaveBus}
          onCancel={() => setIsModalOpen(false)}
          onSuccess={() => {
            refreshBuses();
            setIsModalOpen(false);
          }}
        />
      )}

      {/* View Bus Details Modal */}
      <Dialog
        open={isViewModalOpen}
        onClose={handleCloseViewModal}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            overflow: "hidden",
          },
        }}
      >
        <DialogTitle
          sx={{
            backgroundColor: "primary.main",
            color: "white",
            display: "flex",
            alignItems: "center",
            gap: 2,
            py: 2,
          }}
        >
          <FaBus />
          <Typography variant="h6" fontWeight="bold">
            Bus Details: {selectedBus?.busNo}
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ p: 3 }}>
          {selectedBus && (
            <Box
              sx={{
                display: "flex",
                flexWrap: "wrap",
                gap: 3,
                mt: 2,
                pb: 2,
              }}
            >
              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  BUS INFORMATION
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem label="Bus ID" value={selectedBus.busId} />
                <DetailItem label="Bus Number" value={selectedBus.busNo} />
                <DetailItem label="Bus Type" value={selectedBus.busType} />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  OPERATOR DETAILS
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Operator Name"
                  value={selectedBus.operatorName || "N/A"}
                />
                <DetailItem
                  label="Operator Contact"
                  value={selectedBus.operatorContact || "N/A"}
                />
              </DetailCard>

              <DetailCard>
                <Typography
                  variant="subtitle2"
                  color="textSecondary"
                  gutterBottom
                >
                  ROUTE DETAILS
                </Typography>
                <Divider sx={{ my: 1 }} />
                <DetailItem
                  label="Departure"
                  value={selectedBus.departFrom || "N/A"}
                />
                <DetailItem
                  label="Destination"
                  value={selectedBus.destination || "N/A"}
                />
              </DetailCard>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={handleCloseViewModal}
            variant="outlined"
            color="primary"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

const DetailItem = ({ label, value }) => (
  <Box sx={{ mb: 2 }}>
    <Typography variant="subtitle2" color="textSecondary">
      {label}
    </Typography>
    <Typography variant="body1" sx={{ mt: 0.5, wordBreak: "break-word" }}>
      {value || (
        <Typography component="span" color="text.disabled">
          Not available
        </Typography>
      )}
    </Typography>
  </Box>
);

export default BusList;
