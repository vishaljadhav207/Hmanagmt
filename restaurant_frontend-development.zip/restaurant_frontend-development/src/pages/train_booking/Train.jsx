import React, { useState } from "react";
import { Outlet } from "react-router-dom"; // Import Outlet for nested routes
import TrainBookingTabs from "../../components/TrainBookingTabs";
import TrainImg from "../../assets/432.jpg";
import TrainListing from "../../components/TrainListing";

function Train() {
  const [searchResults, setSearchResults] = useState(null);

  return (
    <>
      <div>
        <div
          style={{ backgroundImage: `url(${TrainImg})` }}
          className="bg-cover bg-center bg-no-repeat h-80 md:h-[400px] w-full flex flex-col justify-center items-center text-white"
        >
          <div className="text-center mt-8">
            <div className="font-bold mb-2 scale-x-120">
              Safe and Enjoyable Journey.
            </div>
            <div className="text-3xl sm:text-4xl md:text-5xl font-sans md:font-serif font-bold transform scale-y-130">
              Trains
            </div>
          </div>
          <TrainBookingTabs
            onBookingSubmit={(data) => setSearchResults(data.searchResults)}
          />
        </div>
      </div>
      <div className="flex justify-center items-center mt-8">
        <div className="text-center text-2xl font-bold text-[#320D36]">
          <TrainListing searchResults={searchResults} />
        </div>
      </div>
      <Outlet />
    </>
  );
}

export default Train;
