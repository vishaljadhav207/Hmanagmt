import { Book } from "@mui/icons-material";
import React, { useState } from "react";
import FlightBookingTab from "../components/flightBookingTab";
import FlightListing from "../components/FlightListing";

function Flight() {
    const [searchResults, setSearchResults] = useState(null);
  return (
     <div>
      <FlightBookingTab onBookingSubmit={setSearchResults} />
      <FlightListing searchResults={searchResults} />
    </div>
  );
}

export default Flight;
