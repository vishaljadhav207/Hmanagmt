import { useState } from "react";
import aboutImg1 from "../assets/aboutImages/premium.jpg";
import aboutImg2 from "../assets/aboutImages/premium1.jpg";
import aboutImg3 from "../assets/aboutImages/premium3.jpg";
import aboutImg4 from "../assets/aboutImages/premium4.jpg";
import { Train, Hotel, Plane, Bus, Star, Users, MapPin, Shield, Award, Heart, CheckCircle, ArrowRight, Globe, Headphones, Waves, Leaf, Crown, Calendar, Phone, Mail, Navigation } from "lucide-react";

const Button = ({ children, className = "", variant = "default", size = "default", type = "button", onClick, ...props }) => (
  <button
    type={type}
    onClick={onClick}
    className={`inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed ${
      variant === "default" ? "bg-purple-600 text-white hover:bg-purple-700 focus:ring-purple-500" : 
      "border-2 border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-gray-500"
    } ${
      size === "default" ? "px-4 py-2 text-sm rounded-lg" : 
      size === "lg" ? "px-6 py-3 text-base rounded-xl" : 
      "px-3 py-1.5 text-xs rounded-md"
    } ${className}`}
    {...props}
  >
    {children}
  </button>
);

const Badge = ({ children, className = "" }) => (
  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${className}`}>
    {children}
  </span>
);

const Card = ({ children, className = "" }) => (
  <div className={`bg-white rounded-lg shadow-md ${className}`}>{children}</div>
);

const CardContent = ({ children, className = "" }) => (
  <div className={`p-6 ${className}`}>{children}</div>
);

const Input = ({ className = "", type = "text", placeholder, value, onChange, required = false, ...props }) => (
  <input
    type={type}
    placeholder={placeholder}
    value={value}
    onChange={onChange}
    required={required}
    className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent ${className}`}
    {...props}
  />
);

const About = () => {
  const [activeService, setActiveService] = useState("hotels");
  const [email, setEmail] = useState("");

  const content = {
    heroSection: {
      luxuryResort: "LUXURY RESORT",
      relaxInHotel: "Relax in our Hotel",
      welcomeMessage: "Welcome to <b>PRAKRITISTAY</b>, your gateway to the finest hotels worldwide. Whether you're planning a business trip, a family vacation, we make booking seamless. Discover exclusive deals, real-time availability, and trusted reviews—all in one place.",
      viewRooms: "View Rooms",
      bookYourStay: "Book Your Stay",
      roomsWithPool: "Rooms with private swimming pool",
      poolDescription: "Indulge in unparalleled opulence at <b>PRAKRITISTAY</b>, where exclusivity meets serenity. Each of our lavishly appointed suites features a private swimming pool, offering an intimate sanctuary surrounded by lush tropical landscapes or breathtaking ocean vistas.",
    },
    review: {
      text: "From the moment I arrived, <b>PRAKRITISTAY</b> redefined luxury for me. My private pool suite was an oasis of tranquility—every detail meticulously crafted for perfection.",
      author: "Michael Smith",
      role: "Client",
    },
    navbar: {
      home: "HOME", hotels: "HOTELS", aboutUs: "ABOUT US", history: "HISTORY", contact: "CONTACT", news: "NEWS", profile: "PROFILE", logout: "LOGOUT",
      hotel: "HOTEL", train: "TRAIN", flight: "FLIGHT", bus: "BUS",
    },
    footer: {
      travelPlatform: "Travel Platform",
      description: "Providing seamless travel bookings for a memorable experience.",
      rightsReserved: "© 2025 PrakritiStay. All rights reserved.",
      home: "Home", aboutUs: "About Us", hotels: "Hotels", contact: "Contact",
      subscribe: "Subscribe to our Newsletter",
      address: "Address: 481 Creekside Lane, Chhatrapati Sambhajinagar, Maharashtra, India",
      email: "Email: info@prakritistay.com",
      phone: "Phone: +91 53 345 7953 32453",
      poweredBy: "Powered by PrakritiStay - Connecting the World with Unforgettable Travel Experiences.",
    },
    newsletter: {
      title: "Join the PrakritiStay Newsletter",
      platform: "TRAVEL PLATFORM",
      description: {
        item1: "Be the first to know about new stays, travel deals, and seasonal offers.",
        item2: "Exclusive access to our latest news and updates from PrakritiStay.",
        item3: "Subscriber-only discounts, special packages, and complimentary upgrades.",
      },
      placeholder: "Your E-mail",
      subscribe: "Subscribe",
    },
  };

  const services = {
    hotels: {
      icon: Hotel, title: content.navbar.hotel, color: "bg-purple-600", bgColor: "bg-purple-50", textColor: "text-purple-700", borderColor: "border-purple-200",
      description: "Experience luxury redefined with our curated collection of premium hotels and resorts worldwide",
      features: ["Private Swimming Pools", "Luxury Suite Accommodations", "24/7 Concierge Service", "Exclusive Resort Access", "Spa & Wellness Centers", "Fine Dining Experiences"],
      stats: { bookings: "2M+", cities: "500+", rating: "4.9", savings: "40%" },
      image: aboutImg1, specialFeature: "Private Pool Suites", description2: content.heroSection.poolDescription,
    },
    trains: {
      icon: Train, title: content.navbar.train, color: "bg-purple-600", bgColor: "bg-violet-50", textColor: "text-purple-700", borderColor: "border-violet-200",
      description: "Journey across India in comfort with our premium train booking service and live tracking",
      features: ["Live Train Tracking", "Premium Class Booking", "Guaranteed Seat Reservation", "E-Ticket Generation", "Meal Preferences", "Travel Insurance"],
      stats: { bookings: "5M+", cities: "800+", rating: "4.7", savings: "25%" },
      image: aboutImg3, specialFeature: "Luxury Train Travel",
      description2: "Experience the romance of rail travel with our premium train services, featuring comfortable berths, gourmet meals, and scenic routes across India's diverse landscapes.",
    },
    flights: {
      icon: Plane, title: content.navbar.flight, color: "bg-purple-600", bgColor: "bg-indigo-50", textColor: "text-purple-700", borderColor: "border-indigo-200",
      description: "Soar to new heights with our comprehensive flight booking service to 500+ destinations",
      features: ["Global Destinations", "Business Class Upgrades", "Flexible Date Search", "Seat Selection", "Priority Check-in", "Miles Rewards Program"],
      stats: { bookings: "3M+", cities: "500+", rating: "4.6", savings: "35%" },
      image: aboutImg2, specialFeature: "Premium Flight Experience",
      description2: "Elevate your journey with our premium flight services, offering seamless booking, exclusive lounges, and personalized travel assistance for the discerning traveler.",
    },
    buses: {
      icon: Bus, title: content.navbar.bus, color: "bg-purple-600", bgColor: "bg-fuchsia-50", textColor: "text-purple-700", borderColor: "border-fuchsia-200",
      description: "Travel in comfort and style with our premium bus services and live GPS tracking",
      features: ["Luxury Coach Services", "Live GPS Tracking", "Reclining Seats", "Onboard Entertainment", "Safety Assured", "Multiple Routes"],
      stats: { bookings: "1.5M+", cities: "200+", rating: "4.5", savings: "30%" },
      image: aboutImg4, specialFeature: "Premium Bus Travel",
      description2: "Experience comfort on wheels with our luxury bus services, featuring spacious seating, entertainment systems, and professional drivers for a safe journey.",
    },
  };

  const companyStats = [
    { icon: Users, label: "Happy Travelers", value: "10M+", color: "text-purple-600" },
    { icon: MapPin, label: "Destinations", value: "500+", color: "text-purple-600" },
    { icon: Award, label: "Years Excellence", value: "15+", color: "text-purple-600" },
    { icon: Star, label: "Average Rating", value: "4.8", color: "text-purple-600" },
  ];

  const whyChooseUs = [
    { icon: Crown, title: "Luxury Redefined", description: "Experience unparalleled luxury with our curated selection of premium accommodations and services", color: "text-purple-600" },
    { icon: Shield, title: "Trusted & Secure", description: "Your bookings and payments are protected with enterprise-grade security and encryption", color: "text-purple-600" },
    { icon: Leaf, title: "Nature Connected", description: "Stay connected with nature through our eco-friendly properties and sustainable travel options", color: "text-purple-600" },
    { icon: Headphones, title: "24/7 Concierge", description: "Round-the-clock personalized assistance to make your travel experience seamless and memorable", color: "text-purple-600" },
  ];

  const currentService = services[activeService];
  const ServiceIcon = currentService.icon;

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    console.log("Newsletter subscription:", email);
    setEmail("");
  };

  const renderHTML = (html) => ({
    __html: html.replace(/<b>/g, '<strong class="text-white font-bold">').replace(/<\/b>/g, "</strong>")
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-purple-900 via-purple-800 to-violet-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-20 w-48 h-48 bg-purple-400/20 rounded-full blur-2xl"></div>
          <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-violet-300/30 rounded-full blur-lg"></div>
        </div>

        <div className="relative container mx-auto px-6 py-15">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="bg-purple-500/20 text-purple-100 border border-purple-400/30 mb-6 px-6 py-3 text-lg">
                <Leaf className="w-5 h-5 mr-2" />
                {content.heroSection.luxuryResort}
              </Badge>
              <h1 className="text-6xl md:text-7xl font-bold mb-8 leading-tight">
                <span className="bg-gradient-to-r from-purple-200 to-violet-200 bg-clip-text text-transparent">
                  PRAKRITISTAY
                </span>
              </h1>
              <h2 className="text-3xl md:text-4xl font-semibold mb-8 text-purple-100">
                {content.heroSection.relaxInHotel}
              </h2>
              <div className="text-xl md:text-2xl mb-12 text-purple-50 leading-relaxed max-w-4xl mx-auto" dangerouslySetInnerHTML={renderHTML(content.heroSection.welcomeMessage)} />
              <div className="flex flex-wrap justify-center gap-6">
                <Button size="lg" className="border-2 border-white text-white hover:bg-white/10 px-10 py-4 text-lg font-semibold">
                  <Hotel className="w-6 h-6 mr-3" />
                  {content.heroSection.viewRooms}
                </Button>
                <Button size="lg" className="border-2 border-white text-white hover:bg-white/10 px-10 py-4 text-lg font-semibold">
                  <Calendar className="w-6 h-6 mr-3" />
                  {content.heroSection.bookYourStay}
                </Button>
              </div>
            </div>

            {/* Pool Feature Highlight */}
            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 mt-16 border border-white/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-purple-500 rounded-2xl flex items-center justify-center">
                  <Waves className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{content.heroSection.roomsWithPool}</h3>
                  <p className="text-purple-100">Exclusive luxury experience</p>
                </div>
              </div>
              <div className="text-lg text-purple-50 leading-relaxed" dangerouslySetInnerHTML={renderHTML(content.heroSection.poolDescription)} />
            </div>
          </div>
        </div>
      </div>

      {/* Company Stats */}
      <div className="bg-white py-16 -mt-12 mx-6 rounded-3xl shadow-2xl relative z-10">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {companyStats.map((stat, index) => {
              const StatIcon = stat.icon;
              return (
                <div key={index} className="text-center group">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gray-50 mb-6 group-hover:scale-110 transition-transform duration-300">
                    <StatIcon className={`w-10 h-10 ${stat.color}`} />
                  </div>
                  <div className="text-4xl font-bold text-gray-900 mb-3">{stat.value}</div>
                  <div className="text-gray-600 font-medium text-lg">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <Badge className="bg-purple-600 text-white mb-6 px-6 py-3 text-lg">
              <Globe className="w-5 h-5 mr-2" />
              {content.footer.travelPlatform}
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">Complete Travel Solutions</h2>
            <p className="text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed">{content.footer.description}</p>
          </div>

          {/* Service Navigation */}
          <div className="flex flex-wrap justify-center gap-6 mb-16">
            {Object.entries(services).map(([key, service]) => {
              const ServiceTabIcon = service.icon;
              return (
                <button
                  key={key}
                  onClick={() => setActiveService(key)}
                  className={`flex items-center gap-4 px-8 py-5 rounded-2xl font-bold text-lg transition-all duration-300 transform ${
                    activeService === key
                      ? `${service.color} text-white shadow-2xl scale-105`
                      : "bg-white text-gray-600 hover:bg-gray-50 border-2 border-gray-200 hover:border-gray-300 hover:scale-102 shadow-md"
                  }`}
                >
                  <ServiceTabIcon className="w-6 h-6" />
                  {service.title}
                </button>
              );
            })}
          </div>

          {/* Active Service Details */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="grid lg:grid-cols-2 gap-0">
              {/* Service Info */}
              <div className="p-15 lg:p-16">
                <div className="flex items-center gap-6 mb-8">
                  <div className={`w-20 h-20 ${currentService.color} rounded-3xl flex items-center justify-center shadow-lg`}>
                    <ServiceIcon className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h3 className="text-4xl font-bold text-gray-900">{currentService.title}</h3>
                    <div className="flex items-center gap-3 mt-3">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <span className="font-bold text-gray-700 text-lg">{currentService.stats.rating}</span>
                      <span className="text-gray-500">• {currentService.stats.bookings} bookings</span>
                    </div>
                  </div>
                </div>

                <p className="text-xl text-gray-600 mb-10 leading-relaxed">{currentService.description}</p>

                {/* Special Feature */}
                <div className={`${currentService.bgColor} rounded-2xl p-6 mb-10`}>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">{currentService.specialFeature}</h4>
                  <p className={`${currentService.textColor} leading-relaxed`}>{currentService.description2}</p>
                </div>

                {/* Features Grid */}
                <div className="mb-10">
                  <h4 className="text-2xl font-bold text-gray-900 mb-6">Premium Features</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {currentService.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                        <CheckCircle className={`w-6 h-6 ${currentService.textColor} flex-shrink-0`} />
                        <span className="text-gray-700 font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-6 mb-10">
                  <div className={`${currentService.bgColor} rounded-2xl p-6 text-center`}>
                    <div className="text-3xl font-bold text-gray-900 mb-2">{currentService.stats.cities}</div>
                    <div className={`text-sm ${currentService.textColor} font-semibold uppercase tracking-wide`}>
                      Destinations
                    </div>
                  </div>
                  <div className={`${currentService.bgColor} rounded-2xl p-6 text-center`}>
                    <div className="text-3xl font-bold text-gray-900 mb-2">Up to {currentService.stats.savings}</div>
                    <div className={`text-sm ${currentService.textColor} font-semibold uppercase tracking-wide`}>
                      Savings
                    </div>
                  </div>
                </div>

                <Button className={`${currentService.color} hover:opacity-90 text-white px-10 py-4 text-xl w-full font-semibold`}>
                  Book {currentService.title} Now
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Button>
              </div>

              {/* Service Image */}
              <div className="relative bg-gradient-to-br from-gray-100 to-gray-200 min-h-[500px] lg:min-h-[800px]">
                <img src={currentService?.image} alt={currentService.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                <div className="absolute bottom-8 left-8 right-8">
                  <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm text-gray-600 mb-1">Premium Experience from</div>
                        <div className="text-3xl font-bold text-gray-900">₹2,999</div>
                      </div>
                      <Badge className={`${currentService.bgColor} ${currentService.textColor} px-4 py-2 text-sm font-semibold`}>
                        <Crown className="w-4 h-4 mr-2" />
                        Luxury Choice
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Us */}
      <div className="bg-gradient-to-br from-purple-50 to-violet-50 py-15">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <Badge className="bg-purple-600 text-white mb-6 px-6 py-3 text-lg">
              <Award className="w-5 h-5 mr-2" />
              Why Choose PrakritiStay
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">Excellence in Every Journey</h2>
            <p className="text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              Experience the perfect blend of luxury, nature, and technology
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => {
              const ItemIcon = item.icon;
              return (
                <Card key={index} className="shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-4 bg-white">
                  <CardContent className="p-10 text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg">
                      <ItemIcon className={`w-10 h-10 ${item.color}`} />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-6">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed text-lg">{item.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="py-10 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <Badge className="bg-yellow-100 text-yellow-700 mb-6 px-6 py-3 text-lg">
              <Heart className="w-5 h-5 mr-2" />
              Client Testimonials
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-900 mb-8">Stories of Excellence</h2>
            <p className="text-2xl text-gray-600 max-w-3xl mx-auto justify-center">
              Hear from our valued clients about their unforgettable experiences
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-10">
            {(( index) => (
              <Card key={index} className="shadow-xl bg-white hover:shadow-2xl transition-all duration-300">
                <CardContent className="p-10">
                  <div className="flex items-center justify-between">
                    <div></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Newsletter Section */}
      <div className="bg-gradient-to-r from-purple-800 via-purple-700 to-violet-800 text-white py-10">
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto text-center">
            <Badge className="bg-white/20 text-white mb-6 px-6 py-3 text-lg">
              <Mail className="w-5 h-5 mr-2" />
              {content.newsletter.platform}
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold mb-8">{content.newsletter.title}</h2>

            <div className="grid md:grid-cols-3 gap-8 mb-12 text-left">
              {[content.newsletter.description.item1, content.newsletter.description.item2, content.newsletter.description.item3].map((item, i) => (
                <div key={i} className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
                  <CheckCircle className="w-8 h-8 text-purple-200 mb-4" />
                  <p className="text-purple-100 leading-relaxed">{item}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
              <Input
                type="email"
                placeholder={content.newsletter.placeholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-6 py-4 text-lg bg-white/10 border-white/30 text-white placeholder:text-purple-200 rounded-xl"
                required
              />
              <Button type="submit" size="lg" className="bg-purple text-purple-700 hover:bg-purple-50 px-8 py-4 text-lg font-semibold rounded-xl">
                {content.newsletter.subscribe}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-purple-900 text-white py-10">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            {/* Brand Section */}
            <div className="md:col-span-2">
              <h3 className="text-3xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-violet-400 bg-clip-text text-transparent">
                PRAKRITISTAY
              </h3>
              <p className="text-gray-300 mb-6 text-lg leading-relaxed">{content.footer.description}</p>
              <div className="space-y-3">
                {[
                  { icon: Navigation, text: content.footer.address },
                  { icon: Mail, text: content.footer.email },
                  { icon: Phone, text: content.footer.phone }
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-purple-400" />
                    <span className="text-gray-300">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-xl font-bold mb-6">Quick Links</h4>
              <div className="space-y-3">
                {[content.footer.home, content.footer.aboutUs, content.footer.hotels, content.footer.contact].map((link, i) => (
                  <div key={i}>
                    <a href="#" className="text-gray-300 hover:text-purple-400 transition-colors text-lg">
                      {link}
                    </a>
                  </div>
                ))}
              </div>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-xl font-bold mb-6">Our Services</h4>
              <div className="space-y-3">
                {Object.values(services).map((service, i) => (
                  <div key={i}>
                    <a href="#" className="text-gray-300 hover:text-purple-400 transition-colors text-lg flex items-center gap-2">
                      <service.icon className="w-4 h-4" />
                      {service.title}
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-purple-700 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400">{content.footer.rightsReserved}</p>
              <p className="text-gray-400 text-center">{content.footer.poweredBy}</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;