import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { submitContact } from "../app/userApi";
import { resetMessage } from "../redux/userSlice";
import { Typography } from "@material-tailwind/react";
import InputField from "../components/InputField";
import AppButton from "../components/AppButton";
import Newsletter from "../components/Newsletter";

export function Contact() {
  const dispatch = useDispatch();
  const [contactData, setContactData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const { loading, error, message } = useSelector((state) => state.user);

  // Clear any existing messages when component mounts
  useEffect(() => {
    dispatch(resetMessage());
  }, [dispatch]);

  const handleInputChange = (e) => {
    setContactData({
      ...contactData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormSubmitted(true);

    // Validate all fields are filled
    const isFormValid = Object.values(contactData).every(
      (value) => value.trim() !== ""
    );

    if (!isFormValid) {
      return;
    }

    dispatch(submitContact(contactData)).then(() => {
      setContactData({
        name: "",
        email: "",
        subject: "",
        message: "",
      });
      setTimeout(() => {
        dispatch(resetMessage());
        setFormSubmitted(false);
      }, 3000);
    });
  };

  return (
    <div>
      <section className="flex flex-col w-full h-full py-20 bg-white-100">
        <div className="flex flex-col lg:flex-row space-y-8 lg:space-y-0 lg:space-x-10 justify-center px-4">
          {/* Left Column - Contact Info */}
          <div className="w-full lg:w-1/3 max-w-md">
            <Typography className="font-mono text-gray-500 text-left">
              HOTEL
            </Typography>
            <Typography
              className="text-left font-serif mb-2"
              color="black-light"
              variant="h2"
            >
              Say Hello
            </Typography>
            <Typography className="text-left mt-4 font-normal !text-lg !text-gray-500">
              We'd love to hear from you! Whether you're looking for more
              information or need assistance with your bookings, our team is
              ready to help. Get in touch with us using the form below, and we
              will get back to you as soon as possible.
            </Typography>
            <Typography className="text-left mt-10 font-normal !text-lg !text-gray-500">
              481 Creekside Lane, Chhatrapati Sambhajinagar City, Maharashtra,
              India
            </Typography>
            <Typography className="text-left mt-1 font-mono !text-lg !text-gray-500">
              +53 345 7953 32453
            </Typography>
            <Typography className="text-left mt-1 font-normal !text-lg !text-gray-500">
              info@prakritistay.com
            </Typography>
          </div>

          {/* Right Column - Contact Form */}
          <div className="w-full lg:w-1/3 max-w-lg">
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <InputField
                type="text"
                placeholder="Your Name"
                name="name"
                value={contactData.name}
                onChange={handleInputChange}
                required
                className="w-full"
                error={formSubmitted && !contactData.name.trim()}
                errorMessage="Name is required"
              />

              <InputField
                type="email"
                placeholder="Your Email"
                name="email"
                value={contactData.email}
                onChange={handleInputChange}
                required
                className="w-full"
                error={formSubmitted && !contactData.email.trim()}
                errorMessage="Valid email is required"
              />

              <InputField
                type="text"
                placeholder="Subject"
                name="subject"
                value={contactData.subject}
                onChange={handleInputChange}
                required
                className="w-full"
                error={formSubmitted && !contactData.subject.trim()}
                errorMessage="Subject is required"
              />

              <InputField
                type="textarea"
                placeholder="Message"
                name="message"
                value={contactData.message}
                onChange={handleInputChange}
                required
                className="w-full"
                rows={5}
                error={formSubmitted && !contactData.message.trim()}
                errorMessage="Message is required"
              />

              <AppButton
                className="w-full"
                color="gray"
                type="submit"
                title={loading ? "Submitting..." : "Submit"}
                disabled={loading}
              />
            </form>

            {/* Form Feedback Messages */}
            {message && (
              <div className="mt-4 p-3 bg-green-100 text-green-700 rounded-lg">
                {message}
              </div>
            )}
            {error && (
              <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-lg">
                {error}
              </div>
            )}
          </div>
        </div>
      </section>
      <Newsletter />
    </div>
  );
}

export default Contact;
