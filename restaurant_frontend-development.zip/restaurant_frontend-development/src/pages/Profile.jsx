import React, { useState, useEffect } from "react";
import profileimage from "../assets/profileimage.png";
import InputField from "../components/InputField";
import AppButton from "../components/AppButton";
import axiosInstance from "../app/axiosInstance";
import { useSelector } from "react-redux";

const Profile = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [profileImage, setProfileImage] = useState(profileimage);

  const [isEditing, setIsEditing] = useState(false);

  const [errors, setErrors] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
  });

  const [fetchError, setFetchError] = useState(null);
  const [updateError, setUpdateError] = useState(null);

  const { userInfo } = useSelector((state) => state.user);
  console.log('userInfo: ', userInfo);

  const fetchProfileData = async () => {
    console.log("userInfo?.userId: ", userInfo?.id);
    try {
      const response = await axiosInstance.get(
        `user/users/${userInfo?.id}`
      );

      const { firstName, lastName, email, mobile } = response.data;
      console.log("response.data: ", response.data);
      setFirstName(firstName);
      setLastName(lastName);
      setEmail(email);
      setPhoneNumber(mobile);
    } catch (error) {
      console.error("Error fetching profile data:", error);
      setFetchError("Failed to fetch profile data. Please try again later.");
    }
  };

  useEffect(() => {
    
    fetchProfileData();
  }, [userInfo?.id]);

  const handleEditProfile = () => {
    setIsEditing(true);
  };

  const handleProfileImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file));
    }
  };

  const handleUpdateProfile = async () => {
    const newErrors = {
      firstName: firstName ? "" : "First Name is required",
      lastName: lastName ? "" : "Last Name is required",
      phoneNumber: phoneNumber ? "" : "Phone Number is required",
    };

    setErrors(newErrors);

    if (newErrors.firstName || newErrors.lastName || newErrors.phoneNumber) {
      return;
    }

    const updatedProfile = {
      firstName,
      lastName,
      email,
      mobile: phoneNumber,
    };

    try {
      const response = await axiosInstance.put(
        `user/updateUser/${userInfo?.id}`,
        updatedProfile
      );
      console.log("Profile updated successfully:", response.data);
      console.log("response: ", response);

      if (response.data.status === "NOT_FOUND") {
        setUpdateError("User not found. Please check the user ID.");
        return;
      }

      
      fetchProfileData();

      setIsEditing(false); 
    } catch (error) {
      console.error("Error updating profile:", error);
      setUpdateError("Failed to update profile. Please try again later.");
    }
  };

  return (
    <div>
      <section className="py-10 my-auto dark:bg-gray-900 mt-0">
        <div className="lg:w-[80%] md:w-[90%] w-[96%] mx-auto flex gap-4">
          <div className="lg:w-[88%] sm:w-[88%] w-full mx-auto shadow-2xl p-4 rounded-xl h-fit self-center dark:bg-gray-800/40">
            <div>
              <h1 className="lg:text-3xl md:text-2xl text-xl font-serif font-extrabold mb-2 dark:text-white text-center">
                Hello, {firstName}!
              </h1>

              {fetchError && (
                <p className="text-red-500 text-center">{fetchError}</p>
              )}

              {updateError && (
                <p className="text-red-500 text-center">{updateError}</p>
              )}

              <div className="w-full rounded-sm bg-cover bg-center bg-no-repeat items-center">
                <div className="mx-auto flex justify-center w-[141px] h-[141px] bg-blue-300/20 rounded-full">
                  {isEditing ? (
                    <>
                      <input
                        type="file"
                        name="profile"
                        id="upload_profile"
                        hidden
                        onChange={handleProfileImageChange}
                      />
                      <label htmlFor="upload_profile">
                        <div className="relative">
                          <img
                            src={profileImage}
                            alt="Profile"
                            className="rounded-full w-36 h-36 object-cover"
                          />
                        </div>
                      </label>
                    </>
                  ) : (
                    <img
                      src={profileImage}
                      alt="Profile"
                      className="rounded-full w-36 h-36 object-cover"
                    />
                  )}
                </div>
              </div>

              <h2 className="text-center mt-1 font-semibold dark:text-gray-300">
                Upload Profile
              </h2>

              <div className="flex flex-col lg:flex-row gap-4 justify-center w-full">
                <div className="w-full mb-4 mt-6 lg:w-1/2">
                  <h4 className="mb-2 dark:text-gray-300">First Name</h4>
                  {isEditing ? (
                    <InputField
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                      className="w-full p-2 !border !border-gray-300 rounded mt-1"
                    />
                  ) : (
                    <h3 className="w-full h-10 p-2 border border-gray-300 rounded mt-1">
                      {firstName}
                    </h3>
                  )}
                  {errors.firstName && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.firstName}
                    </p>
                  )}
                </div>

                <div className="w-full mb-4 mt-6 lg:w-1/2">
                  <h4 className="mb-2 dark:text-gray-300">Last Name</h4>
                  {isEditing ? (
                    <InputField
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      required
                      className="w-full p-2 !border !border-gray-300 rounded mt-1"
                    />
                  ) : (
                    <h3 className="w-full h-10 p-2 border border-gray-300 rounded mt-1">
                      {lastName}
                    </h3>
                  )}
                  {errors.lastName && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.lastName}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex flex-col lg:flex-row gap-4 justify-center w-full">
                <div className="w-full mb-4 mt-6 lg:w-1/2">
                  <h3 className="mb-2 dark:text-gray-300">Email</h3>
                  <div className="w-full h-10 p-2 border border-gray-300 rounded mt-1">
                    {email}
                  </div>
                  {isEditing && (
                    <p className="text-sm text-red-500 mt-1">
                      You cannot change your email address.
                    </p>
                  )}
                </div>

                <div className="w-full mb-4 mt-6 lg:w-1/2">
                  <h4 className="mb-2 dark:text-gray-300">Phone Number</h4>
                  {isEditing ? (
                    <InputField
                      type="text"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                      className="w-full p-2 !border !border-gray-300 rounded mt-1"
                      style={{ borderBottom: "none" }}
                    />
                  ) : (
                    <h3 className="w-full h-10 p-2 !border !border-gray-300 rounded mt-1">
                      {phoneNumber}
                    </h3>
                  )}
                  {errors.phoneNumber && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.phoneNumber}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex justify-center gap-4 mt-6">
                <AppButton
                  onClick={isEditing ? handleUpdateProfile : handleEditProfile}
                  className="bg-fuchsia-950 text-white py-2 px-6 rounded-lg font-semibold hover:bg-[#d6baa0]"
                  title={isEditing ? "Update Profile" : "Edit Profile"}
                >
                  {isEditing ? "Update Profile" : "Edit Profile"}
                </AppButton>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Profile;
