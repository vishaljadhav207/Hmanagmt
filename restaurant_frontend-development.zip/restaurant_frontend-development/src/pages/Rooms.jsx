import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  Typography,
} from "@material-tailwind/react";
import AppButton from "../components/AppButton";
import { useNavigate } from "react-router-dom";
import { setSelectedRoomId, setPage, setPageSize } from "../redux/roomSlice";
import "react-toastify/dist/ReactToastify.css";
import { fetchHotels, getAllHotels } from "../app/hotelApi";
import axiosInstance from "../app/axiosInstance";

const Rooms = ({ bookingData }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { hotels, status, error, currentPage, pageSize } = useSelector(
    (state) => state.hotels
  );

  const [expandedRoomIds, setExpandedRoomIds] = useState([]);
  const [imageUrls, setImageUrls] = useState({});

  useEffect(() => {
    dispatch(
      getAllHotels({
        city: "",
        page: currentPage,
        size: pageSize,
      })
    );
  }, [dispatch, currentPage, pageSize]);

  const fetchImage = async (hotelId) => {
    try {
      const response = await axiosInstance.get(
        `images/getImageById/${hotelId}`,
        {
          responseType: "blob",
        }
      );
      const imageUrl = URL.createObjectURL(response.data);
      setImageUrls((prev) => ({ ...prev, [hotelId]: imageUrl }));
    } catch (error) {
      console.error("Error fetching image:", error);
      setImageUrls((prev) => ({
        ...prev,
        [hotelId]: "/placeholder-image.jpg",
      }));
    }
  };

  useEffect(() => {
    if (hotels && hotels.length > 0) {
      hotels.forEach((hotel) => {
        if (!imageUrls[hotel.hotelId]) {
          fetchImage(hotel.hotelId);
        }
      });
    }
  }, [hotels]);

  useEffect(() => {
    if (bookingData?.selectedCity) {
      dispatch(
        fetchHotels({
          city: bookingData?.selectedCity,
          page: currentPage,
          size: pageSize,
        })
      );
    }
  }, [dispatch, bookingData, currentPage, pageSize]);

  const handleBookNow = (hotelId) => {
    dispatch(setSelectedRoomId(hotelId));
    navigate(`/room-details/${hotelId}`);
  };

  const toggleReadMore = (hotelId) => {
    setExpandedRoomIds((prev) =>
      prev.includes(hotelId)
        ? prev.filter((id) => id !== hotelId)
        : [...prev, hotelId]
    );
  };

  const handlePageChange = (newPage) => {
    dispatch(setPage(newPage));
  };

  const handlePageSizeChange = (newSize) => {
    dispatch(setPageSize(newSize));
  };

  return (
    <div className="mt-10">
      <div className="section_title_container text-center">
        <Typography className="font-mono">LUXURY RESORT</Typography>
        <div className="section_title">
          <Typography
            className="font-serif mb-2"
            color="blue-gray"
            variant="h2"
          >
            Choose a Hotel
          </Typography>
        </div>
      </div>
      <div className="flex justify-center flex-wrap gap-10">
        {status === "loading" && (
          <div className="flex justify-center items-center w-full">
            <svg
              className="animate-spin h-10 w-10 text-[#5A2360]"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
          </div>
        )}
        {hotels && hotels.length > 0 ? (
          hotels.map((room) => (
            <Card
              key={room.hotelId}
              className="mt-6 w-96 rounded-lg shadow-2xl flex flex-col justify-between"
            >
              <CardHeader color="blue-gray" className="relative h-56">
                <img
                  src={imageUrls[room.hotelId] || "/placeholder-image.jpg"}
                  alt={`room ${room.hotelId}`}
                  className="w-full h-full object-cover rounded-t-lg"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "/placeholder-image.jpg";
                  }}
                />
                <div className="absolute bottom-0 left-0 bg-[#5A2360] bg-opacity-50 w-full text-white text-center py-2">
                  <Typography variant="h4" className="text-xl font-bold">
                    {room?.hotelName || "Unknown Hotel"}
                  </Typography>
                </div>
              </CardHeader>
              <CardBody className="p-6 flex-grow">
                <div className="room_content text-center">
                  <div className="room_text text-left mt-4">
                    <p className="text-gray-700 font-bold">
                      Address:{" "}
                      <span className="font-normal">
                        {room?.hotelAdd || "Unknown Address"},
                        {room?.city || "Unknown City"}
                      </span>
                    </p>
                    <p className="text-gray-700 mt-2">
                      {expandedRoomIds.includes(room.hotelId)
                        ? room?.hotelDes || "No description available."
                        : `${(room?.hotelDes || "No description available.")
                            .split(" ")
                            .slice(0, 20)
                            .join(" ")}...`}
                      <button
                        onClick={() => toggleReadMore(room.hotelId)}
                        className="text-blue-500 ml-2"
                      >
                        {expandedRoomIds.includes(room.hotelId)
                          ? "Read less"
                          : "Read more"}
                      </button>
                    </p>
                    <p className="text-gray-700 mt-2 font-bold">
                      Amenities:{" "}
                      <span className="font-normal">
                        {room?.amenities
                          ? room.amenities.map((a) => a.amenityName).join(", ")
                          : "No amenities available."}
                      </span>
                    </p>
                    <p className="text-gray-700 mt-2 font-bold">
                      Rating:{" "}
                      <span className="font-normal text-yellow-500">
                        {room?.hotelRatings ? (
                          <>
                            {Array.from({ length: 5 }, (_, index) => (
                              <span key={index}>
                                {index < Math.floor(room.hotelRatings)
                                  ? "★"
                                  : "☆"}
                              </span>
                            ))}
                          </>
                        ) : (
                          "No rating yet"
                        )}
                      </span>
                    </p>
                  </div>
                </div>
              </CardBody>
              <CardFooter className="pt-0 ">
                <AppButton
                  onClick={() => handleBookNow(room.hotelId)}
                  className="rounded-none w-full bg-[#5A2360] text-white py-2 hover:bg-purple-600 transition-colors duration-300"
                  title="Book now"
                ></AppButton>
              </CardFooter>
            </Card>
          ))
        ) : (
          <p className="text-center text-gray-500">
            {status === "succeeded"
              ? "No rooms available matching your criteria."
              : "No rooms available."}
          </p>
        )}
      </div>
    </div>
  );
};

export default Rooms;
