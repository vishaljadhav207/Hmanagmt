import React, { useEffect } from "react";
import { Button } from "@material-tailwind/react";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import InputField from "../components/InputField";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { changePassword } from "../app/userApi";
import Swal from "sweetalert2";
import { FaEye, FaEyeSlash } from "react-icons/fa";

const ResetPassword = () => {
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [newpassword, setNewPassword] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email;

  const { passwordChangeStatus } = useSelector((state) => state.user);
  useEffect(() => {
    if (
      passwordChangeStatus &&
      passwordChangeStatus?.data?.statusCode === 200
    ) {
      navigate("/");
    }
  }, [passwordChangeStatus]);

  const submit = (e) => {
    e.preventDefault();
    if (!newpassword && !password) {
      setError("Both password must required");
      return;
    }
    if (newpassword !== password) {
      setError("Password does not match");
      return;
    }
    if (email) {
      const payload = { password: newpassword, confirmPassword: password };
      dispatch(changePassword({ email, payload }));
    }
  };

  return (
    <div className="container mx-auto flex justify-center items-center min-h-screen">
      <div
        className="bg-white p-6 shadow-lg rounded-lg"
        style={{ width: "350px" }}
      >
        <h3 className="text-center text-xl font-semibold mb-4">
          Update Password
        </h3>
       
        <form onSubmit={submit}>
          <div className="mb-4">
            <div className="relative mt-5">
              <InputField
                value={newpassword}
                onChange={(e) => {
                  setError("");
                  
                  setNewPassword(e.target.value);
                }}
                placeholder="New Password"
                name="password"
                type={showPassword ? "text" : "password"}
                className="block w-full p-2 pr-10 !border !border-gray-300 rounded focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50"
              />
              <div
                className="absolute top-1/2 right-3 transform -translate-y-1/2 cursor-pointer text-gray-500"
                onClick={() => setShowPassword((prev) => !prev)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </div>
            </div>
          </div>
          <div className="mb-4">
            <div className="relative mt-5">
              <InputField
                value={password}
                onChange={(e) => {
                  setError("");
                  setPassword(e.target.value);
                }}
                placeholder="Confirmed Password"
                name="password"
                type={showNewPassword ? "text" : "password"}
                className="block w-full p-2 pr-10 !border !border-gray-300 rounded focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50"
              />
              <div
                className="absolute top-1/2 right-3 transform -translate-y-1/2 cursor-pointer text-gray-500"
                onClick={() => setShowNewPassword((prev) => !prev)}
              >
                {showNewPassword ? <FaEyeSlash /> : <FaEye />}
              </div>
            </div>
          </div>
          {error && (
          <div className="text-red-500 text-sm mb-3 text-center">{error}</div>
        )}
          <Button
            type="submit"
            className="w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
          >
            
            Reset Password
            
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ResetPassword;
