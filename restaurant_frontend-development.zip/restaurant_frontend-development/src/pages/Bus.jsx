import React, { useState } from "react";
import BusBookingTabs from "../components/BusBookingTabs";
import AllBus from "../components/AllBus";

function Bus() {
  const [searchResults, setSearchResults] = useState(null);

  return (
    <div>
      <BusBookingTabs
        onBookingSubmit={(data) => setSearchResults(data.searchResults)}
      />
      <AllBus searchResults={searchResults} />
    </div>
  );
}

export default Bus;
