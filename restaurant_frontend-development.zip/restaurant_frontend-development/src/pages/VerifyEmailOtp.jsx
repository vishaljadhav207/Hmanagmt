import React, { useEffect } from "react";
import { Button, useSelect } from "@material-tailwind/react";
import { useState } from "react";
import { useDispatch } from "react-redux";
import InputField from "../components/InputField";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { verifyEmail, verifyOtp } from "../app/userApi";
import { domainValidate, validateEmail } from "../utils";
import bgimg2 from "../assets/background2.jpg";
import { useSelector } from "react-redux";
import { FadeLoader, PropagateLoader } from "react-spinners";

const VerifyEmailOtp = () => {
  const [error, setError] = useState(false);
  const [otpError, setOtpError] = useState(false);
  const [otp, setOtp] = useState(null);

  const [showField, setShowField] = useState(false);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [submitRefereceState, setSubmitReferenceState] = useState(null);
  const { loading, emailVerificationStatus, verifyOtpStatus } = useSelector(
    (state) => state.user
  );

  const [email, setEmail] = useState(location.state?.email);

  useEffect(() => {
    if (
      emailVerificationStatus?.statusCode === 200 &&
      !loading &&
      submitRefereceState
    ) {
      setShowField(true);
    }
    setSubmitReferenceState(false);
  }, [submitRefereceState]);

  useEffect(() => {
    if (
      verifyOtpStatus?.statusCode === 200 &&
      !loading &&
      submitRefereceState
    ) {
      navigate(`/reset-password`, { state: { email } });
    } else if (verifyOtpStatus?.status === 500 && submitRefereceState) {
      setError("Invalid OTP");
    }
    setSubmitReferenceState(false);
  }, [submitRefereceState]);

  const handleVerifyOtp = async () => {
    if (!otp) {
      setOtpError(true);
    }
    if (otp) {
      setOtpError(false);
      try {
        await dispatch(verifyOtp({ otp, email }));
        setSubmitReferenceState(true);
      } catch (error) {
        setSubmitReferenceState(true);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(false);
    console.log("email: ", email);

    if (!email) {
      setError("Email must required");

      return;
    } else if (validateEmail(email)) {
      setError("Email format is invalid");

      return;
    } else if (domainValidate(email)) {
      setError(`Invalid email domain`);
      return;
    } else {
      setError(false);
      try {
        await dispatch(verifyEmail(email));
        setSubmitReferenceState(true);
      } catch (error) {
        setSubmitReferenceState(true);
      }
    }
  };
  return (
    <>
      {loading && (
        <div className="fixed inset-0 flex justify-center items-center z-50">
          <FadeLoader color="#1D4ED8" />
        </div>
      )}

      <div
        className={`container mx-auto flex justify-center items-center min-h-screen relative ${
          loading ? "blur-[1px]" : ""
        }`}
      >
        <div
          className="bg-white p-6 shadow-lg rounded-lg"
          style={{ width: "350px" }}
        >
          <img src={bgimg2} />
          {!showField && (
            <>
              <h3 className="text-center text-xl font-semibold mb-4">
                Verify Email
              </h3>

              <div className="pb-7">
                <InputField
                  value={email}
                  onChange={(e) => {
                    setError(false);
                    setEmail(e.target.value);
                  }}
                  placeholder="Enter Email"
                  name="Email"
                  error={error}
                />
              </div>

              <Button
                onClick={handleSubmit}
                type="button"
                className="w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
              >
                Verify
              </Button>
            </>
          )}
          {showField && (
            <div className="mb-4">
              <h3 className="text-center text-xl font-semibold mb-4">
                Verify OTP
              </h3>

              <div className="">
                <InputField
                  value={otp}
                  onChange={(e) => {
                    setOtpError(false);
                    setOtp(e.target.value);
                  }}
                  placeholder="Enter OTP"
                  name="OTP"
                  error={otpError && "OTP is required"}
                />
              </div>
              <p className="text-red-500 text-sm  h-4 mb-2">{error}</p>

              <Button
                onClick={handleVerifyOtp}
                type="button"
                className="w-full py-2 px-4 bg-[#5A2360] text-white rounded-md hover:bg-blue-600"
              >
                Verify
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default VerifyEmailOtp;
