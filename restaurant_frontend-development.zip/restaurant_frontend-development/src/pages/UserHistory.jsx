import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import HistoryItem from "../components/HistoryItem";
import { fetchUserHistory, addRating } from "../redux/userHistorySlice";
import Rating from "../components/Rating";

const UserHistory = () => {
  const dispatch = useDispatch();
  const { history = {}, status, error } = useSelector(
    (state) => state.history
  );

  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  useEffect(() => {
    if (userId && status === "idle") {
      dispatch(fetchUserHistory(userId));
    }
  }, [dispatch, status, userId]);

  const handlePopupSubmit = (rating) => {
    setIsPopupOpen(false);

    const ratingData = {
      bookingId: selectedItem.bookingId,
      userId: userId,
      rating: rating,
      comment: "",
    };

    dispatch(addRating(ratingData))
      .unwrap()
      .then(() => {
        setSelectedItem(null);
      })
      .catch((error) => {
        console.error("Error adding rating:", error);
      });
  };

  const handlePopupClose = () => {
    setIsPopupOpen(false);
    setSelectedItem(null);
  };

  if (status === "loading") {
    return <div>Loading...</div>;
  }

  if (status === "failed") {
    return (
      <div className="text-red-500 text-center py-8">
        Error: {error}
        <button
          onClick={() => dispatch(fetchUserHistory(userId))}
          className="ml-4 px-4 py-2 bg-blue-500 text-white rounded"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="w-full px-4 min-h-screen">
      <div className="space-y-6 mt-6">
        {Array.isArray(history.data) && history.data.length === 0 ? (
          <p className="text-center text-gray-500 py-8">
            No matching bookings found
          </p>
        ) : (
          Array.isArray(history.data) &&
          history.data.map((item) => (
            <div key={item.bookingId || item.userId} className="relative">
              <HistoryItem 
                item={item}
                isRatingPending={!item.rating}
                onRatingClick={() => {
                  if (!item.rating) {
                    setSelectedItem(item);
                    setIsPopupOpen(true);
                  }
                }}
              />
              {isPopupOpen && selectedItem?.bookingId === item.bookingId && (
                <div className="absolute inset-0 flex justify-center items-center">
                  <div className="bg-white p-4 rounded-lg shadow-lg z-10">
                    <Rating
                      isOpen={isPopupOpen}
                      onClose={handlePopupClose}
                      onSubmit={handlePopupSubmit}
                      selectedItem={selectedItem}
                    />
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default UserHistory;