import React from "react";
import Rooms from "./Rooms";
import HeroSection from "../components/HeroSection";
import Newsletter from "../components/Newsletter";
import { CarouselCustomNavigation } from "../components/CarouselCustomNavigation";
import TrainOffersCard from "../components/OfferCard";
import LanguageSwitcher from "../components/LanguageSwitcher";

const Home = () => {
  return (
    <div>
      {/* <HeroSection /> */}

      <TrainOffersCard />

      <CarouselCustomNavigation />
      <Rooms />
      <Newsletter />
    </div>
  );
};

export default Home;
