import React, { useState } from "react";
import BookingTabs from "../components/BookingTabs";
import Rooms from "./Rooms";
import RoomsImg from "../assets/rooms.jpg";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useLocation } from "react-router-dom";

function Hotel() {
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [bookingData, setBookingData] = useState(location.state || null);

  const handleBookingSubmit = (data) => {
    setIsLoading(true);
    setBookingData(data);
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div>
      <div
        style={{ backgroundImage: `url(${RoomsImg})` }}
        className="bg-cover bg-center bg-no-repeat h-80 md:h-[400px] w-full flex flex-col justify-center items-center text-white "
      >
        <div className="text-center mt-8">
          <div className="font-bold mb-2 scale-x-120">LUXURY RESORT</div>
          <div className="text-3xl sm:text-4xl md:text-5xl font-sans md:font-serif font-bold transform scale-y-130">
            Rooms
          </div>
        </div>

        <BookingTabs onBookingSubmit={handleBookingSubmit} />
      </div>

      <Rooms bookingData={bookingData} isLoading={isLoading} />
      <ToastContainer />
    </div>
  );
}

export default Hotel;