import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import {
  Typography,
  Card,
  CardHeader,
  CardBody,
  Button,
  Tabs,
  TabsHeader,
  Tab,
  Chip,
  IconButton,
  Tooltip,
  CardFooter,
} from "@material-tailwind/react";
import {
  TicketIcon,
  ArrowRightIcon,
  ArrowUpRightIcon,
  ArrowDownRightIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon as ClockOutlineIcon,
  ArrowPathIcon,
} from "@heroicons/react/24/solid";
import {
  BusIcon,
  PlaneIcon,
  TicketsIcon,
  TrainIcon,
  HotelIcon,
} from "lucide-react";
import travelAxios from "../app/travelAxios";
import UserHistory from "./UserHistory";
import Swal from "sweetalert2";

const History = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("hotel");
  const [cancelling, setCancelling] = useState(false);

  const { userInfo } = useSelector((state) => state.user);
  const userId = userInfo?.id;

  useEffect(() => {
    const fetchBookingHistory = async () => {
      try {
        setLoading(true);
        const response = await travelAxios.get(
          `ticket/bookingHistory/${userId}`
        );
        setBookings(response.data);
        setError(null);
      } catch (err) {
        setError(err.message || "Failed to fetch booking history");
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchBookingHistory();
    }
  }, [userId]);


  const filteredBookings = (type) => {
    if (type === "all")
      return bookings.filter((b) => b.transportType !== "HOTEL");
    if (type === "hotel")
      return bookings.filter((b) => b.transportType === "HOTEL");
    return bookings.filter((booking) => booking.transportType === type);
  };

  const getTransportIcon = (type) => {
    switch (type) {
      case "HOTEL":
        return <HotelIcon className="h-5 w-5 text-white" />;
      case "RAILWAY":
        return <TrainIcon className="h-5 w-5 text-white" />;
      case "BUS_OPERATOR":
        return <BusIcon className="h-5 w-5 text-white" />;
      case "AIRLINE":
        return <PlaneIcon className="h-5 w-5 text-white" />;
      default:
        return <TicketsIcon className="h-5 w-5 text-white" />;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "CONFIRM":
        return <CheckCircleIcon className="h-5 w-5 text-green-500" />;
      case "CANCELLED":
        return <XCircleIcon className="h-5 w-5 text-red-500" />;
      case "WAITING":
        return <ClockOutlineIcon className="h-5 w-5 text-yellow-500" />;
      default:
        return <ArrowPathIcon className="h-5 w-5 text-blue-500" />;
    }
  };

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  const getTransportColor = (type) => {
    switch (type) {
      case "HOTEL":
        return "bg-[#5A2360]";
      case "RAILWAY":
        return "bg-[#5A2360]";
      case "BUS_OPERATOR":
        return "bg-[#5A2360]";
      case "AIRLINE":
        return "bg-[#5A2360]";
      default:
        return "bg-[#5A2360]";
    }
  };

  const handleCancelTicket = async (ticket) => {
    try {
      const result = await Swal.fire({
        title: 'Are you sure?',
        text: "You want to cancel this ticket?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#5A2360',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Confirm Cancellation',
        cancelButtonText: 'Cancel',
        showLoaderOnConfirm: true,
        preConfirm: async () => {
          try {
            setCancelling(true);
            const response = await travelAxios.patch(
              `ticket/cancelTicket?ticketId=${ticket.ticketId}`
            );
            

            setBookings(bookings.map(booking => 
              booking.ticketId === ticket.ticketId 
                ? { 
                    ...booking, 
                    status: "CANCELLED",
                    cancellationFee: response.data.data.cancellationFee,
                    refundAmount: response.data.data.refundAmount
                  } 
                : booking
            ));
            
            return response.data;
          } catch (err) {
            Swal.showValidationMessage(
              `Failed to cancel ticket: ${err.response?.data?.message || err.message}`
            );
          } finally {
            setCancelling(false);
          }
        },
        allowOutsideClick: () => !Swal.isLoading()
      });

      if (result.isConfirmed) {
        Swal.fire({
          title: 'Ticket Cancelled!',
          html: `
            <div class="text-left">
              <p>Cancellation Fee: ₹${result.value.data.cancellationFee}</p>
              <p>Refund Amount: ₹${result.value.data.refundAmount}</p>
            </div>
          `,
          icon: 'success',
          confirmButtonColor: '#5A2360'
        });
      }
    } catch (err) {
      Swal.fire({
        title: 'Error!',
        text: err.message || 'Failed to cancel ticket',
        icon: 'error',
        confirmButtonColor: '#5A2360'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Typography variant="h5" className="text-[#081123]">
          Loading your booking history...
        </Typography>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-64">
        <Typography variant="h5" color="red">
          Error: {error}
        </Typography>
      </div>
    );
  }

  if (bookings.length === 0) {
    return (
      <div className="flex justify-center items-center h-64">
        <Typography variant="h5" className="text-[#081123]">
          No booking history found
        </Typography>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="bg-[#081123] rounded-xl shadow-md p-4 h-[85px] mt-[20px]">
          <Tabs value={activeTab}>
            <TabsHeader
              className="bg-transparent p-0 flex justify-center"
              indicatorProps={{
                className: "bg-[#5A2360] shadow-lg rounded-lg",
              }}
            >
              <Tab
                value="hotel"
                onClick={() => setActiveTab("hotel")}
                className={`py-3 px-8 mx-2 text-base font-semibold rounded-lg transition-all duration-200 ${
                  activeTab === "hotel"
                    ? "bg-[#5A2360] text-white shadow"
                    : "bg-gray-100 text-[#5A2360] hover:bg-[#5A2360]/10"
                }`}
              >
                <div className="flex items-center gap-2">
                  <HotelIcon className="h-5 w-5" />
                  Hotel
                </div>
              </Tab>
              <Tab
                value="RAILWAY"
                onClick={() => setActiveTab("RAILWAY")}
                className={`py-3 px-8 mx-2 text-base font-semibold rounded-lg transition-all duration-200 ${
                  activeTab === "RAILWAY"
                    ? "bg-[#5A2360] text-white shadow"
                    : "bg-gray-100 text-[#5A2360] hover:bg-[#5A2360]/10"
                }`}
              >
                <div className="flex items-center gap-2">
                  <TrainIcon className="h-5 w-5" />
                  Train
                </div>
              </Tab>
              <Tab
                value="BUS_OPERATOR"
                onClick={() => setActiveTab("BUS_OPERATOR")}
                className={`py-3 px-8 mx-2 text-base font-semibold rounded-lg transition-all duration-200 ${
                  activeTab === "BUS_OPERATOR"
                    ? "bg-[#5A2360] text-white shadow"
                    : "bg-gray-100 text-[#5A2360] hover:bg-[#5A2360]/10"
                }`}
              >
                <div className="flex items-center gap-2">
                  <BusIcon className="h-5 w-5" />
                  Bus
                </div>
              </Tab>
              <Tab
                value="AIRLINE"
                onClick={() => setActiveTab("AIRLINE")}
                className={`py-3 px-8 mx-2 text-base font-semibold rounded-lg transition-all duration-200 ${
                  activeTab === "AIRLINE"
                    ? "bg-[#5A2360] text-white shadow"
                    : "bg-gray-100 text-[#5A2360] hover:bg-[#5A2360]/10"
                }`}
              >
                <div className="flex items-center gap-2">
                  <PlaneIcon className="h-5 w-5" />
                  Flight
                </div>
              </Tab>
            </TabsHeader>
          </Tabs>
        </div>
        <Typography
          variant="h3"
          className="text-[#081123] font-bold text-center mt-[10px]"
        >
          Your Travel History
        </Typography>

        {(activeTab === "all" || activeTab === "hotel") && <UserHistory />}


        {["RAILWAY", "BUS_OPERATOR", "AIRLINE"].includes(activeTab) && (
          <div className="space-y-6">
            {filteredBookings(activeTab).map((booking) => (
              <Card
                key={booking.ticketId}
                className="hover:shadow-lg transition-shadow border border-gray-200 rounded-xl overflow-hidden"
              >
                <CardHeader
                  floated={false}
                  shadow={false}
                  className={`rounded-none ${getTransportColor(
                    booking.transportType
                  )} p-6`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <div
                        className={`p-3 rounded-full ${getTransportColor(
                          booking.transportType
                        )} flex items-center justify-center bg-white/10`}
                      >
                        {getTransportIcon(booking.transportType)}
                      </div>
                      <div>
                        <Typography
                          variant="h5"
                          color="white"
                          className="font-bold"
                        >
                          {booking.transportType === "RAILWAY" &&
                            "Train Ticket"}
                          {booking.transportType === "BUS_OPERATOR" &&
                            "Bus Ticket"}
                          {booking.transportType === "AIRLINE" &&
                            "Flight Ticket"}
                        </Typography>
                        <Typography
                          variant="small"
                          color="white"
                          className="opacity-80"
                        >
                          PNR: {booking.pnrNumber}
                        </Typography>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Chip
                        value={booking.status}
                        color={
                          booking.status === "CONFIRM"
                            ? "green"
                            : booking.status === "CANCELLED"
                            ? "red"
                            : "amber"
                        }
                        className="text-white font-medium"
                      />
                      {getStatusIcon(booking.status)}
                    </div>
                  </div>
                </CardHeader>

                <CardBody className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Journey Details */}
                    <div className="col-span-2">
                      <div className="flex justify-between items-center mb-6">
                        <Typography
                          variant="h5"
                          className="text-[#081123] font-semibold"
                        >
                          Journey Details
                        </Typography>
                        <Typography variant="small" color="gray">
                          Booked on: {formatDate(booking.bookingDate)}
                        </Typography>
                      </div>

                      <div className="flex items-center justify-between p-6 bg-[#081123]/5 rounded-xl">
                        <div className="text-center">
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            From
                          </Typography>
                          <Typography
                            variant="h4"
                            className="text-[#081123] font-bold"
                          >
                            {booking.boarding}
                          </Typography>
                        </div>
                        <div className="flex-1 px-4">
                          <div className="relative">
                            <div className="border-t-2 border-dashed border-[#5A2360]/50"></div>
                            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-white px-2">
                              <ArrowRightIcon className="h-5 w-5 text-[#5A2360]" />
                            </div>
                          </div>
                        </div>
                        <div className="text-center">
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            To
                          </Typography>
                          <Typography
                            variant="h4"
                            className="text-[#081123] font-bold"
                          >
                            {booking.departure}
                          </Typography>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-6 mt-6">
                        <div>
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            Journey Date
                          </Typography>
                          <Typography className="text-[#081123]">
                            {new Date(booking.journeyDate).toLocaleDateString(
                              "en-US",
                              {
                                weekday: "short",
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                              }
                            )}
                          </Typography>
                        </div>
                        <div>
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            Class Type
                          </Typography>
                          <Typography className="text-[#081123]">
                            {booking.classType}
                          </Typography>
                        </div>
                        <div>
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            Seat Preference
                          </Typography>
                          <Typography className="text-[#081123]">
                            {booking.seatPreference || "Standard"}
                          </Typography>
                        </div>
                        <div>
                          <Typography
                            variant="small"
                            color="blue-gray"
                            className="font-medium"
                          >
                            Total Fare
                          </Typography>
                          <Typography color="green" className="font-bold">
                            ₹{booking.totalFare}
                          </Typography>
                        </div>
                        {booking.status === "CANCELLED" && (
                          <>
                            <div>
                              <Typography
                                variant="small"
                                color="blue-gray"
                                className="font-medium"
                              >
                                Cancellation Fee
                              </Typography>
                              <Typography color="red" className="font-bold">
                                ₹{booking.cancellationFee || 0}
                              </Typography>
                            </div>
                            <div>
                              <Typography
                                variant="small"
                                color="blue-gray"
                                className="font-medium"
                              >
                                Refund Amount
                              </Typography>
                              <Typography color="green" className="font-bold">
                                ₹{booking.refundAmount || 0}
                              </Typography>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Passengers */}
                    <div>
                      <Typography
                        variant="h5"
                        className="mb-6 text-[#081123] font-semibold"
                      >
                        Passengers ({booking.passengerList.length || 0})
                      </Typography>

                      {booking.passengerList.length > 0 ? (
                        <div className="space-y-4">
                          {booking.passengerList.map((passenger, index) => (
                            <div
                              key={passenger.passengerId}
                              className="flex justify-between items-center p-4 bg-[#081123]/5 rounded-lg"
                            >
                              <div>
                                <Typography
                                  variant="h6"
                                  className="text-[#081123]"
                                >
                                  {passenger.name}
                                </Typography>
                                <div className="flex gap-4 mt-1">
                                  <Typography
                                    variant="small"
                                    className="text-[#081123]/80"
                                  >
                                    {passenger.age} yrs
                                  </Typography>
                                  <Typography
                                    variant="small"
                                    className="text-[#081123]/80"
                                  >
                                    {passenger.gender}
                                  </Typography>
                                </div>
                              </div>
                              <div className="text-right">
                                <Typography variant="small" color="blue-gray">
                                  Seat
                                </Typography>
                                <Typography className="text-[#081123] font-medium">
                                  {booking.seatNumber[index] ||
                                    "To be assigned"}
                                </Typography>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <Typography color="gray" className="italic">
                          No passenger details available
                        </Typography>
                      )}
                    </div>
                  </div>
                </CardBody>

                <CardFooter className="flex justify-end p-6 pt-0">
                  {booking.status === "CONFIRM" && (
                    <Button
                      variant="outlined"
                      color="red"
                      onClick={() => handleCancelTicket(booking)}
                      className="flex items-center gap-2"
                      disabled={cancelling}
                    >
                      {cancelling ? (
                        <>
                          <ArrowPathIcon className="h-5 w-5 animate-spin" />
                          Cancelling...
                        </>
                      ) : (
                        <>
                          <XCircleIcon className="h-5 w-5" />
                          Cancel Ticket
                        </>
                      )}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default History;