import { BrowserRouter } from "react-router-dom";
import "./App.css";
import Router from "./routers";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Router />
      </BrowserRouter>
    </div>
  );
}

export default App;