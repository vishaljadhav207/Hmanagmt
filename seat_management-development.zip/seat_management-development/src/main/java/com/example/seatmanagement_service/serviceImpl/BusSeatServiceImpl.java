package com.example.seatmanagement_service.serviceImpl;

import com.example.seatmanagement_service.client.BusInfoClient;
import com.example.seatmanagement_service.client.ClassTypeClient;
import com.example.seatmanagement_service.model.BusSeat;
import com.example.seatmanagement_service.repository.BusSeatRepository;
import com.example.seatmanagement_service.service.BusSeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.example.seatmanagement_service.model.BusSeat.Seat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BusSeatServiceImpl implements BusSeatService {

    private final BusSeatRepository busSeatRepository;
    private final BusInfoClient busInfoClient;
    private final ClassTypeClient classTypeClient;

    @Override
    public Optional<BusSeat> getSeatLayout(int busId, int classId) {
        return busSeatRepository.findByBusIdAndClassId(busId, classId);
    }

    @Override
    public BusSeat saveLayout(BusSeat busSeat) {
        return busSeatRepository.save(busSeat);
    }

    @Override
    public boolean updateSeatAvailability(int busId, int classId,  String seatNumber, boolean isAvailable) {
        Optional<BusSeat> optional = busSeatRepository.findByBusIdAndClassId(busId, classId);
        if (optional.isEmpty()) return false;

        BusSeat layout = optional.get();
        layout.getLayout().getSeatMap().forEach(seat -> {
            if (seat.getSeatNumber().equals(seatNumber)) {
                seat.setAvailable(isAvailable);
            }
        });

        busSeatRepository.save(layout);
        return true;
    }

    @Override
    public BusSeat createLayoutFromBusId(int busId, int classId, BusSeat.Layout layout,String token) {
        // Logger for debugging
        Logger logger = LoggerFactory.getLogger(getClass());

        // Get Bus Number by busId from BusInfoClient
        String busNo = busInfoClient.getBusNoByBusId(busId,token);
        if (busNo == null || busNo.isEmpty()) {
            logger.error("Bus number not found for busId: {}", busId);
            throw new IllegalArgumentException("Invalid busId: " + busId); // Handle as needed
        }

        // Get Class Name by classId from ClassTypeClient
        String className = classTypeClient.getClassNameById(classId,token);
        if (className == null || className.isEmpty()) {
            logger.error("Class name not found for classId: {}", classId);
            throw new IllegalArgumentException("Invalid classId: " + classId); // Handle as needed
        }

        logger.info("Creating BusSeat with busNo: {} and className: {}", busNo, className);

        // Build the BusSeat object
        BusSeat busSeat = BusSeat.builder()
                .busId(busId)
                .busNo(busNo)
                .classId(classId)
                .className(className)
                .layout(layout)
                .build();

        // Save and return the BusSeat object
        try {
            return busSeatRepository.save(busSeat);
        } catch (Exception e) {
            logger.error("Error saving BusSeat to repository: ", e);
            throw new RuntimeException("Failed to save BusSeat", e);
        }
    }

    @Override
    public List<Seat> SeatBooking( String seatPrefrence, String classType, String transportId,int passengers) {
       try {
           List<BusSeat> busSeat = busSeatRepository.findByBusNo(transportId);
           String waiting = "WL";
           for (BusSeat busSeat1 : busSeat) {
               if (busSeat1.getClassName().equalsIgnoreCase(classType)) {
                   List<BusSeat.Seat> BusSeat = busSeat1.getLayout().getSeatMap();
                   List<Seat> availableSeat = new ArrayList<>();
                   int seatAdded = 0 ;
                   for (Seat seat : BusSeat) {
                       if (seat.getType().equalsIgnoreCase(seatPrefrence) && seat.isAvailable()) {
                           availableSeat.add(seat);
                           seat.setAvailable(false);
                           busSeatRepository.save(busSeat1);
                           seatAdded++;
                           if(seatAdded == passengers){
                               return availableSeat;
                           }
                       }
                   }
                   for(Seat seat : BusSeat){
                       if(seatPrefrence.isEmpty() && seat.isAvailable()){
                           availableSeat.add(seat);
                           seat.setAvailable(false);
                           busSeatRepository.save(busSeat1);
                           seatAdded++;
                           if(seatAdded == passengers){
                               return availableSeat;
                           }
                       }
                   }
               }
           }
       }catch (Exception e){
           throw new RuntimeException("Error Getting the Seats ");
       }
        return null;
    }

    @Override
    public List<BusSeat> getAllBusSeat() {
        return busSeatRepository.findAll();
    }

    @Override
    public List<BusSeat> getLayoutsByBusId(int busId) {
        return busSeatRepository.findByBusId(busId);
    }

    @Override
    public void deleteSeatById(String id) {
        busSeatRepository.deleteById(id);
    }
    // In BusSeatServiceImpl.java
    @Override
    public Map<String, Boolean> updateMultipleSeatAvailability(int busId, int classId, List<String> seatNumbers, boolean isAvailable) {
        Optional<BusSeat> optional = busSeatRepository.findByBusIdAndClassId(busId, classId);
        Map<String, Boolean> result = new HashMap<>();

        if (optional.isEmpty()) {
            seatNumbers.forEach(seat -> result.put(seat, false));
            return result;
        }

        BusSeat layout = optional.get();

        layout.getLayout().getSeatMap().forEach(seat -> {
            if (seatNumbers.contains(seat.getSeatNumber())) {
                seat.setAvailable(isAvailable);
                result.put(seat.getSeatNumber(), true);
            }
        });

        busSeatRepository.save(layout);

        // Mark seats that weren't found in layout as false
        for (String seat : seatNumbers) {
            result.putIfAbsent(seat, false);
        }

        return result;
    }

}



