package com.example.seatmanagement_service.serviceImpl;

import com.example.seatmanagement_service.client.ClassTypeClient;
import com.example.seatmanagement_service.client.FlightInfoClient;
import com.example.seatmanagement_service.model.FlightSeat;
import com.example.seatmanagement_service.repository.FlightSeatRepository;
import com.example.seatmanagement_service.service.FlightSeatService;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FlightSeatServiceImpl implements FlightSeatService {

    private final FlightSeatRepository flightSeatRepository;
    private final ClassTypeClient classTypeClient;
    private final FlightInfoClient flightInfoClient;

    @Override
    public FlightSeat saveLayout(FlightSeat flightSeat) {
        return flightSeatRepository.save(flightSeat);
    }

    @Override
    public Optional<FlightSeat> getSeatLayout(int flightId, int classId) {
        return flightSeatRepository.findByFlightIdAndClassId(flightId, classId);
    }

    @Override
    public boolean updateSeatAvailability(int flightId, int classId, String seatNumber, boolean isAvailable) {
        Optional<FlightSeat> optionalLayout = flightSeatRepository.findByFlightIdAndClassId(flightId, classId);
        if (optionalLayout.isPresent()) {
            FlightSeat layout = optionalLayout.get();
            layout.getLayout().getSeatMap().forEach(seat -> {
                if (seat.getSeatNumber().equals(seatNumber)) {
                    seat.setAvailable(isAvailable);
                }
            });
            flightSeatRepository.save(layout);
            return true;
        }
        return false;
    }

    @Override
    public FlightSeat createLayoutFromFlightId(int flightId, int classId, FlightSeat.Layout layout, String token) throws JsonProcessingException {
        String className = classTypeClient.getClassNameById(classId, token);
        String flight_no = flightInfoClient.getFlightById(flightId, token);
        FlightSeat flightSeat = FlightSeat.builder()
                .flightId(flightId)
                .flightNo(flight_no)
                .classId(classId)
                .className(className)
                .layout(layout)
                .build();

        return flightSeatRepository.save(flightSeat);
    }

    @Override
    public List<FlightSeat.Seat> getAvailableSeat(String seatPreference, String Type, String transportId, int passengers) {

        try {
            List<FlightSeat> seat = flightSeatRepository.findByFlightNo(transportId);

            for (FlightSeat seat1 : seat) {
                if (seat1.getClassName().equalsIgnoreCase(Type)) {
                    List<FlightSeat.Seat> seats = seat1.getLayout().getSeatMap();
                    List<FlightSeat.Seat> availableSeat = new ArrayList<>();
                    int seatAdded = 0;
                    for (FlightSeat.Seat seat2 : seats) {
                        if (seat2.getType().equalsIgnoreCase(seatPreference) && seat2.isAvailable()) {
                            availableSeat.add(seat2);
                            seat2.setAvailable(false);
                            flightSeatRepository.save(seat1);
                            seatAdded++;
                            if (seatAdded == passengers) {
                                return availableSeat;
                            }
                        }
                    }
                    for (FlightSeat.Seat seat2 : seats) {
                        if (seatPreference.isEmpty() && seat2.isAvailable()) {
                            availableSeat.add(seat2);
                            seat2.setAvailable(false);
                            flightSeatRepository.save(seat1);
                            seatAdded++;
                            if (seatAdded == passengers) {
                                return availableSeat;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error getting the seats !! ");
        }
        return null;
    }

    @Override
    public List<FlightSeat> getAllFlightSeat() {
        return flightSeatRepository.findAll();
    }

    @Override
    public List<FlightSeat> getLayoutsByFlightId(int flightId) {
        return flightSeatRepository.findByFlightId(flightId);
    }

    @Override
    public void deleteSeatById(String id) {
        flightSeatRepository.deleteById(id);
    }

}
