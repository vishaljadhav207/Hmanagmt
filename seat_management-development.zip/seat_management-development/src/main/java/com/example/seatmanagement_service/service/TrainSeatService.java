package com.example.seatmanagement_service.service;

import com.example.seatmanagement_service.model.TrainSeat;


import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TrainSeatService {
    Optional<TrainSeat> getSeatLayout(int trainId, int classId);
    TrainSeat saveLayout(TrainSeat trainSeat);
    boolean updateSeatAvailability(int trainId, int classId,String seatNumber, boolean isAvailable);

    TrainSeat createLayoutFromTrainId(int trainId, int classId, TrainSeat.Layout layout,String token);
    List<TrainSeat.Seat> TrainSeat(String seatPreference , String Type , int transportId ,int passengers);
    List<TrainSeat> getAllTrainSeats();
    List<TrainSeat> getLayoutsByTrainId(int trainId);
    void deleteSeatById(String id);

}
