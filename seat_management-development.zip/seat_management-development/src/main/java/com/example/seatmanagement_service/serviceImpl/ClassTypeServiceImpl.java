package com.example.seatmanagement_service.serviceImpl;

import com.example.seatmanagement_service.client.ClassTypeClient;
import com.example.seatmanagement_service.service.ClassTypeService;

public class ClassTypeServiceImpl implements ClassTypeService {
    private final ClassTypeClient classTypeClient;


    public ClassTypeServiceImpl(ClassTypeClient classTypeClient) {
        this.classTypeClient = classTypeClient;
    }

    @Override
    public String getClassNameById(int classId,String token) {
        return classTypeClient.getClassNameById(classId,token);
    }
}
