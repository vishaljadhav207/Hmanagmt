package com.example.seatmanagement_service.repository;

import com.example.seatmanagement_service.model.FlightSeat;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FlightSeatRepository extends MongoRepository<FlightSeat, String> {
    Optional<FlightSeat> findByFlightIdAndClassId(int flightId, int classId);
    List<FlightSeat> findByFlightNo(String transportId);
    List<FlightSeat> findByFlightId(int flightId);
    void deleteById(String id);
}

