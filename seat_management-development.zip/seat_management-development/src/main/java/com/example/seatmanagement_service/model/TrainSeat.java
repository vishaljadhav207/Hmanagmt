package com.example.seatmanagement_service.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Document(collection = "train_seats")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TrainSeat {
    @Id
    private String id;

    private int trainId; // Matches train_no
    private int classId; // This could be the ID
    private String className;
    private Layout layout;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Layout {
        private int totalRows;
        private int seatsPerRow;
        private List<Seat> seatMap;
    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Seat {
        private String seatNumber;
        private String type;
        private boolean isAvailable;
    }


}
