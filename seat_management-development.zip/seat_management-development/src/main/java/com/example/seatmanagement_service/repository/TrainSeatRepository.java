package com.example.seatmanagement_service.repository;


import com.example.seatmanagement_service.model.TrainSeat;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TrainSeatRepository extends MongoRepository<TrainSeat, String> {
    Optional<TrainSeat> findByTrainIdAndClassId(int trainId, int classId);
    List<TrainSeat> findByTrainId(int trainId);
    void deleteById(String id);
}