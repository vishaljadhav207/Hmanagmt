package com.example.seatmanagement_service.serviceImpl;

import com.example.seatmanagement_service.client.ClassTypeClient;
import com.example.seatmanagement_service.client.TrainInfoClient;
import com.example.seatmanagement_service.model.TrainSeat;

import com.example.seatmanagement_service.repository.TrainSeatRepository;
import com.example.seatmanagement_service.service.TrainSeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TrainSeatServiceImpl implements TrainSeatService {

    @Autowired
    private TrainSeatRepository trainSeatRepository;

    @Autowired
    private TrainInfoClient trainInfoClient;

    @Autowired
    private ClassTypeClient classTypeClient;

    @Override
    public Optional<TrainSeat> getSeatLayout(int trainId, int classId) {
        return trainSeatRepository.findByTrainIdAndClassId(trainId, classId);
    }

    @Override
    public TrainSeat saveLayout(TrainSeat trainSeat) {
        return trainSeatRepository.save(trainSeat);
    }

    @Override
    public boolean updateSeatAvailability(int trainId, int classId, String seatNumber, boolean isAvailable) {
        Optional<TrainSeat> optional = trainSeatRepository.findByTrainIdAndClassId(trainId, classId);
        if (optional.isEmpty()) return false;

        TrainSeat layout = optional.get();
        layout.getLayout().getSeatMap().forEach(seat -> {
            if (seat.getSeatNumber().equals(seatNumber)) {
                seat.setAvailable(isAvailable);
            }
        });

        trainSeatRepository.save(layout);
        return true;
    }




    public TrainSeat createLayoutFromTrainId(int trainId, int classId,  TrainSeat.Layout layout , String token) {
        try {
            String trainNo = trainInfoClient.getTrainNoByTrainId(trainId,token);

            // Validate if trainNo is valid
            if (trainNo == null || trainNo.isEmpty()) {
                throw new IllegalArgumentException("Invalid train number received for trainId: " + trainId);
            }

            String className = classTypeClient.getClassNameById(classId,token);
            System.out.println("Train No: " + trainNo + " --- Class Name: " + className);

            // Convert trainNo to integer (this will throw an exception if the format is invalid)
            int parsedTrainNo = Integer.parseInt(trainNo);

            TrainSeat seatDoc = TrainSeat.builder()
                    .trainId(parsedTrainNo)
                    .classId(classId)
                    .className(className)
                    .layout(layout)
                    .build();

            // Save the TrainSeat object
            return trainSeatRepository.save(seatDoc);

        } catch (IllegalArgumentException e) {
            // Catch invalid arguments (like empty or null trainNo)
            throw new RuntimeException("Invalid input data: " + e.getMessage(), e);
        } catch (Exception e) {
            // General exception handling
            throw new RuntimeException("Error occurred while creating TrainSeat: " + e.getMessage(), e);
        }
    }

    @Override
    public List<TrainSeat.Seat> TrainSeat(String seatPreference, String Type, int transportId,int passengers) {
      try {
          List<TrainSeat> trainSeats = trainSeatRepository.findByTrainId(transportId);
          if(trainSeats.isEmpty() ){
              throw new RuntimeException("Couldnt find train Seats !! ");
          }
          for (TrainSeat seat : trainSeats) {
              if (seat.getClassName().equalsIgnoreCase(Type)) {
                  List<TrainSeat.Seat> seats = seat.getLayout().getSeatMap();
                  List<TrainSeat.Seat> availableSeat = new ArrayList<>();
                  int seatAdded = 0 ;
                  for (TrainSeat.Seat seat1 : seats) {
                      if (seat1.getType().equalsIgnoreCase(seatPreference) && seat1.isAvailable()) {
                          availableSeat.add(seat1);
                          seat1.setAvailable(false);
                          trainSeatRepository.save(seat);
                          seatAdded++;
                          if(seatAdded == passengers){
                              return availableSeat;
                          }
                      }
                  }
//                  List<TrainSeat.Seat> availableSeats = seats.stream().filter(TrainSeat.Seat::isAvailable).map(it->it.setAvailable(false));

                  for(TrainSeat.Seat seat1 : seats){
                      if(seatPreference.isEmpty() && seat1.isAvailable()){
                          availableSeat.add(seat1);
                          seat1.setAvailable(false);
                          trainSeatRepository.save(seat);
                          seatAdded++;
                          if(seatAdded == passengers){
                              return availableSeat;
                          }
                      }
                  }
                  if(seatAdded < passengers){

                  }
              }

          }
      }catch (Exception e){
          throw new RuntimeException("Error Getting the seats !! ");
      }
      return null ;
    }

    @Override
    public List<TrainSeat> getAllTrainSeats() {
        return trainSeatRepository.findAll();
    }


    @Override
    public List<TrainSeat> getLayoutsByTrainId(int trainId) {
        return trainSeatRepository.findByTrainId(trainId);
    }

    @Override
    public void deleteSeatById(String id) {
        trainSeatRepository.deleteById(id);
    }

}
