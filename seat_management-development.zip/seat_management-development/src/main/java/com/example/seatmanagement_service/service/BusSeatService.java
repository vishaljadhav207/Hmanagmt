package com.example.seatmanagement_service.service;

import com.example.seatmanagement_service.model.BusSeat;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface BusSeatService {
    Optional<BusSeat> getSeatLayout(int busId, int classId);
    BusSeat saveLayout(BusSeat busSeat);
    boolean updateSeatAvailability(int busId, int classId, String seatNumber, boolean isAvailable);
    BusSeat createLayoutFromBusId(int busId, int classId, BusSeat.Layout layout,String token);
    List<BusSeat.Seat> SeatBooking(String seatPreference, String Type , String transportId,int passengers );
    List<BusSeat> getAllBusSeat();
    List<BusSeat> getLayoutsByBusId(int busId);
    void deleteSeatById(String id);



    //Map<String, Boolean> updateSpecificSeats(String busNo, String classType, List<String> seatNumbers, boolean isAvailable);

    Map<String, Boolean> updateMultipleSeatAvailability(int busId, int classId, List<String> seatNumbers, boolean available);
}
