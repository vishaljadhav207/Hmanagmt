package com.example.seatmanagement_service.repository;

import com.example.seatmanagement_service.model.BusSeat;
import com.example.seatmanagement_service.model.FlightSeat;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface BusSeatRepository extends MongoRepository<BusSeat, String> {
    Optional<BusSeat> findByBusIdAndClassId(int busId, int classId);

    List<BusSeat> findByBusNo(String busNo);

    List<BusSeat> findByBusId(int busId);

    void deleteById(String id);
}
