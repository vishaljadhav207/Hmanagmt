package com.example.seatmanagement_service.service;

import com.example.seatmanagement_service.model.BusSeat;
import com.example.seatmanagement_service.model.FlightSeat;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FlightSeatService {
    FlightSeat saveLayout(FlightSeat flightSeat);
    Optional<FlightSeat> getSeatLayout(int flightId, int classId);
    boolean updateSeatAvailability(int flightId, int classId, String seatNumber, boolean isAvailable);
    FlightSeat createLayoutFromFlightId(int flightId, int classId, FlightSeat.Layout layout,String token) throws JsonProcessingException;
    List<FlightSeat.Seat> getAvailableSeat(String seatPrefrence , String classType , String transportId, int passengers);
    List<FlightSeat> getAllFlightSeat();
    List<FlightSeat> getLayoutsByFlightId(int fightId);
    void deleteSeatById(String id);
}
