package com.example.seatmanagement_service.dto;

import lombok.Data;

@Data
public class FlightDTO {
    private int flight_id;
    private String flight_no;
    private String airline;
    private String departFrom;
    private String destination;
}
