package com.example.seatmanagement_service.client;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ClassTypeClient {

    private final RestTemplate restTemplate;

    @Value("${travel-platform.url}")
    private String travelPlatformUrl;

    public ClassTypeClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getClassNameById(int classId , String token) {
        String url = travelPlatformUrl + "/api/getClassNameById/" + classId;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION,token);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        String response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
        try {




            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule()); // Register the Java Time module if needed
            mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);


            JsonNode root = mapper.readTree(response);


            return root.path("data").asText();
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse className from response: " + e);
        }
    }
}
