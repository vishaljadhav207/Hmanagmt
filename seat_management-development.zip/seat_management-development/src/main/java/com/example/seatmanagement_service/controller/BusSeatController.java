package com.example.seatmanagement_service.controller;

import com.example.seatmanagement_service.dto.SeatUpdateRequest;
import com.example.seatmanagement_service.model.BusSeat;
import com.example.seatmanagement_service.model.FlightSeat;
import com.example.seatmanagement_service.service.BusSeatService;
import lombok.RequiredArgsConstructor;
import org.apache.tomcat.util.http.parser.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bus-seats")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class BusSeatController {

    @Autowired
    private BusSeatService busSeatService;

    @GetMapping
    public ResponseEntity<?> getLayout(
            @RequestParam int busId,
            @RequestParam int classId
            ) {
        return busSeatService.getSeatLayout(busId, classId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<BusSeat> createLayout(@RequestBody BusSeat busSeat) {
        return ResponseEntity.ok(busSeatService.saveLayout(busSeat));
    }

    @PatchMapping("/update-seat")
    public ResponseEntity<?> updateSeatStatus(
            @RequestParam int busId,
            @RequestParam int classId,
            @RequestParam String seatNumber,
            @RequestParam boolean isAvailable
    ) {
        boolean updated = busSeatService.updateSeatAvailability(busId, classId, seatNumber, isAvailable);
        return updated ? ResponseEntity.ok("Seat updated") : ResponseEntity.notFound().build();
    }

    @PostMapping("/create-by-id")
    public ResponseEntity<BusSeat> createByBusId(
            @RequestParam int busId,
            @RequestParam int classId,
            @RequestBody BusSeat.Layout layout,
    @RequestHeader("Authorization") String token) {

        BusSeat created = busSeatService.createLayoutFromBusId(busId, classId, layout,token);
        return ResponseEntity.ok(created);
    }


   @GetMapping("/BusSeat")
    public ResponseEntity<List<BusSeat.Seat>> checkBusSeat(
            @RequestParam String Type ,
            @RequestParam String transportId,
            @RequestParam(required = false) String seatPreference,
            @RequestParam int passengers){
        try{
            List<BusSeat.Seat> seat = busSeatService.SeatBooking(seatPreference ,Type,transportId,passengers);
            return ResponseEntity.ok(seat);
        }catch (Exception e){
            throw new RuntimeException("Fetching Seat Failed !! ");
        }
   }

   @GetMapping("getAllBusSeat")
    public ResponseEntity<List<BusSeat>> getAllBusSeat()
   {
       return ResponseEntity.ok(busSeatService.getAllBusSeat());
   }

   @GetMapping("/getBusSeatByBusId")
    public ResponseEntity<List<BusSeat>> getLayoutsByBusId(@RequestParam int busId) {
        List<BusSeat> layouts = busSeatService.getLayoutsByBusId(busId);
        if (layouts.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(layouts);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteSeatById(@RequestParam String id) {
        busSeatService.deleteSeatById(id);
        return ResponseEntity.ok("Seat deleted successfully with ID: " + id);
    }


    @PutMapping("/update-specific-seats")
    public ResponseEntity<?> updateSeatStatuses(@RequestBody SeatUpdateRequest request) {
        Map<String, Boolean> results = busSeatService.updateMultipleSeatAvailability(
                request.getBusId(),
                request.getClassId(),
                request.getSeatNumbers(),
                request.isAvailable()
        );

        return ResponseEntity.ok(results);
    }



}
