package com.example.seatmanagement_service.client;

import com.example.seatmanagement_service.dto.FlightDTO;
import com.example.seatmanagement_service.dto.FlightResponseDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class FlightInfoClient {

    private final RestTemplate restTemplate;

    @Value("${travel-platform.url}")
    private String travelPlatformUrl;

    public FlightInfoClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getFlightById(int flightId , String token) throws JsonProcessingException {
        String url = travelPlatformUrl + "/api/flight/flightNoById/" + flightId;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION,token);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        String response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();// extract "data" part
        try{
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule()); // Register the Java Time module if needed
            mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
            JsonNode root = mapper.readTree(response);
            return root.path("data").asText();
        }catch (Exception e){
            throw new RuntimeException("Error Getting Flight Id !! ");
        }
    }
}
