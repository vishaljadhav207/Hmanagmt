package com.example.seatmanagement_service.controller;

import com.example.seatmanagement_service.model.FlightSeat;
import com.example.seatmanagement_service.service.FlightSeatService;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/flight-seats")
@RequiredArgsConstructor
public class FlightSeatController {

    private final FlightSeatService flightSeatService;

    @GetMapping
    public ResponseEntity<?> getLayout(
            @RequestParam int flightId,
            @RequestParam int classId
    ) {
        return flightSeatService.getSeatLayout(flightId, classId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<FlightSeat> createLayout(@RequestBody FlightSeat flightSeat) {
        return ResponseEntity.ok(flightSeatService.saveLayout(flightSeat));
    }

    @PatchMapping("/update-seat")
    public ResponseEntity<?> updateSeatStatus(
            @RequestParam int flightId,
            @RequestParam int classId,
            @RequestParam String seatNumber,
            @RequestParam boolean isAvailable
    ) {
        boolean updated = flightSeatService.updateSeatAvailability(flightId, classId, seatNumber, isAvailable);
        return updated ? ResponseEntity.ok("Seat updated") : ResponseEntity.notFound().build();
    }

    @PostMapping("/create-by-id")
    public ResponseEntity<FlightSeat> createByFlightId(
            @RequestParam int flightId,
            @RequestParam int classId,
            @RequestBody FlightSeat.Layout layout
            , @RequestHeader("Authorization") String token) throws JsonProcessingException {
        FlightSeat created = flightSeatService.createLayoutFromFlightId(flightId, classId, layout, token);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/flightSeats")
    public ResponseEntity<List<FlightSeat.Seat>> getAvailableSeats(@RequestParam(required = false) String seatPreference, @RequestParam String Type
            , @RequestParam String transportId, @RequestParam int passengers) {
        try {
            List<FlightSeat.Seat> seat = flightSeatService.getAvailableSeat(seatPreference, Type, transportId, passengers);
            return ResponseEntity.ok(seat);
        } catch (Exception e) {
            throw new RuntimeException("Error Fetching Flight Seats !! ");
        }
    }

    @GetMapping("getAllFlightSeat")
    public ResponseEntity<List<FlightSeat>> getAllFlightSeats() {
        return ResponseEntity.ok(flightSeatService.getAllFlightSeat());
    }

    @GetMapping("/getFlightSeatByFlightId")
    public ResponseEntity<List<FlightSeat>> getLayoutsByFlightId(@RequestParam int flightId) {
        List<FlightSeat> layouts = flightSeatService.getLayoutsByFlightId(flightId);
        if (layouts.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(layouts);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteSeatById(@RequestParam String id) {
        flightSeatService.deleteSeatById(id);
        return ResponseEntity.ok("Seat deleted successfully with ID: " + id);
    }
}
