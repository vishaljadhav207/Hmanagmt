package com.example.seatmanagement_service.service;

public interface ClassTypeService {
    String getClassNameById(int classId,String token);
}
