package com.example.seatmanagement_service.controller;

import com.example.seatmanagement_service.model.TrainSeat;
import com.example.seatmanagement_service.service.TrainSeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/train-seats")
public class TrainSeatController {

    @Autowired
    private TrainSeatService trainSeatService;

    @GetMapping
    public ResponseEntity<?> getLayout(
            @RequestParam int trainId,
            @RequestParam int classId
           ) {
        return trainSeatService.getSeatLayout(trainId, classId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<TrainSeat> createLayout(@RequestBody TrainSeat trainSeat) {
        return ResponseEntity.ok(trainSeatService.saveLayout(trainSeat));
    }

    @PatchMapping("/update-seat")
    public ResponseEntity<?> updateSeatStatus(
            @RequestParam int trainId,
            @RequestParam int classId,
            @RequestParam String seatNumber,
            @RequestParam boolean isAvailable
    ) {
        boolean updated = trainSeatService.updateSeatAvailability(trainId, classId,  seatNumber, isAvailable);
        return updated ? ResponseEntity.ok("Seat updated") : ResponseEntity.notFound().build();
    }
    @PostMapping("/create-by-id")
    public ResponseEntity<TrainSeat> createByTrainId(
            @RequestParam int trainId,
            @RequestParam int classId,
            @RequestBody TrainSeat.Layout layout,
            @RequestHeader("Authorization") String token) {
        TrainSeat created = trainSeatService.createLayoutFromTrainId(trainId, classId,  layout , token);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/TrainSeat")
    public ResponseEntity<List<TrainSeat.Seat>> getAvailableSeat(@RequestParam(required = false) String seatPreference,
                                                                 @RequestParam String Type,
                                                                 @RequestParam int transportId,
                                                                 @RequestParam int passengers ){
        try{
            List<TrainSeat.Seat> seat = trainSeatService.TrainSeat(seatPreference,Type,transportId,passengers);
            return ResponseEntity.ok(seat);
        }catch (Exception e){
            throw new RuntimeException("Seat Not Found or Failed to fetch seats !! ");
        }
    }

    @GetMapping("/getAllTrainSeats")
    public ResponseEntity<List<TrainSeat>> getAllTrainSeats(){
        return ResponseEntity.ok(trainSeatService.getAllTrainSeats());
    }

    @GetMapping("/getTrainSeatsByTrainId")
    public ResponseEntity<List<TrainSeat>> getLayoutsByTrainId(@RequestParam int trainId) {
        List<TrainSeat> layouts = trainSeatService.getLayoutsByTrainId(trainId);
        if (layouts.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(layouts);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteSeatById(@RequestParam String id) {
        trainSeatService.deleteSeatById(id);
        return ResponseEntity.ok("Seat deleted successfully with ID: " + id);
    }


}
