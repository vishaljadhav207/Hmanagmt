package com.example.seatmanagement_service.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "bus_seats")
public class BusSeat {
    @Id
    private String id;
    private int busId;
    private String busNo;
    private int classId;
    private String className;
    private Layout layout;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Layout {
        private int totalRows;
        private int seatsPerRow;
        private List<Seat> seatMap;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Seat {
        private String seatNumber;
        private String type;
        private boolean isAvailable;
    }
}
