package com.example.seatmanagement_service.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "flight_seats")
public class FlightSeat {
    @Id
    private String id;
    private int flightId;
    private int classId;
    private String flightNo;
    private String className;
    private Layout layout;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Layout {
        private int totalRows;
        private int seatsPerRow;
        private List<Seat> seatMap;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Seat {
        private String seatNumber;
        private String type;
        private boolean available;
    }
}

