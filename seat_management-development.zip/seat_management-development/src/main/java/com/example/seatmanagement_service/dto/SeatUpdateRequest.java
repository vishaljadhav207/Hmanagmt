package com.example.seatmanagement_service.dto;

import lombok.Data;

import java.util.List;

@Data
public class SeatUpdateRequest {
    private int busId;
    private int classId;
    private List<String> seatNumbers;
    private boolean isAvailable;
}
