package com.example.seatmanagement_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatmanagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
