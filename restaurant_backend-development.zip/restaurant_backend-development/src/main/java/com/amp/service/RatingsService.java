package com.amp.service;

import com.amp.entity.Ratings;

import java.util.List;

public interface RatingsService {
    Ratings addRating(Ratings ratings);
    List<Ratings> getAll(int page , int size );
    List<Ratings> findByHotelId(int id);
}
