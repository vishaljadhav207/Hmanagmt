package com.amp.service;


import com.amp.entity.Hotel;
import com.amp.entity.Wishlist;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public interface WishlistService {

    Wishlist saveToWishList(Wishlist wishlist );

    List<Hotel> getHotelOfWish();

    boolean deleteWishlist(long id );
}
