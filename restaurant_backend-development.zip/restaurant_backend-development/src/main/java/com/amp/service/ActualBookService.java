package com.amp.service;

import com.amp.dto.SearchDto;
import com.amp.entity.ActualBooking;
import com.amp.entity.BookingStatus;
import com.amp.entity.Guest;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDate;
import java.util.List;

public interface ActualBookService {

    ActualBooking addRecord(ActualBooking actualBooking );
    SearchDto<ActualBooking> getAllRecords(
            int page, int size, String sortBy, String sortDirection,
            Long userId, String city, LocalDate checkInDate,
            LocalDate checkOutDate, BookingStatus status, String firstName);
    List<Guest> getGuestByBookingId(int id);
    List<ActualBooking> getBookingHistoryByUserId(long userId);

    ActualBooking updateBookingStatus(int BookingId, String action, String status, String remark, long userId);

    SearchDto<ActualBooking> getBookingByHotelId(int page , int size ,
                                                 String sortBy , String sortDirection,
                                                 int hotelId);

}
