package com.amp.service;

import com.amp.entity.Guest;
import org.springframework.stereotype.Service;

import java.util.List;

public interface GuestService {
    Guest createGuest(Guest guest);

    Guest getGuestById(int guestId);

    List<Guest> getAllGuests();

    Guest updateGuest(int guestId, Guest guest);

    boolean deleteGuest(int guestId);
}
