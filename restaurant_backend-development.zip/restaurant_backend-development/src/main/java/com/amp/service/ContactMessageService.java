package com.amp.service;

import com.amp.entity.ContactMessage;

import java.util.List;

public interface ContactMessageService {
    ContactMessage saveMessage(ContactMessage message);
    List<ContactMessage> getAllMessages();
    void deleteMessage(Long id);

    ContactMessage updateReplyAndSendEmail(String email, String reply);
}
