package com.amp.utilis.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {

    private static final String SECRET_KEY = "y6y7nD1Opa4QHq5XZ8D3bLqIB4CgHlFZ5gIhBX5pUr5WHeGmhrjexXj7t2iqN2rS5fbM8yP6Xf+JHSPYyVgYbg==";
    private static final long EXPIRATION_TIME = 86400000*7;  // 100 min


    public String generateToken(String email , long userId , String role,long orgId ) {

        return Jwts.builder()
                .setSubject(email)
                .claim("userId",userId)
                .claim("role",role)
                .claim("organization",orgId)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis()+ EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    public long extractUserId(String token) {
        try {
            // Parse the JWT token
            Claims claims = Jwts.parser()
                    .setSigningKey(SECRET_KEY)
                    .parseClaimsJws(token)
                    .getBody();

            // Extract userId safely. You might want to handle null or type mismatches.
            Object userIdObj = claims.get("userId");
            if (userIdObj == null) {
                throw new IllegalArgumentException("userId claim is missing in the token");
            }

            // Ensure it's a valid long
            if (userIdObj instanceof Integer) {
                return ((Integer) userIdObj).longValue();
            } else if (userIdObj instanceof Long) {
                return (Long) userIdObj;
            } else {
                throw new IllegalArgumentException("userId claim is not of expected type");
            }
        } catch (JwtException e) {
            // Handle JWT parsing exception
            throw new IllegalArgumentException("Invalid JWT token", e);
        } catch (Exception e) {
            // Handle other potential issues (e.g., missing claims)
            throw new IllegalArgumentException("Error extracting userId from the token", e);
        }
    }



    public String extractToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
    private  Date extractExpiration(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
    }
    public boolean validateToken(String token, String email) {
        return (email.equals(extractToken(token)) && !isTokenExpired(token));
    }

    public String getRoleFromToken(String token){
        Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
        String role = (String) claims.get("role");
        return role;
    }
}
