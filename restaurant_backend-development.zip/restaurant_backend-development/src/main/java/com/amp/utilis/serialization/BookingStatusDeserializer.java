package com.amp.utilis.serialization;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.amp.entity.BookingStatus;

import java.io.IOException;

public class BookingStatusDeserializer extends JsonDeserializer<BookingStatus> {

    @Override
    public BookingStatus deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        String statusString = jsonParser.getText();
        return BookingStatus.valueOf(statusString);  // Convert string to enum
    }
}

