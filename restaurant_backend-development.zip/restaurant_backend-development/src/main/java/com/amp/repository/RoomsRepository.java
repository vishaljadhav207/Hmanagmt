package com.amp.repository;

import com.amp.entity.Rooms;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RoomsRepository extends JpaRepository<Rooms, Integer> {
    @Query("SELECT r FROM Rooms r WHERE r.hotel.hotelId = :hotelId")
    List<Rooms> findRoomsByHotelId(int hotelId);

    @Query("SELECT r FROM Rooms r WHERE " +
            "(:roomType IS NULL OR r.roomType LIKE %:roomType%) AND " +
            "(:hotelId IS NULL OR r.hotel.hotelId = :hotelId) AND " +
            "(:minRoomBasePrice IS NULL OR r.roomBasePrice >= :minRoomBasePrice) AND " +
            "(:maxRoomBasePrice IS NULL OR r.roomBasePrice <= :maxRoomBasePrice)")
    Page<Rooms> searchRooms(@Param("roomType") String roomType,
                            @Param("hotelId") Integer hotelId,
                            @Param("minRoomBasePrice") Integer minRoomBasePrice,
                            @Param("maxRoomBasePrice") Integer maxRoomBasePrice,
                            Pageable pageable);


    @Modifying
    @Query("DELETE FROM Rooms r WHERE r.hotel.hotelId = :hotelId")
    void deleteRoomsByHotelId(@Param("hotelId") int hotelId);

}
