package com.amp.repository;

import com.amp.entity.User;
import jakarta.transaction.Transactional;
import org.checkerframework.common.aliasing.qual.Unique;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import static org.hibernate.grammars.hql.HqlParser.SELECT;
import static org.hibernate.sql.ast.Clause.FROM;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    @Transactional
    @Modifying
    @Query("UPDATE User u SET u.password = :password WHERE u.email = :email")
    void updatePassword(@Param("email") String email, @Param("password") String password);

    // Add this custom query to fetch the password by email
    @Query("SELECT u.password FROM User u WHERE u.email = :email")
    String getPasswordByEmail(@Param("email") String email);

    @Query("SELECT u FROM User u WHERE " +
            "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    Page<User> searchUsers(@Param("searchTerm") String searchTerm, Pageable pageable);

    boolean existsByEmail(String email);

    boolean existsByMobile(@Unique String mobile);

    @Query("SELECT u FROM User u WHERE u.orgId = :orgId")
    List<User> findByOrgId(@Param("orgId") Long orgId);

    @Query("SELECT u FROM User u WHERE u.role.roleId = 3001")
    List<User> getFlightAdmin();

    @Query("SELECT u FROM User u WHERE u.role.roleId = 4001 ")
    List<User> getBusAdmin();

    @Query("SELECT u FROM User u WHERE u.role.roleId = 2001")
    List<User> getTrainAdmin();

    List<User> findByOrgIdAndRole_RoleId(Long orgId, int roleId);

}

