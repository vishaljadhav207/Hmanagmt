package com.amp.repository;

import com.amp.entity.ForgotPassword;
import com.amp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ForgetPasswordRepository extends JpaRepository<ForgotPassword,Integer> {
     Optional<ForgotPassword> findByOtp(Integer otp);

     @Query("SELECT r FROM ForgotPassword r WHERE r.user.userId = :userId")
     List<ForgotPassword> findUsers(long userId);
}
