package com.amp.repository;

import com.amp.entity.ActualBooking;
import com.amp.entity.BookingStatus;
import com.amp.entity.Guest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ActualBookRepo extends JpaRepository<ActualBooking,Integer> {

    @Query("SELECT ab FROM ActualBooking ab WHERE ab.userId = :userId")
    List<ActualBooking> findByUserId(@Param("userId") long userId);

    @Query("SELECT g FROM Guest g WHERE g.actualBooking.BookingId = :bookingId")
    List<Guest> findGuestsByBookingId(@Param("bookingId") int bookingId);


    @Query(value = "SELECT * FROM actual_booking ab WHERE " +
            "(:userId IS NULL OR ab.user_id = :userId) AND " +
            "(:city IS NULL OR ab.city ILIKE CONCAT('%', :city, '%')) AND " +
            "(:checkInDate IS NULL OR ab.check_in_date >= :checkInDate) AND " +
            "(:checkOutDate IS NULL OR ab.check_out_date <= :checkOutDate) AND " +
            "(:status IS NULL OR ab.status = CAST(CAST(:status AS text) AS smallint)) AND " +
            "(:firstName IS NULL OR ab.first_name ILIKE CONCAT('%', :firstName, '%'))",
            countQuery = "SELECT count(*) FROM actual_booking ab WHERE " +
                    "(:userId IS NULL OR ab.user_id = :userId) AND " +
                    "(:city IS NULL OR ab.city ILIKE CONCAT('%', :city, '%')) AND " +
                    "(:checkInDate IS NULL OR ab.check_in_date >= :checkInDate) AND " +
                    "(:checkOutDate IS NULL OR ab.check_out_date <= :checkOutDate) AND " +
                    "(:status IS NULL OR ab.status = CAST(CAST(:status AS text) AS smallint)) AND " +
                    "(:firstName IS NULL OR ab.first_name ILIKE CONCAT('%', :firstName, '%'))",
            nativeQuery = true)
    Page<ActualBooking> searchBookings(
            @Param("userId") Long userId,
            @Param("city") String city,
            @Param("checkInDate") LocalDate checkInDate,
            @Param("checkOutDate") LocalDate checkOutDate,
            @Param("status") Integer status,
            @Param("firstName") String firstName,
            Pageable pageable);

    @Query("SELECT ab FROM ActualBooking ab WHERE ab.hotelId = :hotelId")
    Page<ActualBooking> bookingByHotelId(@Param("hotelId") int hotelId, Pageable pageable);

    long count();

}
