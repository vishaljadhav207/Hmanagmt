package com.amp.repository;

import com.amp.entity.Hotel;
import com.amp.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Integer> {
    List<Hotel> findByCityEqualsIgnoreCase(String City);
    List<Hotel> findByHotelOwner(User hotelOwner);
    long count();

    @Query("SELECT h FROM Hotel h WHERE " +
            "(:roomsNeeded = 0 OR h.hotelRooms >= :roomsNeeded) AND " +
            "(:city IS NULL OR :city = '' OR LOWER(h.city) LIKE LOWER(CONCAT('%', :city, '%')))")
    Page<Hotel> searchHotels(@Param("roomsNeeded") int roomsNeeded,  // Keep roomsNeeded as primitive int
                             @Param("city") String city,

                             Pageable pageable);

    @Modifying
    @Query("DELETE FROM Hotel h WHERE h.hotelId = :hotelId")
    void deleteHotelId(@Param("hotelId") int hotelId);
}
