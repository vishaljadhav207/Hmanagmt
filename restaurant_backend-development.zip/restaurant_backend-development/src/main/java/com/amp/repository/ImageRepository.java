package com.amp.repository;

import com.amp.entity.Hotel;
import com.amp.entity.Images;
import com.amp.entity.Rooms;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface ImageRepository extends JpaRepository<Images, Integer> {

    List<Images> findByHotelAndRoom(Hotel hotel, Rooms room);

    List<Images> findByHotelAndRoomIsNull(Hotel hotel);

    List<Images> findByRoomAndHotelIsNull(Rooms room);


    void deleteByRoom_RoomId(int roomId);

    void deleteByRoom_RoomIdAndHotelIsNotNull(int roomId);
}