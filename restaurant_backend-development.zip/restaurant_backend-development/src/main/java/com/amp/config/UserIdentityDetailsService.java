package com.amp.config;

import com.amp.dto.UserIdentityDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class UserIdentityDetailsService {

    public long getUserId() {
        Object principle = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(principle instanceof UserIdentityDetails) {
            UserIdentityDetails userIdentityDetails = (UserIdentityDetails) principle;
            return userIdentityDetails.getUserId();
        }
        throw new RuntimeException("Unauthorized");
    }

}
