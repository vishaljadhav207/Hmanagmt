package com.amp.entity;

import com.amp.repository.RatingsRepo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Getter
@Setter
@Entity
public class Hotel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int hotelId;

    @NotEmpty(message = "Hotel name must not be empty")
    private String hotelName;

    @NotEmpty(message = "City Name Must not be Empty ! ")
    private String city ;

    @NotEmpty(message = "Hotel address must not be empty")
    private String hotelAdd;

    @Min(value = 0, message = "Hotel rooms must be greater than or equal to 0")
    private int hotelRooms;

    private int hotelRatings ;

    @NotEmpty(message = "Hotel description must not be empty")
    private String hotelDes;

    @NotNull(message = "Latitude must not be null")
    private Double latitude;

    @NotNull(message = "Longitude must not be null")
    private Double longitude;


    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "hotel_amenities",
            joinColumns = @JoinColumn(name = "hotel_id"),
            inverseJoinColumns = @JoinColumn(name = "amenity_id"))
    private Set<MasterAmenity> amenities = new HashSet<>();

    @Transient
    private List<Integer> amenityIds = new ArrayList<>();

    // Change hotelOwner to a OneToOne relation
    @JsonIgnoreProperties({"password" , "role"})
    @OneToOne
    @JoinColumn(name = "Owner_id", referencedColumnName = "userId")
   private User hotelOwner;
}
