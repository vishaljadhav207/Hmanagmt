package com.amp.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.checkerframework.common.aliasing.qual.Unique;

@Data
@Entity
@JsonIgnoreProperties("actualBooking")
public class Guest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int guestId;

    @NotEmpty(message = "First name can't be empty")
    private String firstName;
    @NotEmpty(message = "Last name can't be empty")
    private String lastName;
    @NotEmpty(message = "Select gender")
    private String gender;
    @NotNull(message = "Age can't be empty")
    private int age;
    @NotEmpty(message = "Can't be empty")
    private String nationality;
    @Pattern(regexp = "^[0-9]{10}$", message = "Invalid mobile number. ")
    @NotEmpty(message = "user mobile number must not be empty")
    private String phoneNumber;
    @NotEmpty(message = "Name can't be null")
    private String govIdType;
    @NotEmpty(message = "Can't be empty")
    private String govIdNumber;

    @ManyToOne
    @JoinColumn(name = "actual_booking_id")
    private ActualBooking actualBooking;

}
