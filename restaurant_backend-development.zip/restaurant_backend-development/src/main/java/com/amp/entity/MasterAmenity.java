package com.amp.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Entity
@NoArgsConstructor
public class MasterAmenity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @NotEmpty(message = "Amenity name can't be empty")
    private String amenityName;

//    @ManyToMany(mappedBy = "amenities")
//    private Set<Hotel> hotels=new HashSet<>();

}
