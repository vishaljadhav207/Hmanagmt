package com.amp.entity;

public enum BookingStatus {
    PENDING,
    BOOKED,
    CANCELLED,
    REJECTED,
    CHECKED_IN,
    CHECKED_OUT;
}
