package com.amp.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ForgotPassword {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(unique=true)
    private int otp;

    @Column(nullable=false)
    private Date expirationTime;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

}
