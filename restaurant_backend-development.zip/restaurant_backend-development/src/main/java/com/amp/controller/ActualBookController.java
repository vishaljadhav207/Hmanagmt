package com.amp.controller;

import com.amp.config.Authorize;
import com.amp.config.UserIdentityDetailsService;
import com.amp.dto.ApiResponse;
import com.amp.dto.SearchDto;
import com.amp.dto.UpdateBookingStatusDto;
import com.amp.entity.ActualBooking;
import com.amp.entity.BookingStatus;
import com.amp.entity.Guest;
import com.amp.service.ActualBookService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/booking")
@CrossOrigin(origins = "*")
public class ActualBookController {
    @Autowired
    private ActualBookService actualBookService;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    @Authorize({"User"})
    @PostMapping("/addRecord")
    public ApiResponse<ActualBooking> addRecord(@RequestBody ActualBooking actualBooking ){
        return new ApiResponse<>(HttpStatus.ACCEPTED.value()
                ,"Record Saved ",actualBookService.addRecord(actualBooking));
    }

    @Authorize({"Hotel_owner"})
    @GetMapping("/getAll")
    public ApiResponse<SearchDto<ActualBooking>> getRecords(
        @RequestParam int page,
        @RequestParam int size,
        @RequestParam(required = false) String sortBy,
        @RequestParam(required = false) String sortDirection,
        @RequestParam(required = false) Long userId,
        @RequestParam(required = false) String city,
        @RequestParam(required = false) LocalDate checkInDate,
        @RequestParam(required = false) LocalDate checkOutDate,
        @RequestParam(required = false) BookingStatus status,
        @RequestParam(required = false) String firstName) {


    SearchDto<ActualBooking> response = actualBookService.getAllRecords(
            page, size, sortBy, sortDirection,
            userId, city, checkInDate, checkOutDate,
            status, firstName);
    return new ApiResponse<>(HttpStatus.FOUND.value(), "Records Fetched !!", response);
}
    @GetMapping("/guests")
    public ApiResponse<List<Guest>> getGuest(@RequestParam int id){
        return new ApiResponse<>(HttpStatus.FOUND.value(),
                "Guests Were Fetched ! ", actualBookService.getGuestByBookingId(id));
    }

    @Authorize({"Hotel_owner","User"})
    @GetMapping("/history")
    public ApiResponse<List<ActualBooking>> getBookingHistoryByUserId(@RequestParam long userId) {
        return new ApiResponse<>(HttpStatus.FOUND.value(), "Booking History Fetched",
                actualBookService.getBookingHistoryByUserId(userId));
    }


    @Authorize({"Hotel_owner","User"})
    @PutMapping("/updateBookingStatus")
    public ApiResponse<ActualBooking> updateBookingStatus(
            @RequestBody UpdateBookingStatusDto updateBookingStatusDto) {

        try {

            long userId = userIdentityDetailsService.getUserId();

            if (!isValidAction(updateBookingStatusDto.getAction())) {
                return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Invalid action: " + updateBookingStatusDto.getAction(), null);
            }

            if ((updateBookingStatusDto.getAction().equalsIgnoreCase("cancel") || updateBookingStatusDto.getAction().equalsIgnoreCase("reject")) && (updateBookingStatusDto.getRemark() == null ||updateBookingStatusDto.getRemark().isEmpty())) {
                return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Remark is required for cancel or reject actions", null);
            }

            String status = determineStatusBasedOnAction(updateBookingStatusDto.getAction(), updateBookingStatusDto.getRemark());


            ActualBooking updatedBooking = actualBookService.updateBookingStatus(
                    updateBookingStatusDto.getBookingId(), updateBookingStatusDto.getAction(), status, updateBookingStatusDto.getRemark(), userId);

            return new ApiResponse<>(HttpStatus.OK.value(),
                    "Booking status updated successfully", updatedBooking);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error updating booking status: " + e.getMessage(), null);
        }
    }

    @Authorize({"Hotel_owner"})
    @GetMapping("/bookingsByHotelId")
    public ApiResponse<SearchDto<ActualBooking>> bookingsByHotelId( @RequestParam int page,
                                                                    @RequestParam int size,
                                                                    @RequestParam(required = false) String sortBy,
                                                                    @RequestParam(required = false) String sortDirection,
                                                                    @RequestParam int hotelId){
        try{
            return new ApiResponse<>(HttpStatus.OK.value()
                    ,"All Hotel Bookings Fetched ! "
                    ,actualBookService.getBookingByHotelId(page,size,sortBy,sortDirection,hotelId));
        }catch(Exception e ){
            throw new RuntimeException("Error While Fetching Records");
        }
    }

    private boolean isValidAction(String action) {
        return action != null && (action.equalsIgnoreCase("cancel") ||
                action.equalsIgnoreCase("reject") ||
                action.equalsIgnoreCase("checkin") ||
                action.equalsIgnoreCase("checkout"));
    }


    private String determineStatusBasedOnAction(String action, String remark) {
        switch (action.toLowerCase()) {
            case "cancel":
                return "CANCELLED";
            case "reject":
                return "REJECTED";
            case "checkin":
                return "CHECKED_IN";
            case "checkout":
                return "CHECKED_OUT";
            default:
                throw new IllegalArgumentException("Invalid action: " + action);
        }
    }

}


