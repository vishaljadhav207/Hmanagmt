package com.amp.controller;

import com.amp.dto.ApiResponse;
import com.amp.dto.SearchDto;
import com.amp.entity.TemporaryBooking;
import com.amp.service.TempBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/temp-bookings")
public class TempBookController {

    @Autowired
    private TempBookService tempBookService;

    @PostMapping("/add")
    public ApiResponse<TemporaryBooking> add(@RequestBody TemporaryBooking temporaryBooking){
        return new ApiResponse<>(HttpStatus.ACCEPTED.value(),
                "Record was Saved " , tempBookService.addRecord(temporaryBooking));
    }

@GetMapping("/getAll")
public ApiResponse<SearchDto<TemporaryBooking>> getBookings(@RequestParam int page, @RequestParam int size,
                                                            @RequestParam(required = false, defaultValue = "") String sortBy,
                                                            @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                            @RequestParam(required = false, defaultValue = "") String city,
                                                            @RequestParam(required = false, defaultValue = "") Integer minAdults,
                                                            @RequestParam(required = false, defaultValue = "") Integer maxAdults,
                                                            @RequestParam(required = false, defaultValue = "") LocalDate checkInDateStart,
                                                            @RequestParam(required = false, defaultValue = "") LocalDate checkInDateEnd){
    // Call service to fetch records
    SearchDto<TemporaryBooking> response = tempBookService.getTempRecords(page, size, sortBy, sortDirection, city, minAdults, maxAdults, checkInDateStart, checkInDateEnd);
    return new ApiResponse<>(HttpStatus.OK.value(), "Records Fetched Successfully!", response);
}




    @DeleteMapping("/delete/{id}")
    public ApiResponse<Boolean> deleteRecord(@PathVariable int id){
        return new ApiResponse<>(HttpStatus.OK.value(),"Deleted",true);
    }
}