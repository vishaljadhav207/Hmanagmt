package com.amp.controller;

import com.amp.config.Authorize;
import com.amp.dto.ApiResponse;
import com.amp.entity.ContactMessage;
import com.amp.service.ContactMessageService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin(origins = "*")
public class ContactMessageController {

    @Autowired
    private ContactMessageService contactMessageService;

   @Authorize({"User"})
    @PostMapping("/addContact")
    public ApiResponse<ContactMessage> addMessage(@Valid @RequestBody ContactMessage message) {
        try {
            ContactMessage savedMessage = contactMessageService.saveMessage(message);
            return new ApiResponse<>(HttpStatus.CREATED.value(), "Message created successfully", savedMessage);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Error while creating message", null);
        }
    }

    @Authorize({"Admin"})
    @GetMapping("/getContact")
    public ApiResponse<List<ContactMessage>> getAllMessages() {
        try {
            List<ContactMessage> messages = contactMessageService.getAllMessages();
            if (messages.isEmpty()) {
                return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No messages found", null);
            }
            return new ApiResponse<>(HttpStatus.OK.value(), "Messages fetched successfully", messages);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error fetching messages", null);
        }
    }

    @Authorize({"User","Admin"})
    @PutMapping("/updateContact")
    public ApiResponse<ContactMessage> updateReply(@RequestParam String email, @RequestBody String reply) {
        try {
            ContactMessage updatedMessage = contactMessageService.updateReplyAndSendEmail(email, reply);
            if (updatedMessage != null) {
                return new ApiResponse<>(HttpStatus.OK.value(), "Message replied successfully", updatedMessage);
            } else {
                return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Message not found", null);
            }
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.BAD_REQUEST.value(), "Error updating reply", null);
        }
    }

    @Authorize("Admin")
    @DeleteMapping("/deleteContact{id}")
    public ApiResponse<Void> deleteMessage(@PathVariable Long id) {
        try {
            contactMessageService.deleteMessage(id);
            return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "Message deleted successfully", null);
        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "Message not found", null);
        }
    }
}
