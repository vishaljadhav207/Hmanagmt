package com.amp.controller;

import com.amp.config.Authorize;
import com.amp.dto.ApiResponse;
import com.amp.entity.Hotel;
import com.amp.entity.Wishlist;
import com.amp.service.WishlistService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.lang.model.util.Elements;
import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/wishlist")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @Authorize({"User"})
    @PostMapping("/add")
    public Wishlist saveToWishList(@RequestBody Wishlist wishlist){
        return wishlistService.saveToWishList(wishlist);
    }

    @Authorize({"User"})
    @GetMapping("/getWishList")
    public ApiResponse<List<Hotel>> getWishList(){
       return new ApiResponse<>(HttpStatus.OK.value(),
               "Hotels Were Fetched !! ",wishlistService.getHotelOfWish());

    }

    @Authorize({"User"})
    @DeleteMapping("/deleteId")
    public ApiResponse<Boolean> removeFromWishlist(@RequestParam long id) {
        return new ApiResponse<>(HttpStatus.OK.value(), "Hotel removed from wishlist!",wishlistService.deleteWishlist(id));
    }

}
