package com.amp.controller;


import com.amp.client.OrganizationServiceClient;
import com.amp.config.Authorize;
import com.amp.dto.*;

import com.amp.entity.ForgotPassword;
import com.amp.entity.Role;
import com.amp.entity.User;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.ForgetPasswordRepository;
import com.amp.repository.RoleRepository;
import com.amp.repository.UserRepository;
import com.amp.serviceImp.EmailServiceImpl;
import com.amp.service.LoginService;
import com.amp.service.UserService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.validation.Valid;
import org.checkerframework.checker.units.qual.A;
import org.springdoc.core.annotations.ParameterObject;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.net.http.HttpClient;
import java.time.Instant;
import java.util.*;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private LoginService loginService;
    @Autowired
    AuthenticationManager authenticationManager;


    @Autowired
    private EmailServiceImpl emailService;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    PasswordEncoder passwordEncoder;


    @Autowired
    private ForgetPasswordRepository forgetPasswordRepository;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private OrganizationServiceClient organizationServiceClient;

    @PostMapping("/register")
    public ApiResponse<User> registerUser(@Valid @RequestBody User user) {
        try {

            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {
                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {
               throw new BadRequestException("Mobile number already in use");
            }
            Role role=new Role();
             role.setRoleId(1000);
             user.setRole(role);
               User registeredUser = userService.registerUser(user);
               return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {

            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register User", null);
//            throw new RuntimeException(e.getMessage());
        }

    }
    @PostMapping("/HotelOwner/register")
    public ApiResponse<User> registerOwner(@Valid @RequestBody User user) {
        try {
            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {

                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {

                throw new BadRequestException("Mobile number already in use");
            }
            Role role=new Role();
            role.setRoleId(1002);
            user.setRole(role);
            User registeredUser = userService.registerOwner(user);
            return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register Hotel Owner", null);
//            throw new RuntimeException(e.getMessage());
        }
    }

    @Authorize({"Admin"})
    @PostMapping("/registerOrgOwner")
    public ApiResponse<User> registerOrgOwner(@RequestBody User user){
           try{
               return new ApiResponse<>(HttpStatus.OK.value(),"User was Registered ",userService.registerOrganizationOwner(user));
           }catch (Exception E){
               throw new RuntimeException("User Not Registered ! ");
           }
    }
    @Authorize({"Train Admin"})
    @PostMapping("/trainSupervisor/register")
    public ApiResponse<User> registertrainsupervisor(@Valid @RequestBody User user, @RequestHeader("Authorization") String token) {
        try {
            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {

                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {

                throw new BadRequestException("Mobile number already in use");

            }
            Organization org = organizationServiceClient.getOrganizationById(user.getOrgId(),token);

            if (org == null) {
                throw new BadRequestException("Invalid organization ID: Organization does not exist");
            }
            Role role=new Role();
            role.setRoleId(2002);
            user.setRole(role);
            User registeredUser = userService.registertrainsupervisor(user);
            return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register train supervisor", null);
//            throw new RuntimeException(e.getMessage());
        }
    }
    @Authorize({"Flight Admin"})
    @PostMapping("/flightsupervisor/register")
    public ApiResponse<User> registerflightsupervisor(@Valid @RequestBody User user,@RequestHeader("Authorization") String token) {
        try {
            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {

                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {

                throw new BadRequestException("Mobile number already in use");
            }
            Organization org = organizationServiceClient.getOrganizationById(user.getOrgId(),token);

            if (org == null) {
                throw new BadRequestException("Invalid organization ID: Organization does not exist");
            }
            Role role=new Role();
            role.setRoleId(3002);
            user.setRole(role);
            User registeredUser = userService.registerflightsupervisor(user);
            return new ApiResponse<>(HttpStatus.OK.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register flight supervisor", null);
//            throw new RuntimeException(e.getMessage());
        }
    }
    @Authorize({"Bus Admin"})
    @PostMapping("/busSupervisor/register")
    public ApiResponse<User> registerbussupervisor(@Valid @RequestBody User user,@RequestHeader("Authorization") String token) {
        try {
            String email = user.getEmail().toLowerCase();
            user.setEmail(email);

            if (userService.existsByEmail(user.getEmail())) {

                throw new BadRequestException("Email already in use");
            }
            if (userService.existsByMobile(user.getMobile())) {

                throw new BadRequestException("Mobile number already in use");
            }
            Organization org = organizationServiceClient.getOrganizationById(user.getOrgId(),token);

            if (org == null) {
                throw new BadRequestException("Invalid organization ID: Organization does not exist");
            }


            Role role=new Role();
            role.setRoleId(4002);
            user.setRole(role);
            User registeredUser = userService.registerbussupervisor(user);
            return new ApiResponse<>(HttpStatus.CREATED.value(), "Registered successfully", registeredUser);

        } catch (Exception e) {
            return new ApiResponse<>(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Failed to Register bus supervisor", null);
//            throw new RuntimeException(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ApiResponse<JwtLoginResponse> login(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail().toLowerCase();
        loginRequest.setEmail(email);

        JwtLoginResponse loginResponse = loginService.login(loginRequest);
        System.out.println("Token ---->>>>   "+loginResponse.getToken());

        return new ApiResponse<>(HttpStatus.OK.value(), "Login Success", loginResponse);
    }

    @Authorize({"Admin","Hotel_owner","Train Admin","Bus Admin", "Flight Admin"})
    @GetMapping("/allUsers")
    public ApiResponse<SearchDto<User>> findAllUsers(@RequestParam int page, @RequestParam int size,
                                                 @RequestParam(required = false, defaultValue = "") String sortBy,
                                                 @RequestParam(required = false, defaultValue = "") String sortDirection,
                                                 @RequestParam(required = false, defaultValue = "") String searchTerm) {
       SearchDto<User> response = userService.findAllUsers(page, size, sortBy, sortDirection, searchTerm);

       if (response.getData().isEmpty()) {
        return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No users found", response);
    }

       return new ApiResponse<>(HttpStatus.OK.value(), "Users found", response);
    }



    @GetMapping("/users/{id}")
    public User getUserById(@PathVariable long id) {
        return userService.findUserById(id);
    }

    @DeleteMapping("/usersDelete/{id}")
    public ApiResponse<String> deleteUserById(@PathVariable Long id) {
        userService.deleteUserById(id);

        return new ApiResponse<>(HttpStatus.OK.value(), "User deleted successfully", null);
    }

    @PutMapping("updateUser/{id}")
    public ApiResponse<User> updateUser(@Valid @PathVariable Long id, @RequestBody User userDetails) {
        try {
            User updatedUser = userService.updateUser(id, userDetails);
            return new ApiResponse<>(HttpStatus.ACCEPTED.value(), "User updated successfully", updatedUser);
//        } catch (Exception e) {
//           throw new RuntimeException(e.getMessage());
//            return new ApiResponse<>(HttpStatus.ACCEPTED.value(), "User updated successfully", updatedUser);
        } catch (RuntimeException e) {
            return new ApiResponse<>(HttpStatus.NOT_FOUND.value(), "User not found", null);
        }
    }


    @PostMapping("verifyEmail/{email}")
    public ApiResponse<String> verifyEmail(@PathVariable String email) {
      User user=  userRepository.findByEmail(email).orElseThrow(()->new RuntimeException("Email not found"));

      int otp=otpGenerator();
        MailBody mailBody=MailBody.builder().to(email).text(("<html>"
                        + "<body>"
                        + "<p>Dear "+user.getFirstName()+" "+user.getLastName()+", </p>"
                        + "<p>We received a request to reset your password. Please use the following One-Time Password (OTP) to proceed:</p>"
                        + "<p><strong>OTP: " + otp + "</strong></p>"
                        + "<p>If you did not request this, please ignore this email.</p>"
                        + "<p>Best Regards,<br/>The Prakriti Stay Team</p>"
                        + "</body>"
                        + "</html>"))
                .subject("Password Reset Request – Prakriti Stay OTP").build();
        ForgotPassword fp=ForgotPassword.builder().otp(otp).expirationTime(new Date(System.currentTimeMillis()+120*1000)).user(user).build();
        emailService.sendSimpleMessage(mailBody);
        forgetPasswordRepository.save(fp);
        return new ApiResponse<>(HttpStatus.OK.value(), "OTP has been sent to your mail", email);
    }

    @PostMapping("verifyOtp/{otp}/{email}")
    public ApiResponse<String> verifyOtp(@PathVariable Integer otp,@PathVariable String email) {
        User user = userRepository.findByEmail(email).orElseThrow(()-> new ResourceNotFoundException("User not found !! "));
        List<ForgotPassword> forgotPasswordList = forgetPasswordRepository.findUsers((user.getUserId()));
        forgotPasswordList.sort(Comparator.comparing(ForgotPassword::getExpirationTime).reversed());
        ForgotPassword latest = forgotPasswordList.isEmpty() ? null : forgotPasswordList.get(0);
       for(ForgotPassword fp : forgotPasswordList){
           if(fp.getExpirationTime().before(Date.from(Instant.now()))){
               forgetPasswordRepository.deleteById(fp.getId());
           }
       }
            if (latest.getOtp() == otp) {
                return new ApiResponse<>(HttpStatus.OK.value(), "OTP Verified ", "OTP was Verified ");
            }else{
                throw new RuntimeException("OTP Not Valid ! ");
            }
    }

    @PostMapping("/changePassword/{email}")
    public ApiResponse<String> changePasswordHandler(@RequestBody ChangePassword changePassword, @PathVariable String email) {
        if(!Objects.equals(changePassword.password(),changePassword.confirmPassword())) {
            try {
                throw new BadRequestException("Password and Confirm Password must be Same");
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }


        try {

            String encodedPassword=passwordEncoder.encode(changePassword.password());

                userRepository.updatePassword(email, encodedPassword);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return new ApiResponse<>(HttpStatus.OK.value(), "Password changed successfully", email);
      }

      @Authorize({"Admin"})
      @GetMapping("/getByRole")
      public ApiResponse<List<User>> getByRole(@RequestParam String Type){
        try{
            return new ApiResponse<>(HttpStatus.OK.value(),"Admins Were Fetched !! ",userService.getUserByRole(Type));
        }catch (Exception e){
            throw new RuntimeException("Error Fetching Admin");
        }
      }

//        String encodedPassword=passwordEncoder.encode(changePassword.password());
//        userRepository.updatePassword(email,encodedPassword);
//        return new ApiResponse<>(HttpStatus.OK.value(), "Password changed successfully", email);
//    }


    private Integer otpGenerator(){
        Random random=new Random();
        return random.nextInt(100000 ,999999);
    }

    @Authorize({"Admin", "Hotel_owner","User","Flight Admin"})
    @GetMapping("/getUsersByOrganization/{id}")
    public ApiResponse<List<User>> getUsersByOrganization(@PathVariable Long id) {
        List<User> users = userService.getUsersByOrganization(id);
        if (users.isEmpty()) {
            return new ApiResponse<>(HttpStatus.NO_CONTENT.value(), "No users found for this organization", null);
        }
        return new ApiResponse<>(HttpStatus.OK.value(), "Users found", users);
    }


    @GetMapping("/getSupervisorByOrgId")
    public ApiResponse<List<User>> getSupersvisors(@RequestParam long orgId,@RequestParam int roleId,@RequestHeader("Authorization") String token ){
       try{
           return new ApiResponse<>(HttpStatus.OK.value(),"Supervisors Fetched ",userService.getSupervisorByOrgid(orgId,roleId,token));
       }catch (Exception e){
           throw new RuntimeException("Fetching Supervisor Failed ");
       }
    }
}







