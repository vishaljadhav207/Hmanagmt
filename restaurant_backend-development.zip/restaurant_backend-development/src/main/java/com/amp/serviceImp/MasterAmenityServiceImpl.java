package com.amp.serviceImp;

import com.amp.dto.SearchDto;
import com.amp.entity.MasterAmenity;
import com.amp.repository.MasterAmenityRepository;
import com.amp.service.MasterAmenityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Optional;



@Service
public class MasterAmenityServiceImpl implements MasterAmenityService {

    @Autowired
    private MasterAmenityRepository masterAmenityRepo;


@Override
public SearchDto<MasterAmenity> getAllMasterAmenities(int page, int size, String sortBy, String sortDirection, String keyword) {
    try {
        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "amenityName";  // Default sort field
        }
        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default sort direction
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<MasterAmenity> masterAmenityPage;

        if (keyword != null && !keyword.isEmpty()) {
            masterAmenityPage = masterAmenityRepo.findByAmenityNameContainingIgnoreCase(keyword, pageable);
        } else {
            masterAmenityPage = masterAmenityRepo.findAll(pageable);
        }

        long totalAmenity = masterAmenityRepo.count();
        return new SearchDto<>(masterAmenityPage.getContent(), totalAmenity, page, size);

    } catch (Exception e) {
        throw new RuntimeException(e);
    }
}


    @Override
    public MasterAmenity getMasterAmenityById(int id) {
        return masterAmenityRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Master Amenity not found with id: " + id));
    }

    @Override
    public MasterAmenity createMasterAmenity(MasterAmenity masterAmenity) {
        return masterAmenityRepo.save(masterAmenity);
    }

    @Override
    public boolean deleteMasterAmenity(int id) {
        if (masterAmenityRepo.existsById(id)) {
            masterAmenityRepo.deleteById(id);
            return true;
        }
        return false;
    }

    public MasterAmenity updateMasterAmenity(int id, MasterAmenity masterAmenity) {
        Optional<MasterAmenity> existingAmenity = masterAmenityRepo.findById(id);

        if (existingAmenity.isPresent()) {
            MasterAmenity updatedAmenity = existingAmenity.get();
            updatedAmenity.setAmenityName(masterAmenity.getAmenityName()); // Update the amenity name
            // Add any other fields you want to update here.
            return masterAmenityRepo.save(updatedAmenity); // Save the updated entity
        } else {
            throw new RuntimeException("Master Amenity not found with ID " + id);
        }
    }


}
