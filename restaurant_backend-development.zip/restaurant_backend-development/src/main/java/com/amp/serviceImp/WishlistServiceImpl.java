package com.amp.serviceImp;

import com.amp.config.UserIdentityDetailsService;
import com.amp.entity.Hotel;
import com.amp.entity.User;
import com.amp.entity.Wishlist;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.HotelRepository;
import com.amp.repository.WishlistRepository;
import com.amp.service.UserService;
import com.amp.service.WishlistService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class WishlistServiceImpl implements WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private JwtUtil jwtUtil;


    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    @Override
    public Wishlist saveToWishList(Wishlist wishlist) {
        long id = userIdentityDetailsService.getUserId();
        wishlist.setUserId(id);
        Hotel hotel = hotelRepository.
                findById(wishlist.getHotelId()).orElseThrow
                        (()-> new ResourceNotFoundException("Hotel Not Found !! "));
        return wishlistRepository.save(wishlist);
    }

    @Override
    public List<Hotel> getHotelOfWish() {
        long id = userIdentityDetailsService.getUserId();
        List<Wishlist> wishlists = wishlistRepository.findByHotelId(id);
        List<Hotel> hotels = new ArrayList<>();
        for (Wishlist wishlist : wishlists){
            Hotel hotel = hotelRepository.findById(wishlist.getHotelId())
                    .orElseThrow(()-> new RuntimeException("Hotel Not Found !"));
            hotels.add(hotel);
        }
        return hotels;
    }

    @Override
    public boolean deleteWishlist(long id) {
        try{
            wishlistRepository.deleteById(id);
            return true;
        }catch(Exception e){
            throw new RuntimeException("Id not found ! ");
        }
    }

}
