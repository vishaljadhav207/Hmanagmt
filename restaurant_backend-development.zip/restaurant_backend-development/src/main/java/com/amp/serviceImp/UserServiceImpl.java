package com.amp.serviceImp;

import com.amp.client.OrganizationServiceClient;
import com.amp.config.Authorize;
import com.amp.dto.Organization;
import com.amp.dto.SearchDto;
import com.amp.entity.Role;
import com.amp.entity.User;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.RoleRepository;
import com.amp.repository.UserRepository;
import com.amp.service.UserService;
import org.checkerframework.common.aliasing.qual.Unique;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {



        @Autowired
        private UserRepository userRepository;

        @Autowired
        private RoleRepository roleRepository;

        @Autowired
        PasswordEncoder passwordEncoder;

        @Autowired
        private RestTemplate restTemplate;

    @Autowired
    private OrganizationServiceClient organizationServiceClient;

    @Value("${travel.platform.url}") // Set this in application.properties
    private String travelPlatformUrl;


    @Override
    public User registerUser(User user) throws Exception {
        try {

            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if (role == null) {
                throw new Exception("Role not found");
            }
            String encodedPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPassword);
            user.setOrgId(999l);
            user.setRole(role);
            return userRepository.save(user);

        } catch (Exception e) {

            throw new Exception("Error registering user: " + e.getMessage());
        }
    }

    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    @Override
    public boolean existsByMobile(@Unique String mobile) {
        return userRepository.existsByMobile(mobile);
    }

    @Override
    public User registerOrganizationOwner(User user) {
            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if(role == null ){
                throw new RuntimeException("role not found !");
            }
         String encodedPassword = passwordEncoder.encode(user.getPassword());
         user.setPassword(encodedPassword);
       return  userRepository.save(user);
    }


    @Override
public SearchDto<User> findAllUsers(int page, int size, String sortBy, String sortDirection, String searchTerm) {
    try {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "userId";  // Default sort by "id"
        }

        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default sort direction "asc"
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        Page<User> users;

        if (searchTerm != null && !searchTerm.isEmpty()) {

            users = userRepository.searchUsers(searchTerm, pageable);
        } else {

            users = userRepository.findAll(pageable);
        }

        long totalUsers = userRepository.count();
        return new SearchDto<>(users.getContent(), totalUsers, page, size);

    } catch (Exception e) {
        throw new RuntimeException("Error retrieving users: " + e.getMessage());
    }
}


    @Override
    public User findUserById(long id) {
        User user = userRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("User not found with  ! " + id));
        return user;
    }


    @Override
    public void deleteUserById(long id) {

         userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));

        userRepository.deleteById(id);
    }

    @Override
    public User updateUser(long id, User userDetails) {
        User user = userRepository.findById(id).
                orElseThrow(() -> new ResourceNotFoundException("User Not Found with id: !" + id));
        user.setFirstName(userDetails.getFirstName());
        user.setLastName(userDetails.getLastName());
        user.setMobile(userDetails.getMobile());

        return userRepository.save(user);
    }


    @Override
    public List<User> getUsersByOrganization(Long orgId) {
        // Verify organization exists using RestTemplate
        String url = travelPlatformUrl+"/api/organizations/getById/" + orgId;
        ResponseEntity<Void> response = restTemplate.getForEntity(url, Void.class);

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new ResourceNotFoundException("Organization not found");
        }

        return userRepository.findByOrgId(orgId);
    }


    @Override
    public User registerOwner(User user) {
        try {

            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if (role == null) {
                throw new Exception("Role not found");
            }
            String encodedPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPassword);
            user.setRole(role);
            return userRepository.save(user);

        } catch (Exception e) {

            throw new RuntimeException("Error registering user: " + e.getMessage());
        }
    }
    @Override
    public User registertrainsupervisor(User user) {
        try {

            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if (role == null) {
                throw new Exception("Role not found");
            }
            String encodedPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPassword);
            user.setRole(role);
            return userRepository.save(user);

        } catch (Exception e) {

            throw new RuntimeException("Error registering user: " + e.getMessage());
        }
    }

    @Override
    public User registerflightsupervisor(User user) {
        try {

            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if (role == null) {
                throw new Exception("Role not found");
            }
            String encodedPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPassword);
            user.setRole(role);
            return userRepository.save(user);

        } catch (Exception e) {

            throw new RuntimeException("Error registering user: " + e.getMessage());
        }
    }

    @Override
    public User registerbussupervisor(User user) {
        try {

            Role role = roleRepository.findByRoleId(user.getRole().getRoleId());
            if (role == null) {
                throw new Exception("Role not found");
            }
            String encodedPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPassword);
            user.setRole(role);
            return userRepository.save(user);

        } catch (Exception e) {

            throw new RuntimeException("Error registering user: " + e.getMessage());
        }
    }

    @Override
    public List<User> getUserByRole(String Type) {
        try {
            if (Type.equalsIgnoreCase("RAILWAY")) {
                return userRepository.getTrainAdmin();
            } else if (Type.equalsIgnoreCase("AIRLINE")) {
                return userRepository.getFlightAdmin();
            } else if (Type.equalsIgnoreCase("BUS_OPERATOR")) {
                return userRepository.getBusAdmin();
            }
        }catch(Exception e){
            throw new RuntimeException("User Not FOUND ");
        }
        throw new RuntimeException("User List Was Empty !! ");
    }


    @Override
    public List<User> getSupervisorByOrgid(long orgId,int roleId,String token) {
        Organization organization = organizationServiceClient.getOrganizationById(orgId,token);
        if(organization == null ){
            throw new RuntimeException("Organization Not Found ");
        }
      List<User> users = userRepository.findByOrgIdAndRole_RoleId(orgId,roleId);
      if(users.isEmpty()){
          throw new RuntimeException("Cannot Found Users !! ");
      }else{
          return users ;
      }

    }

}
