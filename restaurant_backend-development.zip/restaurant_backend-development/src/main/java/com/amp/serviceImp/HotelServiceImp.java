package com.amp.serviceImp;


import com.amp.entity.*;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.*;
import com.amp.dto.SearchDto;
import com.amp.entity.Hotel;
import com.amp.entity.MasterAmenity;
import com.amp.entity.Ratings;
import com.amp.entity.User;
import com.amp.repository.HotelRepository;
import com.amp.repository.MasterAmenityRepository;
import com.amp.repository.RatingsRepo;
import com.amp.repository.UserRepository;
import com.amp.service.HotelService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class HotelServiceImp implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private MasterAmenityRepository masterAmenityRepo;

    @Autowired
    private RatingsRepo ratingsRepo;

    @Autowired
    private ActualBookRepo actualBookRepo;

    @Autowired
    private RoomsRepository roomsRepository;

    @Override
    public Hotel saveHotelInfo(Hotel hotel) {
        try {

            // Fetch and set hotel owner
            if (hotel.getHotelOwner() != null && hotel.getHotelOwner().getUserId() != 0) {
                User hotelOwner = userRepo.findById(hotel.getHotelOwner().getUserId())
                        .orElseThrow(() -> new RuntimeException("Hotel Owner not found with id: " + hotel.getHotelOwner().getUserId()));

                // Check if the owner already has a hotel associated with them
                List<Hotel> existingHotels = hotelRepository.findByHotelOwner(hotelOwner);
                if (!existingHotels.isEmpty()) {
                    throw new RuntimeException("This hotel owner is already associated with another hotel.");
                }
                hotel.setHotelOwner(hotelOwner);
            }

            Set<MasterAmenity> amenities = new HashSet<>();
            for (Integer amenityId : hotel.getAmenityIds()) {
                MasterAmenity existingAmenity = masterAmenityRepo.findById(amenityId)
                        .orElseThrow(() -> new RuntimeException("Master Amenity not found with id: " + amenityId));
                amenities.add(existingAmenity);
            }
            hotel.setAmenities(amenities);
            Hotel hotel1 = hotelRepository.save(hotel);
            return hotel1;
        } catch (Exception e) {
            e.printStackTrace();  // Log the exception to understand the error
            throw new RuntimeException("Failed to save hotel", e);
        }
    }



    @Override
    public Hotel findHotelById(int id) {
        Hotel hotel =  hotelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Hotel not found with id: " + id));

        List<Ratings> ratings = ratingsRepo.findByHotelId(hotel.getHotelId());
        int sum = 0 ;
        int userCount = 0 ;
        for(Ratings r : ratings){
            sum = sum + r.getRating();
            userCount++;
        }
        if(userCount > 0){
            hotel.setHotelRatings(sum/userCount);
        }else{
            hotel.setHotelRatings(0);
        }

        return hotel;
    }


    @Override
    public SearchDto<Hotel> getAll(int page, int size, String sortBy, String sortDirection, int roomsNeeded, String city) {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "hotelId";  // Default sort by hotelId
        }

        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default to ascending order
        }

        // Set the sorting direction
        Sort sort = sortDirection.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);


        Page<Hotel> hotels = hotelRepository.searchHotels(roomsNeeded == 0 ? -1 : roomsNeeded,
                city.isEmpty() ? null : city,
                pageable);

        long totalHotels = hotelRepository.count();


        for (Hotel hotel : hotels) {
            List<Ratings> ratings = ratingsRepo.findByHotelId(hotel.getHotelId());
            int sum = 0;
            int userCount = 0;
            for (Ratings r : ratings) {
                sum += r.getRating();
                userCount++;
            }
            hotel.setHotelRatings(userCount > 0 ? sum / userCount : 0);
        }

        return new SearchDto<>(hotels.getContent(), totalHotels, page, size);
    }

    @Transactional
    @Override
    public void deletehotelWithRooms(int id) {
        try{
            roomsRepository.deleteRoomsByHotelId(id);

            hotelRepository.deleteHotelId(id);

        }catch(Exception e){
            throw new RuntimeException("Failed to delete hotel ! ");
        }
    }


    @Override
    public Hotel updateHotel(int id, Hotel hotel) {
        if (hotelRepository.existsById(id)) {
            Hotel existingHotel = hotelRepository.findById(id).orElseThrow(() ->
                    new RuntimeException("Hotel not found for update with id: " + id));

            existingHotel.setHotelName(hotel.getHotelName());
            existingHotel.setHotelAdd(hotel.getHotelAdd());
            existingHotel.setHotelDes(hotel.getHotelDes());
            existingHotel.setLatitude(hotel.getLatitude());
            existingHotel.setLongitude(hotel.getLongitude());
            existingHotel.setHotelRooms(hotel.getHotelRooms());

            // Fetch the amenities by their IDs
            Set<MasterAmenity> amenities = new HashSet<>();
            for (Integer amenityId : hotel.getAmenityIds()) {
                MasterAmenity existingAmenity = masterAmenityRepo.findById(amenityId)
                        .orElseThrow(() -> new RuntimeException("Master Amenity not found with id: " + amenityId));
                amenities.add(existingAmenity);
            }

            // Set the amenities for the hotel
            existingHotel.setAmenities(amenities);

            // Save the updated hotel with its amenities
            return hotelRepository.save(existingHotel);
        } else {
            throw new RuntimeException("Hotel not found for update with id: " + id);
        }
    }

    @Override
    public List<Hotel> findByCityEqualsIgnoreCase(String City , int hotelRooms) {
        try {
            List<Hotel> hotel =  hotelRepository.findByCityEqualsIgnoreCase(City);
            List<Hotel> Hotel = new ArrayList<>();
            for(Hotel hotel1 : hotel){
                if(hotel1.getHotelRooms() >= hotelRooms){
                    Hotel.add(hotel1);
                }
            }
            return Hotel;
        }catch(Exception e){
            throw new ResourceNotFoundException("Hotel Was Not Found ! ");
        }
    }
    @Override
    public List<Hotel> findHotelsByUserId(long userId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        // Return all hotels owned by the specified user
        return hotelRepository.findByHotelOwner(user);
    }

    @Override
    public Set<String> getAllHotelLocation() {
        List<Hotel> hotel = hotelRepository.findAll();
        Set<String> location = new HashSet<>();
        for(Hotel hotel1 : hotel){
            String local = hotel1.getCity().toLowerCase();
            location.add(local);
        }
        return location;
    }
    @Override
    public Set<MasterAmenity> getAmenitiesByHotelId(int hotelId) {

        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found with ID: " + hotelId));
        return hotel.getAmenities(); // Return associated amenities
    }

    @Transactional
    @Override
    public boolean deleteAmenityByHotelId(int hotelId , int AmenityId) {
       Hotel hotel = hotelRepository.findById(hotelId).orElseThrow(()-> new RuntimeException("Hotel Not Found ! "));
       try {
           Set<MasterAmenity> amenities = hotel.getAmenities();
           for(MasterAmenity amenity : amenities){
               if(amenity.getId() == AmenityId){
                  amenities.remove(amenity);
                  break;
               }
           }
           hotelRepository.save(hotel);
           return true;
       }catch(Exception e){
           throw new RuntimeException("Deletion failed ");
       }
    }

    @Override
    public Set<MasterAmenity> addAmenitiesToHotel(int hotelId, List<Integer> amenityIds) {

        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found with ID: " + hotelId));

        // Find all amenities by IDs
        Set<MasterAmenity> amenities = new HashSet<>(masterAmenityRepo.findAllById(amenityIds));

        // Add amenities to hotel
        hotel.getAmenities().addAll(amenities);
        hotelRepository.save(hotel);

        return hotel.getAmenities();
    }

    @Override
    public Set<MasterAmenity> updateAmenitiesByHotelId(int hotelId, List<Integer> amenityIds) {

        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new RuntimeException("Hotel not found with ID: " + hotelId));

        // Find all amenities by IDs
        Set<MasterAmenity> amenities = new HashSet<>(masterAmenityRepo.findAllById(amenityIds));

        // Update amenities of hotel
        hotel.setAmenities(amenities);
        hotelRepository.save(hotel);

        return hotel.getAmenities();
    }
}
