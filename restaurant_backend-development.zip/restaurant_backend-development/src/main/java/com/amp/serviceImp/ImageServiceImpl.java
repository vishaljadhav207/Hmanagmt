package com.amp.serviceImp;

import com.amp.entity.Hotel;
import com.amp.entity.Images;
import com.amp.entity.Rooms;
import com.amp.repository.HotelRepository;
import com.amp.repository.ImageRepository;
import com.amp.repository.RoomsRepository;
import com.amp.service.ImageService;
import io.jsonwebtoken.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

@Service
public class ImageServiceImpl implements ImageService {


    @Autowired
    private ImageRepository imageRepository;

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private RoomsRepository roomsRepository;

    private final Path image1 = Path.of("src/main/resources/static/image/hotel");
    private final Path image2 = Path.of("src/main/resources/static/image/room");


    public Images saveImage(MultipartFile imageFile,Hotel hotel,Rooms room) throws IOException, java.io.IOException {

        if (hotel == null && room == null) {
            throw new IllegalArgumentException("Both hotel and room cannot be null");
        }
        String imageName =  imageFile.getOriginalFilename();

        Images image = new Images();
        image.setImageName(imageName);


        if (hotel != null) {
            Files.createDirectories(image1);
            Path targetLocation1 = image1.resolve(imageName);
            Files.copy(imageFile.getInputStream(), targetLocation1, StandardCopyOption.REPLACE_EXISTING);
            image.setImageUrl(targetLocation1.toString());
            image.setHotel(hotel);
        }

        if (room != null) {
            Files.createDirectories(image2);
            Path targetLocation2 = image2.resolve(imageName);
            Files.copy(imageFile.getInputStream(), targetLocation2, StandardCopyOption.REPLACE_EXISTING);
            image.setImageUrl(targetLocation2.toString());
            image.setRoom(room);
        }

         imageRepository.save(image);

        return image;
    }

    @Override
    public void deleteImageById(int id) {
        imageRepository.deleteById(id);

    }

    @Override
    public Images getImageById(int imageId) {
        return imageRepository.findById(imageId).orElse(null);

    }
        @Override
        public List<Images> getImagesByHotelAndRoom(Integer hotelId, Integer roomId) {
            List<Images> images = new ArrayList<>();

            if (hotelId != null && roomId != null) {
                Hotel hotel = hotelRepository.findById(hotelId)
                        .orElseThrow(() -> new IllegalArgumentException("Hotel not found with ID " + hotelId));
                Rooms room = roomsRepository.findById(roomId)
                        .orElseThrow(() -> new IllegalArgumentException("Room not found with ID " + roomId));

                images = imageRepository.findByHotelAndRoom(hotel, room);
            }

            else if (hotelId != null && roomId == null) {
                Hotel hotel = hotelRepository.findById(hotelId)
                        .orElseThrow(() -> new IllegalArgumentException("Hotel not found with ID " + hotelId));

                images = imageRepository.findByHotelAndRoomIsNull(hotel);
            }

            else if (roomId != null && hotelId == null) {
                Rooms room = roomsRepository.findById(roomId)
                        .orElseThrow(() -> new IllegalArgumentException("Room not found with ID " + roomId));
                images = imageRepository.findByRoomAndHotelIsNull(room);
            }

            return images;
        }
    }



