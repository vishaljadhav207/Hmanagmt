package com.amp.serviceImp;

import com.amp.dto.MailBody;
import com.amp.entity.ContactMessage;
import com.amp.repository.ContactMessageRepository;
import com.amp.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ContactMessageServiceImpl implements ContactMessageService {

    @Autowired
    private ContactMessageRepository contactMessageRepository;
    @Autowired
    private EmailServiceImpl emailService;

    @Override
    public ContactMessage saveMessage(ContactMessage message) {
        return contactMessageRepository.save(message);
    }

    @Override
    public List<ContactMessage> getAllMessages() {
        return contactMessageRepository.findAll();
    }

    @Override
    public ContactMessage updateReplyAndSendEmail(String email, String reply) {
        Optional<ContactMessage> optionalMessage = contactMessageRepository.findByEmail(email);
        if (optionalMessage.isPresent()) {
            ContactMessage message = optionalMessage.get();
            message.setAdminReply(reply);
            message.setReplied(true);
            ContactMessage updatedMessage = contactMessageRepository.save(message);

            // Send reply email to the user
            sendReplyEmail(message, reply);

            return updatedMessage;
        }
        return null; // Message not found
    }

    private void sendReplyEmail(ContactMessage message, String reply) {
        String emailContent = "<html>" +
                "<body>" +
                "<p>Dear " + message.getName() + ",</p>" +
                "<p>We are responding to your inquiry. Here is our reply:</p>" +
                "<p><strong>Admin's Reply:</strong> " + reply + "</p>" +
                "<p>Thank you for reaching out to us. If you have any further questions, feel free to reply to this email.</p>" +
                "<p>Best regards,<br/>The Team</p>" +
                "</body>" +
                "</html>";

        // Use MailBody DTO to create the email body
        MailBody mailBody = MailBody.builder()
                .to(message.getEmail())
                .subject("Response to Your Contact Message")
                .text(emailContent)
                .build();

        // Send the email using the existing email service
        emailService.sendSimpleMessage(mailBody);
    }

    @Override
    public void deleteMessage(Long id) {
        contactMessageRepository.deleteById(id);
    }
}
