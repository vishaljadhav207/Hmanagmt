package com.amp.serviceImp;

import com.amp.config.UserIdentityDetailsService;
import com.amp.dto.MailBody;
import com.amp.dto.SearchDto;
import com.amp.dto.UserIdentityDetails;
import com.amp.entity.*;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.*;
import com.amp.service.ActualBookService;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ActualBookImpl implements ActualBookService {

    @Autowired
    private ActualBookRepo actualBookRepo;

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private RoomsRepository roomsRepository;

    @Autowired
    private GuestRepository guestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailServiceImpl emailService;

    @Autowired
    private UserIdentityDetailsService userIdentityDetailsService;

    @Override
    public ActualBooking addRecord(ActualBooking actualBooking) {
        try {
           long userId = userIdentityDetailsService.getUserId();
           actualBooking.setUserId(userId);

            List<Guest> guest = new ArrayList<>();
            for (Guest guestt : actualBooking.getGuest()) {

                boolean isValid = validateGovId(guestt.getGovIdType(),guestt.getGovIdNumber());
                if(!isValid){
                    throw new RuntimeException("Goverment Id Format do not match for :" + guestt.getGovIdType());
                }
                guestt.setActualBooking(actualBooking);
                guest.add(guestt);
            }
            actualBooking.setGuest(guest);


            Hotel hotel = hotelRepository.findById(actualBooking.getHotelId())
                    .orElseThrow(()-> new RuntimeException("Hotel Id not Found !! "));
            actualBooking.setHotelName(hotel.getHotelName());
            actualBooking.setHotelAddress(hotel.getHotelAdd());

            User user = userRepository.findById(actualBooking.getUserId())
                    .orElseThrow(()-> new RuntimeException("User Id not Found !! "));
            actualBooking.setEmail(user.getEmail());
            actualBooking.setMobile(user.getMobile());
            actualBooking.setFirstName(user.getFirstName());
            actualBooking.setLastName(user.getLastName());


            List<Rooms> rooms = roomsRepository.findRoomsByHotelId(actualBooking.getHotelId());
            for(Rooms room : rooms){
                if(actualBooking.getRoomType().trim().equalsIgnoreCase(room.getRoomType())){
                    actualBooking.setRoomId(room.getRoomId());
                    actualBooking.setAvailableRooms(room.getNumberOfRooms());

                    if (actualBooking.getPaymentMethod().trim().equalsIgnoreCase("Upi")) {
                        actualBooking.setPaymentStatus("Done");
                        actualBooking.setStatus(BookingStatus.BOOKED);// Set status to Booked
                        MailBody mailBody = MailBody.builder().to(user.getEmail()).text("<html>" +
                                "<body>" +
                                "<p>Dear " + user.getFirstName() + ",</p>" +
                                "<p>We are pleased to confirm your booking with us! Thank you for choosing our service. Your booking details are as follows:</p>" +
                                "<p><strong>Booking Details:</strong></p>" +
                                "<ul>" +
                                "<li><strong>Hotel Name:</strong> " +hotel.getHotelName() + "</li>" +
                                "<li><strong>Room Type:</strong> " + room.getRoomType() + "</li>" +
                                "<li><strong>Check-in Date:</strong> " + actualBooking.getCheckInDate() + "</li>" +
                                "<li><strong>Check-out Date:</strong> " + actualBooking.getCheckOutDate() + "</li>" +
                                "<li><strong>Status:</strong> Confirmed</li>" +
                                "</ul>" +
                                "<p>If you need to make any changes or have any questions about your booking, please don't hesitate to reach out to us.</p>" +
                                "<p> <strong> TollFree Number : " +1800+" "+2011+
                                "<p>We look forward to welcoming you to Prakriti Stay and ensuring you have a pleasant stay!</p>" +
                                "<p>Best regards,<br/>" +
                                "The Prakriti Stay Team</p>" +
                                "</body>" +
                                "</html>"

                        ).subject("Booking Details With Prakriti Stay ").build();
                        emailService.sendSimpleMessage(mailBody);
                        Rooms rooms1 = roomsRepository.findById(room.getRoomId()).orElseThrow(()-> new RuntimeException("room not found ! "));
                        rooms1.setNumberOfRooms(rooms1.getNumberOfRooms()- actualBooking.getRoomsNeeded());
                        hotel.setHotelRooms(hotel.getHotelRooms()-actualBooking.getRoomsNeeded());
                        if( rooms1.getNumberOfRooms() < 0){
                            throw new RuntimeException("Could not process booking , All rooms Booked ! ");
                        }
                    } else {
                        actualBooking.setPaymentStatus("Pending");
                        actualBooking.setStatus(BookingStatus.PENDING);  // Set status to Pending
                    }
                }
            }

            return actualBookRepo.save(actualBooking);
        } catch (Exception e) {
            throw new RuntimeException("Record not saved !! " + e.getMessage());
        }
    }

    @Override
    public SearchDto<ActualBooking> getAllRecords(
            int page, int size, String sortBy, String sortDirection,
            Long userId, String city, LocalDate checkInDate,
            LocalDate checkOutDate, BookingStatus status, String firstName) {
        try {
            Sort sort = Sort.unsorted();
            if (sortBy != null && !sortBy.isEmpty()) {
                sort = (sortDirection != null && sortDirection.equalsIgnoreCase("desc"))
                        ? Sort.by(sortBy).descending()
                        : Sort.by(sortBy).ascending();
            }

            Pageable pageable = PageRequest.of(page, size, sort);

            // Convert status enum to ordinal value (integer)
            Integer statusOrdinal = status != null ? status.ordinal() : null;

            Page<ActualBooking> actualBookings = actualBookRepo.searchBookings(
                    userId,
                    city,
                    checkInDate,
                    checkOutDate,
                    statusOrdinal,
                    firstName,
                    pageable);

            return new SearchDto<>(
                    actualBookings.getContent(),
                    actualBookings.getTotalElements(),
                    page,
                    size
            );
        } catch (Exception e) {
            throw new ResourceNotFoundException("Records Not Found!!");
        }
    }

    public List<Guest> getGuestByBookingId(int id) {
        try {
            return actualBookRepo.findGuestsByBookingId(id);
        } catch (Exception e) {
            throw new ResourceNotFoundException("List Was Not Found ");
        }
    }

    @Override
    public List<ActualBooking> getBookingHistoryByUserId(long userId) {
        try {

            return actualBookRepo.findByUserId(userId);
        } catch (Exception e) {
            throw new ResourceNotFoundException("No bookings found for user with id " + userId);
        }
    }

    @Override
    public ActualBooking updateBookingStatus(int BookingId, String action, String status, String remark, long userId) {
        try {
            ActualBooking booking = actualBookRepo.findById(BookingId)
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id " + BookingId));
            User user = userRepository.findById(booking.getUserId()).orElseThrow(()-> new ResourceNotFoundException("User not found ! "));
            Hotel hotel = hotelRepository.findById(booking.getHotelId())
                    .orElseThrow(() -> new ResourceNotFoundException("Hotel not found with id " + booking.getHotelId()));

            if (booking.getUserId() == userId) {
                if ("cancel".equalsIgnoreCase(action)) {
                    if (booking.getStatus() == BookingStatus.CANCELLED) {
                        throw new RuntimeException("This booking is already canceled.");
                    }
                    booking.setStatus(BookingStatus.CANCELLED);
                    booking.setRemark(remark);
                    MailBody mailBody = MailBody.builder().to(user.getEmail()).text("<html>" +
                            "<body>" +
                            "<p>Dear " + user.getFirstName() + ",</p>" +
                            "<p>We wanted to inform you that your booking with ID <strong>" + booking.getBookingId() + "</strong> has been successfully canceled. " +
                            "If you did not request this cancellation, please contact our support team immediately.</p>" +
                            "<p><strong>Booking Details:</strong></p>" +
                            "<ul>" +
                            "<li><strong>Booking ID:</strong> " + booking.getBookingId() + "</li>" +
                            "<li><strong>Status:</strong> Canceled</li>" +
                            "<li><strong>Remark:</strong> " + remark + "</li>" +
                            "</ul>" +
                            "<p>If you need any further assistance, please feel free to reach out.</p>" +
                            "<p> <strong> Toll Free Number : " + 1800+" "+2011 +
                            "<p>Thank you for choosing our service.</p>" +
                            "<p>Best regards,<br/>" +
                            "The Prakriti Stay Team</p>" +
                            "</body>" +
                            "</html>"

                    ).subject("Cancellation Confirm ! ").build();

                    emailService.sendSimpleMessage(mailBody);
                } else {
                    throw new RuntimeException("Invalid action for the user.");
                }
            } else if (hotel.getHotelOwner().getUserId() == userId) {
                switch (action.toLowerCase()) {

                    case "reject":
                        if (booking.getStatus() == BookingStatus.CANCELLED) {
                            throw new RuntimeException("There is no booking to reject.");
                        }
                        if (booking.getStatus() == BookingStatus.REJECTED) {
                            throw new RuntimeException("The booking has already been rejected.");
                        }
                        if (remark == null || remark.isEmpty()) {
                            throw new RuntimeException("Remark is required when rejecting a request.");
                        }
                        if(booking.getStatus() == BookingStatus.BOOKED) {
                            booking.setStatus(BookingStatus.REJECTED);
                            MailBody mailBody = MailBody.builder().to(user.getEmail()).text(
                                    "<html>" +
                                            "<body>" +
                                            "<p>Dear " + user.getFirstName() + ",</p>" +
                                            "<p>We regret to inform you that we are unable to process your booking with ID <strong>" + booking.getBookingId() + "</strong> at this time. Due to unforeseen circumstances, the room you requested is no longer available.</p>" +
                                            "<p><strong>Booking Details:</strong></p>" +
                                            "<ul>" +
                                            "<li><strong>Booking ID:</strong> " + booking.getBookingId() + "</li>" +
                                            "<li><strong>Status:</strong> Rejected</li>" +
                                            "<li><strong>Reason:</strong> Due to personal reasons or Due to Some Technical Error .</li>" +
                                            "</ul>" +
                                            "<p>We sincerely apologize for any inconvenience this may have caused and hope to have the opportunity to serve you in the future. Please feel free to reach out to us for any clarifications or further assistance.</p>" +
                                            "<p>If you have any further questions or if you'd like to make a new booking, don't hesitate to contact us.</p>" +
                                            "<p>Thank you for your understanding, and we hope to welcome you in the future.</p>" +
                                            "<p>Best regards,<br/>" +
                                            "The Prakriti Stay Team</p>" +
                                            "</body>" +
                                            "</html>"
                            ).subject("Booking Rejected ! ").build();
                            emailService.sendSimpleMessage(mailBody);
                        }else {
                            throw new RuntimeException("cannot be Rejected");
                        }
                        booking.setRemark(remark);
                        break;

                    case "checkin":
                        if (booking.getStatus() == BookingStatus.CANCELLED) {
                            throw new RuntimeException("Cannot check-in, the booking is canceled.");
                        }
                        if (booking.getStatus() == BookingStatus.CHECKED_IN) {
                            throw new RuntimeException("The booking has already been checked in.");
                        }
                        if (booking.getStatus() == BookingStatus.REJECTED) {
                            throw new RuntimeException("Cannot check-in, the booking is Rejected.");
                        }
                        booking.setStatus(BookingStatus.CHECKED_IN);
                        break;

                    case "checkout":
                        if (booking.getStatus() == BookingStatus.CHECKED_OUT) {
                            throw new RuntimeException("The booking has already been checked out.");
                        }
                        if (booking.getStatus() != BookingStatus.CHECKED_IN) {
                            throw new RuntimeException("Cannot check out, the booking has not been checked in.");
                        }

                        booking.setStatus(BookingStatus.CHECKED_OUT);
                        ActualBooking actualBooking = actualBookRepo.findById(BookingId).
                                orElseThrow(()-> new RuntimeException("Booking Id not found ! "));
                        Hotel hotel1 = hotelRepository.findById(actualBooking.getHotelId()).
                                orElseThrow(()-> new RuntimeException("Hotel id not found "));
                        hotel1.setHotelRooms(actualBooking.getRoomsNeeded()+hotel1.getHotelRooms());
                        Rooms rooms = roomsRepository.findById(actualBooking.getRoomId()).
                                orElseThrow(()-> new ResourceNotFoundException("Room Not found ! "));
                        rooms.setNumberOfRooms(actualBooking.getRoomsNeeded()+ rooms.getNumberOfRooms());
                        break;

                    default:
                        throw new RuntimeException("Invalid action for the hotel owner.");
                }
            } else {
                throw new RuntimeException("You do not have permission to update this booking.");
            }

            booking.setStatus(BookingStatus.valueOf(status));

            return actualBookRepo.save(booking);
        } catch (Exception e) {
            throw new RuntimeException("Error updating booking status: " + e.getMessage());
        }
    }

    @Override
    public SearchDto<ActualBooking> getBookingByHotelId(int page , int size ,
                                                        String sortBy , String sortDirection,
                                                        int hotelId) {
        try {
            Sort sort = Sort.unsorted();
            if (sortBy != null && !sortBy.isEmpty()) {
                sort = (sortDirection != null && sortDirection.equalsIgnoreCase("desc"))
                        ? Sort.by(sortBy).descending()
                        : Sort.by(sortBy).ascending();
            }
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<ActualBooking> actualBookings = actualBookRepo.bookingByHotelId(hotelId , pageable);
            return new SearchDto<>(
                    actualBookings.getContent(),
                    actualBookings.getTotalElements(),
                    page,
                    size
            );
        }catch (Exception e){
          throw new RuntimeException("Records Were Not Fetched !! ");
        }
    }

    private boolean validateGovId(String govIdType, String govIdNumber) {
        if (govIdNumber == null || govIdNumber.isEmpty()) {
            return false;
        }

        switch (govIdType.trim().toLowerCase()) {
            case "aadhar":
                return govIdNumber.matches("^[0-9]{12}$");
            case "passport":
                return govIdNumber.matches("^[A-PR-WY][1-9]\\d{7}$");
            case "driving license":
                return govIdNumber.matches("^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$");
            case "voter id":
                return govIdNumber.matches("^[A-Z]{2}[0-9]{8}$");
            default:
                return false;
        }
    }


}





