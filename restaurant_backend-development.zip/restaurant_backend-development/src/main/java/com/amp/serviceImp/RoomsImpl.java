package com.amp.serviceImp;

import com.amp.dto.RoomsUpdateDTO;
import com.amp.dto.SearchDto;
import com.amp.entity.Hotel;
import com.amp.entity.Rooms;
import com.amp.exception.ResourceNotFoundException;
import com.amp.repository.HotelRepository;
import com.amp.repository.ImageRepository;
import com.amp.repository.RoomsRepository;
import com.amp.service.RoomsService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomsImpl implements RoomsService {
    @Autowired
    private RoomsRepository roomsRepository;

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private ImageRepository imagesRepository;


    @Override
    public Rooms addRoom(Rooms rooms) {
        Hotel hotel = hotelRepository.findById(rooms.getHotel().getHotelId()).
                orElseThrow(()-> new ResourceNotFoundException("Hotel Not Found !! "));
        if(rooms.getNumberOfRooms() > hotel.getHotelRooms()){
            throw new RuntimeException("Rooms size exceeded than hotel Rooms ");
        }

        List<Rooms> room = roomsRepository.findRoomsByHotelId(hotel.getHotelId());
        int validRooms = hotel.getHotelRooms();
        int addedRooms = 0 ;
        for(Rooms rooms1 : room){
            addedRooms += rooms1.getNumberOfRooms();
        }
        if(addedRooms >= validRooms || rooms.getNumberOfRooms()+addedRooms > validRooms){
            throw new RuntimeException("Maximum Number Of Rooms Have been Added to the Hotel ! ");
        }
        rooms.setHotel(hotel);
        return roomsRepository.save(rooms);
    }

@Override
public SearchDto<Rooms> getAllRooms(int page, int size, String sortBy, String sortDirection, String roomType, Integer hotelId, Integer minRoomBasePrice, Integer maxRoomBasePrice) {
    try {

        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "roomId";  // Default sorting field
        }
        if (sortDirection == null || sortDirection.isEmpty()) {
            sortDirection = "asc";  // Default sorting direction
        }

        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);


        Page<Rooms> rooms = roomsRepository.searchRooms(roomType, hotelId, minRoomBasePrice, maxRoomBasePrice, pageable);
        long totalRooms = roomsRepository.count();
        return new SearchDto<>(rooms.getContent(), totalRooms, page, size);
    } catch (Exception e) {
        throw new RuntimeException("Error fetching rooms: " + e.getMessage());
    }
}


    @Override
    @Transactional
    public boolean deleteRoomsById(int roomId) {
        if (!roomsRepository.existsById(roomId)) {
            throw new RuntimeException("Room with ID " + roomId + " not found");
        }

        // Step 1: Delete all images linked to this room (including those that reference a hotel)
        imagesRepository.deleteByRoom_RoomIdAndHotelIsNotNull(roomId); // 👈 for hotel-linked images
        imagesRepository.deleteByRoom_RoomId(roomId);                  // 👈 general room images

        // Step 2: Delete the room itself
        roomsRepository.deleteById(roomId);

        return true;
    }



    @Override
    public Rooms updateRoomsById(int id, RoomsUpdateDTO dto) {
        try {
            Rooms existingRoom = roomsRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Room with ID " + id + " not found"));

            if (dto.getRoomType() != null) {
                existingRoom.setRoomType(dto.getRoomType());
            }
            if (dto.getRoomBasePrice() != null) {
                existingRoom.setRoomBasePrice(dto.getRoomBasePrice());
            }
            if (dto.getNumberOfRooms() != null) {
                existingRoom.setNumberOfRooms(dto.getNumberOfRooms());
            }

            return roomsRepository.save(existingRoom);
        } catch (Exception e) {
            throw new RuntimeException("Room update failed: " + e.getMessage(), e);
        }
    }



    @Override
    public List<Rooms> getRoomsByHotelId(int hotelId) {
        try {
            return roomsRepository.findRoomsByHotelId(hotelId);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching rooms for hotel with ID " + hotelId, e);
        }
    }
    @Override
    public Boolean deleteRoomsByHotelId(int hotelId) {
        try {

            List<Rooms> rooms = roomsRepository.findRoomsByHotelId(hotelId);
            if (rooms.isEmpty()) {
                throw new RuntimeException("No rooms found for hotel with ID " + hotelId);
            }
            roomsRepository.deleteAll(rooms);
            return true;
        } catch (Exception e) {
            throw new RuntimeException("Error deleting rooms for hotel with ID " + hotelId, e);
        }
    }

}
