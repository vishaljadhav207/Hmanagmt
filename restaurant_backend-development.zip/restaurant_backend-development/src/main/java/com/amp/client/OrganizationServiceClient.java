package com.amp.client; // Adjust the package as needed

import com.amp.dto.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;

@Service
public class OrganizationServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    private final String ORGANIZATION_SERVICE_BASE_URL = "http://localhost:8081";

    public Organization getOrganizationById(Long orgId,String token) {
        if (orgId == null) {
            return null;
        }
        String url = ORGANIZATION_SERVICE_BASE_URL + "/api/organizations/getById/" + orgId;

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION,token);
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<Organization> response = restTemplate.exchange(url, HttpMethod.GET,entity, Organization.class);
            return response.getBody();
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        } catch (Exception e) {
            System.err.println("Error calling Organization Service: " + e.getMessage());
            return null;
        }
    }
}
