package com.amp.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateBookingStatusDto {
    @NotNull(message = "BookingId cannot be null")
    private Integer bookingId;

    @NotEmpty(message = "Action cannot be empty")
    private String action;

    private String remark;
}
