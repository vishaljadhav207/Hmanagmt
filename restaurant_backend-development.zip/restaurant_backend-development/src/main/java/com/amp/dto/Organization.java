package com.amp.dto;

import lombok.Data;

@Data
public class Organization {
    private Long orgId;
    private String type;
    private String orgName;
    private Long userId;
}