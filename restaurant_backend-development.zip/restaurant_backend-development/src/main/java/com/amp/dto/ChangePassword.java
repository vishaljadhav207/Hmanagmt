package com.amp.dto;

public record ChangePassword(String password, String confirmPassword) {

}
