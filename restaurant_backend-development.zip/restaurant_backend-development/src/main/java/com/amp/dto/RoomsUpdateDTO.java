package com.amp.dto;

import lombok.Data;

@Data
public class RoomsUpdateDTO {

    private String roomType;
    private Integer roomBasePrice;
    private Integer numberOfRooms;
}
