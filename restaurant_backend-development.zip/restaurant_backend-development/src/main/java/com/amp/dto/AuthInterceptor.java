package com.amp.dto;

import com.amp.config.Authorize;
import com.amp.utilis.jwt.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.management.RuntimeMBeanException;
import java.nio.file.AccessDeniedException;
import java.util.Arrays;
import java.util.List;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
        if(!(handler instanceof HandlerMethod)){
            return true ;
        }

        String path = request.getRequestURI();
        if (path.matches("/api/user/login") ||
                path.matches("/api/user/register")
                || path.matches("/api/user/verifyOtp/.*")
                || path.matches("/api/user/verifyEmail/.*")
                || path.matches("/api/user/changePassword/.*")
                || path.matches("/api/user/HotelOwner/register")
                || path.matches("/api/user/OrgOwner/register")
//                || path.matches("/api/user/trainSupervisor/register")
//                || path.matches("/api/user/flightSupervisor/register")
//                || path.matches("/api/user/busSupervisor/register")
                || path.matches("/api/user/users/.*")
              ||path.startsWith("/api/images/")
        ){
            return true; // Skip token check for public endpoints
        }

        String authHeader = request.getHeader("Authorization");
        if(authHeader == null || !authHeader.startsWith("Bearer ")){
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            throw new RuntimeException("Token Not Found or Invalid ! ");
        }

        String token = authHeader.substring(7);
        try{
            String role = jwtUtil.getRoleFromToken(token);
            request.setAttribute("role" , role);
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Authorize authorize = handlerMethod.getMethodAnnotation(Authorize.class);
            if(authorize != null ){
                List<String> allowedRoles = Arrays.asList(authorize.value());
                if(!allowedRoles.contains(role)){
                    response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    throw new RuntimeException("Access Denied !! ");
                }
            }
            return true;
        }catch (Exception e){
            throw new RuntimeException("Authorization Failed  !!");
        }
    }

}
